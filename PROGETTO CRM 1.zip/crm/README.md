# CRM — Azienda IT

CRM interno per la gestione di clienti, commesse, assistenza, progetti, scadenze e noleggi.
Stato attuale: **Fase 0 + Fase 1 + modulo Progetti** — fondamenta, autenticazione, permessi, anagrafiche,
commesse, documenti, e la gestione completa dei progetti (bacheca Kanban, to-do per task, ore, avanzamento, template).

Architettura completa: `docs/architettura-crm.md` (copia anche nel progetto Claude "CRM").

---

## Stack

| Livello | Tecnologia |
|---|---|
| Backend | Node.js 22+/24 LTS, NestJS 11, TypeScript |
| Database | PostgreSQL 16+, Drizzle ORM (migrazioni SQL versionate) |
| Validazione | Zod 4 (schemi condivisi tra frontend e backend in `packages/shared`) |
| Frontend | React 19, Vite 7, Tailwind CSS 4, Radix UI, TanStack Query, React Hook Form |
| Produzione | Ubuntu Server 24.04, systemd, Nginx (HTTPS + reverse proxy) — guida in `docs/installazione-ubuntu.md` |

## Struttura

```text
crm/
├── apps/
│   ├── api/                  # Backend NestJS
│   │   ├── drizzle/          # Migrazioni SQL (generate + personalizzate)
│   │   ├── src/
│   │   │   ├── common/       # Guard, decoratori, errori, utilità
│   │   │   ├── config/       # Variabili d'ambiente validate
│   │   │   ├── database/     # Schema, connessione, migrazioni, seed
│   │   │   └── modules/      # auth, utenti, ruoli, audit, clienti, commesse, progetti, allegati
│   │   └── test/             # Test di integrazione su PostgreSQL reale
│   └── web/                  # Frontend React
│       └── src/
│           ├── app/          # Router, layout, protezioni rotte
│           ├── components/   # ui/ (base) e common/ (tabella, pagina)
│           ├── features/     # Una cartella per funzionalità
│           └── lib/          # Client API, autenticazione, utilità
├── packages/shared/          # Schemi Zod, tipi, catalogo permessi
├── deploy/ubuntu/            # Installazione, aggiornamento, backup, systemd, Nginx
├── docs/                     # Architettura e guida di installazione
└── scripts/sviluppo/         # Creazione del database sul PC di sviluppo
```

---

## Avvio in sviluppo

### 1. Prerequisiti

- **Node.js 22 o 24** — https://nodejs.org
- **pnpm 10** — `npm install -g pnpm@10.28.0`
- **PostgreSQL 16 o 17** installato sul PC — https://www.postgresql.org/download/ (su Windows l'installer ufficiale include `psql`)

### 2. Configurazione

```bash
# Crea utente e database di sviluppo e test (comando per Linux/macOS; su Windows: psql -U postgres -f scripts\sviluppo\crea-database.sql)
sudo -u postgres psql -f scripts/sviluppo/crea-database.sql
# Copia il file di esempio
cp .env.example .env
# Genera un segreto JWT e incollalo in JWT_SECRET dentro .env
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

### 3. Primo avvio

```bash
# Installa le dipendenze
pnpm install
# Compila la libreria condivisa
pnpm build:shared
# Crea le tabelle
pnpm db:migrate
# Crea permessi, ruoli predefiniti e il primo Admin (da ADMIN_EMAIL / ADMIN_PASSWORD_INIZIALE)
pnpm db:seed
```

### 4. Avvio quotidiano (due terminali)

```bash
pnpm dev:api     # API su http://localhost:3000
pnpm dev:web     # Interfaccia su http://localhost:5173
```

Apri http://localhost:5173 e accedi con `ADMIN_EMAIL` e `ADMIN_PASSWORD_INIZIALE`: al primo accesso
il CRM chiede di impostare una password personale.

> Se modifichi `packages/shared`, rilancia `pnpm build:shared`.

---

## Test

```bash
pnpm typecheck   # Controllo dei tipi su tutto il progetto
pnpm test        # 13 test unitari + 38 test di integrazione dell'API (database crm_test)
```

I test di integrazione cancellano e ricreano il database `crm_test` (mai quello di sviluppo).
Coprono: login e blocco account, rotazione e furto del refresh token, cambio password obbligatorio,
permessi e ambito "propri", dati economici nascosti, ultimo Admin protetto, validazioni fiscali,
upload con contenuto falsificato, audit log non modificabile, e per i progetti: creazione da template,
riordino dei task nella bacheca, to-do assegnate, registrazione ore e calcolo dell'avanzamento.

## Modulo Progetti

Il modulo serve a seguire i lavori a corpo (installazioni, migrazioni, rinnovi di rete), che hanno
fasi e attività ricorrenti. È separato dall'assistenza: le ore dei progetti **non** scalano dai
pacchetti ore dei contratti.

- **Template** (`/progetti/template`, permesso `template.manage`): definiscono le fasi della bacheca,
  i task predefiniti e le loro voci di to-do. Alla creazione di un progetto la struttura viene
  **copiata**: modificare il template in seguito non tocca i progetti già avviati. Il seed installa
  due template di esempio ("Installazione nuovo server" e "Rinnovo infrastruttura di rete").
- **Bacheca Kanban**: i task si trascinano fra le fasi; la vista si aggiorna subito e in caso di
  errore del server torna com'era. Ogni task ha un **solo responsabile**.
- **To-do**: ogni task ha un elenco di attività, e ogni voce può essere assegnata a un tecnico
  diverso dal responsabile del task.
- **Ore**: si registrano sul singolo task indicando data, durata (`1:30` oppure `1,5`) e descrizione.
- **Riepilogo**: avanzamento in percentuale (task nelle fasi marcate come completate sul totale),
  task in ritardo, ore preventivate contro registrate, distribuzione per fase e ore per tecnico.

Per un tecnico con ambito "propri": vede solo i progetti in cui è coinvolto, sposta solo i task di
cui è responsabile e registra ore solo a proprio nome. Le regole sono in
`apps/api/src/modules/progetti/accesso-progetti.ts` e descritte in `docs/architettura-crm.md` §7.4.

## Modifiche al database

```bash
# 1. Modifica i file in apps/api/src/database/schema
# 2. Genera la migrazione SQL e controllala
pnpm --filter @crm/api db:generate
# 3. Applica
pnpm db:migrate
```

---

## Produzione (server aziendale)

Installazione nativa su **Ubuntu Server 24.04**: guida completa in [`docs/installazione-ubuntu.md`](docs/installazione-ubuntu.md).

```bash
# Una sola volta: pacchetti, PostgreSQL, Node.js, segreti, Nginx, systemd, backup, firewall
sudo DOMINIO=crm.azienda.local ADMIN_EMAIL=admin@azienda.it RETE_LAN=192.168.1.0/24 ./deploy/ubuntu/installa.sh
# Installazione e ogni aggiornamento successivo (con backup e ritorno automatico in caso di errore)
sudo crm-aggiorna /opt/crm/sorgente
```

Comandi di gestione: `crm-aggiorna`, `crm-torna-indietro`, `crm-backup`, `crm-ripristina-backup`.

---

## Sicurezza implementata

- Password con **argon2id**, minimo 12 caratteri, blocco progressivo dopo 5 tentativi falliti
- **Access token JWT** (15 min, solo in memoria) + **refresh token** in cookie `httpOnly`, `Secure`, `SameSite=Strict`, ruotato a ogni uso con rilevamento del riutilizzo
- **RBAC configurabile** con ambito "tutti/propri", verificato sul server a ogni richiesta; rotte senza regola di accesso **bloccate per impostazione predefinita**
- Modifica di permessi o disattivazione utente con **effetto immediato** (versione permessi nel token)
- **Dati economici** rimossi dalle risposte per chi non ha il permesso
- Validazione Zod di ogni input, query parametrizzate (nessuna SQL injection), ricerca con caratteri jolly neutralizzati
- Upload: whitelist estensioni, **verifica del contenuto reale**, nomi casuali, download forzato con CSP sandbox
- **Audit log in sola aggiunta** (trigger PostgreSQL che blocca UPDATE/DELETE/TRUNCATE)
- Header di sicurezza (Helmet, CSP, HSTS), rate limiting, log con dati sensibili oscurati
- In produzione: API e PostgreSQL raggiungibili solo da `127.0.0.1`, servizio systemd isolato (file system in sola lettura tranne gli allegati, nessun privilegio), segreti generati automaticamente in `/etc/crm/crm.env` (permessi 640), firewall limitato alle reti aziendali
