-- =====================================================================================
-- Crea utente e database per lo SVILUPPO sul proprio PC (non usare in produzione)
-- Eseguire come amministratore di PostgreSQL, ad esempio:
--   Linux/macOS:  sudo -u postgres psql -f scripts/sviluppo/crea-database.sql
--   Windows:      psql -U postgres -f scripts\sviluppo\crea-database.sql
-- =====================================================================================

-- Utente applicativo con la password indicata in .env.example (CREATEDB serve ai test)
CREATE ROLE crm LOGIN PASSWORD 'crm_dev_password' CREATEDB;
-- Database di sviluppo
CREATE DATABASE crm OWNER crm;
-- Database dei test automatici (viene svuotato a ogni esecuzione dei test)
CREATE DATABASE crm_test OWNER crm;
