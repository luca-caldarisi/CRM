// Punto di ingresso della libreria condivisa: riesporta tutti i moduli
// (le estensioni .js sono richieste dalla risoluzione dei moduli ESM; TypeScript le mappa ai file .ts)

// Catalogo e tipi dei permessi
export * from './permessi.js';
// Schemi e tipi comuni (paginazione, errori, campi)
export * from './comune.js';
// Validatori fiscali
export * from './validatori.js';
// Autenticazione
export * from './auth.js';
// Utenti e ruoli
export * from './utenti.js';
// Clienti, sedi, contatti
export * from './clienti.js';
// Commesse
export * from './commesse.js';
// Progetti, task, to-do e ore
export * from './progetti.js';
// Allegati e audit log
export * from './allegati-audit.js';
