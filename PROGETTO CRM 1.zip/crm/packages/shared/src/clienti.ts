// =====================================================================================
// Schemi e tipi per clienti, sedi e contatti
// =====================================================================================

// Importa Zod
import { z } from 'zod';
// Importa schemi comuni
import { emailOpzionale, idSchema, paginazioneSchema, telefonoOpzionale, testoOpzionale } from './comune.js';
// Importa i validatori fiscali
import { isCodiceFiscaleValido, isPartitaIvaItalianaValida, normalizzaIdentificativo } from './validatori.js';

// ----------------------------------- Clienti ------------------------------------------

// Partita IVA facoltativa: italiana (11 cifre con controllo) o estera (prefisso paese + 2-13 caratteri)
const partitaIvaSchema = testoOpzionale(20)
  // Normalizza togliendo spazi/punti e mettendo in maiuscolo
  .transform((v) => (v == null ? v : normalizzaIdentificativo(v)))
  // Verifica il formato
  .refine((v) => {
    // Campo vuoto: valido
    if (v == null) return true;
    // Solo cifre: deve essere una P.IVA italiana corretta
    if (/^\d+$/.test(v)) return isPartitaIvaItalianaValida(v);
    // Prefisso "IT": si valida la parte numerica
    if (v.startsWith('IT')) return isPartitaIvaItalianaValida(v.slice(2));
    // Partita IVA estera: due lettere seguite da 2-13 caratteri alfanumerici
    return /^[A-Z]{2}[A-Z0-9]{2,13}$/.test(v);
  }, 'Partita IVA non valida')
  // Salva le P.IVA italiane senza prefisso "IT" per evitare duplicati scritti in modo diverso
  .transform((v) => (v != null && /^IT\d{11}$/.test(v) ? v.slice(2) : v));

// Codice fiscale facoltativo (16 caratteri o 11 cifre)
const codiceFiscaleSchema = testoOpzionale(16)
  // Normalizza
  .transform((v) => (v == null ? v : normalizzaIdentificativo(v)))
  // Verifica il carattere di controllo
  .refine((v) => v == null || isCodiceFiscaleValido(v), 'Codice fiscale non valido');

// Codice destinatario SDI per la fatturazione elettronica: 7 caratteri alfanumerici
const codiceSdiSchema = testoOpzionale(7)
  // Normalizza in maiuscolo
  .transform((v) => (v == null ? v : v.toUpperCase()))
  // Verifica la lunghezza esatta
  .refine((v) => v == null || /^[A-Z0-9]{7}$/.test(v), 'Il codice SDI deve avere 7 caratteri');

// Campi di un cliente (senza refinement, così può essere reso parziale per la modifica)
const campiCliente = z.object({
  // Ragione sociale obbligatoria
  ragioneSociale: z.string().trim().min(2, 'Minimo 2 caratteri').max(200),
  // Partita IVA
  partitaIva: partitaIvaSchema,
  // Codice fiscale
  codiceFiscale: codiceFiscaleSchema,
  // Codice SDI
  codiceSdi: codiceSdiSchema,
  // PEC
  pec: emailOpzionale(),
  // Email generica
  email: emailOpzionale(),
  // Telefono principale
  telefono: telefonoOpzionale(),
  // Sito web
  sitoWeb: testoOpzionale(200),
  // Note commerciali
  note: testoOpzionale(5000),
  // Commerciale di riferimento (determina l'ambito "propri")
  commercialeId: idSchema.nullish(),
});

// Schema di creazione cliente
export const creaClienteSchema = campiCliente;
// Tipo input creazione cliente
export type CreaClienteInput = z.input<typeof creaClienteSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type CreaClienteDati = z.output<typeof creaClienteSchema>;
// Schema di modifica cliente
export const aggiornaClienteSchema = campiCliente.partial();
// Tipo input modifica cliente
export type AggiornaClienteInput = z.input<typeof aggiornaClienteSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type AggiornaClienteDati = z.output<typeof aggiornaClienteSchema>;

// Filtri della lista clienti
export const filtriClientiSchema = paginazioneSchema.extend({
  // Filtra per commerciale di riferimento
  commercialeId: idSchema.optional(),
});

// Cliente nella lista
export interface ClienteLista {
  id: string;
  codice: string;
  ragioneSociale: string;
  partitaIva: string | null;
  email: string | null;
  telefono: string | null;
  citta: string | null;
  commerciale: { id: string; nome: string; cognome: string } | null;
  numeroCommesseAperte: number;
  updatedAt: string;
}

// Cliente completo
export interface Cliente {
  id: string;
  codice: string;
  ragioneSociale: string;
  partitaIva: string | null;
  codiceFiscale: string | null;
  codiceSdi: string | null;
  pec: string | null;
  email: string | null;
  telefono: string | null;
  sitoWeb: string | null;
  note: string | null;
  commerciale: { id: string; nome: string; cognome: string } | null;
  createdAt: string;
  updatedAt: string;
}

// ------------------------------------ Sedi --------------------------------------------

// Tipi di sede con etichette per l'interfaccia
export const TIPI_SEDE = { legale: 'Sede legale', operativa: 'Sede operativa' } as const;
// Tipo unione dei tipi di sede
export type TipoSede = keyof typeof TIPI_SEDE;

// Campi di una sede
const campiSede = z.object({
  // Tipo di sede
  tipo: z.enum(['legale', 'operativa']),
  // Nome descrittivo facoltativo (es. "Magazzino Bologna")
  nome: testoOpzionale(100),
  // Indirizzo (via e numero civico)
  indirizzo: z.string().trim().min(2, 'Indirizzo obbligatorio').max(200),
  // CAP
  cap: testoOpzionale(10),
  // Città
  citta: z.string().trim().min(2, 'Città obbligatoria').max(100),
  // Sigla provincia (2 lettere)
  provincia: testoOpzionale(2)
    .transform((v) => (v == null ? v : v.toUpperCase()))
    .refine((v) => v == null || /^[A-Z]{2}$/.test(v), 'Sigla provincia di 2 lettere'),
  // Codice nazione ISO a 2 lettere
  nazione: z
    .string()
    .trim()
    .toUpperCase()
    .regex(/^[A-Z]{2}$/, 'Codice nazione di 2 lettere')
    .default('IT'),
});

// Schema di creazione sede
export const creaSedeSchema = campiSede;
// Tipo input creazione sede
export type CreaSedeInput = z.input<typeof creaSedeSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type CreaSedeDati = z.output<typeof creaSedeSchema>;
// Schema di modifica sede (tutti i campi facoltativi, nessun default applicato)
export const aggiornaSedeSchema = campiSede.extend({ nazione: z.string().trim().toUpperCase().regex(/^[A-Z]{2}$/) }).partial();
// Tipo input modifica sede
export type AggiornaSedeInput = z.input<typeof aggiornaSedeSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type AggiornaSedeDati = z.output<typeof aggiornaSedeSchema>;

// Sede come restituita dalle API
export interface Sede {
  id: string;
  clienteId: string;
  tipo: TipoSede;
  nome: string | null;
  indirizzo: string;
  cap: string | null;
  citta: string;
  provincia: string | null;
  nazione: string;
}

// ---------------------------------- Contatti ------------------------------------------

// Campi di un contatto
const campiContatto = z.object({
  // Nome obbligatorio
  nome: z.string().trim().min(1, 'Nome obbligatorio').max(80),
  // Cognome facoltativo (es. contatti generici tipo "Ufficio acquisti")
  cognome: testoOpzionale(80),
  // Ruolo in azienda (es. "Responsabile IT")
  ruoloAziendale: testoOpzionale(100),
  // Email
  email: emailOpzionale(),
  // Telefono fisso
  telefono: telefonoOpzionale(),
  // Cellulare
  cellulare: telefonoOpzionale(),
  // Contatto principale del cliente
  principale: z.boolean().default(false),
  // Sede di riferimento facoltativa
  sedeId: idSchema.nullish(),
  // Note
  note: testoOpzionale(2000),
});

// Schema di creazione contatto
export const creaContattoSchema = campiContatto;
// Tipo input creazione contatto
export type CreaContattoInput = z.input<typeof creaContattoSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type CreaContattoDati = z.output<typeof creaContattoSchema>;
// Schema di modifica contatto
export const aggiornaContattoSchema = campiContatto.extend({ principale: z.boolean() }).partial();
// Tipo input modifica contatto
export type AggiornaContattoInput = z.input<typeof aggiornaContattoSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type AggiornaContattoDati = z.output<typeof aggiornaContattoSchema>;

// Contatto come restituito dalle API
export interface Contatto {
  id: string;
  clienteId: string;
  nome: string;
  cognome: string | null;
  ruoloAziendale: string | null;
  email: string | null;
  telefono: string | null;
  cellulare: string | null;
  principale: boolean;
  sedeId: string | null;
  note: string | null;
}
