// =====================================================================================
// Catalogo dei permessi dell'applicazione
// -------------------------------------------------------------------------------------
// È l'unica fonte di verità: il seed lo copia nel database, il backend lo usa nei guard
// e il frontend lo usa per mostrare/nascondere pulsanti e voci di menu.
// Per aggiungere un permesso: aggiungerlo qui, ricompilare e rieseguire il seed.
// =====================================================================================

// Ambiti possibili di un permesso:
// - "tutti"  = l'utente agisce su tutti i record
// - "propri" = l'utente agisce solo sui record di cui è responsabile/assegnatario
export const AMBITI = ['tutti', 'propri'] as const;

// Tipo TypeScript derivato dall'array: 'tutti' | 'propri'
export type Ambito = (typeof AMBITI)[number];

// Struttura della definizione di un singolo permesso
export interface DefinizionePermesso {
  // Codice univoco nel formato modulo.azione
  codice: string;
  // Modulo di appartenenza, usato per raggruppare le righe nella matrice
  modulo: string;
  // Descrizione leggibile mostrata all'Admin
  descrizione: string;
  // true se per questo permesso ha senso l'ambito "propri"
  supportaPropri: boolean;
}

// Elenco completo dei permessi disponibili nella Fase 1
export const CATALOGO_PERMESSI = [
  // --- Clienti (anagrafica, sedi, contatti) ---
  { codice: 'clienti.read', modulo: 'Clienti', descrizione: 'Visualizzare clienti, sedi e contatti', supportaPropri: true },
  { codice: 'clienti.write', modulo: 'Clienti', descrizione: 'Creare e modificare clienti, sedi e contatti', supportaPropri: true },
  { codice: 'clienti.delete', modulo: 'Clienti', descrizione: 'Eliminare clienti', supportaPropri: true },
  // --- Commesse ---
  { codice: 'commesse.read', modulo: 'Commesse', descrizione: 'Visualizzare le commesse', supportaPropri: true },
  { codice: 'commesse.write', modulo: 'Commesse', descrizione: 'Creare e modificare commesse', supportaPropri: true },
  { codice: 'commesse.delete', modulo: 'Commesse', descrizione: 'Eliminare commesse', supportaPropri: true },
  // --- Progetti (bacheca task, to-do, ore) ---
  { codice: 'progetti.read', modulo: 'Progetti', descrizione: 'Visualizzare i progetti e le bacheche', supportaPropri: true },
  { codice: 'progetti.write', modulo: 'Progetti', descrizione: 'Creare e modificare i progetti', supportaPropri: true },
  { codice: 'progetti.delete', modulo: 'Progetti', descrizione: 'Eliminare i progetti', supportaPropri: true },
  { codice: 'task.write', modulo: 'Progetti', descrizione: 'Creare, spostare e modificare task e to-do', supportaPropri: true },
  { codice: 'ore.write', modulo: 'Progetti', descrizione: 'Registrare le ore sui task (ambito "tutti" = anche per altri tecnici)', supportaPropri: true },
  { codice: 'template.manage', modulo: 'Progetti', descrizione: 'Gestire i template di progetto', supportaPropri: false },
  // --- Dati economici (trasversale a tutti i moduli) ---
  { codice: 'economici.read', modulo: 'Dati economici', descrizione: 'Vedere e modificare valori, prezzi e canoni', supportaPropri: false },
  // --- Amministrazione ---
  { codice: 'utenti.manage', modulo: 'Amministrazione', descrizione: 'Gestire gli utenti', supportaPropri: false },
  { codice: 'ruoli.manage', modulo: 'Amministrazione', descrizione: 'Gestire ruoli e permessi', supportaPropri: false },
  { codice: 'audit.read', modulo: 'Amministrazione', descrizione: 'Consultare il registro attività', supportaPropri: false },
] as const satisfies readonly DefinizionePermesso[];

// Tipo unione di tutti i codici validi (es. 'clienti.read' | 'clienti.write' | ...)
export type CodicePermesso = (typeof CATALOGO_PERMESSI)[number]['codice'];

// Array dei soli codici, comodo per le validazioni
export const CODICI_PERMESSI = CATALOGO_PERMESSI.map((p) => p.codice) as CodicePermesso[];

// Mappa dei permessi effettivi di un utente: codice -> ambito concesso
// Un codice assente significa "permesso non concesso"
export type MappaPermessi = Partial<Record<CodicePermesso, Ambito>>;

// Nome del ruolo amministratore di sistema (ha sempre tutti i permessi e non è modificabile)
export const NOME_RUOLO_ADMIN = 'Admin';

// Ruoli predefiniti creati dal seed al primo avvio (poi l'Admin può modificarli liberamente)
export const RUOLI_PREDEFINITI: ReadonlyArray<{ nome: string; descrizione: string; permessi: MappaPermessi }> = [
  {
    // Commerciale: gestisce anagrafiche e commesse con visibilità completa e dati economici
    nome: 'Commerciale',
    descrizione: 'Gestione clienti e commesse, accesso ai dati economici',
    permessi: {
      'clienti.read': 'tutti',
      'clienti.write': 'tutti',
      'commesse.read': 'tutti',
      'commesse.write': 'tutti',
      'progetti.read': 'tutti',
      'economici.read': 'tutti',
    },
  },
  {
    // Tecnico: consulta anagrafiche e commesse, senza dati economici
    nome: 'Tecnico',
    descrizione: 'Consultazione anagrafiche; operatività su progetti e task assegnati',
    permessi: {
      'clienti.read': 'tutti',
      'commesse.read': 'tutti',
      // Vede i progetti di cui è responsabile o in cui ha task assegnati
      'progetti.read': 'propri',
      // Sposta e aggiorna solo i task che lo riguardano
      'task.write': 'propri',
      // Registra soltanto le proprie ore
      'ore.write': 'propri',
    },
  },
  {
    // Sola lettura: vede tutto tranne dati economici e amministrazione
    nome: 'Sola lettura',
    descrizione: 'Consultazione senza possibilità di modifica',
    permessi: {
      'clienti.read': 'tutti',
      'commesse.read': 'tutti',
      'progetti.read': 'tutti',
    },
  },
];

// Funzione di utilità: restituisce l'ambito concesso per un permesso, oppure null se non concesso
export function ambitoPermesso(permessi: MappaPermessi, codice: CodicePermesso): Ambito | null {
  // L'operatore ?? trasforma undefined (permesso assente) in null
  return permessi[codice] ?? null;
}
