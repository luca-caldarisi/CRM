// Test unitari dei validatori fiscali e degli schemi più delicati

// Importa le funzioni di test di Vitest
import { describe, expect, it } from 'vitest';
// Importa i validatori da testare
import { isCodiceFiscaleValido, isPartitaIvaItalianaValida } from './validatori.js';
// Importa gli schemi da testare
import { creaClienteSchema } from './clienti.js';
import { creaCommessaSchema } from './commesse.js';
import { impostaPermessiSchema } from './utenti.js';

// Gruppo di test sulla Partita IVA
describe('isPartitaIvaItalianaValida', () => {
  // P.IVA reali pubbliche con carattere di controllo corretto
  it('accetta partite IVA valide', () => {
    // P.IVA di esempio corretta
    expect(isPartitaIvaItalianaValida('01234567897')).toBe(true);
    // P.IVA di una grande azienda italiana (dato pubblico)
    expect(isPartitaIvaItalianaValida('00488410010')).toBe(true);
  });
  // Carattere di controllo errato o formato sbagliato
  it('rifiuta partite IVA non valide', () => {
    // Ultima cifra sbagliata
    expect(isPartitaIvaItalianaValida('01234567890')).toBe(false);
    // Troppo corta
    expect(isPartitaIvaItalianaValida('0123456789')).toBe(false);
    // Contiene lettere
    expect(isPartitaIvaItalianaValida('0123456789A')).toBe(false);
  });
});

// Gruppo di test sul Codice Fiscale
describe('isCodiceFiscaleValido', () => {
  // Codice fiscale di esempio con carattere di controllo corretto
  it('accetta un codice fiscale di persona valido', () => {
    expect(isCodiceFiscaleValido('RSSMRA85T10A562S')).toBe(true);
  });
  // Stesso codice con controllo errato
  it('rifiuta un carattere di controllo errato', () => {
    expect(isCodiceFiscaleValido('RSSMRA85T10A562T')).toBe(false);
  });
  // CF numerico di persona giuridica
  it('accetta il codice fiscale numerico di un\'azienda', () => {
    expect(isCodiceFiscaleValido('00488410010')).toBe(true);
  });
});

// Gruppo di test sullo schema cliente
describe('creaClienteSchema', () => {
  // La P.IVA con prefisso IT e spazi viene normalizzata
  it('normalizza la partita IVA italiana', () => {
    // Esegue la validazione
    const r = creaClienteSchema.parse({ ragioneSociale: 'Acme Srl', partitaIva: 'IT 01234567897' });
    // Deve restare solo la parte numerica
    expect(r.partitaIva).toBe('01234567897');
  });
  // I campi vuoti diventano null
  it('trasforma le stringhe vuote in null', () => {
    // Esegue la validazione con campi vuoti
    const r = creaClienteSchema.parse({ ragioneSociale: 'Acme Srl', email: '', note: '' });
    // Devono essere null
    expect(r.email).toBeNull();
    expect(r.note).toBeNull();
  });
  // P.IVA estera accettata
  it('accetta una partita IVA estera', () => {
    expect(creaClienteSchema.safeParse({ ragioneSociale: 'GmbH', partitaIva: 'DE123456789' }).success).toBe(true);
  });
});

// Gruppo di test sullo schema commessa
describe('creaCommessaSchema', () => {
  // Dati di base validi
  const base = { clienteId: '0191f3a0-0000-7000-8000-000000000000', titolo: 'Assistenza 2026', tipo: 'assistenza', dataApertura: '2026-01-10' };
  // Chiusura precedente all'apertura
  it('rifiuta una data di chiusura precedente all\'apertura', () => {
    expect(creaCommessaSchema.safeParse({ ...base, dataChiusura: '2026-01-01' }).success).toBe(false);
  });
  // Importo con 3 decimali
  it('rifiuta importi con più di due decimali', () => {
    expect(creaCommessaSchema.safeParse({ ...base, valore: 10.555 }).success).toBe(false);
  });
  // Importo corretto
  it('accetta un importo con due decimali', () => {
    expect(creaCommessaSchema.safeParse({ ...base, valore: 1500.1 }).success).toBe(true);
  });
});

// Gruppo di test sulla matrice permessi
describe('impostaPermessiSchema', () => {
  // Ambito "propri" su un permesso che non lo supporta
  it('rifiuta l\'ambito "propri" dove non ha senso', () => {
    expect(impostaPermessiSchema.safeParse({ permessi: [{ codice: 'utenti.manage', ambito: 'propri' }] }).success).toBe(false);
  });
  // Codice ripetuto
  it('rifiuta permessi ripetuti', () => {
    const p = { codice: 'clienti.read', ambito: 'tutti' };
    expect(impostaPermessiSchema.safeParse({ permessi: [p, p] }).success).toBe(false);
  });
});
