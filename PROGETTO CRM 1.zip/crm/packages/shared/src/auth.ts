// =====================================================================================
// Schemi e tipi per autenticazione e gestione password
// =====================================================================================

// Importa Zod
import { z } from 'zod';
// Importa il tipo della mappa permessi
import type { MappaPermessi } from './permessi.js';

// Lunghezza minima della password (linee guida NIST: meglio lunga che complessa)
export const PASSWORD_MIN = 12;
// Lunghezza massima: evita attacchi DoS con password enormi da sottoporre ad hashing
export const PASSWORD_MAX = 128;

// Password troppo comuni rifiutate anche se abbastanza lunghe
const PASSWORD_COMUNI = new Set([
  'password1234', 'password12345', 'password123456', '123456789012', '1234567890123',
  'qwertyuiop12', 'qwertyuiopas', 'passwordpassword', 'amministratore', 'administrator',
  'admin1234567', 'benvenuto123', 'benvenuto2026', 'cambiami1234', 'passw0rd1234',
]);

// Schema di una nuova password (usato per creazione utente e cambio password)
export const passwordSchema = z
  // Deve essere una stringa
  .string()
  // Lunghezza minima
  .min(PASSWORD_MIN, `La password deve avere almeno ${PASSWORD_MIN} caratteri`)
  // Lunghezza massima
  .max(PASSWORD_MAX, `La password può avere al massimo ${PASSWORD_MAX} caratteri`)
  // Non deve essere nell'elenco delle password comuni (confronto senza maiuscole)
  .refine((v) => !PASSWORD_COMUNI.has(v.toLowerCase()), 'Password troppo comune, scegline una diversa');

// Schema della richiesta di login
export const loginSchema = z.object({
  // Email normalizzata in minuscolo
  email: z.string().trim().toLowerCase().pipe(z.email('Email non valida')),
  // Al login non si applicano le regole della password: si verifica solo che non sia vuota
  password: z.string().min(1, 'Inserisci la password').max(PASSWORD_MAX),
});
// Tipo dei dati di login
export type LoginInput = z.input<typeof loginSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type LoginDati = z.output<typeof loginSchema>;

// Schema del cambio password
export const cambiaPasswordSchema = z
  .object({
    // Password attuale, necessaria per confermare l'identità
    passwordAttuale: z.string().min(1, 'Inserisci la password attuale').max(PASSWORD_MAX),
    // Nuova password conforme alle regole
    nuovaPassword: passwordSchema,
  })
  // La nuova password deve essere diversa dalla precedente
  .refine((v) => v.passwordAttuale !== v.nuovaPassword, {
    // Messaggio mostrato all'utente
    message: 'La nuova password deve essere diversa da quella attuale',
    // Campo a cui associare l'errore nel form
    path: ['nuovaPassword'],
  });
// Tipo dei dati del cambio password
export type CambiaPasswordInput = z.input<typeof cambiaPasswordSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type CambiaPasswordDati = z.output<typeof cambiaPasswordSchema>;

// Risposta di login e refresh
export interface RispostaToken {
  // Access token JWT da inviare nell'header Authorization
  accessToken: string;
  // Durata del token in secondi
  scadeTraSecondi: number;
}

// Dati dell'utente autenticato restituiti da GET /auth/me
export interface UtenteSessione {
  // Identificativo utente
  id: string;
  // Email di accesso
  email: string;
  // Nome
  nome: string;
  // Cognome
  cognome: string;
  // Ruolo assegnato
  ruolo: { id: string; nome: string; diSistema: boolean };
  // Permessi effettivi con relativo ambito
  permessi: MappaPermessi;
  // true se l'utente deve cambiare password prima di poter usare l'applicazione
  deveCambiarePassword: boolean;
}

// Codici di errore specifici dell'autenticazione, usati dal frontend per reagire
export const CODICI_ERRORE_AUTH = {
  // Access token scaduto o non valido: il client deve fare refresh
  tokenNonValido: 'token_non_valido',
  // Permessi cambiati dopo l'emissione del token: il client deve fare refresh
  tokenObsoleto: 'token_obsoleto',
  // L'utente deve cambiare la password prima di continuare
  cambioPasswordRichiesto: 'cambio_password_richiesto',
  // Un'altra scheda del browser ha appena rinnovato la sessione: riprovare
  refreshInCorso: 'refresh_in_corso',
} as const;
