// =====================================================================================
// Schemi e tipi per progetti, bacheca dei task, to-do e registrazioni ore
// =====================================================================================

// Importa Zod
import { z } from 'zod';
// Importa schemi comuni
import { dataIsoSchema, idSchema, paginazioneSchema, testoOpzionale } from './comune.js';

// ------------------------------- Stati ed etichette -----------------------------------

// Stati di un progetto con etichette per l'interfaccia
export const STATI_PROGETTO = {
  pianificato: 'Pianificato',
  in_corso: 'In corso',
  sospeso: 'Sospeso',
  concluso: 'Concluso',
  annullato: 'Annullato',
} as const;
// Tipo unione degli stati
export type StatoProgetto = keyof typeof STATI_PROGETTO;

// Priorità di un task
export const PRIORITA_TASK = {
  bassa: 'Bassa',
  media: 'Media',
  alta: 'Alta',
  urgente: 'Urgente',
} as const;
// Tipo unione delle priorità
export type PrioritaTask = keyof typeof PRIORITA_TASK;

// ------------------------------------ Durate ------------------------------------------

// Converte il testo di una durata in minuti: accetta "1:30", "1,5", "1.5" e "90m"
// Restituisce null se il formato non è riconosciuto
export function minutiDaTesto(testo: string): number | null {
  // Toglie gli spazi e usa il punto come separatore decimale
  const pulito = testo.trim().replace(',', '.').toLowerCase();
  // Campo vuoto
  if (pulito === '') return null;
  // Formato "1:30" (ore:minuti)
  const orologio = /^(\d{1,3}):([0-5]\d)$/.exec(pulito);
  if (orologio) return Number(orologio[1]) * 60 + Number(orologio[2]);
  // Formato "90m" (minuti)
  const minuti = /^(\d{1,5})m$/.exec(pulito);
  if (minuti) return Number(minuti[1]);
  // Formato "1.5" oppure "1.5h" (ore decimali)
  const ore = /^(\d{1,3}(?:\.\d{1,2})?)h?$/.exec(pulito);
  if (ore) return Math.round(Number(ore[1]) * 60);
  // Formato non riconosciuto
  return null;
}

// Converte i minuti in testo leggibile: 90 -> "1h 30m", 120 -> "2h", 45 -> "45m"
export function testoDaMinuti(minuti: number): string {
  // Ore intere
  const h = Math.floor(minuti / 60);
  // Minuti rimanenti
  const m = minuti % 60;
  // Meno di un'ora
  if (h === 0) return `${m}m`;
  // Ore esatte
  if (m === 0) return `${h}h`;
  // Ore e minuti
  return `${h}h ${m}m`;
}

// Campo durata di un form: testo libero convertito in minuti (1 minuto - 24 ore)
const durataSchema = z
  // Testo digitato dall'utente
  .string()
  .trim()
  // Conversione in minuti
  .transform((v, ctx) => {
    // Interpreta il formato
    const minuti = minutiDaTesto(v);
    // Formato non valido
    if (minuti === null) {
      ctx.addIssue({ code: 'custom', message: 'Durata non valida: usare 1:30 oppure 1,5' });
      return z.NEVER;
    }
    // Durata fuori dai limiti ragionevoli
    if (minuti < 1 || minuti > 24 * 60) {
      ctx.addIssue({ code: 'custom', message: 'La durata deve essere compresa tra 1 minuto e 24 ore' });
      return z.NEVER;
    }
    // Minuti validi
    return minuti;
  });

// Ore stimate di un task: numero con al massimo due decimali
const oreStimateSchema = z
  .number('Valore non valido')
  .min(0, 'Le ore non possono essere negative')
  .max(9999, 'Valore troppo elevato')
  .refine((v) => Math.abs(Math.round(v * 100) - v * 100) < 1e-6, 'Massimo 2 decimali')
  .nullish();

// ----------------------------------- Progetti -----------------------------------------

// Campi di un progetto
const campiProgetto = z.object({
  // Cliente per cui si svolge il progetto
  clienteId: idSchema,
  // Commessa collegata (facoltativa)
  commessaId: idSchema.nullish(),
  // Nome del progetto
  nome: z.string().trim().min(2, 'Minimo 2 caratteri').max(200),
  // Descrizione
  descrizione: testoOpzionale(5000),
  // Stato
  stato: z.enum(['pianificato', 'in_corso', 'sospeso', 'concluso', 'annullato']).default('pianificato'),
  // Tecnico responsabile
  responsabileId: idSchema.nullish(),
  // Date previste ed effettiva
  dataInizio: dataIsoSchema.nullish(),
  dataFinePrevista: dataIsoSchema.nullish(),
  dataFineEffettiva: dataIsoSchema.nullish(),
  // Note interne
  note: testoOpzionale(5000),
});

// Creazione progetto: può partire da un template, che definisce colonne e task iniziali
export const creaProgettoSchema = campiProgetto
  .extend({
    // Template da cui copiare colonne, task e to-do (facoltativo)
    templateId: idSchema.nullish(),
  })
  // Le date devono essere coerenti
  .refine((v) => !v.dataInizio || !v.dataFinePrevista || v.dataFinePrevista >= v.dataInizio, {
    message: 'La fine prevista non può precedere l\'inizio',
    path: ['dataFinePrevista'],
  });
// Tipi dei dati di creazione
export type CreaProgettoInput = z.input<typeof creaProgettoSchema>;
export type CreaProgettoDati = z.output<typeof creaProgettoSchema>;

// Modifica progetto: cliente e template non si cambiano
export const aggiornaProgettoSchema = campiProgetto
  .omit({ clienteId: true })
  .extend({ stato: z.enum(['pianificato', 'in_corso', 'sospeso', 'concluso', 'annullato']) })
  .partial();
// Tipi dei dati di modifica
export type AggiornaProgettoInput = z.input<typeof aggiornaProgettoSchema>;
export type AggiornaProgettoDati = z.output<typeof aggiornaProgettoSchema>;

// Filtri dell'elenco progetti
export const filtriProgettiSchema = paginazioneSchema.extend({
  clienteId: idSchema.optional(),
  commessaId: idSchema.optional(),
  responsabileId: idSchema.optional(),
  stato: z.enum(['pianificato', 'in_corso', 'sospeso', 'concluso', 'annullato']).optional(),
});

// ------------------------------------- Task -------------------------------------------

// Campi di un task
const campiTask = z.object({
  // Colonna della bacheca in cui si trova
  colonnaId: idSchema,
  // Titolo
  titolo: z.string().trim().min(2, 'Minimo 2 caratteri').max(200),
  // Descrizione
  descrizione: testoOpzionale(5000),
  // Priorità
  priorita: z.enum(['bassa', 'media', 'alta', 'urgente']).default('media'),
  // Tecnico responsabile del task
  responsabileId: idSchema.nullish(),
  // Scadenza
  dataScadenza: dataIsoSchema.nullish(),
  // Ore preventivate
  oreStimate: oreStimateSchema,
});

// Creazione task
export const creaTaskSchema = campiTask;
export type CreaTaskInput = z.input<typeof creaTaskSchema>;
export type CreaTaskDati = z.output<typeof creaTaskSchema>;

// Modifica task (la colonna si cambia con lo spostamento)
export const aggiornaTaskSchema = campiTask
  .omit({ colonnaId: true })
  .extend({ priorita: z.enum(['bassa', 'media', 'alta', 'urgente']) })
  .partial();
export type AggiornaTaskInput = z.input<typeof aggiornaTaskSchema>;
export type AggiornaTaskDati = z.output<typeof aggiornaTaskSchema>;

// Spostamento di un task nella bacheca (trascinamento)
export const spostaTaskSchema = z.object({
  // Colonna di destinazione
  colonnaId: idSchema,
  // Posizione nella colonna (0 = in cima)
  posizione: z.coerce.number().int().min(0).max(999),
});
export type SpostaTaskInput = z.input<typeof spostaTaskSchema>;

// ------------------------------------ To-do -------------------------------------------

// Creazione di una voce della to-do
export const creaTodoSchema = z.object({
  // Testo della voce
  titolo: z.string().trim().min(1, 'Testo obbligatorio').max(200),
  // Tecnico incaricato (facoltativo: può essere diverso dal responsabile del task)
  assegnatarioId: idSchema.nullish(),
});
export type CreaTodoInput = z.input<typeof creaTodoSchema>;
export type CreaTodoDati = z.output<typeof creaTodoSchema>;

// Modifica di una voce della to-do
export const aggiornaTodoSchema = creaTodoSchema.extend({ completata: z.boolean() }).partial();
export type AggiornaTodoInput = z.input<typeof aggiornaTodoSchema>;
export type AggiornaTodoDati = z.output<typeof aggiornaTodoSchema>;

// ------------------------------- Registrazioni ore ------------------------------------

// Registrazione delle ore lavorate su un task
export const registraOreSchema = z.object({
  // Giorno di lavoro
  data: dataIsoSchema,
  // Durata ("1:30" oppure "1,5")
  durata: durataSchema,
  // Descrizione dell'attività svolta
  descrizione: testoOpzionale(500),
  // Tecnico a cui attribuire le ore (solo con il permesso di registrare per altri)
  utenteId: idSchema.nullish(),
});
export type RegistraOreInput = z.input<typeof registraOreSchema>;
export type RegistraOreDati = z.output<typeof registraOreSchema>;

// Filtri dell'elenco ore di un progetto
export const filtriOreSchema = z.object({
  utenteId: idSchema.optional(),
  dal: dataIsoSchema.optional(),
  al: dataIsoSchema.optional(),
});

// -------------------------------- Template progetti -----------------------------------

// Dati generali di un template
export const creaTemplateSchema = z.object({
  // Nome (es. "Configurazione nuovo server")
  nome: z.string().trim().min(2, 'Minimo 2 caratteri').max(120),
  // Categoria per raggruppare i template
  categoria: testoOpzionale(60),
  // Descrizione
  descrizione: testoOpzionale(1000),
  // Durata indicativa in giorni
  durataStimataGg: z.number().int().min(0).max(999).nullish(),
  // Template disponibile nella creazione dei progetti
  attivo: z.boolean().default(true),
});
export type CreaTemplateInput = z.input<typeof creaTemplateSchema>;
export type CreaTemplateDati = z.output<typeof creaTemplateSchema>;

// Modifica dei dati generali
export const aggiornaTemplateSchema = creaTemplateSchema.extend({ attivo: z.boolean() }).partial();
export type AggiornaTemplateInput = z.input<typeof aggiornaTemplateSchema>;
export type AggiornaTemplateDati = z.output<typeof aggiornaTemplateSchema>;

// Struttura del template: colonne della bacheca e task predefiniti
export const strutturaTemplateSchema = z.object({
  // Colonne, nell'ordine in cui compaiono nella bacheca
  colonne: z
    .array(
      z.object({
        // Nome della colonna (es. "In lavorazione")
        nome: z.string().trim().min(1, 'Nome obbligatorio').max(40),
        // I task in questa colonna contano come completati nell'avanzamento
        consideraCompletato: z.boolean().default(false),
      }),
    )
    .min(2, 'Servono almeno due colonne')
    .max(8, 'Massimo 8 colonne')
    // Almeno una colonna deve rappresentare il lavoro finito
    .refine((c) => c.some((x) => x.consideraCompletato), 'Indicare almeno una colonna di completamento'),
  // Task predefiniti creati insieme al progetto
  task: z
    .array(
      z.object({
        // Titolo del task
        titolo: z.string().trim().min(2).max(200),
        // Descrizione
        descrizione: testoOpzionale(2000),
        // Indice della colonna iniziale (0 = prima colonna)
        colonnaIndice: z.number().int().min(0).max(7).default(0),
        // Ore preventivate
        oreStimate: oreStimateSchema,
        // Voci della to-do del task
        todo: z.array(z.string().trim().min(1).max(200)).max(30).default([]),
      }),
    )
    .max(60, 'Massimo 60 task per template'),
});
export type StrutturaTemplateInput = z.input<typeof strutturaTemplateSchema>;
export type StrutturaTemplateDati = z.output<typeof strutturaTemplateSchema>;

// --------------------------------- Tipi di risposta -----------------------------------

// Riferimento sintetico a un utente
export interface RiferimentoUtente {
  id: string;
  nome: string;
  cognome: string;
}

// Colonna della bacheca di un progetto
export interface ColonnaProgetto {
  id: string;
  nome: string;
  ordine: number;
  consideraCompletato: boolean;
}

// Task come compare nella bacheca
export interface TaskBacheca {
  id: string;
  colonnaId: string;
  titolo: string;
  priorita: PrioritaTask;
  dataScadenza: string | null;
  oreStimate: string | null;
  minutiRegistrati: number;
  responsabile: RiferimentoUtente | null;
  todoTotali: number;
  todoCompletate: number;
  ordine: number;
}

// Voce della to-do
export interface VoceTodo {
  id: string;
  taskId: string;
  titolo: string;
  completata: boolean;
  completataIl: string | null;
  assegnatario: RiferimentoUtente | null;
  ordine: number;
}

// Registrazione ore
export interface RegistrazioneOre {
  id: string;
  taskId: string;
  data: string;
  minuti: number;
  descrizione: string | null;
  utente: RiferimentoUtente;
  createdAt: string;
}

// Task completo (finestra di dettaglio)
export interface TaskDettaglio extends TaskBacheca {
  progettoId: string;
  descrizione: string | null;
  completatoIl: string | null;
  todo: VoceTodo[];
  ore: RegistrazioneOre[];
  createdAt: string;
  updatedAt: string;
}

// Progetto nell'elenco
export interface ProgettoLista {
  id: string;
  codice: string;
  nome: string;
  stato: StatoProgetto;
  cliente: { id: string; ragioneSociale: string };
  responsabile: RiferimentoUtente | null;
  dataInizio: string | null;
  dataFinePrevista: string | null;
  taskTotali: number;
  taskCompletati: number;
  avanzamento: number;
}

// Progetto completo
export interface Progetto {
  id: string;
  codice: string;
  nome: string;
  descrizione: string | null;
  stato: StatoProgetto;
  cliente: { id: string; ragioneSociale: string };
  commessa: { id: string; codice: string; titolo: string } | null;
  template: { id: string; nome: string } | null;
  responsabile: RiferimentoUtente | null;
  dataInizio: string | null;
  dataFinePrevista: string | null;
  dataFineEffettiva: string | null;
  note: string | null;
  colonne: ColonnaProgetto[];
  createdAt: string;
  updatedAt: string;
}

// Bacheca completa: colonne con i relativi task
export interface Bacheca {
  colonne: Array<ColonnaProgetto & { task: TaskBacheca[] }>;
}

// Riepilogo dell'avanzamento
export interface RiepilogoProgetto {
  // Avanzamento in percentuale sui task completati
  avanzamento: number;
  taskTotali: number;
  taskCompletati: number;
  // Task ancora aperti con scadenza superata
  taskInRitardo: number;
  // Ore preventivate e registrate (in minuti)
  minutiStimati: number;
  minutiRegistrati: number;
  // Numero di task per colonna
  perColonna: Array<{ colonnaId: string; nome: string; consideraCompletato: boolean; task: number }>;
  // Ore registrate per tecnico
  perTecnico: Array<{ utente: RiferimentoUtente; minuti: number; task: number }>;
  // Voci della to-do completate sul totale
  todoTotali: number;
  todoCompletate: number;
  // Ultime registrazioni ore
  ultimeOre: RegistrazioneOre[];
}

// Template nell'elenco
export interface TemplateProgetto {
  id: string;
  nome: string;
  categoria: string | null;
  descrizione: string | null;
  durataStimataGg: number | null;
  attivo: boolean;
  numeroColonne: number;
  numeroTask: number;
}

// Template con la struttura completa
export interface TemplateProgettoDettaglio extends TemplateProgetto {
  colonne: Array<{ id: string; nome: string; ordine: number; consideraCompletato: boolean }>;
  task: Array<{
    id: string;
    titolo: string;
    descrizione: string | null;
    colonnaIndice: number;
    oreStimate: string | null;
    ordine: number;
    todo: string[];
  }>;
}
