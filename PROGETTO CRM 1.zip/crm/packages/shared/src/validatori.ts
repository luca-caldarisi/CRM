// =====================================================================================
// Validatori per dati fiscali italiani
// -------------------------------------------------------------------------------------
// Funzioni pure (senza dipendenze) usate dagli schemi Zod sia nel frontend sia nel backend,
// così l'utente vede l'errore subito nel form e il server rifiuta comunque dati non validi.
// =====================================================================================

// Verifica il carattere di controllo di una sequenza di 11 cifre (Partita IVA o CF di un'azienda)
export function isPartitaIvaItalianaValida(valore: string): boolean {
  // Deve essere composta esattamente da 11 cifre
  if (!/^\d{11}$/.test(valore)) return false;
  // Accumulatore della somma di controllo
  let somma = 0;
  // Scorre le prime 10 cifre (l'undicesima è il carattere di controllo)
  for (let i = 0; i < 10; i++) {
    // Converte il carattere nella cifra numerica corrispondente
    let cifra = Number(valore[i]);
    // Le posizioni dispari (indice 1, 3, 5, ...) vanno raddoppiate
    if (i % 2 === 1) {
      // Raddoppia la cifra
      cifra *= 2;
      // Se il risultato ha due cifre si sottrae 9 (equivale a sommarne le cifre)
      if (cifra > 9) cifra -= 9;
    }
    // Aggiunge la cifra (eventualmente trasformata) alla somma
    somma += cifra;
  }
  // Il carattere di controllo atteso è il complemento a 10 dell'ultima cifra della somma
  const controllo = (10 - (somma % 10)) % 10;
  // Confronta con l'undicesima cifra effettiva
  return controllo === Number(valore[10]);
}

// Valori dei caratteri in posizione dispari (1ª, 3ª, 5ª...) secondo l'algoritmo del Codice Fiscale
const VALORI_DISPARI: Record<string, number> = {
  '0': 1, '1': 0, '2': 5, '3': 7, '4': 9, '5': 13, '6': 15, '7': 17, '8': 19, '9': 21,
  A: 1, B: 0, C: 5, D: 7, E: 9, F: 13, G: 15, H: 17, I: 19, J: 21, K: 2, L: 4, M: 18,
  N: 20, O: 11, P: 3, Q: 6, R: 8, S: 12, T: 14, U: 16, V: 10, W: 22, X: 25, Y: 24, Z: 23,
};

// Espressione regolare della struttura di un Codice Fiscale di persona fisica (incluse omocodie)
const REGEX_CF_PERSONA = /^[A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]$/;

// Verifica un Codice Fiscale: 16 caratteri (persona fisica) oppure 11 cifre (persona giuridica)
export function isCodiceFiscaleValido(valore: string): boolean {
  // Le persone giuridiche hanno un CF numerico con lo stesso controllo della Partita IVA
  if (/^\d{11}$/.test(valore)) return isPartitaIvaItalianaValida(valore);
  // Per le persone fisiche verifica prima la struttura
  if (!REGEX_CF_PERSONA.test(valore)) return false;
  // Accumulatore della somma di controllo
  let somma = 0;
  // Scorre i primi 15 caratteri
  for (let i = 0; i < 15; i++) {
    // Carattere corrente (sicuramente presente grazie alla regex)
    const carattere = valore[i]!;
    // Indice pari (0, 2, 4...) = posizione dispari nella numerazione umana (1ª, 3ª...)
    if (i % 2 === 0) {
      // Usa la tabella dei valori dispari
      somma += VALORI_DISPARI[carattere]!;
    } else {
      // Posizioni pari: le cifre valgono se stesse, le lettere A=0 ... Z=25
      somma += /\d/.test(carattere) ? Number(carattere) : carattere.charCodeAt(0) - 65;
    }
  }
  // Il carattere di controllo è la lettera corrispondente al resto della divisione per 26
  const atteso = String.fromCharCode(65 + (somma % 26));
  // Confronta con il sedicesimo carattere
  return atteso === valore[15];
}

// Normalizza un identificativo fiscale: maiuscolo e senza spazi o punti
export function normalizzaIdentificativo(valore: string): string {
  // Rimuove spazi e punti, poi converte in maiuscolo
  return valore.replace(/[\s.]/g, '').toUpperCase();
}
