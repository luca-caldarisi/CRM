// =====================================================================================
// Schemi e tipi per le commesse
// =====================================================================================

// Importa Zod
import { z } from 'zod';
// Importa schemi comuni
import { dataIsoSchema, idSchema, paginazioneSchema, testoOpzionale } from './comune.js';

// Tipi di commessa con etichette per l'interfaccia
export const TIPI_COMMESSA = {
  assistenza: 'Assistenza',
  progetto: 'Progetto',
  fornitura: 'Fornitura',
  mista: 'Mista',
} as const;
// Tipo unione dei tipi di commessa
export type TipoCommessa = keyof typeof TIPI_COMMESSA;

// Stati di commessa con etichette
export const STATI_COMMESSA = {
  aperta: 'Aperta',
  sospesa: 'Sospesa',
  chiusa: 'Chiusa',
  annullata: 'Annullata',
} as const;
// Tipo unione degli stati
export type StatoCommessa = keyof typeof STATI_COMMESSA;

// Importo in euro: non negativo, massimo 2 decimali, entro i limiti della colonna numeric(12,2)
export const importoSchema = z
  // Numero
  .number('Importo non valido')
  // Non negativo
  .min(0, 'L\'importo non può essere negativo')
  // Limite della colonna del database
  .max(9_999_999_999.99, 'Importo troppo elevato')
  // Al massimo due decimali (tolleranza per l'aritmetica in virgola mobile)
  .refine((v) => Math.abs(Math.round(v * 100) - v * 100) < 1e-6, 'Massimo 2 decimali');

// Campi di una commessa
const campiCommessa = z.object({
  // Cliente a cui appartiene
  clienteId: idSchema,
  // Titolo
  titolo: z.string().trim().min(2, 'Minimo 2 caratteri').max(200),
  // Descrizione facoltativa
  descrizione: testoOpzionale(5000),
  // Tipo di commessa
  tipo: z.enum(['assistenza', 'progetto', 'fornitura', 'mista']),
  // Stato (predefinito: aperta)
  stato: z.enum(['aperta', 'sospesa', 'chiusa', 'annullata']).default('aperta'),
  // Valore economico (visibile/modificabile solo con permesso economici.read)
  valore: importoSchema.nullish(),
  // Data di apertura
  dataApertura: dataIsoSchema,
  // Data di chiusura facoltativa
  dataChiusura: dataIsoSchema.nullish(),
  // Responsabile interno (determina l'ambito "propri")
  responsabileId: idSchema.nullish(),
});

// Schema di creazione con controllo coerenza delle date
export const creaCommessaSchema = campiCommessa.refine(
  // La chiusura non può precedere l'apertura (le date ISO si confrontano come stringhe)
  (v) => v.dataChiusura == null || v.dataChiusura >= v.dataApertura,
  { message: 'La data di chiusura non può precedere l\'apertura', path: ['dataChiusura'] },
);
// Tipo input creazione commessa
export type CreaCommessaInput = z.input<typeof creaCommessaSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type CreaCommessaDati = z.output<typeof creaCommessaSchema>;

// Schema di modifica: il cliente non si può cambiare, lo stato non ha default
export const aggiornaCommessaSchema = campiCommessa
  // Rimuove il cliente dai campi modificabili
  .omit({ clienteId: true })
  // Ridefinisce lo stato senza valore predefinito
  .extend({ stato: z.enum(['aperta', 'sospesa', 'chiusa', 'annullata']) })
  // Rende tutti i campi facoltativi
  .partial();
// Tipo input modifica commessa
export type AggiornaCommessaInput = z.input<typeof aggiornaCommessaSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type AggiornaCommessaDati = z.output<typeof aggiornaCommessaSchema>;

// Filtri della lista commesse
export const filtriCommesseSchema = paginazioneSchema.extend({
  // Filtra per cliente
  clienteId: idSchema.optional(),
  // Filtra per stato
  stato: z.enum(['aperta', 'sospesa', 'chiusa', 'annullata']).optional(),
  // Filtra per tipo
  tipo: z.enum(['assistenza', 'progetto', 'fornitura', 'mista']).optional(),
  // Filtra per responsabile
  responsabileId: idSchema.optional(),
});

// Commessa come restituita dalle API
export interface Commessa {
  id: string;
  codice: string;
  cliente: { id: string; codice: string; ragioneSociale: string };
  titolo: string;
  descrizione: string | null;
  tipo: TipoCommessa;
  stato: StatoCommessa;
  // Importo come stringa decimale (es. "1500.00"); assente se l'utente non ha il permesso economici.read
  valore?: string | null;
  dataApertura: string;
  dataChiusura: string | null;
  responsabile: { id: string; nome: string; cognome: string } | null;
  createdAt: string;
  updatedAt: string;
}
