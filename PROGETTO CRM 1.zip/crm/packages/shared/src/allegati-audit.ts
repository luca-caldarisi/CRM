// =====================================================================================
// Schemi e tipi per allegati e registro attività (audit log)
// =====================================================================================

// Importa Zod
import { z } from 'zod';
// Importa schemi comuni
import { dataIsoSchema, idSchema, paginazioneSchema } from './comune.js';

// ----------------------------------- Allegati -----------------------------------------

// Entità a cui è possibile collegare allegati (si estenderà nelle fasi successive)
export const ENTITA_ALLEGATO = ['cliente', 'commessa', 'progetto'] as const;
// Tipo unione delle entità
export type EntitaAllegato = (typeof ENTITA_ALLEGATO)[number];

// Dimensione massima di un file in megabyte
export const ALLEGATO_MAX_MB = 25;

// Estensioni di file ammesse (whitelist: tutto il resto viene rifiutato)
export const ESTENSIONI_AMMESSE = [
  'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods',
  'txt', 'csv', 'png', 'jpg', 'jpeg', 'webp', 'zip',
] as const;

// Campi testuali inviati insieme al file nel form multipart
export const caricaAllegatoSchema = z.object({
  // Tipo di entità
  entita: z.enum(ENTITA_ALLEGATO),
  // Identificativo dell'entità
  entitaId: idSchema,
});

// Filtri per elencare gli allegati di un'entità
export const filtriAllegatiSchema = caricaAllegatoSchema;

// Allegato come restituito dalle API
export interface Allegato {
  id: string;
  entita: EntitaAllegato;
  entitaId: string;
  nomeOriginale: string;
  mimeType: string;
  dimensione: number;
  caricatoDa: { id: string; nome: string; cognome: string };
  createdAt: string;
}

// ---------------------------------- Audit log -----------------------------------------

// Azioni registrate nel log
export const AZIONI_AUDIT = {
  creazione: 'Creazione',
  modifica: 'Modifica',
  eliminazione: 'Eliminazione',
  login: 'Accesso',
  login_fallito: 'Accesso fallito',
  logout: 'Uscita',
  cambio_password: 'Cambio password',
  reset_password: 'Reset password',
  permessi: 'Modifica permessi',
} as const;
// Tipo unione delle azioni
export type AzioneAudit = keyof typeof AZIONI_AUDIT;

// Filtri del registro attività
export const filtriAuditSchema = paginazioneSchema.extend({
  // Tipo di entità (es. "cliente")
  entita: z.string().trim().max(50).optional(),
  // Identificativo dell'entità
  entitaId: idSchema.optional(),
  // Utente che ha eseguito l'azione
  utenteId: idSchema.optional(),
  // Tipo di azione
  azione: z.enum(Object.keys(AZIONI_AUDIT) as [AzioneAudit, ...AzioneAudit[]]).optional(),
  // Dal giorno (incluso)
  dal: dataIsoSchema.optional(),
  // Al giorno (incluso)
  al: dataIsoSchema.optional(),
});

// Voce del registro attività
export interface VoceAudit {
  id: string;
  azione: AzioneAudit;
  entita: string;
  entitaId: string | null;
  descrizione: string | null;
  modifiche: Record<string, { prima: unknown; dopo: unknown }> | null;
  utente: { id: string; nome: string; cognome: string } | null;
  ip: string | null;
  createdAt: string;
}
