// =====================================================================================
// Schemi e tipi per la gestione utenti e ruoli
// =====================================================================================

// Importa Zod
import { z } from 'zod';
// Importa schemi comuni
import { booleanQuerySchema, idSchema, paginazioneSchema, testoOpzionale } from './comune.js';
// Importa lo schema della password
import { passwordSchema } from './auth.js';
// Importa catalogo e tipi dei permessi
import { AMBITI, CATALOGO_PERMESSI, CODICI_PERMESSI, type Ambito, type CodicePermesso } from './permessi.js';

// ------------------------------------ Utenti ------------------------------------------

// Schema di creazione utente
export const creaUtenteSchema = z.object({
  // Email di accesso, univoca, in minuscolo
  email: z.string().trim().toLowerCase().pipe(z.email('Email non valida')),
  // Nome obbligatorio
  nome: z.string().trim().min(1, 'Nome obbligatorio').max(80),
  // Cognome obbligatorio
  cognome: z.string().trim().min(1, 'Cognome obbligatorio').max(80),
  // Ruolo da assegnare
  ruoloId: idSchema,
  // Password iniziale facoltativa: se assente il server ne genera una casuale
  passwordIniziale: passwordSchema.optional(),
});
// Tipo dell'input di creazione (prima delle trasformazioni)
export type CreaUtenteInput = z.input<typeof creaUtenteSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type CreaUtenteDati = z.output<typeof creaUtenteSchema>;

// Schema di modifica utente: tutti i campi facoltativi
export const aggiornaUtenteSchema = z
  .object({
    // Nome
    nome: z.string().trim().min(1).max(80),
    // Cognome
    cognome: z.string().trim().min(1).max(80),
    // Nuovo ruolo
    ruoloId: idSchema,
    // Attivazione/disattivazione dell'account
    attivo: z.boolean(),
  })
  .partial();
// Tipo dell'input di modifica
export type AggiornaUtenteInput = z.input<typeof aggiornaUtenteSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type AggiornaUtenteDati = z.output<typeof aggiornaUtenteSchema>;

// Filtri della lista utenti
export const filtriUtentiSchema = paginazioneSchema.extend({
  // Filtra per ruolo
  ruoloId: idSchema.optional(),
  // Filtra per stato attivo/disattivo
  attivo: booleanQuerySchema.optional(),
});

// Utente come restituito dalle API
export interface Utente {
  id: string;
  email: string;
  nome: string;
  cognome: string;
  attivo: boolean;
  deveCambiarePassword: boolean;
  ultimoAccesso: string | null;
  bloccatoFinoA: string | null;
  ruolo: { id: string; nome: string; diSistema: boolean };
  createdAt: string;
}

// Opzione utente per le select (es. scelta del responsabile)
export interface OpzioneUtente {
  id: string;
  nome: string;
  cognome: string;
}

// Risposta alla creazione utente o al reset password: la password temporanea è mostrata UNA sola volta
export interface RispostaPasswordTemporanea {
  // Utente creato o aggiornato
  utente: Utente;
  // Password in chiaro da comunicare all'utente (null se l'Admin l'ha scelta)
  passwordTemporanea: string | null;
}

// ------------------------------------- Ruoli ------------------------------------------

// Schema di creazione ruolo
export const creaRuoloSchema = z.object({
  // Nome del ruolo, univoco
  nome: z.string().trim().min(2, 'Minimo 2 caratteri').max(50),
  // Descrizione facoltativa
  descrizione: testoOpzionale(200),
});
// Tipo input creazione ruolo
export type CreaRuoloInput = z.input<typeof creaRuoloSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type CreaRuoloDati = z.output<typeof creaRuoloSchema>;

// Schema di modifica ruolo
export const aggiornaRuoloSchema = creaRuoloSchema.partial();
// Tipo input modifica ruolo
export type AggiornaRuoloInput = z.input<typeof aggiornaRuoloSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type AggiornaRuoloDati = z.output<typeof aggiornaRuoloSchema>;

// Insieme dei codici che supportano l'ambito "propri"
const CODICI_CON_PROPRI = new Set<string>(CATALOGO_PERMESSI.filter((p) => p.supportaPropri).map((p) => p.codice));

// Schema per impostare l'intera matrice permessi di un ruolo
export const impostaPermessiSchema = z.object({
  // Elenco completo dei permessi concessi (quelli assenti vengono revocati)
  permessi: z
    .array(
      z.object({
        // Codice del permesso, deve esistere nel catalogo
        codice: z.enum(CODICI_PERMESSI as [CodicePermesso, ...CodicePermesso[]]),
        // Ambito concesso
        ambito: z.enum(AMBITI),
      }),
    )
    // Non può contenere più elementi del catalogo
    .max(CODICI_PERMESSI.length)
    // Nessun codice ripetuto
    .refine((l) => new Set(l.map((p) => p.codice)).size === l.length, 'Permesso ripetuto')
    // L'ambito "propri" è ammesso solo dove ha senso
    .refine(
      (l) => l.every((p) => p.ambito === 'tutti' || CODICI_CON_PROPRI.has(p.codice)),
      'Ambito "propri" non ammesso per uno dei permessi',
    ),
});
// Tipo input matrice permessi
export type ImpostaPermessiInput = z.input<typeof impostaPermessiSchema>;
// Tipo dei dati dopo validazione e trasformazioni (quello ricevuto dal backend)
export type ImpostaPermessiDati = z.output<typeof impostaPermessiSchema>;

// Ruolo come restituito dalle API
export interface Ruolo {
  id: string;
  nome: string;
  descrizione: string | null;
  diSistema: boolean;
  numeroUtenti: number;
  permessi: Array<{ codice: CodicePermesso; ambito: Ambito }>;
}
