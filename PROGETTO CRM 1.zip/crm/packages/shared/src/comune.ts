// =====================================================================================
// Schemi e tipi comuni a tutte le API (paginazione, ordinamento, errori, campi di testo)
// =====================================================================================

// Importa la libreria di validazione Zod
import { z } from 'zod';

// Dimensione di pagina predefinita delle liste
export const PAGE_SIZE_DEFAULT = 25;
// Dimensione massima consentita: evita richieste che scaricano tutto il database
export const PAGE_SIZE_MAX = 100;

// Parametri di query comuni a tutte le liste
export const paginazioneSchema = z.object({
  // Numero di pagina (la query string arriva come testo, quindi si converte in numero)
  page: z.coerce.number().int().min(1).default(1),
  // Elementi per pagina, limitati tra 1 e il massimo consentito
  pageSize: z.coerce.number().int().min(1).max(PAGE_SIZE_MAX).default(PAGE_SIZE_DEFAULT),
  // Testo di ricerca libera (facoltativo)
  q: z.string().trim().max(100).optional(),
  // Ordinamento: elenco di campi separati da virgola, "-" davanti = decrescente
  sort: z
    .string()
    .regex(/^-?[a-zA-Z]+(,-?[a-zA-Z]+)*$/, 'Formato ordinamento non valido')
    .optional(),
});

// Tipo TypeScript dei parametri di paginazione già validati
export type Paginazione = z.output<typeof paginazioneSchema>;

// Formato standard delle risposte delle liste
export interface RispostaPaginata<T> {
  // Elementi della pagina richiesta
  data: T[];
  // Informazioni per costruire la paginazione nell'interfaccia
  meta: { page: number; pageSize: number; total: number };
}

// Formato standard delle risposte di un singolo elemento
export interface RispostaSingola<T> {
  // Elemento restituito
  data: T;
}

// Formato degli errori secondo lo standard RFC 9457 (Problem Details)
export interface ProblemDetails {
  // Codice macchina dell'errore (es. "validazione", "permesso_negato")
  type: string;
  // Titolo breve leggibile
  title: string;
  // Codice di stato HTTP
  status: number;
  // Descrizione dettagliata (facoltativa)
  detail?: string;
  // Errori di validazione campo per campo (facoltativi)
  errors?: Array<{ campo: string; messaggio: string }>;
}

// Campo di testo facoltativo: spazi rimossi, stringa vuota trasformata in null
// (null = "svuota il campo", undefined = "non modificare" nelle PATCH)
export function testoOpzionale(max: number) {
  return (
    z
      // Deve essere una stringa senza spazi iniziali/finali e non oltre il massimo
      .string()
      .trim()
      .max(max, `Massimo ${max} caratteri`)
      // Accetta anche null e undefined
      .nullish()
      // Converte la stringa vuota (campo del form lasciato vuoto) in null
      .transform((v) => (v === '' ? null : v))
  );
}

// Email facoltativa, normalizzata in minuscolo
export function emailOpzionale() {
  return (
    z
      // Stringa senza spazi, in minuscolo
      .string()
      .trim()
      .toLowerCase()
      // Stringa vuota oppure email valida
      .refine((v) => v === '' || z.email().safeParse(v).success, 'Email non valida')
      .max(254)
      .nullish()
      // Stringa vuota trasformata in null
      .transform((v) => (v === '' ? null : v))
  );
}

// Numero di telefono facoltativo: cifre, spazi, +, -, parentesi e punti
export function telefonoOpzionale() {
  return testoOpzionale(30).refine(
    // Se presente deve rispettare il formato
    (v) => v == null || /^[+\d][\d\s().-]{4,29}$/.test(v),
    'Numero di telefono non valido',
  );
}

// Data in formato ISO "AAAA-MM-GG" (senza orario)
export const dataIsoSchema = z.iso.date('Data non valida (formato AAAA-MM-GG)');

// Query string booleana: accetta solo "true" o "false" (z.coerce.boolean trasformerebbe "false" in true)
export const booleanQuerySchema = z.enum(['true', 'false']).transform((v) => v === 'true');

// Identificativo UUID
export const idSchema = z.uuid('Identificativo non valido');

// Schema del parametro di rotta ":id"
export const parametroIdSchema = z.object({ id: idSchema });
