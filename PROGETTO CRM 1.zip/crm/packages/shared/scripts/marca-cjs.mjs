// Script eseguito dopo la build: segnala a Node che la cartella dist/cjs contiene CommonJS
// Serve perché il package.json principale dichiara "type": "module" (valido per dist/esm)

// Importa la funzione per scrivere file dal modulo standard di Node
import { writeFileSync } from 'node:fs';

// Scrive un package.json minimale dentro dist/cjs che sovrascrive il tipo di modulo
writeFileSync(new URL('../dist/cjs/package.json', import.meta.url), JSON.stringify({ type: 'commonjs' }) + '\n');
