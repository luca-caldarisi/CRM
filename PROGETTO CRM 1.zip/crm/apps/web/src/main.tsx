// =====================================================================================
// Punto di ingresso del frontend: monta l'applicazione React nella pagina
// =====================================================================================

// Importa la modalità rigorosa di React (segnala problemi in sviluppo)
import { StrictMode } from 'react';
// Importa la funzione per creare la radice React
import { createRoot } from 'react-dom/client';
// Importa i provider globali e il router
import { Applicazione } from './app/applicazione';
// Importa gli stili globali (Tailwind + font)
import './styles.css';

// Elemento contenitore definito in index.html
const contenitore = document.getElementById('root');
// Controllo di sicurezza
if (!contenitore) throw new Error('Elemento #root non trovato');

// Avvia il rendering
createRoot(contenitore).render(
  <StrictMode>
    <Applicazione />
  </StrictMode>,
);
