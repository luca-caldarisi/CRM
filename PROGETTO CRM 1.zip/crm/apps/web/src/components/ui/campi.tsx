// =====================================================================================
// Campi dei form: input, textarea, select, etichetta e contenitore con messaggio di errore
// =====================================================================================

// Importa i tipi di React
import type { InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from 'react';
// Importa l'utilità per le classi
import { cn } from '@/lib/utils';

// Classi comuni a input, select e textarea
const base =
  'block w-full rounded-lg border border-slate-300 bg-white px-3 text-sm text-slate-900 shadow-sm placeholder:text-slate-400 focus:border-primario-500 focus:outline-none focus:ring-2 focus:ring-primario-500/20 disabled:bg-slate-50 disabled:text-slate-500 aria-[invalid=true]:border-red-400 aria-[invalid=true]:ring-red-500/20';

// Campo di testo
export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={cn(base, 'h-9', className)} {...props} />;
}

// Area di testo multiriga
export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={cn(base, 'min-h-24 py-2', className)} {...props} />;
}

// Menu a tendina nativo (accessibile e affidabile su tutti i dispositivi)
export function Select({ className, ...props }: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className={cn(base, 'h-9 pr-8', className)} {...props} />;
}

// Proprietà del contenitore di un campo
interface ProprietaCampo {
  // Etichetta
  etichetta: string;
  // id dell'input collegato (per l'accessibilità: click sull'etichetta = focus sul campo)
  htmlFor: string;
  // Messaggio di errore
  errore?: string;
  // Testo di aiuto sotto il campo
  aiuto?: string;
  // Campo obbligatorio (mostra l'asterisco)
  obbligatorio?: boolean;
  // Classi aggiuntive (es. per occupare due colonne)
  className?: string;
  // Il campo vero e proprio
  children: ReactNode;
}

// Contenitore: etichetta + campo + errore/aiuto
export function Campo({ etichetta, htmlFor, errore, aiuto, obbligatorio, className, children }: ProprietaCampo) {
  return (
    <div className={cn('space-y-1.5', className)}>
      {/* Etichetta collegata al campo */}
      <label htmlFor={htmlFor} className="block text-sm font-medium text-slate-700">
        {etichetta}
        {/* Asterisco per i campi obbligatori */}
        {obbligatorio && <span className="ml-0.5 text-red-500" aria-hidden>*</span>}
      </label>
      {/* Campo */}
      {children}
      {/* Messaggio di errore annunciato dagli screen reader */}
      {errore ? (
        <p role="alert" className="text-xs text-red-600">{errore}</p>
      ) : (
        // Testo di aiuto
        aiuto && <p className="text-xs text-slate-500">{aiuto}</p>
      )}
    </div>
  );
}
