// =====================================================================================
// Pulsante con varianti grafiche coerenti in tutta l'applicazione
// =====================================================================================

// Importa i tipi di React
import type { ButtonHTMLAttributes } from 'react';
// Importa class-variance-authority per definire le varianti
import { cva, type VariantProps } from 'class-variance-authority';
// Importa l'icona di caricamento
import { Loader2 } from 'lucide-react';
// Importa l'utilità per unire le classi
import { cn } from '@/lib/utils';

// Definizione delle varianti di stile
const varianti = cva(
  // Classi comuni a tutti i pulsanti
  'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-colors disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0',
  {
    variants: {
      // Aspetto
      variante: {
        // Azione principale della schermata
        primario: 'bg-primario-600 text-white shadow-sm hover:bg-primario-700',
        // Azione secondaria
        secondario: 'border border-slate-300 bg-white text-slate-700 shadow-sm hover:bg-slate-50',
        // Azione poco evidente (es. nelle tabelle)
        fantasma: 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
        // Azione distruttiva (eliminazione)
        pericolo: 'bg-red-600 text-white shadow-sm hover:bg-red-700',
      },
      // Dimensione
      dimensione: {
        normale: 'h-9 px-4',
        piccolo: 'h-8 px-3 text-xs',
        icona: 'size-9',
      },
    },
    // Valori predefiniti
    defaultVariants: { variante: 'primario', dimensione: 'normale' },
  },
);

// Proprietà del pulsante: attributi HTML standard + varianti + stato di caricamento
interface ProprietaPulsante extends ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof varianti> {
  // Mostra lo spinner e disabilita il pulsante
  caricamento?: boolean;
}

// Componente pulsante
export function Button({ className, variante, dimensione, caricamento, disabled, children, type = 'button', ...props }: ProprietaPulsante) {
  return (
    // type="button" predefinito: evita invii accidentali dei form
    <button type={type} className={cn(varianti({ variante, dimensione }), className)} disabled={disabled || caricamento} {...props}>
      {/* Spinner durante le operazioni in corso */}
      {caricamento && <Loader2 className="animate-spin" aria-hidden />}
      {/* Contenuto del pulsante */}
      {children}
    </button>
  );
}
