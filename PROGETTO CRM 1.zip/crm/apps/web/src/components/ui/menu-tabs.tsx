// =====================================================================================
// Menu a discesa e schede (tabs) basati su Radix UI
// =====================================================================================

// Importa i tipi di React
import type { ReactNode } from 'react';
// Importa le primitive di Radix
import { DropdownMenu, Tabs as RadixTabs } from 'radix-ui';
// Importa l'utilità classi
import { cn } from '@/lib/utils';

// ------------------------------------ Menu --------------------------------------------

// Voce di un menu a discesa
export interface VoceMenu {
  // Testo
  etichetta: string;
  // Icona facoltativa
  icona?: ReactNode;
  // Azione
  onSelect: () => void;
  // Voce distruttiva (colore rosso)
  pericolo?: boolean;
  // Nascosta (es. permesso mancante)
  nascosta?: boolean;
}

// Menu a discesa aperto da un elemento "grilletto"
export function Menu({ grilletto, voci, allineamento = 'end' }: { grilletto: ReactNode; voci: VoceMenu[]; allineamento?: 'start' | 'end' }) {
  // Voci visibili
  const visibili = voci.filter((v) => !v.nascosta);
  // Nessuna voce: il menu non viene mostrato
  if (visibili.length === 0) return null;
  return (
    <DropdownMenu.Root>
      {/* Elemento che apre il menu */}
      <DropdownMenu.Trigger asChild>{grilletto}</DropdownMenu.Trigger>
      <DropdownMenu.Portal>
        {/* Pannello del menu */}
        <DropdownMenu.Content align={allineamento} sideOffset={4} className="z-50 min-w-44 rounded-lg border border-slate-200 bg-white p-1 shadow-lg">
          {visibili.map((v) => (
            // Singola voce navigabile da tastiera
            <DropdownMenu.Item
              key={v.etichetta}
              onSelect={v.onSelect}
              className={cn(
                'flex cursor-pointer items-center gap-2 rounded-md px-2.5 py-1.5 text-sm outline-none data-[highlighted]:bg-slate-100 [&_svg]:size-4',
                v.pericolo ? 'text-red-600 data-[highlighted]:bg-red-50' : 'text-slate-700',
              )}
            >
              {v.icona}
              {v.etichetta}
            </DropdownMenu.Item>
          ))}
        </DropdownMenu.Content>
      </DropdownMenu.Portal>
    </DropdownMenu.Root>
  );
}

// ------------------------------------ Tabs --------------------------------------------

// Definizione di una scheda
export interface Scheda {
  // Identificativo (usato anche nell'URL)
  id: string;
  // Etichetta
  etichetta: string;
  // Contatore facoltativo accanto all'etichetta
  contatore?: number;
  // Contenuto
  contenuto: ReactNode;
  // Nascosta
  nascosta?: boolean;
}

// Schede con barra di navigazione
export function Tabs({ schede, attiva, onCambia }: { schede: Scheda[]; attiva: string; onCambia: (id: string) => void }) {
  // Schede visibili
  const visibili = schede.filter((s) => !s.nascosta);
  return (
    <RadixTabs.Root value={attiva} onValueChange={onCambia}>
      {/* Barra delle schede scorrevole orizzontalmente su schermi piccoli */}
      <RadixTabs.List className="flex gap-1 overflow-x-auto border-b border-slate-200">
        {visibili.map((s) => (
          <RadixTabs.Trigger
            key={s.id}
            value={s.id}
            className="-mb-px flex items-center gap-2 whitespace-nowrap border-b-2 border-transparent px-3 py-2.5 text-sm font-medium text-slate-500 hover:text-slate-800 data-[state=active]:border-primario-600 data-[state=active]:text-primario-700"
          >
            {s.etichetta}
            {/* Contatore */}
            {s.contatore !== undefined && <span className="rounded-full bg-slate-100 px-1.5 text-xs text-slate-600">{s.contatore}</span>}
          </RadixTabs.Trigger>
        ))}
      </RadixTabs.List>
      {/* Contenuti: viene montato solo quello della scheda attiva */}
      {visibili.map((s) => (
        <RadixTabs.Content key={s.id} value={s.id} className="pt-5 focus:outline-none">
          {s.contenuto}
        </RadixTabs.Content>
      ))}
    </RadixTabs.Root>
  );
}
