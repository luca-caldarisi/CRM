// =====================================================================================
// Elementi grafici semplici: card, badge, skeleton, avatar
// =====================================================================================

// Importa i tipi di React
import type { HTMLAttributes, ReactNode } from 'react';
// Importa l'utilità per le classi
import { cn, iniziali } from '@/lib/utils';

// Contenitore bianco con bordo
export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn('rounded-(--radius-card) border border-slate-200 bg-white shadow-xs', className)} {...props} />;
}

// Intestazione di una card con titolo ed eventuali azioni a destra
export function CardHeader({ titolo, descrizione, azioni }: { titolo: string; descrizione?: string; azioni?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-5 py-4">
      {/* Titolo e descrizione */}
      <div>
        <h2 className="text-sm font-semibold text-slate-900">{titolo}</h2>
        {descrizione && <p className="mt-0.5 text-xs text-slate-500">{descrizione}</p>}
      </div>
      {/* Azioni */}
      {azioni && <div className="flex shrink-0 items-center gap-2">{azioni}</div>}
    </div>
  );
}

// Colori disponibili per i badge
const coloriBadge = {
  grigio: 'bg-slate-100 text-slate-700 ring-slate-500/10',
  verde: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20',
  giallo: 'bg-amber-50 text-amber-800 ring-amber-600/20',
  rosso: 'bg-red-50 text-red-700 ring-red-600/10',
  blu: 'bg-primario-50 text-primario-700 ring-primario-700/10',
} as const;

// Tipo dei colori
export type ColoreBadge = keyof typeof coloriBadge;

// Etichetta colorata per stati e categorie
export function Badge({ colore = 'grigio', className, children }: { colore?: ColoreBadge; className?: string; children: ReactNode }) {
  return <span className={cn('inline-flex items-center whitespace-nowrap rounded-md px-2 py-0.5 text-xs font-medium ring-1 ring-inset', coloriBadge[colore], className)}>{children}</span>;
}

// Segnaposto animato durante il caricamento
export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-md bg-slate-200/70', className)} aria-hidden />;
}

// Cerchio con le iniziali dell'utente
export function Avatar({ nome, cognome, className }: { nome: string; cognome?: string | null; className?: string }) {
  return (
    <span className={cn('inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-primario-100 text-xs font-semibold text-primario-700', className)} aria-hidden>
      {iniziali(nome, cognome)}
    </span>
  );
}
