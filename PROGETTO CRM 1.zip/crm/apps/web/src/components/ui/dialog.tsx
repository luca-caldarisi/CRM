// =====================================================================================
// Finestre modali basate su Radix UI (gestione focus, tasto Esc e accessibilità inclusi)
// =====================================================================================

// Importa i tipi di React
import type { ReactNode } from 'react';
// Importa le primitive Dialog e AlertDialog di Radix
import { AlertDialog as RadixAlert, Dialog as RadixDialog } from 'radix-ui';
// Importa l'icona di chiusura
import { X } from 'lucide-react';
// Importa il pulsante e l'utilità classi
import { Button } from './button';
import { cn } from '@/lib/utils';

// Classi dello sfondo scuro dietro la finestra
const sfondo = 'fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-[2px]';
// Classi della finestra centrata
const pannello = 'fixed left-1/2 top-1/2 z-50 w-[calc(100vw-2rem)] -translate-x-1/2 -translate-y-1/2 rounded-xl bg-white shadow-xl focus:outline-none';

// Proprietà della finestra modale
interface ProprietaDialog {
  // Aperta o chiusa
  aperto: boolean;
  // Chiamata quando l'utente la chiude (Esc, click fuori, X)
  onChiudi: () => void;
  // Titolo
  titolo: string;
  // Descrizione sotto il titolo
  descrizione?: string;
  // Larghezza massima
  larghezza?: 'md' | 'lg' | 'xl';
  // Contenuto
  children: ReactNode;
}

// Finestra modale generica
export function Dialog({ aperto, onChiudi, titolo, descrizione, larghezza = 'md', children }: ProprietaDialog) {
  return (
    <RadixDialog.Root open={aperto} onOpenChange={(v) => !v && onChiudi()}>
      <RadixDialog.Portal>
        {/* Sfondo */}
        <RadixDialog.Overlay className={sfondo} />
        {/* Finestra */}
        <RadixDialog.Content className={cn(pannello, { md: 'max-w-md', lg: 'max-w-2xl', xl: 'max-w-4xl' }[larghezza])}>
          {/* Intestazione */}
          <div className="flex items-start justify-between gap-4 border-b border-slate-100 px-6 py-4">
            <div>
              {/* Titolo annunciato dagli screen reader */}
              <RadixDialog.Title className="text-base font-semibold text-slate-900">{titolo}</RadixDialog.Title>
              {/* Descrizione (sempre presente per l'accessibilità, eventualmente vuota) */}
              <RadixDialog.Description className="mt-0.5 text-sm text-slate-500">{descrizione}</RadixDialog.Description>
            </div>
            {/* Pulsante di chiusura */}
            <RadixDialog.Close asChild>
              <Button variante="fantasma" dimensione="icona" aria-label="Chiudi">
                <X />
              </Button>
            </RadixDialog.Close>
          </div>
          {/* Contenuto scorrevole se troppo alto */}
          <div className="max-h-[calc(100vh-10rem)] overflow-y-auto px-6 py-5">{children}</div>
        </RadixDialog.Content>
      </RadixDialog.Portal>
    </RadixDialog.Root>
  );
}

// Barra dei pulsanti in fondo a un form dentro una finestra
export function PiedeDialog({ children }: { children: ReactNode }) {
  return <div className="-mx-6 -mb-5 mt-6 flex justify-end gap-2 border-t border-slate-100 bg-slate-50/60 px-6 py-3">{children}</div>;
}

// Proprietà della conferma
interface ProprietaConferma {
  aperto: boolean;
  onChiudi: () => void;
  // Azione da eseguire alla conferma
  onConferma: () => void;
  titolo: string;
  messaggio: ReactNode;
  // Testo del pulsante di conferma
  testoConferma?: string;
  // Operazione in corso
  caricamento?: boolean;
}

// Finestra di conferma per le operazioni distruttive
export function ConfermaDialog({ aperto, onChiudi, onConferma, titolo, messaggio, testoConferma = 'Elimina', caricamento }: ProprietaConferma) {
  return (
    <RadixAlert.Root open={aperto} onOpenChange={(v) => !v && onChiudi()}>
      <RadixAlert.Portal>
        {/* Sfondo */}
        <RadixAlert.Overlay className={sfondo} />
        {/* Finestra */}
        <RadixAlert.Content className={cn(pannello, 'max-w-md p-6')}>
          {/* Titolo */}
          <RadixAlert.Title className="text-base font-semibold text-slate-900">{titolo}</RadixAlert.Title>
          {/* Messaggio */}
          <RadixAlert.Description className="mt-2 text-sm text-slate-600">{messaggio}</RadixAlert.Description>
          {/* Pulsanti: il focus iniziale va su "Annulla" per evitare conferme accidentali */}
          <div className="mt-6 flex justify-end gap-2">
            <RadixAlert.Cancel asChild>
              <Button variante="secondario">Annulla</Button>
            </RadixAlert.Cancel>
            <Button variante="pericolo" caricamento={caricamento} onClick={onConferma}>
              {testoConferma}
            </Button>
          </div>
        </RadixAlert.Content>
      </RadixAlert.Portal>
    </RadixAlert.Root>
  );
}
