// =====================================================================================
// Componenti di struttura delle pagine: intestazione, ricerca, stati vuoto/errore/accesso negato
// =====================================================================================

// Importa React e i tipi
import { useEffect, useState, type ReactNode } from 'react';
// Importa il link del router
import { Link } from 'react-router';
// Importa le icone
import { AlertTriangle, ChevronRight, Loader2, Lock, Search } from 'lucide-react';
// Importa componenti e hook
import { Input } from '@/components/ui/campi';
import { useDebounce } from '@/lib/hooks';

// Voce del percorso di navigazione (breadcrumb)
export interface Briciola {
  etichetta: string;
  // Destinazione (assente per la voce corrente)
  a?: string;
}

// Intestazione della pagina con breadcrumb, titolo, sottotitolo e azioni
export function IntestazionePagina({ titolo, sottotitolo, briciole, azioni }: { titolo: ReactNode; sottotitolo?: ReactNode; briciole?: Briciola[]; azioni?: ReactNode }) {
  return (
    <div className="mb-6">
      {/* Breadcrumb */}
      {briciole && (
        <nav aria-label="Percorso" className="mb-2 flex items-center gap-1 text-xs text-slate-500">
          {briciole.map((b, i) => (
            <span key={b.etichetta} className="flex items-center gap-1">
              {/* Separatore */}
              {i > 0 && <ChevronRight className="size-3" aria-hidden />}
              {/* Link o testo corrente */}
              {b.a ? <Link to={b.a} className="hover:text-slate-800">{b.etichetta}</Link> : <span aria-current="page">{b.etichetta}</span>}
            </span>
          ))}
        </nav>
      )}
      {/* Titolo e azioni */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-xl font-semibold tracking-tight text-slate-900">{titolo}</h1>
          {sottotitolo && <div className="mt-1 text-sm text-slate-500">{sottotitolo}</div>}
        </div>
        {azioni && <div className="flex flex-wrap items-center gap-2">{azioni}</div>}
      </div>
    </div>
  );
}

// Campo di ricerca che notifica il valore solo dopo una breve pausa di digitazione
export function CampoRicerca({ valore, onCambia, segnaposto = 'Cerca…' }: { valore: string; onCambia: (v: string) => void; segnaposto?: string }) {
  // Testo digitato (aggiornato a ogni tasto)
  const [testo, setTesto] = useState(valore);
  // Valore stabilizzato
  const ritardato = useDebounce(testo, 300);
  // Notifica il valore stabilizzato se diverso da quello corrente
  useEffect(() => {
    if (ritardato !== valore) onCambia(ritardato);
  }, [ritardato]);
  // Allinea il testo se il valore cambia dall'esterno (es. navigazione indietro)
  useEffect(() => setTesto(valore), [valore]);
  return (
    <div className="relative w-full sm:w-72">
      {/* Icona lente */}
      <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-400" aria-hidden />
      {/* Campo */}
      <Input type="search" value={testo} onChange={(e) => setTesto(e.target.value)} placeholder={segnaposto} aria-label={segnaposto} className="pl-9" />
    </div>
  );
}

// Messaggio di errore di caricamento
export function StatoErrore({ messaggio = 'Impossibile caricare i dati.' }: { messaggio?: string }) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700" role="alert">
      <AlertTriangle className="size-4 shrink-0" aria-hidden />
      {messaggio}
    </div>
  );
}

// Pagina di accesso negato (rotta raggiunta senza permesso)
export function AccessoNegato() {
  return (
    <div className="mx-auto mt-24 max-w-sm text-center">
      {/* Icona lucchetto */}
      <div className="mx-auto flex size-12 items-center justify-center rounded-full bg-slate-100">
        <Lock className="size-5 text-slate-500" aria-hidden />
      </div>
      <h1 className="mt-4 text-lg font-semibold text-slate-900">Accesso non consentito</h1>
      <p className="mt-1 text-sm text-slate-500">Il tuo ruolo non prevede l'accesso a questa sezione. Se ti serve, chiedi a un amministratore.</p>
      <Link to="/" className="mt-4 inline-block text-sm font-medium text-primario-600 hover:text-primario-700">
        Torna alla dashboard
      </Link>
    </div>
  );
}

// Coppia etichetta/valore per le schede di dettaglio
export function DatoDettaglio({ etichetta, children }: { etichetta: string; children: ReactNode }) {
  return (
    <div>
      <dt className="text-xs font-medium text-slate-500">{etichetta}</dt>
      {/* Il valore mostra un trattino se vuoto */}
      <dd className="mt-1 break-words text-sm text-slate-900">{children || '—'}</dd>
    </div>
  );
}

// Indicatore mostrato mentre si scarica il codice di una pagina (rotte caricate a richiesta)
export function Caricamento() {
  return (
    // Area centrata con ruolo "status" per i lettori di schermo
    <div className="flex h-64 items-center justify-center" role="status" aria-label="Caricamento">
      {/* Icona animata */}
      <Loader2 className="size-6 animate-spin text-primario-600" aria-hidden />
    </div>
  );
}
