// =====================================================================================
// Tabella dati con ordinamento, caricamento, stato vuoto e paginazione lato server
// =====================================================================================

// Importa i tipi di React
import type { ReactNode } from 'react';
// Importa le icone
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, ChevronsUpDown } from 'lucide-react';
// Importa componenti e utilità
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/elementi';
import { cn } from '@/lib/utils';

// Definizione di una colonna
export interface Colonna<T> {
  // Chiave univoca della colonna
  id: string;
  // Intestazione
  titolo: string;
  // Contenuto della cella per una riga
  cella: (riga: T) => ReactNode;
  // Nome del campo di ordinamento lato server (se assente la colonna non è ordinabile)
  ordinabile?: string;
  // Classi aggiuntive (es. allineamento a destra, nascondi su mobile)
  className?: string;
}

// Proprietà della tabella
interface ProprietaTabella<T> {
  // Colonne
  colonne: Colonna<T>[];
  // Righe da mostrare
  righe: T[] | undefined;
  // Chiave univoca di ogni riga
  chiave: (riga: T) => string;
  // Dati in caricamento
  caricamento?: boolean;
  // Ordinamento corrente (es. "-codice")
  ordinamento?: string;
  // Cambio di ordinamento
  onOrdina?: (sort: string) => void;
  // Click su una riga (es. apertura del dettaglio)
  onClickRiga?: (riga: T) => void;
  // Contenuto mostrato quando non ci sono righe
  vuoto?: ReactNode;
}

// Componente tabella generico
export function Tabella<T>({ colonne, righe, chiave, caricamento, ordinamento, onOrdina, onClickRiga, vuoto }: ProprietaTabella<T>) {
  // Campo e direzione dell'ordinamento corrente
  const campoOrdine = ordinamento?.replace(/^-/, '');
  const decrescente = ordinamento?.startsWith('-');

  // Click su un'intestazione ordinabile: crescente -> decrescente -> crescente
  const cambiaOrdine = (campo: string) => onOrdina?.(campoOrdine === campo && !decrescente ? `-${campo}` : campo);

  return (
    // Scorrimento orizzontale su schermi stretti
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        {/* Intestazione */}
        <thead className="border-b border-slate-200 bg-slate-50/80 text-xs font-medium uppercase tracking-wide text-slate-500">
          <tr>
            {colonne.map((c) => (
              <th
                key={c.id}
                scope="col"
                className={cn('px-4 py-2.5 font-medium', c.className)}
                // Stato dell'ordinamento comunicato agli screen reader
                aria-sort={c.ordinabile && campoOrdine === c.ordinabile ? (decrescente ? 'descending' : 'ascending') : undefined}
              >
                {c.ordinabile && onOrdina ? (
                  // Intestazione cliccabile
                  <button type="button" onClick={() => cambiaOrdine(c.ordinabile!)} className="inline-flex items-center gap-1 uppercase hover:text-slate-800">
                    {c.titolo}
                    {/* Icona della direzione */}
                    {campoOrdine === c.ordinabile ? decrescente ? <ArrowDown className="size-3.5" /> : <ArrowUp className="size-3.5" /> : <ChevronsUpDown className="size-3.5 opacity-40" />}
                  </button>
                ) : (
                  c.titolo
                )}
              </th>
            ))}
          </tr>
        </thead>
        {/* Corpo */}
        <tbody className="divide-y divide-slate-100">
          {caricamento && !righe
            ? // Righe segnaposto durante il primo caricamento
              Array.from({ length: 5 }, (_, i) => (
                <tr key={i}>
                  {colonne.map((c) => (
                    <td key={c.id} className={cn('px-4 py-3', c.className)}>
                      <Skeleton className="h-4 w-3/4" />
                    </td>
                  ))}
                </tr>
              ))
            : righe?.map((riga) => (
                // Riga dati
                <tr
                  key={chiave(riga)}
                  onClick={onClickRiga ? () => onClickRiga(riga) : undefined}
                  className={cn('bg-white', onClickRiga && 'cursor-pointer hover:bg-slate-50')}
                >
                  {colonne.map((c) => (
                    <td key={c.id} className={cn('px-4 py-3 text-slate-700', c.className)}>
                      {c.cella(riga)}
                    </td>
                  ))}
                </tr>
              ))}
        </tbody>
      </table>
      {/* Stato vuoto */}
      {!caricamento && righe?.length === 0 && <div className="px-4 py-12 text-center text-sm text-slate-500">{vuoto ?? 'Nessun risultato'}</div>}
    </div>
  );
}

// Barra di paginazione
export function Paginazione({ page, pageSize, total, onCambia }: { page: number; pageSize: number; total: number; onCambia: (page: number) => void }) {
  // Numero totale di pagine (almeno 1)
  const pagine = Math.max(1, Math.ceil(total / pageSize));
  // Primo e ultimo elemento mostrati
  const da = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const a = Math.min(page * pageSize, total);
  return (
    <div className="flex items-center justify-between gap-4 border-t border-slate-200 px-4 py-3 text-sm text-slate-600">
      {/* Riepilogo */}
      <p>
        {da}–{a} di <span className="font-medium text-slate-900">{total}</span>
      </p>
      {/* Pulsanti precedente/successiva */}
      <div className="flex items-center gap-2">
        <Button variante="secondario" dimensione="piccolo" disabled={page <= 1} onClick={() => onCambia(page - 1)} aria-label="Pagina precedente">
          <ChevronLeft />
        </Button>
        <span className="tabular-nums">
          {page} / {pagine}
        </span>
        <Button variante="secondario" dimensione="piccolo" disabled={page >= pagine} onClick={() => onCambia(page + 1)} aria-label="Pagina successiva">
          <ChevronRight />
        </Button>
      </div>
    </div>
  );
}
