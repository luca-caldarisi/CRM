// =====================================================================================
// Storico delle attività di un'entità (usato nelle schede cliente e commessa)
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa i tipi e le etichette condivisi
import { AZIONI_AUDIT, type VoceAudit } from '@crm/shared';
// Importa componenti
import { Badge, Skeleton, type ColoreBadge } from '@/components/ui/elementi';
import { Paginazione } from '@/components/common/tabella';
// Importa hook e utilità
import { useAudit } from '@/features/amministrazione-api';
import { formattaDataOra, nomeCompleto } from '@/lib/utils';

// Colore del badge per ogni azione
export const COLORE_AZIONE: Record<VoceAudit['azione'], ColoreBadge> = {
  creazione: 'verde',
  modifica: 'blu',
  eliminazione: 'rosso',
  login: 'grigio',
  login_fallito: 'giallo',
  logout: 'grigio',
  cambio_password: 'grigio',
  reset_password: 'giallo',
  permessi: 'giallo',
};

// Mostra un valore del registro in forma leggibile
export function valoreLeggibile(v: unknown): string {
  // Vuoto
  if (v === null || v === undefined || v === '') return '—';
  // Booleani in italiano
  if (typeof v === 'boolean') return v ? 'Sì' : 'No';
  // Oggetti come JSON compatto
  if (typeof v === 'object') return JSON.stringify(v);
  // Testo e numeri
  return String(v);
}

// Elenco delle modifiche di una voce
export function DettaglioModifiche({ modifiche }: { modifiche: VoceAudit['modifiche'] }) {
  // Nessuna modifica registrata
  if (!modifiche) return null;
  return (
    <dl className="mt-2 space-y-1 rounded-md bg-slate-50 p-2.5 text-xs">
      {Object.entries(modifiche).map(([campo, { prima, dopo }]) => (
        <div key={campo} className="grid grid-cols-[8rem_1fr] gap-2">
          {/* Nome del campo */}
          <dt className="truncate font-medium text-slate-600">{campo}</dt>
          {/* Valore precedente barrato e nuovo valore */}
          <dd className="min-w-0 break-words text-slate-800">
            <span className="text-slate-400 line-through">{valoreLeggibile(prima)}</span> → {valoreLeggibile(dopo)}
          </dd>
        </div>
      ))}
    </dl>
  );
}

// Storico di una singola entità
export function StoricoAttivita({ entita, entitaId }: { entita: string; entitaId: string }) {
  // Pagina corrente
  const [page, setPage] = useState(1);
  // Voci del registro
  const { data, isLoading } = useAudit({ entita, entitaId, page, pageSize: 20 });

  // Caricamento
  if (isLoading) return <Skeleton className="h-24" />;
  // Nessuna voce
  if (!data?.data.length) return <p className="py-6 text-center text-sm text-slate-500">Nessuna attività registrata</p>;

  return (
    <div className="rounded-lg border border-slate-200">
      {/* Linea temporale */}
      <ol className="divide-y divide-slate-100">
        {data.data.map((v) => (
          <li key={v.id} className="px-4 py-3">
            <div className="flex flex-wrap items-center gap-2 text-sm">
              {/* Azione */}
              <Badge colore={COLORE_AZIONE[v.azione]}>{AZIONI_AUDIT[v.azione]}</Badge>
              {/* Autore */}
              <span className="font-medium text-slate-900">{nomeCompleto(v.utente)}</span>
              {/* Data */}
              <span className="text-slate-500">{formattaDataOra(v.createdAt)}</span>
            </div>
            {/* Campi modificati */}
            <DettaglioModifiche modifiche={v.azione === 'modifica' ? v.modifiche : null} />
          </li>
        ))}
      </ol>
      {/* Paginazione se necessaria */}
      {data.meta.total > data.meta.pageSize && <Paginazione {...data.meta} onCambia={setPage} />}
    </div>
  );
}
