// =====================================================================================
// Registro attività: chi ha fatto cosa e quando, con filtri
// =====================================================================================

// Importa React
import { Fragment, useState } from 'react';
// Importa le icone
import { ChevronDown, ChevronRight } from 'lucide-react';
// Importa etichette condivise
import { AZIONI_AUDIT, type AzioneAudit } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Input, Select } from '@/components/ui/campi';
import { Badge, Card, Skeleton } from '@/components/ui/elementi';
import { IntestazionePagina, StatoErrore } from '@/components/common/pagina';
import { Paginazione } from '@/components/common/tabella';
// Importa hook e utilità
import { COLORE_AZIONE, DettaglioModifiche } from './storico-attivita';
import { useAudit } from '@/features/amministrazione-api';
import { useFiltriUrl } from '@/lib/hooks';
import { formattaDataOra, nomeCompleto } from '@/lib/utils';

// Etichette leggibili dei tipi di entità
const ENTITA: Record<string, string> = { cliente: 'Cliente', sede: 'Sede', contatto: 'Contatto', commessa: 'Commessa', allegato: 'Documento', utente: 'Utente', ruolo: 'Ruolo', sessione: 'Sessione' };

export function PaginaAudit() {
  // Filtri nell'URL
  const { filtri, page, imposta } = useFiltriUrl(['azione', 'entita', 'dal', 'al'] as const);
  // Voce espansa per vedere il dettaglio delle modifiche
  const [espansa, setEspansa] = useState<string | null>(null);
  // Dati
  const { data, isLoading, isError } = useAudit({ ...filtri, page, pageSize: 50 });

  return (
    <>
      <IntestazionePagina briciole={[{ etichetta: 'Amministrazione' }, { etichetta: 'Registro attività' }]} titolo="Registro attività" sottotitolo="Il registro non può essere modificato né cancellato." />
      {isError && <StatoErrore />}
      <Card>
        {/* Filtri */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 p-3">
          <Select value={filtri.azione} onChange={(e) => imposta({ azione: e.target.value })} className="w-auto" aria-label="Filtra per azione">
            <option value="">Tutte le azioni</option>
            {Object.entries(AZIONI_AUDIT).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
          </Select>
          <Select value={filtri.entita} onChange={(e) => imposta({ entita: e.target.value })} className="w-auto" aria-label="Filtra per tipo di elemento">
            <option value="">Tutti gli elementi</option>
            {Object.entries(ENTITA).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
          </Select>
          {/* Intervallo di date */}
          <label className="flex items-center gap-1.5 text-sm text-slate-600">
            Dal <Input type="date" value={filtri.dal} onChange={(e) => imposta({ dal: e.target.value })} className="w-auto" />
          </label>
          <label className="flex items-center gap-1.5 text-sm text-slate-600">
            Al <Input type="date" value={filtri.al} onChange={(e) => imposta({ al: e.target.value })} className="w-auto" />
          </label>
          {/* Azzeramento filtri */}
          {Object.values(filtri).some(Boolean) && (
            <Button variante="fantasma" dimensione="piccolo" onClick={() => imposta({ azione: null, entita: null, dal: null, al: null })}>
              Azzera filtri
            </Button>
          )}
        </div>
        {/* Tabella con righe espandibili */}
        {isLoading ? (
          <div className="p-4"><Skeleton className="h-40" /></div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50/80 text-xs font-medium uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="w-8 px-4 py-2.5" aria-label="Espandi" />
                  <th className="px-4 py-2.5 font-medium">Data</th>
                  <th className="px-4 py-2.5 font-medium">Utente</th>
                  <th className="px-4 py-2.5 font-medium">Azione</th>
                  <th className="px-4 py-2.5 font-medium">Elemento</th>
                  <th className="hidden px-4 py-2.5 font-medium lg:table-cell">IP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {data?.data.map((v) => {
                  // La riga è espandibile solo se contiene modifiche
                  const espandibile = !!v.modifiche;
                  return (
                    <Fragment key={v.id}>
                      <tr className={espandibile ? 'cursor-pointer hover:bg-slate-50' : undefined} onClick={espandibile ? () => setEspansa(espansa === v.id ? null : v.id) : undefined}>
                        {/* Freccia */}
                        <td className="px-4 py-3 text-slate-400">{espandibile && (espansa === v.id ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />)}</td>
                        {/* Data */}
                        <td className="whitespace-nowrap px-4 py-3 tabular-nums text-slate-600">{formattaDataOra(v.createdAt)}</td>
                        {/* Utente */}
                        <td className="px-4 py-3">{v.utente ? nomeCompleto(v.utente) : <span className="text-slate-400">Sistema / anonimo</span>}</td>
                        {/* Azione */}
                        <td className="px-4 py-3"><Badge colore={COLORE_AZIONE[v.azione as AzioneAudit]}>{AZIONI_AUDIT[v.azione as AzioneAudit]}</Badge></td>
                        {/* Entità e descrizione */}
                        <td className="px-4 py-3">
                          <span className="text-slate-500">{ENTITA[v.entita] ?? v.entita}</span>
                          {v.descrizione && <span className="ml-1.5 text-slate-800">{v.descrizione}</span>}
                        </td>
                        {/* IP */}
                        <td className="hidden px-4 py-3 font-mono text-xs text-slate-500 lg:table-cell">{v.ip ?? '—'}</td>
                      </tr>
                      {/* Dettaglio delle modifiche */}
                      {espansa === v.id && (
                        <tr>
                          <td />
                          <td colSpan={5} className="px-4 pb-4">
                            <DettaglioModifiche modifiche={v.modifiche} />
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
            {data?.data.length === 0 && <p className="px-4 py-12 text-center text-sm text-slate-500">Nessuna attività trovata</p>}
          </div>
        )}
        {data && <Paginazione {...data.meta} onCambia={(p) => imposta({ page: p })} />}
      </Card>
    </>
  );
}
