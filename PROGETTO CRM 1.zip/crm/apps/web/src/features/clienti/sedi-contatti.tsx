// =====================================================================================
// Schede "Sedi" e "Contatti" del dettaglio cliente, con relative finestre di modifica
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il form e l'integrazione Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le icone
import { Mail, MapPin, MoreHorizontal, Pencil, Phone, Plus, Smartphone, Star, Trash2 } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa i tipi di Zod
import type { z } from 'zod';
// Importa schemi, etichette e tipi condivisi
import { creaContattoSchema, creaSedeSchema, TIPI_SEDE, type Contatto, type Sede } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input, Select, Textarea } from '@/components/ui/campi';
import { ConfermaDialog, Dialog, PiedeDialog } from '@/components/ui/dialog';
import { Badge, Card, Skeleton } from '@/components/ui/elementi';
import { Menu } from '@/components/ui/menu-tabs';
// Importa hook ed errori
import { useContatti, useEliminaContatto, useEliminaSede, useSalvaContatto, useSalvaSede, useSedi } from './api';
// Importa l'hook che riallinea le select con opzioni asincrone
import { useAllineaSelect } from '@/lib/hooks';
import { applicaErroriForm, notificaErrore } from '@/lib/errori';

// ------------------------------------- Sedi -----------------------------------------

// Tipi del form sede
type IngressoSede = z.input<typeof creaSedeSchema>;
type UscitaSede = z.output<typeof creaSedeSchema>;

// Finestra di creazione/modifica sede
function FormSede({ clienteId, sede, onChiudi }: { clienteId: string; sede?: Sede; onChiudi: () => void }) {
  // Mutation di salvataggio
  const salva = useSalvaSede(clienteId);
  // Form con valori iniziali
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<IngressoSede, unknown, UscitaSede>({
    resolver: zodResolver(creaSedeSchema),
    defaultValues: { tipo: sede?.tipo ?? 'operativa', nome: sede?.nome ?? '', indirizzo: sede?.indirizzo ?? '', cap: sede?.cap ?? '', citta: sede?.citta ?? '', provincia: sede?.provincia ?? '', nazione: sede?.nazione ?? 'IT' },
  });

  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      // Salva (creazione o modifica)
      await salva.mutateAsync({ id: sede?.id, dati });
      toast.success('Sede salvata');
      onChiudi();
    } catch (errore) {
      applicaErroriForm(errore, setError);
    }
  });

  return (
    <Dialog aperto onChiudi={onChiudi} titolo={sede ? 'Modifica sede' : 'Nuova sede'} larghezza="lg">
      <form onSubmit={invia} noValidate>
        <div className="grid gap-4 sm:grid-cols-6">
          {/* Tipo */}
          <Campo etichetta="Tipo" htmlFor="tipo" obbligatorio className="sm:col-span-2">
            <Select id="tipo" {...register('tipo')}>
              {Object.entries(TIPI_SEDE).map(([valore, etichetta]) => (
                <option key={valore} value={valore}>{etichetta}</option>
              ))}
            </Select>
          </Campo>
          {/* Nome descrittivo */}
          <Campo etichetta="Nome" htmlFor="nome" aiuto="Es. Magazzino, Filiale Nord" errore={errors.nome?.message} className="sm:col-span-4">
            <Input id="nome" {...register('nome')} />
          </Campo>
          {/* Indirizzo */}
          <Campo etichetta="Indirizzo" htmlFor="indirizzo" obbligatorio errore={errors.indirizzo?.message} className="sm:col-span-6">
            <Input id="indirizzo" autoComplete="street-address" aria-invalid={!!errors.indirizzo} {...register('indirizzo')} />
          </Campo>
          {/* CAP, città, provincia, nazione */}
          <Campo etichetta="CAP" htmlFor="cap" errore={errors.cap?.message} className="sm:col-span-1">
            <Input id="cap" autoComplete="postal-code" {...register('cap')} />
          </Campo>
          <Campo etichetta="Città" htmlFor="citta" obbligatorio errore={errors.citta?.message} className="sm:col-span-3">
            <Input id="citta" aria-invalid={!!errors.citta} {...register('citta')} />
          </Campo>
          <Campo etichetta="Prov." htmlFor="provincia" errore={errors.provincia?.message} className="sm:col-span-1">
            <Input id="provincia" maxLength={2} className="uppercase" aria-invalid={!!errors.provincia} {...register('provincia')} />
          </Campo>
          <Campo etichetta="Nazione" htmlFor="nazione" errore={errors.nazione?.message} className="sm:col-span-1">
            <Input id="nazione" maxLength={2} className="uppercase" {...register('nazione')} />
          </Campo>
        </div>
        {/* Pulsanti */}
        <PiedeDialog>
          <Button variante="secondario" onClick={onChiudi}>Annulla</Button>
          <Button type="submit" caricamento={isSubmitting}>Salva</Button>
        </PiedeDialog>
      </form>
    </Dialog>
  );
}

// Scheda con l'elenco delle sedi
export function SchedaSedi({ clienteId, modificabile }: { clienteId: string; modificabile: boolean }) {
  // Dati
  const { data, isLoading } = useSedi(clienteId);
  // Sede in modifica (null = nessuna, "nuova" = creazione)
  const [inModifica, setInModifica] = useState<Sede | 'nuova' | null>(null);
  // Sede da eliminare
  const [daEliminare, setDaEliminare] = useState<Sede | null>(null);
  // Mutation di eliminazione
  const elimina = useEliminaSede(clienteId);

  // Caricamento
  if (isLoading) return <Skeleton className="h-24" />;

  return (
    <div className="space-y-3">
      {/* Pulsante nuova sede */}
      {modificabile && (
        <div className="flex justify-end">
          <Button variante="secondario" dimensione="piccolo" onClick={() => setInModifica('nuova')}>
            <Plus /> Aggiungi sede
          </Button>
        </div>
      )}
      {/* Nessuna sede */}
      {data?.length === 0 && <p className="py-6 text-center text-sm text-slate-500">Nessuna sede registrata</p>}
      {/* Card delle sedi */}
      <div className="grid gap-3 md:grid-cols-2">
        {data?.map((s) => (
          <Card key={s.id} className="flex gap-3 p-4">
            <MapPin className="mt-0.5 size-4 shrink-0 text-slate-400" aria-hidden />
            <div className="min-w-0 flex-1 text-sm">
              {/* Tipo e nome */}
              <div className="flex items-center gap-2">
                <Badge colore={s.tipo === 'legale' ? 'blu' : 'grigio'}>{TIPI_SEDE[s.tipo]}</Badge>
                {s.nome && <span className="font-medium text-slate-900">{s.nome}</span>}
              </div>
              {/* Indirizzo completo */}
              <p className="mt-2 text-slate-700">{s.indirizzo}</p>
              <p className="text-slate-500">{[s.cap, s.citta, s.provincia && `(${s.provincia})`, s.nazione !== 'IT' && s.nazione].filter(Boolean).join(' ')}</p>
            </div>
            {/* Azioni */}
            {modificabile && (
              <Menu
                grilletto={<Button variante="fantasma" dimensione="icona" aria-label="Azioni sede"><MoreHorizontal /></Button>}
                voci={[
                  { etichetta: 'Modifica', icona: <Pencil />, onSelect: () => setInModifica(s) },
                  { etichetta: 'Elimina', icona: <Trash2 />, onSelect: () => setDaEliminare(s), pericolo: true },
                ]}
              />
            )}
          </Card>
        ))}
      </div>
      {/* Finestra di modifica */}
      {inModifica && <FormSede clienteId={clienteId} sede={inModifica === 'nuova' ? undefined : inModifica} onChiudi={() => setInModifica(null)} />}
      {/* Conferma eliminazione */}
      <ConfermaDialog
        aperto={!!daEliminare}
        onChiudi={() => setDaEliminare(null)}
        caricamento={elimina.isPending}
        onConferma={() => daEliminare && elimina.mutate(daEliminare.id, { onSuccess: () => setDaEliminare(null), onError: notificaErrore })}
        titolo="Eliminare la sede?"
        messaggio="I contatti collegati a questa sede resteranno associati al cliente."
      />
    </div>
  );
}

// ----------------------------------- Contatti ---------------------------------------

// Tipi del form contatto
type IngressoContatto = z.input<typeof creaContattoSchema>;
type UscitaContatto = z.output<typeof creaContattoSchema>;

// Finestra di creazione/modifica contatto
function FormContatto({ clienteId, contatto, onChiudi }: { clienteId: string; contatto?: Contatto; onChiudi: () => void }) {
  // Mutation
  const salva = useSalvaContatto(clienteId);
  // Sedi per la select
  const { data: sedi } = useSedi(clienteId);
  // Form
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<IngressoContatto, unknown, UscitaContatto>({
    resolver: zodResolver(creaContattoSchema),
    defaultValues: {
      nome: contatto?.nome ?? '',
      cognome: contatto?.cognome ?? '',
      ruoloAziendale: contatto?.ruoloAziendale ?? '',
      email: contatto?.email ?? '',
      telefono: contatto?.telefono ?? '',
      cellulare: contatto?.cellulare ?? '',
      principale: contatto?.principale ?? false,
      sedeId: contatto?.sedeId ?? null,
      note: contatto?.note ?? '',
    },
  });
  // Mostra il valore corretto nella select anche se le sedi arrivano dopo l'apertura
  useAllineaSelect(setValue, getValues, ['sedeId'], [sedi]);

  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      await salva.mutateAsync({ id: contatto?.id, dati });
      toast.success('Contatto salvato');
      onChiudi();
    } catch (errore) {
      applicaErroriForm(errore, setError);
    }
  });

  return (
    <Dialog aperto onChiudi={onChiudi} titolo={contatto ? 'Modifica contatto' : 'Nuovo contatto'} larghezza="lg">
      <form onSubmit={invia} noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          {/* Nome e cognome */}
          <Campo etichetta="Nome" htmlFor="c-nome" obbligatorio errore={errors.nome?.message}>
            <Input id="c-nome" autoFocus aria-invalid={!!errors.nome} {...register('nome')} />
          </Campo>
          <Campo etichetta="Cognome" htmlFor="c-cognome" errore={errors.cognome?.message}>
            <Input id="c-cognome" {...register('cognome')} />
          </Campo>
          {/* Ruolo e sede */}
          <Campo etichetta="Ruolo in azienda" htmlFor="c-ruolo" errore={errors.ruoloAziendale?.message}>
            <Input id="c-ruolo" placeholder="Es. Responsabile IT" {...register('ruoloAziendale')} />
          </Campo>
          <Campo etichetta="Sede" htmlFor="c-sede" errore={errors.sedeId?.message}>
            <Select id="c-sede" {...register('sedeId', { setValueAs: (v: string) => v || null })}>
              <option value="">— Nessuna —</option>
              {sedi?.map((s) => (
                <option key={s.id} value={s.id}>{s.nome ?? TIPI_SEDE[s.tipo]} · {s.citta}</option>
              ))}
            </Select>
          </Campo>
          {/* Recapiti */}
          <Campo etichetta="Email" htmlFor="c-email" errore={errors.email?.message}>
            <Input id="c-email" type="email" aria-invalid={!!errors.email} {...register('email')} />
          </Campo>
          <Campo etichetta="Telefono" htmlFor="c-telefono" errore={errors.telefono?.message}>
            <Input id="c-telefono" type="tel" aria-invalid={!!errors.telefono} {...register('telefono')} />
          </Campo>
          <Campo etichetta="Cellulare" htmlFor="c-cellulare" errore={errors.cellulare?.message}>
            <Input id="c-cellulare" type="tel" aria-invalid={!!errors.cellulare} {...register('cellulare')} />
          </Campo>
          {/* Contatto principale */}
          <label className="flex items-center gap-2 self-end pb-2 text-sm text-slate-700">
            <input type="checkbox" className="size-4 rounded border-slate-300 text-primario-600" {...register('principale')} />
            Contatto principale
          </label>
          {/* Note */}
          <Campo etichetta="Note" htmlFor="c-note" className="sm:col-span-2">
            <Textarea id="c-note" rows={2} {...register('note')} />
          </Campo>
        </div>
        {/* Pulsanti */}
        <PiedeDialog>
          <Button variante="secondario" onClick={onChiudi}>Annulla</Button>
          <Button type="submit" caricamento={isSubmitting}>Salva</Button>
        </PiedeDialog>
      </form>
    </Dialog>
  );
}

// Scheda con l'elenco dei contatti
export function SchedaContatti({ clienteId, modificabile }: { clienteId: string; modificabile: boolean }) {
  // Dati
  const { data, isLoading } = useContatti(clienteId);
  // Contatto in modifica
  const [inModifica, setInModifica] = useState<Contatto | 'nuovo' | null>(null);
  // Contatto da eliminare
  const [daEliminare, setDaEliminare] = useState<Contatto | null>(null);
  // Mutation eliminazione
  const elimina = useEliminaContatto(clienteId);

  // Caricamento
  if (isLoading) return <Skeleton className="h-24" />;

  return (
    <div className="space-y-3">
      {/* Pulsante nuovo contatto */}
      {modificabile && (
        <div className="flex justify-end">
          <Button variante="secondario" dimensione="piccolo" onClick={() => setInModifica('nuovo')}>
            <Plus /> Aggiungi contatto
          </Button>
        </div>
      )}
      {/* Nessun contatto */}
      {data?.length === 0 && <p className="py-6 text-center text-sm text-slate-500">Nessun contatto registrato</p>}
      {/* Card dei contatti */}
      <div className="grid gap-3 md:grid-cols-2">
        {data?.map((c) => (
          <Card key={c.id} className="flex gap-3 p-4">
            <div className="min-w-0 flex-1 text-sm">
              {/* Nome, ruolo e badge principale */}
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-medium text-slate-900">{c.nome} {c.cognome}</span>
                {c.principale && (
                  <Badge colore="giallo">
                    <Star className="mr-1 size-3" aria-hidden /> Principale
                  </Badge>
                )}
              </div>
              {c.ruoloAziendale && <p className="text-slate-500">{c.ruoloAziendale}</p>}
              {/* Recapiti cliccabili */}
              <div className="mt-2 space-y-1 text-slate-700">
                {c.email && <a href={`mailto:${c.email}`} className="flex items-center gap-2 hover:text-primario-700"><Mail className="size-3.5 text-slate-400" aria-hidden />{c.email}</a>}
                {c.telefono && <a href={`tel:${c.telefono}`} className="flex items-center gap-2 hover:text-primario-700"><Phone className="size-3.5 text-slate-400" aria-hidden />{c.telefono}</a>}
                {c.cellulare && <a href={`tel:${c.cellulare}`} className="flex items-center gap-2 hover:text-primario-700"><Smartphone className="size-3.5 text-slate-400" aria-hidden />{c.cellulare}</a>}
              </div>
            </div>
            {/* Azioni */}
            {modificabile && (
              <Menu
                grilletto={<Button variante="fantasma" dimensione="icona" aria-label="Azioni contatto"><MoreHorizontal /></Button>}
                voci={[
                  { etichetta: 'Modifica', icona: <Pencil />, onSelect: () => setInModifica(c) },
                  { etichetta: 'Elimina', icona: <Trash2 />, onSelect: () => setDaEliminare(c), pericolo: true },
                ]}
              />
            )}
          </Card>
        ))}
      </div>
      {/* Finestra di modifica */}
      {inModifica && <FormContatto clienteId={clienteId} contatto={inModifica === 'nuovo' ? undefined : inModifica} onChiudi={() => setInModifica(null)} />}
      {/* Conferma eliminazione */}
      <ConfermaDialog
        aperto={!!daEliminare}
        onChiudi={() => setDaEliminare(null)}
        caricamento={elimina.isPending}
        onConferma={() => daEliminare && elimina.mutate(daEliminare.id, { onSuccess: () => setDaEliminare(null), onError: notificaErrore })}
        titolo="Eliminare il contatto?"
        messaggio={<>I dati di <strong>{daEliminare?.nome} {daEliminare?.cognome}</strong> verranno cancellati definitivamente.</>}
      />
    </div>
  );
}
