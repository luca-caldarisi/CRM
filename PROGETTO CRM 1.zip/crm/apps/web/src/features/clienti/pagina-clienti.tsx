// =====================================================================================
// Elenco clienti con ricerca, ordinamento e paginazione
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il router
import { useNavigate } from 'react-router';
// Importa le icone
import { Plus } from 'lucide-react';
// Importa il tipo condiviso
import type { ClienteLista } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Badge, Card } from '@/components/ui/elementi';
import { CampoRicerca, IntestazionePagina, StatoErrore } from '@/components/common/pagina';
import { Paginazione, Tabella, type Colonna } from '@/components/common/tabella';
// Importa hook e utilità
import { useClienti } from './api';
import { FormCliente } from './form-cliente';
import { usePermesso } from '@/lib/auth';
import { useFiltriUrl } from '@/lib/hooks';
import { nomeCompleto } from '@/lib/utils';

// Colonne della tabella
const COLONNE: Colonna<ClienteLista>[] = [
  {
    id: 'ragioneSociale',
    titolo: 'Cliente',
    ordinabile: 'ragioneSociale',
    // Ragione sociale in evidenza con codice sotto
    cella: (c) => (
      <div>
        <p className="font-medium text-slate-900">{c.ragioneSociale}</p>
        <p className="text-xs text-slate-500">{c.codice}</p>
      </div>
    ),
  },
  // Colonne secondarie nascoste su schermi piccoli
  { id: 'partitaIva', titolo: 'P. IVA', cella: (c) => c.partitaIva ?? '—', className: 'hidden md:table-cell' },
  { id: 'citta', titolo: 'Città', cella: (c) => c.citta ?? '—', className: 'hidden lg:table-cell' },
  { id: 'contatti', titolo: 'Contatti', cella: (c) => <span className="text-xs">{c.email ?? c.telefono ?? '—'}</span>, className: 'hidden xl:table-cell' },
  { id: 'commerciale', titolo: 'Commerciale', cella: (c) => nomeCompleto(c.commerciale), className: 'hidden md:table-cell' },
  // Contatore commesse attive
  { id: 'commesse', titolo: 'Commesse', cella: (c) => (c.numeroCommesseAperte > 0 ? <Badge colore="blu">{c.numeroCommesseAperte} attive</Badge> : <span className="text-slate-400">—</span>), className: 'text-right' },
];

export function PaginaClienti() {
  // Navigazione
  const naviga = useNavigate();
  // Filtri salvati nell'URL
  const { filtri, page, imposta } = useFiltriUrl(['q', 'sort'] as const);
  // Finestra di creazione
  const [nuovo, setNuovo] = useState(false);
  // Permesso di creazione (per mostrare il pulsante)
  const puoCreare = usePermesso('clienti.write');
  // Dati
  const { data, isLoading, isError } = useClienti({ q: filtri.q, sort: filtri.sort, page });

  return (
    <>
      {/* Intestazione */}
      <IntestazionePagina
        titolo="Clienti"
        sottotitolo={data ? `${data.meta.total} clienti` : undefined}
        azioni={
          puoCreare && (
            <Button onClick={() => setNuovo(true)}>
              <Plus /> Nuovo cliente
            </Button>
          )
        }
      />
      {/* Errore */}
      {isError && <StatoErrore />}
      {/* Tabella */}
      <Card>
        {/* Barra filtri */}
        <div className="border-b border-slate-200 p-3">
          <CampoRicerca valore={filtri.q} onCambia={(q) => imposta({ q })} segnaposto="Cerca per nome, codice, P.IVA, email…" />
        </div>
        <Tabella
          colonne={COLONNE}
          righe={data?.data}
          chiave={(c) => c.id}
          caricamento={isLoading}
          ordinamento={filtri.sort || 'ragioneSociale'}
          onOrdina={(sort) => imposta({ sort })}
          onClickRiga={(c) => naviga(`/clienti/${c.id}`)}
          vuoto={filtri.q ? 'Nessun cliente corrisponde alla ricerca' : 'Nessun cliente registrato'}
        />
        {/* Paginazione */}
        {data && <Paginazione {...data.meta} onCambia={(p) => imposta({ page: p })} />}
      </Card>
      {/* Finestra nuovo cliente (montata solo quando serve) */}
      {nuovo && <FormCliente aperto onChiudi={() => setNuovo(false)} />}
    </>
  );
}
