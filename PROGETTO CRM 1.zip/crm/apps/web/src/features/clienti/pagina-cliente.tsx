// =====================================================================================
// Scheda di dettaglio di un cliente
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il router
import { useNavigate, useParams, useSearchParams } from 'react-router';
// Importa le icone
import { MoreHorizontal, Pencil, Trash2 } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa componenti
import { Button } from '@/components/ui/button';
import { ConfermaDialog } from '@/components/ui/dialog';
import { Badge, Card, CardHeader, Skeleton } from '@/components/ui/elementi';
import { Menu, Tabs } from '@/components/ui/menu-tabs';
import { DatoDettaglio, IntestazionePagina, StatoErrore } from '@/components/common/pagina';
// Importa funzionalità collegate
import { useCliente, useEliminaCliente } from './api';
import { FormCliente } from './form-cliente';
import { SchedaContatti, SchedaSedi } from './sedi-contatti';
import { ElencoCommesseCliente } from '@/features/commesse/elenco-commesse-cliente';
import { ElencoProgettiCollegati } from '@/features/progetti/elenco-progetti-collegati';
import { PannelloAllegati } from '@/features/allegati/pannello-allegati';
import { StoricoAttivita } from '@/features/audit/storico-attivita';
// Importa permessi, errori e utilità
import { usePermesso } from '@/lib/auth';
import { notificaErrore } from '@/lib/errori';
import { ErroreApi } from '@/lib/api';
import { formattaDataOra, nomeCompleto } from '@/lib/utils';

export function PaginaCliente() {
  // Identificativo dall'URL
  const { id = '' } = useParams();
  // Navigazione
  const naviga = useNavigate();
  // Scheda attiva salvata nell'URL (?scheda=contatti)
  const [params, setParams] = useSearchParams();
  const scheda = params.get('scheda') ?? 'panoramica';
  // Stato delle finestre
  const [modifica, setModifica] = useState(false);
  const [conferma, setConferma] = useState(false);
  // Dati del cliente
  const { data: cliente, isLoading, error } = useCliente(id);
  // Eliminazione
  const elimina = useEliminaCliente();
  // Permessi (solo interfaccia)
  const puoModificare = usePermesso('clienti.write');
  const puoEliminare = usePermesso('clienti.delete');
  const puoVedereAudit = usePermesso('audit.read');
  const puoVedereCommesse = usePermesso('commesse.read');
  // Scheda progetti visibile solo a chi può leggere i progetti
  const puoVedereProgetti = usePermesso('progetti.read');

  // Cliente inesistente o fuori ambito
  if (error instanceof ErroreApi && error.status === 404) return <StatoErrore messaggio="Cliente non trovato o non accessibile." />;
  // Altri errori
  if (error) return <StatoErrore />;
  // Caricamento
  if (isLoading || !cliente) return <Skeleton className="h-64" />;

  return (
    <>
      {/* Intestazione con azioni */}
      <IntestazionePagina
        briciole={[{ etichetta: 'Clienti', a: '/clienti' }, { etichetta: cliente.ragioneSociale }]}
        titolo={cliente.ragioneSociale}
        sottotitolo={
          <span className="flex flex-wrap items-center gap-2">
            <Badge>{cliente.codice}</Badge>
            {cliente.partitaIva && <span>P.IVA {cliente.partitaIva}</span>}
          </span>
        }
        azioni={
          <>
            {puoModificare && (
              <Button variante="secondario" onClick={() => setModifica(true)}>
                <Pencil /> Modifica
              </Button>
            )}
            <Menu
              grilletto={<Button variante="secondario" dimensione="icona" aria-label="Altre azioni"><MoreHorizontal /></Button>}
              voci={[{ etichetta: 'Elimina cliente', icona: <Trash2 />, onSelect: () => setConferma(true), pericolo: true, nascosta: !puoEliminare }]}
            />
          </>
        }
      />

      {/* Schede */}
      <Tabs
        attiva={scheda}
        onCambia={(s) => setParams({ scheda: s }, { replace: true })}
        schede={[
          {
            id: 'panoramica',
            etichetta: 'Panoramica',
            contenuto: (
              <div className="grid gap-4 lg:grid-cols-3">
                {/* Dati anagrafici */}
                <Card className="lg:col-span-2">
                  <CardHeader titolo="Dati anagrafici" />
                  <dl className="grid gap-x-6 gap-y-4 p-5 sm:grid-cols-2">
                    <DatoDettaglio etichetta="Partita IVA">{cliente.partitaIva}</DatoDettaglio>
                    <DatoDettaglio etichetta="Codice fiscale">{cliente.codiceFiscale}</DatoDettaglio>
                    <DatoDettaglio etichetta="Codice SDI">{cliente.codiceSdi}</DatoDettaglio>
                    <DatoDettaglio etichetta="PEC">{cliente.pec && <a className="text-primario-700 hover:underline" href={`mailto:${cliente.pec}`}>{cliente.pec}</a>}</DatoDettaglio>
                    <DatoDettaglio etichetta="Email">{cliente.email && <a className="text-primario-700 hover:underline" href={`mailto:${cliente.email}`}>{cliente.email}</a>}</DatoDettaglio>
                    <DatoDettaglio etichetta="Telefono">{cliente.telefono && <a className="text-primario-700 hover:underline" href={`tel:${cliente.telefono}`}>{cliente.telefono}</a>}</DatoDettaglio>
                    <DatoDettaglio etichetta="Sito web">{cliente.sitoWeb}</DatoDettaglio>
                    <DatoDettaglio etichetta="Commerciale">{cliente.commerciale && nomeCompleto(cliente.commerciale)}</DatoDettaglio>
                  </dl>
                </Card>
                {/* Note e informazioni di sistema */}
                <Card>
                  <CardHeader titolo="Note" />
                  <div className="space-y-4 p-5">
                    {/* Le note mantengono gli a capo */}
                    <p className="whitespace-pre-line text-sm text-slate-700">{cliente.note || <span className="text-slate-400">Nessuna nota</span>}</p>
                    <div className="border-t border-slate-100 pt-4 text-xs text-slate-500">
                      <p>Creato il {formattaDataOra(cliente.createdAt)}</p>
                      <p>Aggiornato il {formattaDataOra(cliente.updatedAt)}</p>
                    </div>
                  </div>
                </Card>
              </div>
            ),
          },
          { id: 'sedi', etichetta: 'Sedi', contenuto: <SchedaSedi clienteId={id} modificabile={puoModificare} /> },
          { id: 'contatti', etichetta: 'Contatti', contenuto: <SchedaContatti clienteId={id} modificabile={puoModificare} /> },
          { id: 'commesse', etichetta: 'Commesse', contenuto: <ElencoCommesseCliente cliente={cliente} />, nascosta: !puoVedereCommesse },
          { id: 'progetti', etichetta: 'Progetti', contenuto: <ElencoProgettiCollegati cliente={cliente} />, nascosta: !puoVedereProgetti },
          { id: 'documenti', etichetta: 'Documenti', contenuto: <PannelloAllegati entita="cliente" entitaId={id} modificabile={puoModificare} /> },
          { id: 'attivita', etichetta: 'Attività', contenuto: <StoricoAttivita entita="cliente" entitaId={id} />, nascosta: !puoVedereAudit },
        ]}
      />

      {/* Finestra di modifica */}
      {modifica && <FormCliente aperto cliente={cliente} onChiudi={() => setModifica(false)} />}
      {/* Conferma eliminazione */}
      <ConfermaDialog
        aperto={conferma}
        onChiudi={() => setConferma(false)}
        caricamento={elimina.isPending}
        onConferma={() =>
          elimina.mutate(id, {
            onSuccess: () => {
              toast.success('Cliente eliminato');
              naviga('/clienti');
            },
            onError: (e) => {
              setConferma(false);
              notificaErrore(e);
            },
          })
        }
        titolo="Eliminare il cliente?"
        messaggio={<>Il cliente <strong>{cliente.ragioneSociale}</strong> non sarà più visibile. Lo storico resta nel registro attività. Non è possibile eliminare clienti con commesse aperte.</>}
      />
    </>
  );
}
