// =====================================================================================
// Finestra di creazione/modifica di un cliente
// =====================================================================================

// Importa il router
import { useNavigate } from 'react-router';
// Importa il form e l'integrazione Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le notifiche
import { toast } from 'sonner';
// Importa Zod per i tipi
import type { z } from 'zod';
// Importa schema e tipi condivisi
import { creaClienteSchema, type Cliente } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input, Select, Textarea } from '@/components/ui/campi';
import { Dialog, PiedeDialog } from '@/components/ui/dialog';
// Importa hook e utilità
import { useAggiornaCliente, useCreaCliente } from './api';
import { useOpzioniUtenti } from '@/features/amministrazione-api';
import { useAmbito } from '@/lib/auth';
// Importa l'hook che riallinea le select con opzioni asincrone
import { useAllineaSelect } from '@/lib/hooks';
import { applicaErroriForm } from '@/lib/errori';

// Tipi dei valori del form (prima e dopo la validazione)
type Ingresso = z.input<typeof creaClienteSchema>;
type Uscita = z.output<typeof creaClienteSchema>;

// Proprietà della finestra
interface ProprietaForm {
  aperto: boolean;
  onChiudi: () => void;
  // Cliente da modificare (assente = nuovo cliente)
  cliente?: Cliente;
}

export function FormCliente({ aperto, onChiudi, cliente }: ProprietaForm) {
  // Navigazione (dopo la creazione si apre la scheda)
  const naviga = useNavigate();
  // Mutation di creazione e modifica
  const crea = useCreaCliente();
  const aggiorna = useAggiornaCliente(cliente?.id ?? '');
  // Utenti per la scelta del commerciale
  const { data: utenti } = useOpzioniUtenti();
  // Con ambito "propri" il commerciale è sempre l'utente stesso: il campo non si mostra
  const puoAssegnare = useAmbito('clienti.write') === 'tutti';

  // Form: i valori null diventano stringhe vuote per gli input HTML
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<Ingresso, unknown, Uscita>({
    resolver: zodResolver(creaClienteSchema),
    values: {
      ragioneSociale: cliente?.ragioneSociale ?? '',
      partitaIva: cliente?.partitaIva ?? '',
      codiceFiscale: cliente?.codiceFiscale ?? '',
      codiceSdi: cliente?.codiceSdi ?? '',
      pec: cliente?.pec ?? '',
      email: cliente?.email ?? '',
      telefono: cliente?.telefono ?? '',
      sitoWeb: cliente?.sitoWeb ?? '',
      note: cliente?.note ?? '',
      commercialeId: cliente?.commerciale?.id ?? null,
    },
  });
  // Mostra il valore corretto nelle select anche se le opzioni arrivano dopo l'apertura
  useAllineaSelect(setValue, getValues, ['commercialeId'], [utenti]);

  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      if (cliente) {
        // Modifica
        await aggiorna.mutateAsync(dati);
        toast.success('Cliente aggiornato');
        onChiudi();
      } else {
        // Creazione e apertura della scheda
        const nuovo = await crea.mutateAsync(dati);
        toast.success(`Cliente ${nuovo.codice} creato`);
        onChiudi();
        naviga(`/clienti/${nuovo.id}`);
      }
    } catch (errore) {
      // Errori di validazione sui campi, altri come notifica
      applicaErroriForm(errore, setError);
    }
  });

  return (
    <Dialog aperto={aperto} onChiudi={onChiudi} titolo={cliente ? 'Modifica cliente' : 'Nuovo cliente'} descrizione={cliente?.codice} larghezza="lg">
      <form onSubmit={invia} noValidate>
        {/* Griglia a due colonne su schermi medi */}
        <div className="grid gap-4 sm:grid-cols-2">
          {/* Ragione sociale su tutta la larghezza */}
          <Campo etichetta="Ragione sociale" htmlFor="ragioneSociale" obbligatorio errore={errors.ragioneSociale?.message} className="sm:col-span-2">
            <Input id="ragioneSociale" autoFocus aria-invalid={!!errors.ragioneSociale} {...register('ragioneSociale')} />
          </Campo>
          {/* Dati fiscali */}
          <Campo etichetta="Partita IVA" htmlFor="partitaIva" errore={errors.partitaIva?.message}>
            <Input id="partitaIva" aria-invalid={!!errors.partitaIva} {...register('partitaIva')} />
          </Campo>
          <Campo etichetta="Codice fiscale" htmlFor="codiceFiscale" errore={errors.codiceFiscale?.message}>
            <Input id="codiceFiscale" aria-invalid={!!errors.codiceFiscale} {...register('codiceFiscale')} />
          </Campo>
          <Campo etichetta="Codice SDI" htmlFor="codiceSdi" errore={errors.codiceSdi?.message}>
            <Input id="codiceSdi" maxLength={7} aria-invalid={!!errors.codiceSdi} {...register('codiceSdi')} />
          </Campo>
          <Campo etichetta="PEC" htmlFor="pec" errore={errors.pec?.message}>
            <Input id="pec" type="email" aria-invalid={!!errors.pec} {...register('pec')} />
          </Campo>
          {/* Contatti generali */}
          <Campo etichetta="Email" htmlFor="email" errore={errors.email?.message}>
            <Input id="email" type="email" aria-invalid={!!errors.email} {...register('email')} />
          </Campo>
          <Campo etichetta="Telefono" htmlFor="telefono" errore={errors.telefono?.message}>
            <Input id="telefono" type="tel" aria-invalid={!!errors.telefono} {...register('telefono')} />
          </Campo>
          <Campo etichetta="Sito web" htmlFor="sitoWeb" errore={errors.sitoWeb?.message}>
            <Input id="sitoWeb" placeholder="www.esempio.it" aria-invalid={!!errors.sitoWeb} {...register('sitoWeb')} />
          </Campo>
          {/* Commerciale di riferimento: stringa vuota convertita in null */}
          {puoAssegnare && (
            <Campo etichetta="Commerciale di riferimento" htmlFor="commercialeId" errore={errors.commercialeId?.message}>
              <Select id="commercialeId" {...register('commercialeId', { setValueAs: (v: string) => v || null })}>
                <option value="">— Nessuno —</option>
                {utenti?.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.cognome} {u.nome}
                  </option>
                ))}
              </Select>
            </Campo>
          )}
          {/* Note */}
          <Campo etichetta="Note" htmlFor="note" errore={errors.note?.message} className="sm:col-span-2">
            <Textarea id="note" rows={3} {...register('note')} />
          </Campo>
        </div>
        {/* Pulsanti */}
        <PiedeDialog>
          <Button variante="secondario" onClick={onChiudi}>
            Annulla
          </Button>
          <Button type="submit" caricamento={isSubmitting}>
            {cliente ? 'Salva modifiche' : 'Crea cliente'}
          </Button>
        </PiedeDialog>
      </form>
    </Dialog>
  );
}
