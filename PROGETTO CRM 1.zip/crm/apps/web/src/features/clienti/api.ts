// =====================================================================================
// Hook per leggere e modificare clienti, sedi e contatti tramite TanStack Query
// -------------------------------------------------------------------------------------
// Le "query" leggono e memorizzano i dati in cache; le "mutation" li modificano e
// invalidano la cache interessata, così tutte le schermate si aggiornano da sole.
// =====================================================================================

// Importa le funzioni di TanStack Query
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
// Importa i tipi condivisi
import type { AggiornaClienteInput, Cliente, ClienteLista, Contatto, CreaClienteInput, CreaContattoInput, CreaSedeInput, RispostaPaginata, Sede } from '@crm/shared';
// Importa il client API
import { api } from '@/lib/api';

// Chiavi della cache: struttura gerarchica per invalidare in blocco
export const chiaviClienti = {
  // Tutto ciò che riguarda i clienti
  tutti: ['clienti'] as const,
  // Liste con filtri
  lista: (filtri: object) => ['clienti', 'lista', filtri] as const,
  // Singolo cliente
  dettaglio: (id: string) => ['clienti', 'dettaglio', id] as const,
  // Sedi di un cliente
  sedi: (id: string) => ['clienti', 'dettaglio', id, 'sedi'] as const,
  // Contatti di un cliente
  contatti: (id: string) => ['clienti', 'dettaglio', id, 'contatti'] as const,
};

// Filtri della lista clienti
export interface FiltriClienti {
  q?: string;
  page?: number;
  pageSize?: number;
  sort?: string;
  commercialeId?: string;
}

// Lista paginata dei clienti
// "abilitato" permette di non eseguire la query (es. utente senza permesso)
export function useClienti(filtri: FiltriClienti, abilitato = true) {
  return useQuery({
    enabled: abilitato,
    queryKey: chiaviClienti.lista(filtri),
    queryFn: ({ signal }) => api<RispostaPaginata<ClienteLista>>('/clienti', { query: { ...filtri }, signal }),
    // Durante il cambio pagina mantiene visibili i dati precedenti (niente "salti" della tabella)
    placeholderData: keepPreviousData,
  });
}

// Dettaglio di un cliente
export function useCliente(id: string) {
  return useQuery({ queryKey: chiaviClienti.dettaglio(id), queryFn: ({ signal }) => api<Cliente>(`/clienti/${id}`, { signal }) });
}

// Creazione cliente
export function useCreaCliente() {
  // Accesso alla cache
  const qc = useQueryClient();
  return useMutation({
    // Chiamata POST
    mutationFn: (dati: CreaClienteInput) => api<Cliente>('/clienti', { method: 'POST', body: dati }),
    // Al termine invalida tutte le liste clienti
    onSuccess: () => qc.invalidateQueries({ queryKey: chiaviClienti.tutti }),
  });
}

// Modifica cliente
export function useAggiornaCliente(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (dati: AggiornaClienteInput) => api<Cliente>(`/clienti/${id}`, { method: 'PATCH', body: dati }),
    onSuccess: (cliente) => {
      // Aggiorna subito il dettaglio in cache con la risposta del server
      qc.setQueryData(chiaviClienti.dettaglio(id), cliente);
      // Invalida le liste
      void qc.invalidateQueries({ queryKey: chiaviClienti.tutti });
    },
  });
}

// Eliminazione cliente
export function useEliminaCliente() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api<void>(`/clienti/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: chiaviClienti.tutti }),
  });
}

// ------------------------------------- Sedi -----------------------------------------

// Sedi di un cliente
export function useSedi(clienteId: string) {
  return useQuery({ queryKey: chiaviClienti.sedi(clienteId), queryFn: ({ signal }) => api<Sede[]>(`/clienti/${clienteId}/sedi`, { signal }) });
}

// Creazione o modifica di una sede (id presente = modifica)
export function useSalvaSede(clienteId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, dati }: { id?: string; dati: CreaSedeInput }) =>
      id ? api<Sede>(`/sedi/${id}`, { method: 'PATCH', body: dati }) : api<Sede>(`/clienti/${clienteId}/sedi`, { method: 'POST', body: dati }),
    // Aggiorna sedi e lista (la città della sede legale compare nella lista)
    onSuccess: () => qc.invalidateQueries({ queryKey: chiaviClienti.tutti }),
  });
}

// Eliminazione sede
export function useEliminaSede(clienteId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api<void>(`/sedi/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: chiaviClienti.sedi(clienteId) });
      void qc.invalidateQueries({ queryKey: chiaviClienti.contatti(clienteId) });
    },
  });
}

// ----------------------------------- Contatti ---------------------------------------

// Contatti di un cliente
export function useContatti(clienteId: string) {
  return useQuery({ queryKey: chiaviClienti.contatti(clienteId), queryFn: ({ signal }) => api<Contatto[]>(`/clienti/${clienteId}/contatti`, { signal }) });
}

// Creazione o modifica di un contatto
export function useSalvaContatto(clienteId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, dati }: { id?: string; dati: CreaContattoInput }) =>
      id ? api<Contatto>(`/contatti/${id}`, { method: 'PATCH', body: dati }) : api<Contatto>(`/clienti/${clienteId}/contatti`, { method: 'POST', body: dati }),
    onSuccess: () => qc.invalidateQueries({ queryKey: chiaviClienti.contatti(clienteId) }),
  });
}

// Eliminazione contatto
export function useEliminaContatto(clienteId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api<void>(`/contatti/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: chiaviClienti.contatti(clienteId) }),
  });
}
