// =====================================================================================
// Dashboard iniziale (Fase 1): contatori principali e ultime commesse
// I KPI completi (scadenze, ore, fatturato) arriveranno con i moduli delle fasi successive.
// =====================================================================================

// Importa il router
import { Link, useNavigate } from 'react-router';
// Importa le icone
import { ArrowRight, Briefcase, Building2, PauseCircle } from 'lucide-react';
// Importa componenti
import { Card, CardHeader, Skeleton } from '@/components/ui/elementi';
import { IntestazionePagina } from '@/components/common/pagina';
import { Tabella } from '@/components/common/tabella';
// Importa hook e utilità
import { useClienti } from '@/features/clienti/api';
import { useCommesse } from '@/features/commesse/api';
import { colonneCommesse } from '@/features/commesse/pagina-commesse';
import { useAuth, usePermesso } from '@/lib/auth';

// Riquadro con un numero chiave
function Indicatore({ etichetta, valore, icona: Icona, a }: { etichetta: string; valore: number | undefined; icona: typeof Building2; a: string }) {
  return (
    // L'intero riquadro è un link alla lista corrispondente
    <Link to={a} className="group">
      <Card className="flex items-center gap-4 p-5 transition-shadow group-hover:shadow-md">
        {/* Icona */}
        <span className="flex size-10 items-center justify-center rounded-lg bg-primario-50 text-primario-600">
          <Icona className="size-5" aria-hidden />
        </span>
        {/* Valore ed etichetta */}
        <div>
          {valore === undefined ? <Skeleton className="h-7 w-12" /> : <p className="text-2xl font-semibold tabular-nums text-slate-900">{valore}</p>}
          <p className="text-sm text-slate-500">{etichetta}</p>
        </div>
      </Card>
    </Link>
  );
}

export function PaginaDashboard() {
  // Utente per il saluto
  const { utente } = useAuth();
  // Navigazione
  const naviga = useNavigate();
  // Permessi
  const vedeClienti = usePermesso('clienti.read');
  const vedeCommesse = usePermesso('commesse.read');
  const vedeEconomici = usePermesso('economici.read');
  // Contatori: si chiede una sola riga e si usa il totale restituito dal server
  const clienti = useClienti({ pageSize: 1 }, vedeClienti);
  const aperte = useCommesse({ stato: 'aperta', pageSize: 1 }, vedeCommesse);
  const sospese = useCommesse({ stato: 'sospesa', pageSize: 1 }, vedeCommesse);
  // Ultime commesse aperte
  const ultime = useCommesse({ stato: 'aperta', pageSize: 5, sort: '-dataApertura' }, vedeCommesse);

  return (
    <>
      {/* Saluto */}
      <IntestazionePagina titolo={`Ciao ${utente?.nome ?? ''}`} sottotitolo="Ecco la situazione di oggi" />
      {/* Indicatori (solo quelli consentiti dal ruolo) */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {vedeClienti && <Indicatore etichetta="Clienti attivi" valore={clienti.data?.meta.total} icona={Building2} a="/clienti" />}
        {vedeCommesse && <Indicatore etichetta="Commesse aperte" valore={aperte.data?.meta.total} icona={Briefcase} a="/commesse?stato=aperta" />}
        {vedeCommesse && <Indicatore etichetta="Commesse sospese" valore={sospese.data?.meta.total} icona={PauseCircle} a="/commesse?stato=sospesa" />}
      </div>
      {/* Ultime commesse */}
      {vedeCommesse && (
        <Card className="mt-6">
          <CardHeader
            titolo="Ultime commesse aperte"
            azioni={
              <Link to="/commesse" className="inline-flex items-center gap-1 text-sm font-medium text-primario-600 hover:text-primario-700">
                Tutte <ArrowRight className="size-4" />
              </Link>
            }
          />
          <Tabella colonne={colonneCommesse(vedeEconomici)} righe={ultime.data?.data} chiave={(c) => c.id} caricamento={ultime.isLoading} onClickRiga={(c) => naviga(`/commesse/${c.id}`)} vuoto="Nessuna commessa aperta" />
        </Card>
      )}
    </>
  );
}
