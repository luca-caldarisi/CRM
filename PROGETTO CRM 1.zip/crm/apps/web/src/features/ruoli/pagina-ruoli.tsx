// =====================================================================================
// Ruoli e permessi: elenco ruoli a sinistra, matrice dei permessi del ruolo selezionato a destra
// =====================================================================================

// Importa React
import { useEffect, useMemo, useState } from 'react';
// Importa il form per il nuovo ruolo
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le icone
import { Lock, Plus, Trash2, Users } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa schemi e tipi condivisi
import { creaRuoloSchema, type Ambito, type CodicePermesso, type CreaRuoloInput, type DefinizionePermesso, type Ruolo } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input } from '@/components/ui/campi';
import { ConfermaDialog, Dialog, PiedeDialog } from '@/components/ui/dialog';
import { Badge, Card, CardHeader, Skeleton } from '@/components/ui/elementi';
import { IntestazionePagina, StatoErrore } from '@/components/common/pagina';
// Importa hook, errori e utilità
import { useCatalogoPermessi, useCreaRuolo, useEliminaRuolo, useImpostaPermessi, useRuoli } from '@/features/amministrazione-api';
import { applicaErroriForm, notificaErrore } from '@/lib/errori';
import { cn } from '@/lib/utils';

// Valore di una cella della matrice: nessun permesso, solo propri, tutti
type ValoreMatrice = Ambito | 'nessuno';

// Selettore a tre posizioni per un singolo permesso
function SelettoreAmbito({ valore, onCambia, supportaPropri, disabilitato, etichetta }: { valore: ValoreMatrice; onCambia: (v: ValoreMatrice) => void; supportaPropri: boolean; disabilitato: boolean; etichetta: string }) {
  // Opzioni disponibili
  const opzioni: Array<{ v: ValoreMatrice; testo: string; nascosta?: boolean }> = [
    { v: 'nessuno', testo: 'No' },
    { v: 'propri', testo: 'Propri', nascosta: !supportaPropri },
    { v: 'tutti', testo: 'Tutti' },
  ];
  return (
    // Gruppo di pulsanti radio accessibile
    <div role="radiogroup" aria-label={etichetta} className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-0.5">
      {opzioni
        .filter((o) => !o.nascosta)
        .map((o) => (
          <button
            key={o.v}
            type="button"
            role="radio"
            aria-checked={valore === o.v}
            disabled={disabilitato}
            onClick={() => onCambia(o.v)}
            className={cn(
              'rounded-md px-2.5 py-1 text-xs font-medium transition-colors disabled:cursor-not-allowed',
              valore === o.v ? (o.v === 'nessuno' ? 'bg-white text-slate-700 shadow-sm' : 'bg-primario-600 text-white shadow-sm') : 'text-slate-500 hover:text-slate-800',
            )}
          >
            {o.testo}
          </button>
        ))}
    </div>
  );
}

// Matrice dei permessi di un ruolo
function MatricePermessi({ ruolo, catalogo }: { ruolo: Ruolo; catalogo: DefinizionePermesso[] }) {
  // Mutation di salvataggio
  const salva = useImpostaPermessi();
  // Stato iniziale ricavato dal ruolo
  const iniziale = useMemo(() => Object.fromEntries(ruolo.permessi.map((p) => [p.codice, p.ambito])) as Partial<Record<CodicePermesso, Ambito>>, [ruolo]);
  // Stato locale modificabile
  const [valori, setValori] = useState(iniziale);
  // Al cambio di ruolo (o dopo il salvataggio) riparte dai dati del server
  useEffect(() => setValori(iniziale), [iniziale]);
  // Modifiche non salvate
  const modificato = JSON.stringify(valori) !== JSON.stringify(iniziale);
  // Il ruolo Admin è in sola lettura
  const bloccato = ruolo.diSistema;
  // Permessi raggruppati per modulo
  const moduli = useMemo(() => {
    // Mappa modulo -> permessi
    const gruppi = new Map<string, DefinizionePermesso[]>();
    for (const p of catalogo) gruppi.set(p.modulo, [...(gruppi.get(p.modulo) ?? []), p]);
    return [...gruppi.entries()];
  }, [catalogo]);

  // Aggiorna un singolo permesso
  const imposta = (codice: CodicePermesso, v: ValoreMatrice) =>
    setValori((attuali) => {
      // Copia
      const nuovi = { ...attuali };
      // "nessuno" rimuove il permesso
      if (v === 'nessuno') delete nuovi[codice];
      else nuovi[codice] = v;
      return nuovi;
    });

  // Salvataggio dell'intera matrice
  const invia = () =>
    salva.mutate(
      { id: ruolo.id, dati: { permessi: Object.entries(valori).map(([codice, ambito]) => ({ codice: codice as CodicePermesso, ambito: ambito! })) } },
      { onSuccess: () => toast.success('Permessi salvati', { description: 'Gli utenti del ruolo li riceveranno alla prossima richiesta.' }), onError: notificaErrore },
    );

  return (
    <Card>
      <CardHeader
        titolo={`Permessi · ${ruolo.nome}`}
        descrizione={bloccato ? 'Il ruolo Admin ha sempre tutti i permessi e non è modificabile.' : '"Propri" limita l\'accesso ai record di cui l\'utente è responsabile.'}
        azioni={
          !bloccato && (
            <>
              {/* Annulla le modifiche locali */}
              {modificato && <Button variante="fantasma" dimensione="piccolo" onClick={() => setValori(iniziale)}>Annulla</Button>}
              {/* Salva */}
              <Button dimensione="piccolo" disabled={!modificato} caricamento={salva.isPending} onClick={invia}>Salva permessi</Button>
            </>
          )
        }
      />
      {/* Gruppi per modulo */}
      <div className="divide-y divide-slate-100">
        {moduli.map(([modulo, permessi]) => (
          <section key={modulo} className="px-5 py-4">
            <h3 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">{modulo}</h3>
            <ul className="space-y-2">
              {permessi.map((p) => (
                <li key={p.codice} className="flex flex-wrap items-center justify-between gap-3">
                  {/* Descrizione e codice tecnico */}
                  <div className="min-w-0">
                    <p className="text-sm text-slate-800">{p.descrizione}</p>
                    <p className="font-mono text-[11px] text-slate-400">{p.codice}</p>
                  </div>
                  {/* Selettore */}
                  <SelettoreAmbito
                    etichetta={p.descrizione}
                    valore={valori[p.codice as CodicePermesso] ?? 'nessuno'}
                    onCambia={(v) => imposta(p.codice as CodicePermesso, v)}
                    supportaPropri={p.supportaPropri}
                    disabilitato={bloccato}
                  />
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </Card>
  );
}

// Finestra di creazione ruolo
function FormRuolo({ onChiudi, onCreato }: { onChiudi: () => void; onCreato: (r: Ruolo) => void }) {
  // Mutation
  const crea = useCreaRuolo();
  // Form
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<CreaRuoloInput>({ resolver: zodResolver(creaRuoloSchema) });
  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      // Crea e seleziona il nuovo ruolo
      const r = await crea.mutateAsync(dati);
      toast.success(`Ruolo ${r.nome} creato`, { description: 'Ora configura i suoi permessi.' });
      onCreato(r);
    } catch (errore) {
      applicaErroriForm(errore, setError);
    }
  });
  return (
    <Dialog aperto onChiudi={onChiudi} titolo="Nuovo ruolo" descrizione="Il ruolo nasce senza permessi.">
      <form onSubmit={invia} noValidate className="space-y-4">
        <Campo etichetta="Nome" htmlFor="r-nome" obbligatorio errore={errors.nome?.message}>
          <Input id="r-nome" autoFocus aria-invalid={!!errors.nome} {...register('nome')} />
        </Campo>
        <Campo etichetta="Descrizione" htmlFor="r-descrizione" errore={errors.descrizione?.message}>
          <Input id="r-descrizione" {...register('descrizione')} />
        </Campo>
        <PiedeDialog>
          <Button variante="secondario" onClick={onChiudi}>Annulla</Button>
          <Button type="submit" caricamento={isSubmitting}>Crea ruolo</Button>
        </PiedeDialog>
      </form>
    </Dialog>
  );
}

export function PaginaRuoli() {
  // Dati
  const { data: ruoli, isLoading, isError } = useRuoli();
  const { data: catalogo } = useCatalogoPermessi();
  // Ruolo selezionato
  const [selezionatoId, setSelezionatoId] = useState<string | null>(null);
  // Finestre
  const [nuovo, setNuovo] = useState(false);
  const [daEliminare, setDaEliminare] = useState<Ruolo | null>(null);
  // Mutation eliminazione
  const elimina = useEliminaRuolo();
  // Ruolo mostrato: quello scelto oppure il primo non di sistema
  const selezionato = ruoli?.find((r) => r.id === selezionatoId) ?? ruoli?.find((r) => !r.diSistema) ?? ruoli?.[0];

  return (
    <>
      <IntestazionePagina
        briciole={[{ etichetta: 'Amministrazione' }, { etichetta: 'Ruoli e permessi' }]}
        titolo="Ruoli e permessi"
        sottotitolo="Le modifiche hanno effetto immediato sugli utenti del ruolo."
        azioni={<Button onClick={() => setNuovo(true)}><Plus /> Nuovo ruolo</Button>}
      />
      {isError && <StatoErrore />}
      {isLoading ? (
        <Skeleton className="h-96" />
      ) : (
        <div className="grid gap-6 lg:grid-cols-[18rem_1fr]">
          {/* Elenco ruoli */}
          <ul className="space-y-2" aria-label="Ruoli">
            {ruoli?.map((r) => (
              <li key={r.id}>
                <div
                  className={cn(
                    'flex items-start gap-3 rounded-lg border bg-white p-3 transition-colors',
                    selezionato?.id === r.id ? 'border-primario-300 ring-2 ring-primario-100' : 'border-slate-200 hover:border-slate-300',
                  )}
                >
                  {/* Area cliccabile per selezionare */}
                  <button type="button" onClick={() => setSelezionatoId(r.id)} className="min-w-0 flex-1 text-left" aria-pressed={selezionato?.id === r.id}>
                    <p className="flex items-center gap-1.5 text-sm font-medium text-slate-900">
                      {r.diSistema && <Lock className="size-3.5 text-slate-400" aria-label="Ruolo di sistema" />}
                      {r.nome}
                    </p>
                    {r.descrizione && <p className="mt-0.5 line-clamp-2 text-xs text-slate-500">{r.descrizione}</p>}
                    <div className="mt-2 flex items-center gap-2 text-xs text-slate-500">
                      <Users className="size-3.5" aria-hidden /> {r.numeroUtenti}
                      <Badge>{r.permessi.length} permessi</Badge>
                    </div>
                  </button>
                  {/* Eliminazione (solo ruoli non di sistema e senza utenti) */}
                  {!r.diSistema && r.numeroUtenti === 0 && (
                    <Button variante="fantasma" dimensione="icona" aria-label={`Elimina ruolo ${r.nome}`} onClick={() => setDaEliminare(r)}>
                      <Trash2 />
                    </Button>
                  )}
                </div>
              </li>
            ))}
          </ul>
          {/* Matrice del ruolo selezionato */}
          {selezionato && catalogo && <MatricePermessi key={selezionato.id} ruolo={selezionato} catalogo={catalogo} />}
        </div>
      )}

      {/* Finestre */}
      {nuovo && (
        <FormRuolo
          onChiudi={() => setNuovo(false)}
          onCreato={(r) => {
            setNuovo(false);
            setSelezionatoId(r.id);
          }}
        />
      )}
      <ConfermaDialog
        aperto={!!daEliminare}
        onChiudi={() => setDaEliminare(null)}
        caricamento={elimina.isPending}
        onConferma={() => daEliminare && elimina.mutate(daEliminare.id, { onSuccess: () => setDaEliminare(null), onError: notificaErrore })}
        titolo="Eliminare il ruolo?"
        messaggio={<>Il ruolo <strong>{daEliminare?.nome}</strong> verrà eliminato.</>}
      />
    </>
  );
}
