// =====================================================================================
// Pannello documenti: elenco, caricamento (anche trascinando i file) e download
// =====================================================================================

// Importa React
import { useRef, useState } from 'react';
// Importa TanStack Query
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
// Importa le icone
import { Download, FileText, Trash2, Upload } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa costanti e tipi condivisi
import { ALLEGATO_MAX_MB, ESTENSIONI_AMMESSE, type Allegato, type EntitaAllegato } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { ConfermaDialog } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/elementi';
// Importa API, errori e utilità
import { api, scaricaFile } from '@/lib/api';
import { notificaErrore } from '@/lib/errori';
import { cn, formattaDataOra, formattaDimensione, nomeCompleto } from '@/lib/utils';

// Proprietà del pannello
interface ProprietaAllegati {
  // Entità a cui sono collegati i documenti
  entita: EntitaAllegato;
  entitaId: string;
  // L'utente può caricare ed eliminare (solo interfaccia: il server ricontrolla)
  modificabile: boolean;
}

export function PannelloAllegati({ entita, entitaId, modificabile }: ProprietaAllegati) {
  // Cache delle query
  const qc = useQueryClient();
  // Chiave della cache per questo elenco
  const chiave = ['allegati', entita, entitaId];
  // Input file nascosto
  const inputFile = useRef<HTMLInputElement>(null);
  // Area di trascinamento attiva
  const [trascinamento, setTrascinamento] = useState(false);
  // Allegato da eliminare (apre la conferma)
  const [daEliminare, setDaEliminare] = useState<Allegato | null>(null);

  // Elenco documenti
  const { data, isLoading } = useQuery({ queryKey: chiave, queryFn: ({ signal }) => api<Allegato[]>('/allegati', { query: { entita, entitaId }, signal }) });

  // Caricamento di un file
  const carica = useMutation({
    mutationFn: (file: File) => {
      // Corpo multipart con i campi richiesti dall'API
      const fd = new FormData();
      fd.append('entita', entita);
      fd.append('entitaId', entitaId);
      fd.append('file', file);
      // Invio
      return api<Allegato>('/allegati', { method: 'POST', formData: fd });
    },
    // Aggiorna l'elenco
    onSuccess: (a) => {
      toast.success(`${a.nomeOriginale} caricato`);
      void qc.invalidateQueries({ queryKey: chiave });
    },
    onError: notificaErrore,
  });

  // Eliminazione
  const elimina = useMutation({
    mutationFn: (id: string) => api<void>(`/allegati/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      setDaEliminare(null);
      void qc.invalidateQueries({ queryKey: chiave });
    },
    onError: notificaErrore,
  });

  // Controlli rapidi lato client (il server li ripete comunque) e caricamento in sequenza
  const gestisciFile = async (files: FileList | null) => {
    // Nessun file
    if (!files) return;
    for (const file of Array.from(files)) {
      // Estensione
      const estensione = file.name.split('.').pop()?.toLowerCase() ?? '';
      // Estensione non ammessa
      if (!(ESTENSIONI_AMMESSE as readonly string[]).includes(estensione)) {
        toast.error(`${file.name}: tipo di file non ammesso`);
        continue;
      }
      // Troppo grande
      if (file.size > ALLEGATO_MAX_MB * 1024 * 1024) {
        toast.error(`${file.name}: supera ${ALLEGATO_MAX_MB} MB`);
        continue;
      }
      // Carica e attende prima del successivo
      await carica.mutateAsync(file).catch(() => undefined);
    }
    // Svuota l'input per poter ricaricare lo stesso file
    if (inputFile.current) inputFile.current.value = '';
  };

  return (
    <div className="space-y-4">
      {/* Area di caricamento */}
      {modificabile && (
        <div
          // Evidenzia l'area quando un file ci passa sopra
          onDragOver={(e) => {
            e.preventDefault();
            setTrascinamento(true);
          }}
          onDragLeave={() => setTrascinamento(false)}
          // Rilascio dei file
          onDrop={(e) => {
            e.preventDefault();
            setTrascinamento(false);
            void gestisciFile(e.dataTransfer.files);
          }}
          className={cn('flex flex-col items-center justify-center rounded-lg border-2 border-dashed px-4 py-6 text-center transition-colors', trascinamento ? 'border-primario-400 bg-primario-50' : 'border-slate-200')}
        >
          <Upload className="size-5 text-slate-400" aria-hidden />
          <p className="mt-2 text-sm text-slate-600">Trascina qui i file oppure</p>
          <Button variante="secondario" dimensione="piccolo" className="mt-2" caricamento={carica.isPending} onClick={() => inputFile.current?.click()}>
            Scegli file
          </Button>
          <p className="mt-2 text-xs text-slate-400">PDF, Office, immagini, CSV, ZIP · max {ALLEGATO_MAX_MB} MB</p>
          {/* Input nascosto */}
          <input ref={inputFile} type="file" multiple hidden accept={ESTENSIONI_AMMESSE.map((e) => `.${e}`).join(',')} onChange={(e) => void gestisciFile(e.target.files)} />
        </div>
      )}

      {/* Elenco */}
      {isLoading ? (
        <Skeleton className="h-16" />
      ) : data?.length === 0 ? (
        <p className="py-6 text-center text-sm text-slate-500">Nessun documento</p>
      ) : (
        <ul className="divide-y divide-slate-100 rounded-lg border border-slate-200">
          {data?.map((a) => (
            <li key={a.id} className="flex items-center gap-3 px-4 py-3">
              {/* Icona */}
              <FileText className="size-5 shrink-0 text-slate-400" aria-hidden />
              {/* Nome e dettagli */}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-900">{a.nomeOriginale}</p>
                <p className="text-xs text-slate-500">
                  {formattaDimensione(a.dimensione)} · {nomeCompleto(a.caricatoDa)} · {formattaDataOra(a.createdAt)}
                </p>
              </div>
              {/* Scarica */}
              <Button variante="fantasma" dimensione="icona" aria-label={`Scarica ${a.nomeOriginale}`} onClick={() => scaricaFile(`/allegati/${a.id}/download`, a.nomeOriginale).catch(notificaErrore)}>
                <Download />
              </Button>
              {/* Elimina */}
              {modificabile && (
                <Button variante="fantasma" dimensione="icona" aria-label={`Elimina ${a.nomeOriginale}`} onClick={() => setDaEliminare(a)}>
                  <Trash2 />
                </Button>
              )}
            </li>
          ))}
        </ul>
      )}

      {/* Conferma eliminazione */}
      <ConfermaDialog
        aperto={!!daEliminare}
        onChiudi={() => setDaEliminare(null)}
        onConferma={() => daEliminare && elimina.mutate(daEliminare.id)}
        caricamento={elimina.isPending}
        titolo="Eliminare il documento?"
        messaggio={<>Il file <strong>{daEliminare?.nomeOriginale}</strong> verrà eliminato definitivamente.</>}
      />
    </div>
  );
}
