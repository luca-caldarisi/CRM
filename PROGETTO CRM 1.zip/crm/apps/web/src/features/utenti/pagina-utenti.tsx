// =====================================================================================
// Gestione utenti: elenco, creazione, modifica, attivazione e reset password
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il form e l'integrazione Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le icone
import { Check, Copy, KeyRound, MoreHorizontal, Pencil, Plus, Power } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa Zod
import { z } from 'zod';
// Importa schemi e tipi condivisi
import { creaUtenteSchema, type RispostaPasswordTemporanea, type Utente } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input, Select } from '@/components/ui/campi';
import { ConfermaDialog, Dialog, PiedeDialog } from '@/components/ui/dialog';
import { Avatar, Badge, Card } from '@/components/ui/elementi';
import { Menu } from '@/components/ui/menu-tabs';
import { CampoRicerca, IntestazionePagina, StatoErrore } from '@/components/common/pagina';
import { Paginazione, Tabella, type Colonna } from '@/components/common/tabella';
// Importa hook ed errori
import { useAggiornaUtente, useCreaUtente, useResetPassword, useRuoli, useUtenti } from '@/features/amministrazione-api';
import { useAuth } from '@/lib/auth';
import { applicaErroriForm, notificaErrore } from '@/lib/errori';
import { useFiltriUrl, useAllineaSelect } from '@/lib/hooks';
import { formattaDataOra } from '@/lib/utils';

// Schema del form: in modifica l'email non si cambia e la password non si imposta
const schemaModifica = creaUtenteSchema.pick({ nome: true, cognome: true, ruoloId: true }).extend({ email: z.string() });

// Finestra di creazione/modifica utente
function FormUtente({ utente, onChiudi, onCreato }: { utente?: Utente; onChiudi: () => void; onCreato: (r: RispostaPasswordTemporanea) => void }) {
  // Ruoli disponibili
  const { data: ruoli } = useRuoli();
  // Mutation
  const crea = useCreaUtente();
  const aggiorna = useAggiornaUtente();
  // Form: schema diverso tra creazione e modifica
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<z.input<typeof creaUtenteSchema>>({
    resolver: zodResolver(utente ? schemaModifica : creaUtenteSchema) as never,
    defaultValues: { email: utente?.email ?? '', nome: utente?.nome ?? '', cognome: utente?.cognome ?? '', ruoloId: utente?.ruolo.id ?? '' },
  });
  // Mostra il valore corretto nelle select anche se le opzioni arrivano dopo l'apertura
  useAllineaSelect(setValue, getValues, ['ruoloId'], [ruoli]);

  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      if (utente) {
        // Modifica di nome, cognome e ruolo
        await aggiorna.mutateAsync({ id: utente.id, dati: { nome: dati.nome, cognome: dati.cognome, ruoloId: dati.ruoloId } });
        toast.success('Utente aggiornato');
        onChiudi();
      } else {
        // Creazione senza password: il server ne genera una temporanea
        const risposta = await crea.mutateAsync({ email: dati.email, nome: dati.nome, cognome: dati.cognome, ruoloId: dati.ruoloId });
        onChiudi();
        onCreato(risposta);
      }
    } catch (errore) {
      applicaErroriForm(errore, setError);
    }
  });

  return (
    <Dialog aperto onChiudi={onChiudi} titolo={utente ? 'Modifica utente' : 'Nuovo utente'} descrizione={utente ? utente.email : 'Verrà generata una password temporanea da comunicare all\'utente.'}>
      <form onSubmit={invia} noValidate className="space-y-4">
        {/* Email solo in creazione */}
        {!utente && (
          <Campo etichetta="Email" htmlFor="u-email" obbligatorio errore={errors.email?.message}>
            <Input id="u-email" type="email" autoFocus aria-invalid={!!errors.email} {...register('email')} />
          </Campo>
        )}
        {/* Nome e cognome */}
        <div className="grid gap-4 sm:grid-cols-2">
          <Campo etichetta="Nome" htmlFor="u-nome" obbligatorio errore={errors.nome?.message}>
            <Input id="u-nome" aria-invalid={!!errors.nome} {...register('nome')} />
          </Campo>
          <Campo etichetta="Cognome" htmlFor="u-cognome" obbligatorio errore={errors.cognome?.message}>
            <Input id="u-cognome" aria-invalid={!!errors.cognome} {...register('cognome')} />
          </Campo>
        </div>
        {/* Ruolo */}
        <Campo etichetta="Ruolo" htmlFor="u-ruolo" obbligatorio errore={errors.ruoloId?.message}>
          <Select id="u-ruolo" aria-invalid={!!errors.ruoloId} {...register('ruoloId')}>
            <option value="">— Seleziona un ruolo —</option>
            {ruoli?.map((r) => <option key={r.id} value={r.id}>{r.nome}</option>)}
          </Select>
        </Campo>
        {/* Pulsanti */}
        <PiedeDialog>
          <Button variante="secondario" onClick={onChiudi}>Annulla</Button>
          <Button type="submit" caricamento={isSubmitting}>{utente ? 'Salva' : 'Crea utente'}</Button>
        </PiedeDialog>
      </form>
    </Dialog>
  );
}

// Finestra che mostra UNA volta la password temporanea
function DialogPasswordTemporanea({ risposta, onChiudi }: { risposta: RispostaPasswordTemporanea; onChiudi: () => void }) {
  // Stato "copiato" per il feedback sul pulsante
  const [copiato, setCopiato] = useState(false);
  // Copia negli appunti
  const copia = async () => {
    await navigator.clipboard.writeText(risposta.passwordTemporanea ?? '');
    setCopiato(true);
  };
  return (
    <Dialog aperto onChiudi={onChiudi} titolo="Password temporanea" descrizione={`${risposta.utente.nome} ${risposta.utente.cognome} · ${risposta.utente.email}`}>
      <div className="space-y-4">
        {/* Password in carattere monospaziato */}
        <div className="flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 p-3">
          <code className="flex-1 select-all font-mono text-base tracking-wide text-slate-900">{risposta.passwordTemporanea}</code>
          <Button variante="secondario" dimensione="piccolo" onClick={() => void copia()}>
            {copiato ? <Check /> : <Copy />} {copiato ? 'Copiata' : 'Copia'}
          </Button>
        </div>
        {/* Avvertenza */}
        <p className="text-sm text-slate-600">
          Comunicala all'utente con un canale sicuro (di persona o telefono, non via email). <strong>Non sarà più visibile</strong> dopo la chiusura di questa finestra. Al primo accesso l'utente dovrà sceglierne una nuova.
        </p>
        <PiedeDialog>
          <Button onClick={onChiudi}>Ho comunicato la password</Button>
        </PiedeDialog>
      </div>
    </Dialog>
  );
}

export function PaginaUtenti() {
  // Utente corrente (non può disattivare se stesso)
  const { utente: io } = useAuth();
  // Filtri nell'URL
  const { filtri, page, imposta } = useFiltriUrl(['q', 'ruoloId', 'attivo'] as const);
  // Dati
  const { data, isLoading, isError } = useUtenti({ q: filtri.q, ruoloId: filtri.ruoloId, attivo: filtri.attivo, page });
  const { data: ruoli } = useRuoli();
  // Finestre
  const [inModifica, setInModifica] = useState<Utente | 'nuovo' | null>(null);
  const [password, setPassword] = useState<RispostaPasswordTemporanea | null>(null);
  const [daResettare, setDaResettare] = useState<Utente | null>(null);
  // Mutation
  const aggiorna = useAggiornaUtente();
  const reset = useResetPassword();

  // Attiva/disattiva un utente
  const cambiaStato = (u: Utente) =>
    aggiorna.mutate({ id: u.id, dati: { attivo: !u.attivo } }, { onSuccess: () => toast.success(u.attivo ? 'Utente disattivato' : 'Utente riattivato'), onError: notificaErrore });

  // Colonne
  const colonne: Colonna<Utente>[] = [
    {
      id: 'nome',
      titolo: 'Utente',
      ordinabile: 'cognome',
      cella: (u) => (
        <div className="flex items-center gap-3">
          <Avatar nome={u.nome} cognome={u.cognome} />
          <div className="min-w-0">
            <p className="font-medium text-slate-900">{u.nome} {u.cognome}</p>
            <p className="truncate text-xs text-slate-500">{u.email}</p>
          </div>
        </div>
      ),
    },
    { id: 'ruolo', titolo: 'Ruolo', cella: (u) => <Badge colore={u.ruolo.diSistema ? 'blu' : 'grigio'}>{u.ruolo.nome}</Badge> },
    {
      id: 'stato',
      titolo: 'Stato',
      cella: (u) => (
        <div className="flex flex-wrap gap-1">
          {u.attivo ? <Badge colore="verde">Attivo</Badge> : <Badge>Disattivato</Badge>}
          {u.bloccatoFinoA && <Badge colore="rosso">Bloccato</Badge>}
          {u.deveCambiarePassword && u.attivo && <Badge colore="giallo">Primo accesso</Badge>}
        </div>
      ),
    },
    { id: 'accesso', titolo: 'Ultimo accesso', ordinabile: 'ultimoAccesso', cella: (u) => formattaDataOra(u.ultimoAccesso), className: 'hidden md:table-cell' },
    {
      id: 'azioni',
      titolo: '',
      className: 'w-12 text-right',
      cella: (u) => (
        <Menu
          grilletto={<Button variante="fantasma" dimensione="icona" aria-label={`Azioni per ${u.nome} ${u.cognome}`}><MoreHorizontal /></Button>}
          voci={[
            { etichetta: 'Modifica', icona: <Pencil />, onSelect: () => setInModifica(u) },
            { etichetta: 'Reset password', icona: <KeyRound />, onSelect: () => setDaResettare(u) },
            { etichetta: u.attivo ? 'Disattiva' : 'Riattiva', icona: <Power />, onSelect: () => cambiaStato(u), pericolo: u.attivo, nascosta: u.id === io?.id },
          ]}
        />
      ),
    },
  ];

  return (
    <>
      {/* Intestazione */}
      <IntestazionePagina
        briciole={[{ etichetta: 'Amministrazione' }, { etichetta: 'Utenti' }]}
        titolo="Utenti"
        sottotitolo="Gli utenti non si eliminano: si disattivano, così lo storico delle loro attività resta consultabile."
        azioni={<Button onClick={() => setInModifica('nuovo')}><Plus /> Nuovo utente</Button>}
      />
      {isError && <StatoErrore />}
      <Card>
        {/* Filtri */}
        <div className="flex flex-wrap gap-2 border-b border-slate-200 p-3">
          <CampoRicerca valore={filtri.q} onCambia={(q) => imposta({ q })} segnaposto="Cerca per nome o email…" />
          <Select value={filtri.ruoloId} onChange={(e) => imposta({ ruoloId: e.target.value })} className="w-auto" aria-label="Filtra per ruolo">
            <option value="">Tutti i ruoli</option>
            {ruoli?.map((r) => <option key={r.id} value={r.id}>{r.nome}</option>)}
          </Select>
          <Select value={filtri.attivo} onChange={(e) => imposta({ attivo: e.target.value })} className="w-auto" aria-label="Filtra per stato">
            <option value="">Tutti</option>
            <option value="true">Attivi</option>
            <option value="false">Disattivati</option>
          </Select>
        </div>
        {/* Tabella */}
        <Tabella colonne={colonne} righe={data?.data} chiave={(u) => u.id} caricamento={isLoading} vuoto="Nessun utente trovato" />
        {data && <Paginazione {...data.meta} onCambia={(p) => imposta({ page: p })} />}
      </Card>

      {/* Finestre */}
      {inModifica && <FormUtente utente={inModifica === 'nuovo' ? undefined : inModifica} onChiudi={() => setInModifica(null)} onCreato={setPassword} />}
      {password && <DialogPasswordTemporanea risposta={password} onChiudi={() => setPassword(null)} />}
      <ConfermaDialog
        aperto={!!daResettare}
        onChiudi={() => setDaResettare(null)}
        caricamento={reset.isPending}
        testoConferma="Genera nuova password"
        onConferma={() =>
          daResettare &&
          reset.mutate(daResettare.id, {
            onSuccess: (r) => {
              setDaResettare(null);
              setPassword(r);
            },
            onError: notificaErrore,
          })
        }
        titolo="Reimpostare la password?"
        messaggio={<>Verrà generata una password temporanea per <strong>{daResettare?.nome} {daResettare?.cognome}</strong>. Tutte le sue sessioni aperte verranno chiuse e l'eventuale blocco rimosso.</>}
      />
    </>
  );
}
