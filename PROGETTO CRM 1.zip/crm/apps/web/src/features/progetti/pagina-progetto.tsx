// =====================================================================================
// Dettaglio di un progetto: bacheca Kanban, riepilogo, ore, dati, documenti e attività
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il router
import { Link, useNavigate, useParams, useSearchParams } from 'react-router';
// Importa le icone
import { MoreHorizontal, Pencil, Trash2 } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa componenti
import { Button } from '@/components/ui/button';
import { ConfermaDialog } from '@/components/ui/dialog';
import { Badge, Card, CardHeader, Skeleton } from '@/components/ui/elementi';
import { Menu, Tabs } from '@/components/ui/menu-tabs';
import { DatoDettaglio, IntestazionePagina, StatoErrore } from '@/components/common/pagina';
// Importa funzionalità del modulo
import { useEliminaProgetto, useProgetto } from './api';
import { Bacheca } from './bacheca';
import { BadgeStatoProgetto } from './componenti';
import { DialogTask } from './dialog-task';
import { FormProgetto } from './form-progetto';
import { FormTask } from './form-task';
import { RiepilogoProgetto } from './riepilogo';
import { SchedaOre } from './scheda-ore';
// Importa funzionalità collegate
import { PannelloAllegati } from '@/features/allegati/pannello-allegati';
import { StoricoAttivita } from '@/features/audit/storico-attivita';
// Importa permessi, errori e utilità
import { ErroreApi } from '@/lib/api';
import { usePermesso } from '@/lib/auth';
import { notificaErrore } from '@/lib/errori';
import { formattaData, formattaDataOra, nomeCompleto } from '@/lib/utils';

export function PaginaProgetto() {
  // Identificativo dall'URL
  const { id = '' } = useParams();
  // Navigazione
  const naviga = useNavigate();
  // Scheda attiva salvata nell'URL
  const [params, setParams] = useSearchParams();
  const scheda = params.get('scheda') ?? 'bacheca';
  // Finestre
  const [modifica, setModifica] = useState(false);
  const [conferma, setConferma] = useState(false);
  // Task aperto nel dettaglio
  const [taskAperto, setTaskAperto] = useState<string | null>(null);
  // Colonna in cui creare un nuovo task (null = finestra chiusa)
  const [nuovoTaskIn, setNuovoTaskIn] = useState<string | null>(null);
  // Dati
  const { data: p, isLoading, error } = useProgetto(id);
  // Eliminazione
  const elimina = useEliminaProgetto();
  // Permessi di interfaccia
  const puoModificare = usePermesso('progetti.write');
  const puoEliminare = usePermesso('progetti.delete');
  const puoVedereAudit = usePermesso('audit.read');

  // Errori e caricamento
  if (error instanceof ErroreApi && error.status === 404) return <StatoErrore messaggio="Progetto non trovato o non accessibile." />;
  if (error) return <StatoErrore />;
  if (isLoading || !p) return <Skeleton className="h-64" />;

  // Un progetto concluso o annullato è di sola lettura: la bacheca non si modifica più
  const chiuso = p.stato === 'concluso' || p.stato === 'annullato';

  return (
    <>
      {/* Intestazione */}
      <IntestazionePagina
        briciole={[{ etichetta: 'Progetti', a: '/progetti' }, { etichetta: p.codice }]}
        titolo={p.nome}
        sottotitolo={
          <span className="flex flex-wrap items-center gap-2">
            <Badge>{p.codice}</Badge>
            <BadgeStatoProgetto stato={p.stato} />
            {/* Link al cliente */}
            <Link to={`/clienti/${p.cliente.id}`} className="text-primario-700 hover:underline">{p.cliente.ragioneSociale}</Link>
            {/* Link alla commessa collegata */}
            {p.commessa && (
              <Link to={`/commesse/${p.commessa.id}`} className="text-slate-500 hover:underline">{p.commessa.codice}</Link>
            )}
          </span>
        }
        azioni={
          <>
            {puoModificare && <Button variante="secondario" onClick={() => setModifica(true)}><Pencil /> Modifica</Button>}
            <Menu
              grilletto={<Button variante="secondario" dimensione="icona" aria-label="Altre azioni"><MoreHorizontal /></Button>}
              voci={[{ etichetta: 'Elimina progetto', icona: <Trash2 />, onSelect: () => setConferma(true), pericolo: true, nascosta: !puoEliminare }]}
            />
          </>
        }
      />

      {/* Schede */}
      <Tabs
        attiva={scheda}
        onCambia={(s) => setParams({ scheda: s }, { replace: true })}
        schede={[
          {
            id: 'bacheca',
            etichetta: 'Bacheca',
            contenuto: (
              <>
                {/* Avviso di sola lettura sui progetti chiusi */}
                {chiuso && (
                  <p className="mb-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-600">
                    Il progetto è {p.stato === 'concluso' ? 'concluso' : 'annullato'}: la bacheca è in sola lettura. Riportalo "in corso" per modificarla.
                  </p>
                )}
                {/* Bacheca Kanban */}
                <Bacheca progettoId={id} onApriTask={setTaskAperto} onNuovoTask={setNuovoTaskIn} soloLettura={chiuso} />
              </>
            ),
          },
          { id: 'riepilogo', etichetta: 'Riepilogo', contenuto: <RiepilogoProgetto progettoId={id} /> },
          { id: 'ore', etichetta: 'Ore', contenuto: <SchedaOre progettoId={id} /> },
          {
            id: 'dettagli',
            etichetta: 'Dettagli',
            contenuto: (
              <div className="grid gap-4 lg:grid-cols-3">
                {/* Descrizione e note */}
                <div className="space-y-4 lg:col-span-2">
                  <Card>
                    <CardHeader titolo="Descrizione" />
                    <p className="whitespace-pre-line p-5 text-sm text-slate-700">{p.descrizione || <span className="text-slate-400">Nessuna descrizione</span>}</p>
                  </Card>
                  <Card>
                    <CardHeader titolo="Note interne" />
                    <p className="whitespace-pre-line p-5 text-sm text-slate-700">{p.note || <span className="text-slate-400">Nessuna nota</span>}</p>
                  </Card>
                </div>
                {/* Dati principali */}
                <Card>
                  <CardHeader titolo="Informazioni" />
                  <dl className="grid gap-4 p-5">
                    <DatoDettaglio etichetta="Responsabile">{p.responsabile && nomeCompleto(p.responsabile)}</DatoDettaglio>
                    <DatoDettaglio etichetta="Inizio">{p.dataInizio && formattaData(p.dataInizio)}</DatoDettaglio>
                    <DatoDettaglio etichetta="Fine prevista">{p.dataFinePrevista && formattaData(p.dataFinePrevista)}</DatoDettaglio>
                    <DatoDettaglio etichetta="Fine effettiva">{p.dataFineEffettiva && formattaData(p.dataFineEffettiva)}</DatoDettaglio>
                    <DatoDettaglio etichetta="Commessa">{p.commessa && `${p.commessa.codice} — ${p.commessa.titolo}`}</DatoDettaglio>
                    <DatoDettaglio etichetta="Template di origine">{p.template?.nome}</DatoDettaglio>
                    <div className="border-t border-slate-100 pt-3 text-xs text-slate-500">Aggiornato il {formattaDataOra(p.updatedAt)}</div>
                  </dl>
                </Card>
              </div>
            ),
          },
          { id: 'documenti', etichetta: 'Documenti', contenuto: <PannelloAllegati entita="progetto" entitaId={id} modificabile={puoModificare} /> },
          { id: 'attivita', etichetta: 'Attività', contenuto: <StoricoAttivita entita="progetto" entitaId={id} />, nascosta: !puoVedereAudit },
        ]}
      />

      {/* Finestra di modifica del progetto */}
      {modifica && <FormProgetto progetto={p} onChiudi={() => setModifica(false)} />}
      {/* Finestra di dettaglio di un task */}
      {taskAperto && <DialogTask taskId={taskAperto} onChiudi={() => setTaskAperto(null)} soloLettura={chiuso} />}
      {/* Finestra di creazione di un task */}
      {nuovoTaskIn && <FormTask progettoId={id} colonne={p.colonne} colonnaIniziale={nuovoTaskIn} onChiudi={() => setNuovoTaskIn(null)} />}
      {/* Conferma eliminazione */}
      <ConfermaDialog
        aperto={conferma}
        onChiudi={() => setConferma(false)}
        caricamento={elimina.isPending}
        onConferma={() =>
          elimina.mutate(id, {
            onSuccess: () => {
              toast.success('Progetto eliminato');
              naviga('/progetti');
            },
            onError: (e) => {
              setConferma(false);
              notificaErrore(e);
            },
          })
        }
        titolo="Eliminare il progetto?"
        messaggio={<>Il progetto <strong>{p.codice}</strong> non sarà più visibile, insieme alla sua bacheca. Lo storico resta nel registro attività.</>}
      />
    </>
  );
}
