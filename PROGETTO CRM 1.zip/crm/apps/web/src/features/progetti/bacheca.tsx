// =====================================================================================
// Bacheca Kanban dei task di un progetto, con trascinamento tra le colonne
// -------------------------------------------------------------------------------------
// Il trascinamento aggiorna subito la vista (stato locale) e poi invia lo spostamento al
// server: se la richiesta fallisce si ricarica la bacheca vera e si mostra l'errore.
// =====================================================================================

// Importa gli hook di React
import { useEffect, useMemo, useState } from 'react';
// Importa il cuore di dnd-kit
import {
  DndContext,
  DragOverlay,
  KeyboardSensor,
  PointerSensor,
  closestCorners,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from '@dnd-kit/core';
// Importa gli helper per gli elenchi ordinabili
import { SortableContext, sortableKeyboardCoordinates, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
// Importa l'helper per le trasformazioni CSS
import { CSS } from '@dnd-kit/utilities';
// Importa le icone
import { CalendarClock, CheckSquare, Clock, GripVertical, Plus } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa i tipi condivisi
import type { ColonnaProgetto, TaskBacheca } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/elementi';
import { StatoErrore } from '@/components/common/pagina';
// Importa funzionalità del modulo
import { useBacheca, useSpostaTask } from './api';
import { BadgePriorita, Durata, oreInMinuti } from './componenti';
// Importa permessi, errori e utilità
import { useAmbito, useAuth, usePermesso } from '@/lib/auth';
import { notificaErrore } from '@/lib/errori';
import { cn, formattaData, iniziali } from '@/lib/utils';

// Colonna con i propri task (forma usata dallo stato locale)
type ColonnaConTask = ColonnaProgetto & { task: TaskBacheca[] };

// Proprietà della bacheca
interface ProprietaBacheca {
  // Progetto di cui mostrare la bacheca
  progettoId: string;
  // Apre il dettaglio di un task
  onApriTask: (taskId: string) => void;
  // Apre la creazione di un task nella colonna indicata
  onNuovoTask: (colonnaId: string) => void;
  // Il progetto è chiuso: la bacheca diventa di sola lettura
  soloLettura?: boolean;
}

export function Bacheca({ progettoId, onApriTask, onNuovoTask, soloLettura = false }: ProprietaBacheca) {
  // Dati dal server
  const { data, isLoading, isError } = useBacheca(progettoId);
  // Spostamento
  const sposta = useSpostaTask();
  // Permesso di modificare i task
  const puoModificare = usePermesso('task.write') && !soloLettura;
  // Ambito sui task e utente collegato: con ambito "propri" si trascinano solo i task propri
  const ambito = useAmbito('task.write');
  const { utente } = useAuth();

  // true se questo specifico task è trascinabile dall'utente collegato
  // (stessa regola applicata dal server: mostrare una maniglia che porta a un 403 sarebbe solo frustrante)
  function trascinabile(t: TaskBacheca): boolean {
    // Sola lettura o permesso mancante
    if (!puoModificare) return false;
    // Ambito completo: qualsiasi task
    if (ambito === 'tutti') return true;
    // Ambito "propri": solo i task di cui è responsabile
    return t.responsabile?.id === utente?.id;
  }
  // Copia locale delle colonne, aggiornata immediatamente durante il trascinamento
  const [colonne, setColonne] = useState<ColonnaConTask[]>([]);
  // Task attualmente trascinato (per l'anteprima che segue il cursore)
  const [trascinato, setTrascinato] = useState<TaskBacheca | null>(null);

  // Allinea lo stato locale ai dati del server a ogni ricarica
  useEffect(() => {
    if (data) setColonne(data.colonne);
  }, [data]);

  // Sensori: mouse/touch con una piccola soglia (per non confondere click e trascinamento) e tastiera
  const sensori = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  // Mappa taskId -> colonna, per ritrovare rapidamente la provenienza
  const colonnaDelTask = useMemo(() => {
    // Mappa vuota
    const mappa = new Map<string, string>();
    // Registra ogni task nella propria colonna
    for (const c of colonne) for (const t of c.task) mappa.set(t.id, c.id);
    // Mappa completa
    return mappa;
  }, [colonne]);

  // Inizio del trascinamento: memorizza il task per l'anteprima
  function inizio(evento: DragStartEvent) {
    // Cerca il task in tutte le colonne
    const task = colonne.flatMap((c) => c.task).find((t) => t.id === evento.active.id);
    // Lo memorizza (null se non trovato)
    setTrascinato(task ?? null);
  }

  // Fine del trascinamento: calcola la destinazione, aggiorna la vista e chiama il server
  function fine(evento: DragEndEvent) {
    // Nasconde l'anteprima
    setTrascinato(null);
    // Identificativo del task trascinato
    const taskId = String(evento.active.id);
    // Nessuna destinazione valida (rilasciato fuori): non cambia nulla
    if (!evento.over) return;
    // Identificativo dell'elemento sotto il cursore: può essere un task o una colonna
    const sopra = String(evento.over.id);
    // Colonna di partenza
    const origine = colonnaDelTask.get(taskId);
    // Senza colonna di partenza non si può procedere
    if (!origine) return;
    // Colonna di destinazione: se si rilascia su un task si prende la sua colonna
    const destinazione = colonnaDelTask.get(sopra) ?? sopra;
    // La destinazione deve essere una colonna esistente
    const colonnaDest = colonne.find((c) => c.id === destinazione);
    if (!colonnaDest) return;
    // Task già presenti nella colonna di destinazione, escluso quello trascinato
    const altri = colonnaDest.task.filter((t) => t.id !== taskId);
    // Indice del task su cui si è rilasciato dentro quell'elenco
    const indice = altri.findIndex((t) => t.id === sopra);
    // Posizione finale: al posto del task su cui si rilascia, oppure in fondo se si rilascia sulla colonna
    const posizione = indice === -1 ? altri.length : indice;
    // Stato attuale del task nella vista
    const task = colonne.flatMap((c) => c.task).find((t) => t.id === taskId);
    if (!task) return;
    // Nessun movimento reale: evita una chiamata inutile
    if (origine === destinazione && colonne.find((c) => c.id === origine)!.task.findIndex((t) => t.id === taskId) === posizione) return;
    // Aggiorna subito la vista (l'utente vede il risultato senza attendere la rete)
    setColonne((precedenti) =>
      precedenti.map((c) => {
        // Rimuove il task dalla colonna di partenza
        const senzaTask = c.task.filter((t) => t.id !== taskId);
        // Colonna di destinazione: reinserisce il task nella nuova posizione
        if (c.id === destinazione) {
          // Copia dell'elenco
          const nuovo = [...senzaTask];
          // Inserimento
          nuovo.splice(posizione, 0, { ...task, colonnaId: destinazione });
          // Colonna aggiornata
          return { ...c, task: nuovo };
        }
        // Altre colonne: solo eventuale rimozione
        return { ...c, task: senzaTask };
      }),
    );
    // Invia lo spostamento al server
    sposta.mutate(
      { taskId, colonnaId: destinazione, posizione },
      {
        // In caso di errore mostra il messaggio e ripristina i dati del server
        onError: (errore) => {
          notificaErrore(errore);
          if (data) setColonne(data.colonne);
        },
        // Se il task entra in una colonna di completamento lo segnala
        onSuccess: () => {
          if (colonnaDest.consideraCompletato && origine !== destinazione) toast.success(`"${task.titolo}" completato`);
        },
      },
    );
  }

  // Caricamento
  if (isLoading) return <Skeleton className="h-72" />;
  // Errore
  if (isError) return <StatoErrore messaggio="Impossibile caricare la bacheca." />;

  return (
    <DndContext sensors={sensori} collisionDetection={closestCorners} onDragStart={inizio} onDragEnd={fine} onDragCancel={() => setTrascinato(null)}>
      {/* Colonne affiancate, scorrevoli in orizzontale sugli schermi piccoli */}
      <div className="flex gap-4 overflow-x-auto pb-2">
        {colonne.map((c) => (
          <Colonna key={c.id} colonna={c} onApriTask={onApriTask} onNuovoTask={onNuovoTask} puoModificare={puoModificare} trascinabile={trascinabile} />
        ))}
      </div>
      {/* Anteprima che segue il cursore durante il trascinamento */}
      <DragOverlay>{trascinato && <CorpoCard task={trascinato} trascinamento />}</DragOverlay>
    </DndContext>
  );
}

// ------------------------------------- Colonna ------------------------------------------

// Una colonna della bacheca: intestazione, elenco ordinabile e pulsante di aggiunta
function Colonna({
  colonna,
  onApriTask,
  onNuovoTask,
  puoModificare,
  trascinabile,
}: {
  colonna: ColonnaConTask;
  onApriTask: (id: string) => void;
  onNuovoTask: (colonnaId: string) => void;
  puoModificare: boolean;
  // Dice se il singolo task è trascinabile dall'utente collegato
  trascinabile: (t: TaskBacheca) => boolean;
}) {
  // Zona di rilascio: serve per poter trascinare anche in una colonna vuota
  const { setNodeRef, isOver } = useDroppable({ id: colonna.id });

  return (
    <section className="flex w-64 shrink-0 flex-col" aria-label={colonna.nome}>
      {/* Intestazione della colonna */}
      <div className="mb-2 flex items-center justify-between px-1">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-700">
          {/* Pallino verde per le colonne che contano come completamento */}
          {colonna.consideraCompletato && <span className="size-2 rounded-full bg-emerald-500" aria-label="Colonna di completamento" />}
          {colonna.nome}
          {/* Numero di task */}
          <span className="rounded bg-slate-200 px-1.5 text-xs font-medium tabular-nums text-slate-600">{colonna.task.length}</span>
        </h3>
        {/* Aggiunta rapida di un task in questa colonna */}
        {puoModificare && (
          <Button variante="fantasma" dimensione="icona" onClick={() => onNuovoTask(colonna.id)} aria-label={`Nuovo task in ${colonna.nome}`}>
            <Plus />
          </Button>
        )}
      </div>
      {/* Contenitore dei task */}
      <div
        ref={setNodeRef}
        className={cn('flex min-h-32 flex-1 flex-col gap-2 rounded-lg bg-slate-100/70 p-2 transition-colors', isOver && 'bg-primario-50 ring-1 ring-primario-200')}
      >
        {/* Elenco ordinabile */}
        <SortableContext items={colonna.task.map((t) => t.id)} strategy={verticalListSortingStrategy}>
          {colonna.task.map((t) => (
            <CardTask key={t.id} task={t} onApri={() => onApriTask(t.id)} trascinabile={trascinabile(t)} />
          ))}
        </SortableContext>
        {/* Colonna vuota */}
        {colonna.task.length === 0 && <p className="px-1 py-6 text-center text-xs text-slate-400">Nessun task</p>}
      </div>
    </section>
  );
}

// -------------------------------------- Card task ---------------------------------------

// Card trascinabile di un task
function CardTask({ task, onApri, trascinabile }: { task: TaskBacheca; onApri: () => void; trascinabile: boolean }) {
  // Stato del trascinamento per questo elemento
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: task.id, disabled: !trascinabile });

  return (
    <div
      ref={setNodeRef}
      // Posizione durante il trascinamento
      style={{ transform: CSS.Transform.toString(transform), transition }}
      // L'originale resta al suo posto in trasparenza mentre l'anteprima segue il cursore
      className={cn(isDragging && 'opacity-40')}
    >
      <CorpoCard
        task={task}
        onApri={onApri}
        // Maniglia di trascinamento: gli ascoltatori vanno sulla maniglia, non su tutta la card,
        // così il click sul corpo apre il dettaglio senza ambiguità
        maniglia={trascinabile ? { ...attributes, ...listeners } : undefined}
      />
    </div>
  );
}

// Contenuto grafico della card (usato anche dall'anteprima di trascinamento)
function CorpoCard({
  task,
  onApri,
  maniglia,
  trascinamento = false,
}: {
  task: TaskBacheca;
  onApri?: () => void;
  maniglia?: Record<string, unknown>;
  trascinamento?: boolean;
}) {
  // Minuti preventivati, convertiti dalle ore decimali
  const minutiStimati = oreInMinuti(task.oreStimate);
  // Scadenza superata: il task è in ritardo
  const inRitardo = task.dataScadenza != null && task.dataScadenza < new Date().toLocaleDateString('sv-SE');

  return (
    <div className={cn('rounded-lg border border-slate-200 bg-white p-2.5 shadow-xs', trascinamento && 'rotate-1 shadow-lg')}>
      {/* Titolo con maniglia di trascinamento */}
      <div className="flex items-start gap-1">
        {/* Maniglia (assente in sola lettura) */}
        {maniglia && (
          <span
            {...maniglia}
            className="-ml-1 mt-0.5 cursor-grab touch-none rounded p-0.5 text-slate-300 hover:bg-slate-100 hover:text-slate-500"
            aria-label={`Sposta ${task.titolo}`}
          >
            <GripVertical className="size-4" />
          </span>
        )}
        {/* Il titolo apre il dettaglio */}
        <button type="button" onClick={onApri} className="min-w-0 flex-1 text-left text-sm font-medium text-slate-900 hover:text-primario-700">
          {task.titolo}
        </button>
      </div>
      {/* Riga di informazioni sintetiche */}
      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500">
        {/* Priorità diversa da quella normale */}
        <BadgePriorita priorita={task.priorita} />
        {/* Avanzamento della to-do */}
        {task.todoTotali > 0 && (
          <span className={cn('inline-flex items-center gap-1', task.todoCompletate === task.todoTotali && 'text-emerald-600')}>
            <CheckSquare className="size-3.5" aria-hidden />
            {task.todoCompletate}/{task.todoTotali}
          </span>
        )}
        {/* Ore registrate sul preventivo */}
        {(task.minutiRegistrati > 0 || minutiStimati > 0) && (
          <span className="inline-flex items-center gap-1" title="Ore registrate / preventivate">
            <Clock className="size-3.5" aria-hidden />
            <Durata minuti={task.minutiRegistrati} />
            {minutiStimati > 0 && <span className="text-slate-400">/ <Durata minuti={minutiStimati} /></span>}
          </span>
        )}
        {/* Scadenza, evidenziata se superata */}
        {task.dataScadenza && (
          <span className={cn('inline-flex items-center gap-1', inRitardo && 'font-medium text-red-600')}>
            <CalendarClock className="size-3.5" aria-hidden />
            {formattaData(task.dataScadenza)}
          </span>
        )}
        {/* Responsabile: iniziali in fondo a destra */}
        {task.responsabile && (
          <span
            className="ml-auto inline-flex size-6 items-center justify-center rounded-full bg-primario-100 text-[10px] font-semibold text-primario-700"
            title={`${task.responsabile.nome} ${task.responsabile.cognome}`}
          >
            {iniziali(task.responsabile.nome, task.responsabile.cognome)}
          </span>
        )}
      </div>
    </div>
  );
}
