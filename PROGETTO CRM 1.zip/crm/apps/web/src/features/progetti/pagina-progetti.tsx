// =====================================================================================
// Elenco progetti con ricerca, filtro per stato, avanzamento e paginazione
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il router
import { useNavigate } from 'react-router';
// Importa le icone
import { LayoutTemplate, Plus } from 'lucide-react';
// Importa etichette e tipi condivisi
import { STATI_PROGETTO, type ProgettoLista, type StatoProgetto } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Select } from '@/components/ui/campi';
import { Badge, Card } from '@/components/ui/elementi';
import { CampoRicerca, IntestazionePagina, StatoErrore } from '@/components/common/pagina';
import { Paginazione, Tabella, type Colonna } from '@/components/common/tabella';
// Importa funzionalità del modulo
import { useProgetti } from './api';
import { FormProgetto } from './form-progetto';
import { BadgeStatoProgetto, BarraAvanzamento } from './componenti';
// Importa permessi e utilità
import { usePermesso } from '@/lib/auth';
import { useFiltriUrl } from '@/lib/hooks';
import { formattaData, nomeCompleto } from '@/lib/utils';

// Colonne della tabella dei progetti
// "mostraCliente" viene disattivato quando l'elenco è già dentro la scheda di un cliente
export function colonneProgetti(mostraCliente = true): Colonna<ProgettoLista>[] {
  return [
    {
      id: 'nome',
      titolo: 'Progetto',
      ordinabile: 'codice',
      cella: (p) => (
        <div>
          {/* Nome e codice */}
          <p className="font-medium text-slate-900">{p.nome}</p>
          <p className="text-xs text-slate-500">{p.codice}</p>
        </div>
      ),
    },
    ...(mostraCliente
      ? [{ id: 'cliente', titolo: 'Cliente', ordinabile: 'cliente', cella: (p: ProgettoLista) => p.cliente.ragioneSociale, className: 'hidden md:table-cell' }]
      : []),
    { id: 'stato', titolo: 'Stato', ordinabile: 'stato', cella: (p) => <BadgeStatoProgetto stato={p.stato} /> },
    {
      id: 'avanzamento',
      titolo: 'Avanzamento',
      cella: (p) => (
        <div className="w-36">
          {/* Barra e conteggio dei task */}
          <BarraAvanzamento valore={p.avanzamento} />
          <p className="mt-1 text-xs text-slate-500">{p.taskCompletati}/{p.taskTotali} task</p>
        </div>
      ),
    },
    { id: 'fine', titolo: 'Fine prevista', ordinabile: 'dataFinePrevista', cella: (p) => formattaData(p.dataFinePrevista), className: 'hidden sm:table-cell' },
    { id: 'responsabile', titolo: 'Responsabile', cella: (p) => nomeCompleto(p.responsabile), className: 'hidden xl:table-cell' },
  ];
}

export function PaginaProgetti() {
  // Navigazione
  const naviga = useNavigate();
  // Filtri salvati nell'URL (così la pagina è condivisibile e il "torna indietro" funziona)
  const { filtri, page, imposta } = useFiltriUrl(['q', 'sort', 'stato'] as const);
  // Finestra di creazione
  const [nuovo, setNuovo] = useState(false);
  // Permessi di interfaccia
  const puoCreare = usePermesso('progetti.write');
  const puoGestireTemplate = usePermesso('template.manage');
  // Dati
  const { data, isLoading, isError } = useProgetti({ q: filtri.q, sort: filtri.sort, stato: filtri.stato as StatoProgetto | '', page });

  return (
    <>
      {/* Intestazione */}
      <IntestazionePagina
        titolo="Progetti"
        sottotitolo={data ? `${data.meta.total} progetti` : undefined}
        azioni={
          <>
            {/* Accesso ai template per chi li gestisce */}
            {puoGestireTemplate && (
              <Button variante="secondario" onClick={() => naviga('/progetti/template')}>
                <LayoutTemplate /> Template
              </Button>
            )}
            {puoCreare && <Button onClick={() => setNuovo(true)}><Plus /> Nuovo progetto</Button>}
          </>
        }
      />
      {/* Errore di caricamento */}
      {isError && <StatoErrore />}
      <Card>
        {/* Barra filtri */}
        <div className="flex flex-wrap gap-2 border-b border-slate-200 p-3">
          <CampoRicerca valore={filtri.q} onCambia={(q) => imposta({ q })} segnaposto="Cerca per nome, codice, cliente…" />
          {/* Filtro stato */}
          <Select value={filtri.stato} onChange={(e) => imposta({ stato: e.target.value })} className="w-auto" aria-label="Filtra per stato">
            <option value="">Tutti gli stati</option>
            {Object.entries(STATI_PROGETTO).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
          </Select>
        </div>
        {/* Tabella */}
        <Tabella
          colonne={colonneProgetti()}
          righe={data?.data}
          chiave={(p) => p.id}
          caricamento={isLoading}
          ordinamento={filtri.sort || '-codice'}
          onOrdina={(sort) => imposta({ sort })}
          onClickRiga={(p) => naviga(`/progetti/${p.id}`)}
          vuoto="Nessun progetto trovato"
        />
        {/* Paginazione */}
        {data && <Paginazione {...data.meta} onCambia={(p) => imposta({ page: p })} />}
      </Card>
      {/* Finestra nuovo progetto */}
      {nuovo && <FormProgetto onChiudi={() => setNuovo(false)} />}
    </>
  );
}

// Badge riutilizzabile con il numero di task completati (usato nelle schede collegate)
export function BadgeTask({ completati, totali }: { completati: number; totali: number }) {
  return <Badge colore={totali > 0 && completati === totali ? 'verde' : 'grigio'}>{completati}/{totali} task</Badge>;
}
