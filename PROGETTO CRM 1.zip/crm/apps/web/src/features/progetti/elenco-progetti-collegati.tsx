// =====================================================================================
// Elenco dei progetti di un cliente o di una commessa (scheda "Progetti" nei dettagli)
// -------------------------------------------------------------------------------------
// Un solo componente per entrambe le schede: cambia soltanto il filtro passato all'API.
// =====================================================================================

// Importa lo stato locale di React
import { useState } from 'react';
// Importa la navigazione programmatica
import { useNavigate } from 'react-router';
// Importa l'icona del pulsante
import { Plus } from 'lucide-react';
// Importa i componenti grafici
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/elementi';
import { Paginazione, Tabella } from '@/components/common/tabella';
// Importa il controllo dei permessi
import { usePermesso } from '@/lib/auth';
// Importa hook, form e colonne del modulo progetti
import { useProgetti } from './api';
import { FormProgetto } from './form-progetto';
import { colonneProgetti } from './pagina-progetti';

// Proprietà del componente
interface ProprietaElenco {
  // Cliente di riferimento (sempre presente: anche la commessa appartiene a un cliente)
  cliente: { id: string; ragioneSociale: string };
  // Commessa di riferimento (assente = tutti i progetti del cliente)
  commessaId?: string;
}

export function ElencoProgettiCollegati({ cliente, commessaId }: ProprietaElenco) {
  // Navigazione verso il dettaglio del progetto
  const naviga = useNavigate();
  // Pagina corrente della tabella
  const [page, setPage] = useState(1);
  // Finestra "nuovo progetto" aperta
  const [nuovo, setNuovo] = useState(false);
  // Pulsante di creazione visibile solo a chi può creare progetti
  const puoCreare = usePermesso('progetti.write');
  // Progetti filtrati per commessa (se indicata) oppure per cliente
  const { data, isLoading } = useProgetti(commessaId ? { commessaId, page, pageSize: 10 } : { clienteId: cliente.id, page, pageSize: 10 });

  return (
    <div className="space-y-3">
      {/* Nuovo progetto con cliente (ed eventuale commessa) già compilati */}
      {puoCreare && (
        <div className="flex justify-end">
          <Button variante="secondario" dimensione="piccolo" onClick={() => setNuovo(true)}>
            <Plus /> Nuovo progetto
          </Button>
        </div>
      )}
      {/* Tabella senza la colonna cliente, che qui sarebbe ripetuta su ogni riga */}
      <Card>
        <Tabella colonne={colonneProgetti(false)} righe={data?.data} chiave={(p) => p.id} caricamento={isLoading} onClickRiga={(p) => naviga(`/progetti/${p.id}`)} vuoto="Nessun progetto collegato" />
        {/* Paginazione solo se i progetti non stanno in una pagina */}
        {data && data.meta.total > data.meta.pageSize && <Paginazione {...data.meta} onCambia={setPage} />}
      </Card>
      {/* Finestra di creazione */}
      {nuovo && <FormProgetto cliente={cliente} commessaId={commessaId} onChiudi={() => setNuovo(false)} />}
    </div>
  );
}
