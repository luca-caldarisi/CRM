// =====================================================================================
// Finestra di creazione/modifica di un progetto
// -------------------------------------------------------------------------------------
// In creazione si può scegliere un template: colonne, task e to-do vengono copiati nel
// nuovo progetto. In modifica il template non è più cambiabile (la bacheca esiste già).
// =====================================================================================

// Importa il router
import { useNavigate } from 'react-router';
// Importa il form e l'integrazione Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le notifiche
import { toast } from 'sonner';
// Importa i tipi di Zod
import type { z } from 'zod';
// Importa schemi, etichette e tipi condivisi
import { creaProgettoSchema, STATI_PROGETTO, type Progetto } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input, Select, Textarea } from '@/components/ui/campi';
import { Dialog, PiedeDialog } from '@/components/ui/dialog';
// Importa hook
import { useAggiornaProgetto, useCreaProgetto, useTemplate } from './api';
import { useClienti } from '@/features/clienti/api';
import { useCommesse } from '@/features/commesse/api';
import { useOpzioniUtenti } from '@/features/amministrazione-api';
import { useAmbito } from '@/lib/auth';
// Importa l'hook che riallinea le select con opzioni asincrone
import { useAllineaSelect } from '@/lib/hooks';
import { applicaErroriForm } from '@/lib/errori';

// Tipi dei valori del form (ingresso = quello che scrive l'utente, uscita = dopo la validazione)
type Ingresso = z.input<typeof creaProgettoSchema>;
type Uscita = z.output<typeof creaProgettoSchema>;

// Data odierna in formato AAAA-MM-GG (il locale "sv-SE" usa proprio questo formato)
const oggi = () => new Date().toLocaleDateString('sv-SE');

// Proprietà della finestra
interface ProprietaForm {
  onChiudi: () => void;
  // Progetto da modificare (assente = nuovo)
  progetto?: Progetto;
  // Cliente preselezionato (apertura dalla scheda cliente)
  cliente?: { id: string; ragioneSociale: string };
  // Commessa preselezionata (apertura dalla scheda commessa)
  commessaId?: string;
}

export function FormProgetto({ onChiudi, progetto, cliente, commessaId }: ProprietaForm) {
  // Navigazione
  const naviga = useNavigate();
  // Mutation
  const crea = useCreaProgetto();
  const aggiorna = useAggiornaProgetto(progetto?.id ?? '');
  // Utenti per il responsabile
  const { data: utenti } = useOpzioniUtenti();
  // Template utilizzabili (solo in creazione: in modifica la bacheca esiste già)
  const { data: template } = useTemplate(true);
  // Cliente fissato: dal progetto in modifica o dalla scheda cliente
  const clienteFisso = progetto?.cliente ?? cliente;
  // Clienti per la select (primi 100 in ordine alfabetico)
  const { data: clienti } = useClienti({ pageSize: 100, sort: 'ragioneSociale' });
  // Commesse del cliente selezionato, per collegare il progetto
  const { data: commesse } = useCommesse({ clienteId: clienteFisso?.id, pageSize: 100 }, !!clienteFisso);
  // Solo con ambito "tutti" si può assegnare il progetto a un altro responsabile
  const puoAssegnare = useAmbito('progetti.write') === 'tutti';

  // Form
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<Ingresso, unknown, Uscita>({
    resolver: zodResolver(creaProgettoSchema),
    defaultValues: {
      clienteId: clienteFisso?.id ?? '',
      commessaId: progetto?.commessa?.id ?? commessaId ?? null,
      templateId: null,
      nome: progetto?.nome ?? '',
      descrizione: progetto?.descrizione ?? '',
      stato: progetto?.stato ?? 'pianificato',
      responsabileId: progetto?.responsabile?.id ?? null,
      dataInizio: progetto?.dataInizio ?? oggi(),
      dataFinePrevista: progetto?.dataFinePrevista ?? null,
      dataFineEffettiva: progetto?.dataFineEffettiva ?? null,
      note: progetto?.note ?? '',
    },
  });
  // Mostra il valore corretto nelle select anche se le opzioni arrivano dopo l'apertura
  useAllineaSelect(setValue, getValues, ['clienteId', 'templateId', 'commessaId', 'responsabileId'], [clienti, template, commesse, utenti]);

  // Invio del form
  const invia = handleSubmit(async (dati) => {
    // Cliente e template non fanno parte della modifica
    const { clienteId, templateId, ...resto } = dati;
    try {
      if (progetto) {
        // Modifica
        await aggiorna.mutateAsync(resto);
        toast.success('Progetto aggiornato');
        onChiudi();
      } else {
        // Creazione e apertura del dettaglio
        const nuovo = await crea.mutateAsync({ ...resto, clienteId, templateId });
        toast.success(`Progetto ${nuovo.codice} creato`);
        onChiudi();
        naviga(`/progetti/${nuovo.id}`);
      }
    } catch (errore) {
      // Riporta gli errori del server sui campi del form
      applicaErroriForm(errore, setError);
    }
  });

  return (
    <Dialog aperto onChiudi={onChiudi} titolo={progetto ? 'Modifica progetto' : 'Nuovo progetto'} descrizione={progetto?.codice ?? clienteFisso?.ragioneSociale} larghezza="lg">
      <form onSubmit={invia} noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          {/* Cliente: select solo in creazione senza cliente preselezionato */}
          {!clienteFisso && (
            <Campo etichetta="Cliente" htmlFor="clienteId" obbligatorio errore={errors.clienteId?.message} className="sm:col-span-2">
              <Select id="clienteId" aria-invalid={!!errors.clienteId} {...register('clienteId')}>
                <option value="">— Seleziona un cliente —</option>
                {clienti?.data.map((c) => (
                  <option key={c.id} value={c.id}>{c.ragioneSociale} ({c.codice})</option>
                ))}
              </Select>
            </Campo>
          )}
          {/* Nome */}
          <Campo etichetta="Nome del progetto" htmlFor="nome" obbligatorio errore={errors.nome?.message} className="sm:col-span-2">
            <Input id="nome" autoFocus aria-invalid={!!errors.nome} {...register('nome')} />
          </Campo>
          {/* Template: solo in creazione */}
          {!progetto && (
            <Campo
              etichetta="Template"
              htmlFor="templateId"
              className="sm:col-span-2"
              aiuto="Copia colonne, task e to-do nel nuovo progetto. Senza template si parte da una bacheca standard vuota."
            >
              <Select id="templateId" {...register('templateId', { setValueAs: (v: string) => v || null })}>
                <option value="">— Bacheca standard (senza task) —</option>
                {template?.map((t) => (
                  <option key={t.id} value={t.id}>{t.nome}{t.categoria ? ` · ${t.categoria}` : ''} ({t.numeroTask} task)</option>
                ))}
              </Select>
            </Campo>
          )}
          {/* Stato */}
          <Campo etichetta="Stato" htmlFor="stato" obbligatorio>
            <Select id="stato" {...register('stato')}>
              {Object.entries(STATI_PROGETTO).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
            </Select>
          </Campo>
          {/* Commessa collegata (facoltativa) */}
          <Campo etichetta="Commessa collegata" htmlFor="commessaId" errore={errors.commessaId?.message} aiuto={clienteFisso ? undefined : 'Disponibile dopo aver scelto il cliente'}>
            <Select id="commessaId" disabled={!clienteFisso} {...register('commessaId', { setValueAs: (v: string) => v || null })}>
              <option value="">— Nessuna —</option>
              {commesse?.data.map((c) => (
                <option key={c.id} value={c.id}>{c.codice} — {c.titolo}</option>
              ))}
            </Select>
          </Campo>
          {/* Date */}
          <Campo etichetta="Inizio" htmlFor="dataInizio" errore={errors.dataInizio?.message}>
            <Input id="dataInizio" type="date" aria-invalid={!!errors.dataInizio} {...register('dataInizio', { setValueAs: (v: string) => v || null })} />
          </Campo>
          <Campo etichetta="Fine prevista" htmlFor="dataFinePrevista" errore={errors.dataFinePrevista?.message}>
            <Input id="dataFinePrevista" type="date" aria-invalid={!!errors.dataFinePrevista} {...register('dataFinePrevista', { setValueAs: (v: string) => v || null })} />
          </Campo>
          {/* Responsabile */}
          {puoAssegnare && (
            <Campo etichetta="Responsabile" htmlFor="responsabileId" errore={errors.responsabileId?.message}>
              <Select id="responsabileId" {...register('responsabileId', { setValueAs: (v: string) => v || null })}>
                <option value="">— Nessuno —</option>
                {utenti?.map((u) => <option key={u.id} value={u.id}>{u.cognome} {u.nome}</option>)}
              </Select>
            </Campo>
          )}
          {/* Fine effettiva: solo in modifica (in creazione la imposta il passaggio a "concluso") */}
          {progetto && (
            <Campo etichetta="Fine effettiva" htmlFor="dataFineEffettiva" errore={errors.dataFineEffettiva?.message} aiuto="Impostata automaticamente alla conclusione">
              <Input id="dataFineEffettiva" type="date" aria-invalid={!!errors.dataFineEffettiva} {...register('dataFineEffettiva', { setValueAs: (v: string) => v || null })} />
            </Campo>
          )}
          {/* Descrizione */}
          <Campo etichetta="Descrizione" htmlFor="descrizione" errore={errors.descrizione?.message} className="sm:col-span-2">
            <Textarea id="descrizione" rows={3} {...register('descrizione')} />
          </Campo>
        </div>
        {/* Pulsanti */}
        <PiedeDialog>
          <Button variante="secondario" onClick={onChiudi}>Annulla</Button>
          <Button type="submit" caricamento={isSubmitting}>{progetto ? 'Salva modifiche' : 'Crea progetto'}</Button>
        </PiedeDialog>
      </form>
    </Dialog>
  );
}
