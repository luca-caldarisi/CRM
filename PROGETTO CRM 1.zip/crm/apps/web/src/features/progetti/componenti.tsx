// =====================================================================================
// Elementi grafici riutilizzati dal modulo Progetti: stato, priorità, avanzamento, durate
// =====================================================================================

// Importa etichette e tipi condivisi
import { PRIORITA_TASK, STATI_PROGETTO, testoDaMinuti, type PrioritaTask, type StatoProgetto } from '@crm/shared';
// Importa il badge e il tipo dei colori
import { Badge, type ColoreBadge } from '@/components/ui/elementi';
// Importa l'utilità per le classi
import { cn } from '@/lib/utils';

// Colore del badge per ogni stato del progetto
export const COLORE_STATO_PROGETTO: Record<StatoProgetto, ColoreBadge> = {
  pianificato: 'grigio',
  in_corso: 'blu',
  sospeso: 'giallo',
  concluso: 'verde',
  annullato: 'rosso',
};

// Badge dello stato di un progetto
export function BadgeStatoProgetto({ stato }: { stato: StatoProgetto }) {
  return <Badge colore={COLORE_STATO_PROGETTO[stato]}>{STATI_PROGETTO[stato]}</Badge>;
}

// Colore del badge per ogni priorità
const COLORE_PRIORITA: Record<PrioritaTask, ColoreBadge> = { bassa: 'grigio', media: 'blu', alta: 'giallo', urgente: 'rosso' };

// Badge della priorità di un task (la priorità "media" non si mostra: è il caso normale)
export function BadgePriorita({ priorita }: { priorita: PrioritaTask }) {
  // La priorità normale non merita rumore visivo
  if (priorita === 'media') return null;
  // Etichetta colorata
  return <Badge colore={COLORE_PRIORITA[priorita]}>{PRIORITA_TASK[priorita]}</Badge>;
}

// Barra di avanzamento con percentuale
export function BarraAvanzamento({ valore, className, mostraPercentuale = true }: { valore: number; className?: string; mostraPercentuale?: boolean }) {
  return (
    <div className={cn('flex items-center gap-2', className)}>
      {/* Traccia della barra, con valore annunciato agli screen reader */}
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-slate-200" role="progressbar" aria-valuenow={valore} aria-valuemin={0} aria-valuemax={100} aria-label="Avanzamento">
        {/* Parte riempita: verde al 100%, altrimenti colore primario */}
        <div className={cn('h-full rounded-full transition-all', valore === 100 ? 'bg-emerald-500' : 'bg-primario-500')} style={{ width: `${valore}%` }} />
      </div>
      {/* Percentuale in cifre */}
      {mostraPercentuale && <span className="w-9 shrink-0 text-right text-xs font-medium tabular-nums text-slate-600">{valore}%</span>}
    </div>
  );
}

// Durata in minuti formattata (es. 90 -> "1h 30m"); trattino se nulla
export function Durata({ minuti }: { minuti: number | null | undefined }) {
  // Nessuna durata registrata
  if (!minuti) return <span className="text-slate-400">—</span>;
  // Testo leggibile
  return <span className="tabular-nums">{testoDaMinuti(minuti)}</span>;
}

// Converte le ore stimate (stringa decimale del database) in minuti interi
export function oreInMinuti(ore: string | null | undefined): number {
  // Campo vuoto
  if (ore == null) return 0;
  // Ore decimali convertite in minuti
  return Math.round(Number(ore) * 60);
}
