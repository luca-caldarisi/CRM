// =====================================================================================
// Finestra di creazione di un task nella bacheca
// =====================================================================================

// Importa il form e l'integrazione Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le notifiche
import { toast } from 'sonner';
// Importa i tipi di Zod
import type { z } from 'zod';
// Importa schemi, etichette e tipi condivisi
import { creaTaskSchema, PRIORITA_TASK, type ColonnaProgetto } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input, Select, Textarea } from '@/components/ui/campi';
import { Dialog, PiedeDialog } from '@/components/ui/dialog';
// Importa hook
import { useCreaTask } from './api';
import { useOpzioniUtenti } from '@/features/amministrazione-api';
import { useAmbito } from '@/lib/auth';
// Importa l'hook che riallinea le select con opzioni asincrone
import { useAllineaSelect } from '@/lib/hooks';
import { applicaErroriForm } from '@/lib/errori';

// Tipi dei valori del form
type Ingresso = z.input<typeof creaTaskSchema>;
type Uscita = z.output<typeof creaTaskSchema>;

// Proprietà della finestra
interface ProprietaFormTask {
  // Progetto in cui creare il task
  progettoId: string;
  // Colonne della bacheca disponibili
  colonne: ColonnaProgetto[];
  // Colonna preselezionata (quella del pulsante "+" premuto)
  colonnaIniziale: string;
  // Chiusura
  onChiudi: () => void;
}

export function FormTask({ progettoId, colonne, colonnaIniziale, onChiudi }: ProprietaFormTask) {
  // Mutation di creazione
  const crea = useCreaTask(progettoId);
  // Utenti assegnabili
  const { data: utenti } = useOpzioniUtenti();
  // Solo con ambito completo si può assegnare il task a un altro tecnico
  const puoAssegnare = useAmbito('task.write') === 'tutti';

  // Form
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<Ingresso, unknown, Uscita>({
    resolver: zodResolver(creaTaskSchema),
    defaultValues: { colonnaId: colonnaIniziale, titolo: '', descrizione: '', priorita: 'media', responsabileId: null, dataScadenza: null, oreStimate: null },
  });
  // Mostra il valore corretto nelle select anche se le opzioni arrivano dopo l'apertura
  useAllineaSelect(setValue, getValues, ['responsabileId'], [utenti]);

  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      // Crea il task
      await crea.mutateAsync(dati);
      toast.success('Task creato');
      onChiudi();
    } catch (errore) {
      applicaErroriForm(errore, setError);
    }
  });

  return (
    <Dialog aperto onChiudi={onChiudi} titolo="Nuovo task" larghezza="lg">
      <form onSubmit={invia} noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          {/* Titolo */}
          <Campo etichetta="Titolo" htmlFor="nt-titolo" obbligatorio errore={errors.titolo?.message} className="sm:col-span-2">
            <Input id="nt-titolo" autoFocus aria-invalid={!!errors.titolo} {...register('titolo')} />
          </Campo>
          {/* Colonna di partenza */}
          <Campo etichetta="Fase" htmlFor="nt-colonna" obbligatorio errore={errors.colonnaId?.message}>
            <Select id="nt-colonna" {...register('colonnaId')}>
              {colonne.map((c) => <option key={c.id} value={c.id}>{c.nome}</option>)}
            </Select>
          </Campo>
          {/* Priorità */}
          <Campo etichetta="Priorità" htmlFor="nt-priorita">
            <Select id="nt-priorita" {...register('priorita')}>
              {Object.entries(PRIORITA_TASK).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
            </Select>
          </Campo>
          {/* Scadenza */}
          <Campo etichetta="Scadenza" htmlFor="nt-scadenza" errore={errors.dataScadenza?.message}>
            <Input id="nt-scadenza" type="date" aria-invalid={!!errors.dataScadenza} {...register('dataScadenza', { setValueAs: (v: string) => v || null })} />
          </Campo>
          {/* Ore preventivate */}
          <Campo etichetta="Ore preventivate" htmlFor="nt-ore" errore={errors.oreStimate?.message} aiuto="In ore decimali (es. 1,5)">
            <Input
              id="nt-ore"
              type="number"
              step="0.25"
              min="0"
              inputMode="decimal"
              aria-invalid={!!errors.oreStimate}
              {...register('oreStimate', { setValueAs: (v: string) => (v === '' || v == null ? null : Number(v)) })}
            />
          </Campo>
          {/* Responsabile */}
          {puoAssegnare && (
            <Campo etichetta="Responsabile" htmlFor="nt-responsabile" errore={errors.responsabileId?.message} className="sm:col-span-2">
              <Select id="nt-responsabile" {...register('responsabileId', { setValueAs: (v: string) => v || null })}>
                <option value="">— Nessuno —</option>
                {utenti?.map((u) => <option key={u.id} value={u.id}>{u.cognome} {u.nome}</option>)}
              </Select>
            </Campo>
          )}
          {/* Descrizione */}
          <Campo etichetta="Descrizione" htmlFor="nt-descrizione" errore={errors.descrizione?.message} className="sm:col-span-2">
            <Textarea id="nt-descrizione" rows={3} {...register('descrizione')} />
          </Campo>
        </div>
        {/* Pulsanti */}
        <PiedeDialog>
          <Button variante="secondario" onClick={onChiudi}>Annulla</Button>
          <Button type="submit" caricamento={isSubmitting}>Crea task</Button>
        </PiedeDialog>
      </form>
    </Dialog>
  );
}
