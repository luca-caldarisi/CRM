// =====================================================================================
// Scheda "Ore": tutte le registrazioni del progetto con filtri per tecnico e periodo
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa le utilità condivise
import { testoDaMinuti } from '@crm/shared';
// Importa componenti
import { Input, Select } from '@/components/ui/campi';
import { Card, CardHeader, Skeleton } from '@/components/ui/elementi';
import { StatoErrore } from '@/components/common/pagina';
// Importa hook
import { useOreProgetto } from './api';
import { Durata } from './componenti';
import { useOpzioniUtenti } from '@/features/amministrazione-api';
// Importa utilità
import { formattaData, nomeCompleto } from '@/lib/utils';

export function SchedaOre({ progettoId }: { progettoId: string }) {
  // Filtri locali (non nell'URL: sono di consultazione rapida)
  const [utenteId, setUtenteId] = useState('');
  const [dal, setDal] = useState('');
  const [al, setAl] = useState('');
  // Utenti per il filtro
  const { data: utenti } = useOpzioniUtenti();
  // Registrazioni filtrate (i campi vuoti non vengono inviati)
  const { data: ore, isLoading, isError } = useOreProgetto(progettoId, {
    utenteId: utenteId || undefined,
    dal: dal || undefined,
    al: al || undefined,
  });

  // Totale dei minuti mostrati
  const totale = ore?.reduce((somma, r) => somma + r.minuti, 0) ?? 0;

  return (
    <Card>
      <CardHeader
        titolo="Ore registrate"
        descrizione={ore ? `${ore.length} registrazioni · ${totale > 0 ? testoDaMinuti(totale) : '0m'} in totale` : undefined}
      />
      {/* Barra dei filtri */}
      <div className="flex flex-wrap items-end gap-3 border-b border-slate-100 p-3">
        {/* Tecnico */}
        <label className="text-xs font-medium text-slate-600">
          Tecnico
          <Select value={utenteId} onChange={(e) => setUtenteId(e.target.value)} className="mt-1 w-auto">
            <option value="">Tutti</option>
            {utenti?.map((u) => <option key={u.id} value={u.id}>{u.cognome} {u.nome}</option>)}
          </Select>
        </label>
        {/* Data iniziale */}
        <label className="text-xs font-medium text-slate-600">
          Dal
          <Input type="date" value={dal} onChange={(e) => setDal(e.target.value)} className="mt-1 w-auto" />
        </label>
        {/* Data finale */}
        <label className="text-xs font-medium text-slate-600">
          Al
          <Input type="date" value={al} onChange={(e) => setAl(e.target.value)} className="mt-1 w-auto" />
        </label>
      </div>
      {/* Caricamento */}
      {isLoading && <Skeleton className="m-5 h-32" />}
      {/* Errore */}
      {isError && <div className="p-5"><StatoErrore messaggio="Impossibile caricare le ore." /></div>}
      {/* Elenco */}
      {ore && (
        <ul className="divide-y divide-slate-100">
          {ore.map((r) => (
            <li key={r.id} className="flex flex-wrap items-center gap-3 px-5 py-2.5 text-sm">
              {/* Giorno */}
              <span className="w-24 shrink-0 text-slate-500">{formattaData(r.data)}</span>
              {/* Durata */}
              <span className="w-16 shrink-0 font-medium text-slate-900"><Durata minuti={r.minuti} /></span>
              {/* Tecnico */}
              <span className="w-36 shrink-0 truncate text-slate-600">{nomeCompleto(r.utente)}</span>
              {/* Descrizione dell'attività svolta */}
              <span className="min-w-0 flex-1 truncate text-slate-500">{r.descrizione}</span>
            </li>
          ))}
          {/* Nessuna registrazione con i filtri attivi */}
          {ore.length === 0 && <li className="px-5 py-8 text-center text-sm text-slate-400">Nessuna registrazione</li>}
        </ul>
      )}
    </Card>
  );
}
