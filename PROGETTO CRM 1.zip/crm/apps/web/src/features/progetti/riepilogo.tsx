// =====================================================================================
// Riepilogo dell'avanzamento di un progetto: KPI, distribuzione per colonna, ore per tecnico
// =====================================================================================

// Importa le icone
import { AlertTriangle, CheckCircle2, Clock, ListChecks } from 'lucide-react';
// Importa le utilità condivise
import { testoDaMinuti } from '@crm/shared';
// Importa componenti
import { Card, CardHeader, Skeleton } from '@/components/ui/elementi';
import { StatoErrore } from '@/components/common/pagina';
// Importa funzionalità del modulo
import { useRiepilogo } from './api';
import { BarraAvanzamento, Durata } from './componenti';
// Importa utilità
import { cn, formattaData, nomeCompleto } from '@/lib/utils';

// Riquadro con un indicatore
function Kpi({ etichetta, valore, dettaglio, icona: Icona, tono = 'neutro' }: { etichetta: string; valore: string; dettaglio?: string; icona: typeof Clock; tono?: 'neutro' | 'positivo' | 'attenzione' }) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          {/* Etichetta */}
          <p className="text-xs font-medium text-slate-500">{etichetta}</p>
          {/* Valore principale */}
          <p className="mt-1 text-xl font-semibold tabular-nums text-slate-900">{valore}</p>
          {/* Riga di dettaglio */}
          {dettaglio && <p className="mt-0.5 text-xs text-slate-500">{dettaglio}</p>}
        </div>
        {/* Icona colorata secondo il tono */}
        <span
          className={cn(
            'flex size-9 shrink-0 items-center justify-center rounded-lg',
            tono === 'positivo' ? 'bg-emerald-50 text-emerald-600' : tono === 'attenzione' ? 'bg-amber-50 text-amber-600' : 'bg-slate-100 text-slate-500',
          )}
        >
          <Icona className="size-4" aria-hidden />
        </span>
      </div>
    </Card>
  );
}

export function RiepilogoProgetto({ progettoId }: { progettoId: string }) {
  // Dati del riepilogo
  const { data: r, isLoading, isError } = useRiepilogo(progettoId);

  // Caricamento
  if (isLoading) return <Skeleton className="h-64" />;
  // Errore
  if (isError || !r) return <StatoErrore messaggio="Impossibile caricare il riepilogo." />;

  // Scostamento tra ore registrate e preventivate (positivo = si è andati oltre)
  const scostamento = r.minutiRegistrati - r.minutiStimati;

  return (
    <div className="space-y-4">
      {/* Indicatori principali */}
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {/* Avanzamento sui task completati */}
        <Kpi
          etichetta="Avanzamento"
          valore={`${r.avanzamento}%`}
          dettaglio={`${r.taskCompletati} di ${r.taskTotali} task completati`}
          icona={CheckCircle2}
          tono={r.avanzamento === 100 ? 'positivo' : 'neutro'}
        />
        {/* Ore registrate contro preventivo */}
        <Kpi
          etichetta="Ore registrate"
          valore={r.minutiRegistrati > 0 ? testoDaMinuti(r.minutiRegistrati) : '—'}
          dettaglio={r.minutiStimati > 0 ? `${testoDaMinuti(r.minutiStimati)} preventivate (${scostamento >= 0 ? '+' : '\u2212'}${testoDaMinuti(Math.abs(scostamento))})` : 'Nessun preventivo'}
          icona={Clock}
          tono={r.minutiStimati > 0 && scostamento > 0 ? 'attenzione' : 'neutro'}
        />
        {/* Attività della to-do */}
        <Kpi
          etichetta="Attività (to-do)"
          valore={r.todoTotali > 0 ? `${r.todoCompletate}/${r.todoTotali}` : '—'}
          dettaglio={r.todoTotali > 0 ? `${Math.round((r.todoCompletate / r.todoTotali) * 100)}% completate` : 'Nessuna attività'}
          icona={ListChecks}
        />
        {/* Task scaduti e non completati */}
        <Kpi
          etichetta="Task in ritardo"
          valore={String(r.taskInRitardo)}
          dettaglio={r.taskInRitardo === 0 ? 'Nessuna scadenza superata' : 'Scadenza superata e non completati'}
          icona={AlertTriangle}
          tono={r.taskInRitardo > 0 ? 'attenzione' : 'positivo'}
        />
      </div>

      {/* Barra di avanzamento a tutta larghezza */}
      <Card className="p-4">
        <p className="mb-2 text-xs font-medium text-slate-500">Avanzamento complessivo (calcolato sui task nelle colonne di completamento)</p>
        <BarraAvanzamento valore={r.avanzamento} />
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Distribuzione dei task per colonna */}
        <Card>
          <CardHeader titolo="Task per fase" descrizione="Distribuzione sulla bacheca" />
          <ul className="divide-y divide-slate-100">
            {r.perColonna.map((c) => (
              <li key={c.colonnaId} className="flex items-center gap-3 px-5 py-2.5">
                {/* Nome della fase */}
                <span className="flex min-w-0 flex-1 items-center gap-2 text-sm text-slate-700">
                  {/* Pallino per le colonne di completamento */}
                  {c.consideraCompletato && <span className="size-2 shrink-0 rounded-full bg-emerald-500" aria-hidden />}
                  <span className="truncate">{c.nome}</span>
                </span>
                {/* Barra proporzionale al totale */}
                <span className="h-1.5 w-28 overflow-hidden rounded-full bg-slate-100">
                  <span
                    className={cn('block h-full rounded-full', c.consideraCompletato ? 'bg-emerald-500' : 'bg-primario-400')}
                    style={{ width: `${r.taskTotali === 0 ? 0 : Math.round((c.task / r.taskTotali) * 100)}%` }}
                  />
                </span>
                {/* Numero di task */}
                <span className="w-6 shrink-0 text-right text-sm font-medium tabular-nums text-slate-900">{c.task}</span>
              </li>
            ))}
          </ul>
        </Card>

        {/* Ore per tecnico */}
        <Card>
          <CardHeader titolo="Ore per tecnico" descrizione="Chi ha lavorato sul progetto" />
          <ul className="divide-y divide-slate-100">
            {r.perTecnico.map((t) => (
              <li key={t.utente.id} className="flex items-center gap-3 px-5 py-2.5 text-sm">
                {/* Nome */}
                <span className="min-w-0 flex-1 truncate text-slate-700">{nomeCompleto(t.utente)}</span>
                {/* Numero di task su cui ha lavorato */}
                <span className="shrink-0 text-xs text-slate-500">{t.task} task</span>
                {/* Ore totali */}
                <span className="w-16 shrink-0 text-right font-medium text-slate-900"><Durata minuti={t.minuti} /></span>
              </li>
            ))}
            {/* Nessuna ora registrata */}
            {r.perTecnico.length === 0 && <li className="px-5 py-6 text-center text-xs text-slate-400">Nessuna ora registrata</li>}
          </ul>
        </Card>
      </div>

      {/* Ultime registrazioni di ore */}
      <Card>
        <CardHeader titolo="Ultime ore registrate" descrizione="Le 10 registrazioni più recenti" />
        <ul className="divide-y divide-slate-100">
          {r.ultimeOre.map((o) => (
            <li key={o.id} className="flex items-center gap-3 px-5 py-2.5 text-sm">
              {/* Giorno */}
              <span className="w-24 shrink-0 text-slate-500">{formattaData(o.data)}</span>
              {/* Durata */}
              <span className="w-16 shrink-0 font-medium text-slate-900"><Durata minuti={o.minuti} /></span>
              {/* Tecnico */}
              <span className="w-36 shrink-0 truncate text-slate-600">{nomeCompleto(o.utente)}</span>
              {/* Descrizione dell'attività */}
              <span className="min-w-0 flex-1 truncate text-slate-500">{o.descrizione}</span>
            </li>
          ))}
          {/* Nessuna registrazione */}
          {r.ultimeOre.length === 0 && <li className="px-5 py-6 text-center text-xs text-slate-400">Nessuna registrazione</li>}
        </ul>
      </Card>
    </div>
  );
}
