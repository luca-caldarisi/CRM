// =====================================================================================
// Finestra di dettaglio di un task: dati, voci della to-do e registrazione delle ore
// =====================================================================================

// Importa gli hook di React
import { useState } from 'react';
// Importa il form e l'integrazione Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le notifiche
import { toast } from 'sonner';
// Importa i tipi di Zod
import type { z } from 'zod';
// Importa schemi, etichette, utilità e tipi condivisi
import { aggiornaTaskSchema, PRIORITA_TASK, registraOreSchema, testoDaMinuti, type TaskDettaglio, type VoceTodo } from '@crm/shared';
// Importa le icone
import { Check, Clock, Plus, Trash2, UserRound } from 'lucide-react';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input, Select, Textarea } from '@/components/ui/campi';
import { ConfermaDialog, Dialog, PiedeDialog } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/elementi';
import { StatoErrore } from '@/components/common/pagina';
// Importa funzionalità del modulo
import {
  useAggiornaTask,
  useAggiornaTodo,
  useAggiungiTodo,
  useEliminaOre,
  useEliminaTask,
  useEliminaTodo,
  useRegistraOre,
  useTask,
} from './api';
import { BarraAvanzamento, Durata, oreInMinuti } from './componenti';
// Importa utenti, permessi, errori e utilità
// Importa l'hook che riallinea le select con opzioni asincrone
import { useAllineaSelect } from '@/lib/hooks';
import { useOpzioniUtenti } from '@/features/amministrazione-api';
import { useAmbito, useAuth, usePermesso } from '@/lib/auth';
import { applicaErroriForm, notificaErrore } from '@/lib/errori';
import { cn, formattaData, nomeCompleto } from '@/lib/utils';

// Data odierna in formato AAAA-MM-GG
const oggi = () => new Date().toLocaleDateString('sv-SE');

// Proprietà della finestra
interface ProprietaDialogTask {
  // Task da mostrare
  taskId: string;
  // Chiusura
  onChiudi: () => void;
  // Il progetto è chiuso: sola lettura
  soloLettura?: boolean;
}

export function DialogTask({ taskId, onChiudi, soloLettura = false }: ProprietaDialogTask) {
  // Dati del task
  const { data: task, isLoading, isError } = useTask(taskId);
  // Eliminazione del task
  const elimina = useEliminaTask();
  // Conferma di eliminazione
  const [conferma, setConferma] = useState(false);
  // Permessi di interfaccia
  const puoModificare = usePermesso('task.write') && !soloLettura;
  const puoEliminare = usePermesso('progetti.delete') && !soloLettura;
  const puoRegistrareOre = usePermesso('ore.write') && !soloLettura;

  return (
    <Dialog aperto onChiudi={onChiudi} titolo={task?.titolo ?? 'Task'} descrizione={task ? `Creato il ${formattaData(task.createdAt)}` : undefined} larghezza="xl">
      {/* Caricamento */}
      {isLoading && <Skeleton className="h-64" />}
      {/* Errore */}
      {isError && <StatoErrore messaggio="Impossibile caricare il task." />}
      {/* Contenuto */}
      {task && (
        <>
          {/* Riepilogo in cima: to-do completate e ore */}
          <div className="mb-4 grid gap-3 sm:grid-cols-3">
            {/* Avanzamento della to-do */}
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs font-medium text-slate-500">To-do</p>
              <p className="mt-1 text-sm font-semibold text-slate-900">{task.todoCompletate} di {task.todoTotali}</p>
              {task.todoTotali > 0 && <BarraAvanzamento valore={Math.round((task.todoCompletate / task.todoTotali) * 100)} className="mt-2" mostraPercentuale={false} />}
            </div>
            {/* Ore registrate */}
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs font-medium text-slate-500">Ore registrate</p>
              <p className="mt-1 text-sm font-semibold text-slate-900"><Durata minuti={task.minutiRegistrati} /></p>
              {/* Confronto con il preventivo */}
              {oreInMinuti(task.oreStimate) > 0 && (
                <p className={cn('mt-1 text-xs', task.minutiRegistrati > oreInMinuti(task.oreStimate) ? 'font-medium text-amber-700' : 'text-slate-500')}>
                  su {testoDaMinuti(oreInMinuti(task.oreStimate))} preventivate
                </p>
              )}
            </div>
            {/* Responsabile e scadenza */}
            <div className="rounded-lg border border-slate-200 p-3">
              <p className="text-xs font-medium text-slate-500">Responsabile</p>
              <p className="mt-1 text-sm font-semibold text-slate-900">{nomeCompleto(task.responsabile)}</p>
              {task.dataScadenza && <p className="mt-1 text-xs text-slate-500">Scadenza {formattaData(task.dataScadenza)}</p>}
            </div>
          </div>

          {/* In una finestra modale le sezioni in sequenza sono più leggibili delle schede:
              l'utente vede subito to-do, ore e dati senza dover cercare dove cliccare */}
          <div className="space-y-5">
            {/* Elenco delle voci della to-do */}
            <SezioneTodo task={task} modificabile={puoModificare} />
            {/* Registrazione ore */}
            <SezioneOre task={task} modificabile={puoRegistrareOre} />
            {/* Dati del task */}
            <SezioneDati task={task} modificabile={puoModificare} onSalvato={onChiudi} />
          </div>

          {/* Eliminazione */}
          {puoEliminare && (
            <PiedeDialog>
              <Button variante="pericolo" onClick={() => setConferma(true)}>
                <Trash2 /> Elimina task
              </Button>
            </PiedeDialog>
          )}
          {/* Conferma di eliminazione */}
          <ConfermaDialog
            aperto={conferma}
            onChiudi={() => setConferma(false)}
            caricamento={elimina.isPending}
            titolo="Eliminare il task?"
            messaggio={<>Il task <strong>{task.titolo}</strong> verrà eliminato con le sue voci di to-do e le ore registrate. L'operazione non è reversibile.</>}
            onConferma={() =>
              elimina.mutate(task.id, {
                onSuccess: () => {
                  toast.success('Task eliminato');
                  onChiudi();
                },
                onError: (e) => {
                  setConferma(false);
                  notificaErrore(e);
                },
              })
            }
          />
        </>
      )}
    </Dialog>
  );
}

// ---------------------------------------- To-do -----------------------------------------

// Elenco delle voci con spunta, assegnatario e aggiunta
function SezioneTodo({ task, modificabile }: { task: TaskDettaglio; modificabile: boolean }) {
  // Utente collegato (per capire quali voci può spuntare con ambito "propri")
  const { utente } = useAuth();
  // Ambito sui task
  const ambito = useAmbito('task.write');
  // Utenti assegnabili
  const { data: utenti } = useOpzioniUtenti();
  // Mutation
  const aggiungi = useAggiungiTodo(task.id);
  const aggiorna = useAggiornaTodo(task.id);
  const rimuovi = useEliminaTodo(task.id);
  // Testo della nuova voce
  const [nuova, setNuova] = useState('');
  // Assegnatario della nuova voce
  const [assegnatario, setAssegnatario] = useState('');

  // Con ambito "propri" si possono spuntare solo le voci dei propri task o quelle assegnate a sé
  function puoAgire(voce: VoceTodo): boolean {
    // Senza permesso non si tocca nulla
    if (!modificabile) return false;
    // Ambito completo
    if (ambito === 'tutti') return true;
    // Responsabile del task
    if (task.responsabile?.id === utente?.id) return true;
    // Assegnatario della voce
    return voce.assegnatario?.id === utente?.id;
  }

  // Aggiunge la voce digitata
  function aggiungiVoce() {
    // Testo vuoto: niente da fare
    if (!nuova.trim()) return;
    // Invia
    aggiungi.mutate(
      { titolo: nuova.trim(), assegnatarioId: assegnatario || null },
      {
        onSuccess: () => {
          // Svuota il campo per la voce successiva
          setNuova('');
        },
        onError: notificaErrore,
      },
    );
  }

  return (
    <section>
      {/* Titolo della sezione */}
      <h3 className="mb-2 text-sm font-semibold text-slate-900">Elenco attività (to-do)</h3>
      {/* Voci */}
      <ul className="divide-y divide-slate-100 rounded-lg border border-slate-200">
        {task.todo.map((v) => (
          <li key={v.id} className="flex items-center gap-2 px-3 py-2">
            {/* Spunta */}
            <button
              type="button"
              disabled={!puoAgire(v) || aggiorna.isPending}
              onClick={() => aggiorna.mutate({ id: v.id, dati: { completata: !v.completata } }, { onError: notificaErrore })}
              className={cn(
                'flex size-5 shrink-0 items-center justify-center rounded border transition-colors',
                v.completata ? 'border-emerald-500 bg-emerald-500 text-white' : 'border-slate-300 hover:border-primario-500',
                !puoAgire(v) && 'cursor-not-allowed opacity-60',
              )}
              aria-label={v.completata ? `Segna "${v.titolo}" come da fare` : `Completa "${v.titolo}"`}
              aria-pressed={v.completata}
            >
              {/* Segno di spunta visibile solo quando completata */}
              {v.completata && <Check className="size-3.5" aria-hidden />}
            </button>
            {/* Testo */}
            <span className={cn('min-w-0 flex-1 text-sm', v.completata ? 'text-slate-400 line-through' : 'text-slate-800')}>{v.titolo}</span>
            {/* Assegnatario modificabile a tendina */}
            {modificabile && ambito === 'tutti' ? (
              <Select
                value={v.assegnatario?.id ?? ''}
                onChange={(e) => aggiorna.mutate({ id: v.id, dati: { assegnatarioId: e.target.value || null } }, { onError: notificaErrore })}
                className="h-7 w-auto max-w-40 py-0 text-xs"
                aria-label={`Assegnatario di ${v.titolo}`}
              >
                <option value="">— Non assegnata —</option>
                {utenti?.map((u) => <option key={u.id} value={u.id}>{u.cognome} {u.nome}</option>)}
              </Select>
            ) : (
              // Solo lettura: nome dell'assegnatario
              v.assegnatario && (
                <span className="inline-flex items-center gap-1 text-xs text-slate-500">
                  <UserRound className="size-3.5" aria-hidden />
                  {nomeCompleto(v.assegnatario)}
                </span>
              )
            )}
            {/* Eliminazione della voce (solo il responsabile del task o chi ha ambito completo) */}
            {modificabile && (ambito === 'tutti' || task.responsabile?.id === utente?.id) && (
              <Button
                variante="fantasma"
                dimensione="icona"
                onClick={() => rimuovi.mutate(v.id, { onError: notificaErrore })}
                aria-label={`Elimina "${v.titolo}"`}
              >
                <Trash2 className="text-slate-400" />
              </Button>
            )}
          </li>
        ))}
        {/* Elenco vuoto */}
        {task.todo.length === 0 && <li className="px-3 py-4 text-center text-xs text-slate-400">Nessuna attività nell'elenco</li>}
        {/* Riga di aggiunta */}
        {modificabile && (
          <li className="flex flex-wrap items-center gap-2 bg-slate-50/60 px-3 py-2">
            {/* Testo della nuova voce: Invio aggiunge senza usare il mouse */}
            <Input
              value={nuova}
              onChange={(e) => setNuova(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  aggiungiVoce();
                }
              }}
              placeholder="Aggiungi un'attività e premi Invio…"
              className="h-8 min-w-48 flex-1"
              aria-label="Nuova attività"
            />
            {/* Assegnatario della nuova voce */}
            {ambito === 'tutti' && (
              <Select value={assegnatario} onChange={(e) => setAssegnatario(e.target.value)} className="h-8 w-auto py-0 text-xs" aria-label="Assegna a">
                <option value="">— Non assegnata —</option>
                {utenti?.map((u) => <option key={u.id} value={u.id}>{u.cognome} {u.nome}</option>)}
              </Select>
            )}
            {/* Pulsante di aggiunta */}
            <Button dimensione="piccolo" onClick={aggiungiVoce} caricamento={aggiungi.isPending} disabled={!nuova.trim()}>
              <Plus /> Aggiungi
            </Button>
          </li>
        )}
      </ul>
    </section>
  );
}

// ----------------------------------------- Ore ------------------------------------------

// Tipi del form delle ore
type IngressoOre = z.input<typeof registraOreSchema>;
type UscitaOre = z.output<typeof registraOreSchema>;

// Registrazione e storico delle ore del task
function SezioneOre({ task, modificabile }: { task: TaskDettaglio; modificabile: boolean }) {
  // Utente collegato
  const { utente } = useAuth();
  // Ambito sulle ore: con "tutti" si possono registrare anche per altri tecnici
  const ambito = useAmbito('ore.write');
  // Utenti selezionabili
  const { data: utenti } = useOpzioniUtenti();
  // Mutation
  const registra = useRegistraOre(task.id);
  const rimuovi = useEliminaOre(task.id);

  // Form della nuova registrazione
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    reset,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<IngressoOre, unknown, UscitaOre>({
    resolver: zodResolver(registraOreSchema),
    defaultValues: { data: oggi(), durata: '', descrizione: '', utenteId: null },
  });
  // Mostra il valore corretto nelle select anche se le opzioni arrivano dopo l'apertura
  useAllineaSelect(setValue, getValues, ['utenteId'], [utenti]);

  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      // Registra le ore. Lo schema ha già convertito la durata in minuti: la si rimanda al
      // server nel formato "90m", che il medesimo schema riconosce (il server rivalida sempre).
      await registra.mutateAsync({ ...dati, durata: `${dati.durata}m` });
      // Notifica e ripulisce il form mantenendo la data
      toast.success('Ore registrate');
      reset({ data: dati.data, durata: '', descrizione: '', utenteId: dati.utenteId ?? null });
    } catch (errore) {
      applicaErroriForm(errore, setError);
    }
  });

  return (
    <section>
      {/* Titolo della sezione */}
      <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900">
        <Clock className="size-4 text-slate-400" aria-hidden /> Ore lavorate
      </h3>
      {/* Form di registrazione */}
      {modificabile && (
        <form onSubmit={invia} noValidate className="mb-3 grid gap-3 rounded-lg border border-slate-200 bg-slate-50/60 p-3 sm:grid-cols-[auto_auto_1fr_auto] sm:items-end">
          {/* Giorno */}
          <Campo etichetta="Data" htmlFor="ore-data" errore={errors.data?.message}>
            <Input id="ore-data" type="date" max={oggi()} className="w-auto" aria-invalid={!!errors.data} {...register('data')} />
          </Campo>
          {/* Durata in formato libero */}
          <Campo etichetta="Durata" htmlFor="ore-durata" errore={errors.durata?.message}>
            <Input id="ore-durata" placeholder="1:30 oppure 1,5" className="w-32" aria-invalid={!!errors.durata} {...register('durata')} />
          </Campo>
          {/* Descrizione dell'attività */}
          <Campo etichetta="Attività svolta" htmlFor="ore-descrizione" errore={errors.descrizione?.message}>
            <Input id="ore-descrizione" placeholder="Facoltativa" {...register('descrizione')} />
          </Campo>
          {/* Invio */}
          <Button type="submit" caricamento={isSubmitting}>Registra</Button>
          {/* Tecnico: solo con ambito completo */}
          {ambito === 'tutti' && (
            <Campo etichetta="Tecnico" htmlFor="ore-utente" className="sm:col-span-4 sm:max-w-60">
              <Select id="ore-utente" {...register('utenteId', { setValueAs: (v: string) => v || null })}>
                <option value="">— Io ({nomeCompleto(utente)}) —</option>
                {utenti?.map((u) => <option key={u.id} value={u.id}>{u.cognome} {u.nome}</option>)}
              </Select>
            </Campo>
          )}
        </form>
      )}
      {/* Storico */}
      <ul className="divide-y divide-slate-100 rounded-lg border border-slate-200">
        {task.ore.map((r) => (
          <li key={r.id} className="flex items-center gap-3 px-3 py-2 text-sm">
            {/* Data */}
            <span className="w-24 shrink-0 text-slate-500">{formattaData(r.data)}</span>
            {/* Durata */}
            <span className="w-16 shrink-0 font-medium text-slate-900"><Durata minuti={r.minuti} /></span>
            {/* Tecnico */}
            <span className="w-32 shrink-0 truncate text-slate-600">{nomeCompleto(r.utente)}</span>
            {/* Descrizione */}
            <span className="min-w-0 flex-1 truncate text-slate-500">{r.descrizione}</span>
            {/* Eliminazione: le proprie ore, oppure tutte con ambito completo */}
            {modificabile && (ambito === 'tutti' || r.utente.id === utente?.id) && (
              <Button variante="fantasma" dimensione="icona" onClick={() => rimuovi.mutate(r.id, { onError: notificaErrore })} aria-label="Elimina registrazione">
                <Trash2 className="text-slate-400" />
              </Button>
            )}
          </li>
        ))}
        {/* Nessuna registrazione */}
        {task.ore.length === 0 && <li className="px-3 py-4 text-center text-xs text-slate-400">Nessuna ora registrata</li>}
      </ul>
    </section>
  );
}

// ---------------------------------------- Dati ------------------------------------------

// Tipi del form dei dati del task
type IngressoTask = z.input<typeof aggiornaTaskSchema>;
type UscitaTask = z.output<typeof aggiornaTaskSchema>;

// Modifica dei dati del task
function SezioneDati({ task, modificabile, onSalvato }: { task: TaskDettaglio; modificabile: boolean; onSalvato: () => void }) {
  // Ambito sui task
  const ambito = useAmbito('task.write');
  // Utenti assegnabili
  const { data: utenti } = useOpzioniUtenti();
  // Mutation
  const aggiorna = useAggiornaTask(task.id);

  // Form
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting, isDirty },
  } = useForm<IngressoTask, unknown, UscitaTask>({
    resolver: zodResolver(aggiornaTaskSchema),
    defaultValues: {
      titolo: task.titolo,
      descrizione: task.descrizione ?? '',
      priorita: task.priorita,
      responsabileId: task.responsabile?.id ?? null,
      dataScadenza: task.dataScadenza,
      // Le ore stimate arrivano come stringa decimale e servono come numero nel form
      oreStimate: task.oreStimate != null ? Number(task.oreStimate) : null,
    },
  });
  // Mostra il valore corretto nelle select anche se le opzioni arrivano dopo l'apertura
  useAllineaSelect(setValue, getValues, ['responsabileId'], [utenti]);

  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      // Salva
      await aggiorna.mutateAsync(dati);
      toast.success('Task aggiornato');
      onSalvato();
    } catch (errore) {
      applicaErroriForm(errore, setError);
    }
  });

  // Sola lettura: mostra i dati senza form
  if (!modificabile) {
    return (
      <section>
        <h3 className="mb-2 text-sm font-semibold text-slate-900">Descrizione</h3>
        <p className="whitespace-pre-line rounded-lg border border-slate-200 p-3 text-sm text-slate-700">
          {task.descrizione || <span className="text-slate-400">Nessuna descrizione</span>}
        </p>
      </section>
    );
  }

  return (
    <section>
      {/* Titolo della sezione */}
      <h3 className="mb-2 text-sm font-semibold text-slate-900">Dati del task</h3>
      <form onSubmit={invia} noValidate className="grid gap-4 rounded-lg border border-slate-200 p-3 sm:grid-cols-2">
        {/* Titolo */}
        <Campo etichetta="Titolo" htmlFor="task-titolo" obbligatorio errore={errors.titolo?.message} className="sm:col-span-2">
          <Input id="task-titolo" aria-invalid={!!errors.titolo} {...register('titolo')} />
        </Campo>
        {/* Priorità */}
        <Campo etichetta="Priorità" htmlFor="task-priorita">
          <Select id="task-priorita" {...register('priorita')}>
            {Object.entries(PRIORITA_TASK).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
          </Select>
        </Campo>
        {/* Scadenza */}
        <Campo etichetta="Scadenza" htmlFor="task-scadenza" errore={errors.dataScadenza?.message}>
          <Input id="task-scadenza" type="date" aria-invalid={!!errors.dataScadenza} {...register('dataScadenza', { setValueAs: (v: string) => v || null })} />
        </Campo>
        {/* Ore preventivate */}
        <Campo etichetta="Ore preventivate" htmlFor="task-ore" errore={errors.oreStimate?.message} aiuto="In ore decimali (es. 1,5)">
          <Input
            id="task-ore"
            type="number"
            step="0.25"
            min="0"
            inputMode="decimal"
            aria-invalid={!!errors.oreStimate}
            {...register('oreStimate', { setValueAs: (v: string) => (v === '' || v == null ? null : Number(v)) })}
          />
        </Campo>
        {/* Responsabile: solo con ambito completo (chi ha "propri" può lavorare solo sui suoi) */}
        {ambito === 'tutti' && (
          <Campo etichetta="Responsabile" htmlFor="task-responsabile" errore={errors.responsabileId?.message}>
            <Select id="task-responsabile" {...register('responsabileId', { setValueAs: (v: string) => v || null })}>
              <option value="">— Nessuno —</option>
              {utenti?.map((u) => <option key={u.id} value={u.id}>{u.cognome} {u.nome}</option>)}
            </Select>
          </Campo>
        )}
        {/* Descrizione */}
        <Campo etichetta="Descrizione" htmlFor="task-descrizione" errore={errors.descrizione?.message} className="sm:col-span-2">
          <Textarea id="task-descrizione" rows={3} {...register('descrizione')} />
        </Campo>
        {/* Salvataggio: attivo solo se qualcosa è cambiato */}
        <div className="sm:col-span-2">
          <Button type="submit" caricamento={isSubmitting} disabled={!isDirty}>Salva modifiche</Button>
        </div>
      </form>
    </section>
  );
}
