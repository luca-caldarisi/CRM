// =====================================================================================
// Hook per leggere e modificare progetti, task, to-do, ore e template
// =====================================================================================

// Importa le funzioni di TanStack Query
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
// Importa i tipi condivisi
import type {
  AggiornaProgettoInput,
  AggiornaTaskInput,
  AggiornaTemplateInput,
  AggiornaTodoInput,
  Bacheca,
  CreaProgettoInput,
  CreaTaskInput,
  CreaTemplateInput,
  CreaTodoInput,
  Progetto,
  ProgettoLista,
  RegistraOreInput,
  RegistrazioneOre,
  RiepilogoProgetto,
  RispostaPaginata,
  StatoProgetto,
  StrutturaTemplateInput,
  TaskDettaglio,
  TemplateProgetto,
  TemplateProgettoDettaglio,
  VoceTodo,
} from '@crm/shared';
// Importa il client API
import { api } from '@/lib/api';

// Chiavi della cache: raggruppate per poter invalidare in blocco
export const chiaviProgetti = {
  tutti: ['progetti'] as const,
  lista: (filtri: object) => ['progetti', 'lista', filtri] as const,
  dettaglio: (id: string) => ['progetti', 'dettaglio', id] as const,
  bacheca: (id: string) => ['progetti', 'bacheca', id] as const,
  riepilogo: (id: string) => ['progetti', 'riepilogo', id] as const,
  ore: (id: string, filtri: object) => ['progetti', 'ore', id, filtri] as const,
  task: (id: string) => ['task', id] as const,
  template: ['progetto-template'] as const,
  templateDettaglio: (id: string) => ['progetto-template', id] as const,
};

// Filtri dell'elenco progetti
export interface FiltriProgetti {
  q?: string;
  page?: number;
  pageSize?: number;
  sort?: string;
  clienteId?: string;
  commessaId?: string;
  responsabileId?: string;
  stato?: StatoProgetto | '';
}

// ------------------------------------ Letture ------------------------------------------

// Elenco paginato dei progetti
export function useProgetti(filtri: FiltriProgetti, abilitato = true) {
  return useQuery({
    enabled: abilitato,
    queryKey: chiaviProgetti.lista(filtri),
    queryFn: ({ signal }) => api<RispostaPaginata<ProgettoLista>>('/progetti', { query: { ...filtri }, signal }),
    // Mantiene i dati precedenti durante il cambio pagina: niente sfarfallio
    placeholderData: keepPreviousData,
  });
}

// Dettaglio di un progetto (dati generali e colonne della bacheca)
export function useProgetto(id: string) {
  return useQuery({ queryKey: chiaviProgetti.dettaglio(id), queryFn: ({ signal }) => api<Progetto>(`/progetti/${id}`, { signal }) });
}

// Bacheca Kanban
export function useBacheca(id: string) {
  return useQuery({ queryKey: chiaviProgetti.bacheca(id), queryFn: ({ signal }) => api<Bacheca>(`/progetti/${id}/bacheca`, { signal }) });
}

// Riepilogo dell'avanzamento
export function useRiepilogo(id: string, abilitato = true) {
  return useQuery({ enabled: abilitato, queryKey: chiaviProgetti.riepilogo(id), queryFn: ({ signal }) => api<RiepilogoProgetto>(`/progetti/${id}/riepilogo`, { signal }) });
}

// Ore registrate su tutto il progetto
export function useOreProgetto(id: string, filtri: { utenteId?: string; dal?: string; al?: string }, abilitato = true) {
  return useQuery({
    enabled: abilitato,
    queryKey: chiaviProgetti.ore(id, filtri),
    queryFn: ({ signal }) => api<RegistrazioneOre[]>(`/progetti/${id}/ore`, { query: { ...filtri }, signal }),
  });
}

// Dettaglio di un task (aperto nella finestra laterale)
export function useTask(id: string | null) {
  return useQuery({ enabled: !!id, queryKey: chiaviProgetti.task(id ?? ''), queryFn: ({ signal }) => api<TaskDettaglio>(`/task/${id}`, { signal }) });
}

// Elenco dei template ("soloAttivi" per la creazione di un progetto)
export function useTemplate(soloAttivi = false) {
  return useQuery({
    queryKey: [...chiaviProgetti.template, { soloAttivi }],
    queryFn: ({ signal }) => api<TemplateProgetto[]>('/progetto-template', { query: soloAttivi ? { attivi: 'true' } : {}, signal }),
  });
}

// Dettaglio di un template con la struttura
export function useTemplateDettaglio(id: string | null) {
  return useQuery({ enabled: !!id, queryKey: chiaviProgetti.templateDettaglio(id ?? ''), queryFn: ({ signal }) => api<TemplateProgettoDettaglio>(`/progetto-template/${id}`, { signal }) });
}

// ----------------------------------- Invalidazioni -------------------------------------

// Invalida tutto ciò che riguarda i progetti (bacheca, riepilogo, elenchi)
// Un task modificato cambia avanzamento e conteggi: conviene ricaricare in blocco
function useInvalidaProgetti() {
  const qc = useQueryClient();
  return () => void qc.invalidateQueries({ queryKey: chiaviProgetti.tutti });
}

// Invalida progetti e dettaglio di un task specifico
function useInvalidaTask(taskId?: string) {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: chiaviProgetti.tutti });
    if (taskId) void qc.invalidateQueries({ queryKey: chiaviProgetti.task(taskId) });
  };
}

// ------------------------------------ Progetti -----------------------------------------

// Creazione di un progetto
export function useCreaProgetto() {
  const invalida = useInvalidaProgetti();
  return useMutation({ mutationFn: (dati: CreaProgettoInput) => api<Progetto>('/progetti', { method: 'POST', body: dati }), onSuccess: invalida });
}

// Modifica di un progetto
export function useAggiornaProgetto(id: string) {
  const invalida = useInvalidaProgetti();
  return useMutation({ mutationFn: (dati: AggiornaProgettoInput) => api<Progetto>(`/progetti/${id}`, { method: 'PATCH', body: dati }), onSuccess: invalida });
}

// Eliminazione di un progetto
export function useEliminaProgetto() {
  const invalida = useInvalidaProgetti();
  return useMutation({ mutationFn: (id: string) => api<void>(`/progetti/${id}`, { method: 'DELETE' }), onSuccess: invalida });
}

// --------------------------------------- Task ------------------------------------------

// Creazione di un task nel progetto
export function useCreaTask(progettoId: string) {
  const invalida = useInvalidaProgetti();
  return useMutation({ mutationFn: (dati: CreaTaskInput) => api<TaskDettaglio>(`/progetti/${progettoId}/task`, { method: 'POST', body: dati }), onSuccess: invalida });
}

// Modifica di un task
export function useAggiornaTask(taskId: string) {
  const invalida = useInvalidaTask(taskId);
  return useMutation({ mutationFn: (dati: AggiornaTaskInput) => api<TaskDettaglio>(`/task/${taskId}`, { method: 'PATCH', body: dati }), onSuccess: invalida });
}

// Spostamento di un task nella bacheca (trascinamento)
export function useSpostaTask() {
  const invalida = useInvalidaProgetti();
  return useMutation({
    mutationFn: ({ taskId, colonnaId, posizione }: { taskId: string; colonnaId: string; posizione: number }) =>
      api<TaskDettaglio>(`/task/${taskId}/sposta`, { method: 'POST', body: { colonnaId, posizione } }),
    onSuccess: invalida,
  });
}

// Eliminazione di un task
export function useEliminaTask() {
  const invalida = useInvalidaProgetti();
  return useMutation({ mutationFn: (taskId: string) => api<void>(`/task/${taskId}`, { method: 'DELETE' }), onSuccess: invalida });
}

// --------------------------------------- To-do -----------------------------------------

// Aggiunta di una voce alla to-do
export function useAggiungiTodo(taskId: string) {
  const invalida = useInvalidaTask(taskId);
  return useMutation({ mutationFn: (dati: CreaTodoInput) => api<VoceTodo[]>(`/task/${taskId}/todo`, { method: 'POST', body: dati }), onSuccess: invalida });
}

// Modifica di una voce della to-do (spunta, testo, assegnatario)
export function useAggiornaTodo(taskId: string) {
  const invalida = useInvalidaTask(taskId);
  return useMutation({
    mutationFn: ({ id, dati }: { id: string; dati: AggiornaTodoInput }) => api<VoceTodo[]>(`/todo/${id}`, { method: 'PATCH', body: dati }),
    onSuccess: invalida,
  });
}

// Eliminazione di una voce della to-do
export function useEliminaTodo(taskId: string) {
  const invalida = useInvalidaTask(taskId);
  return useMutation({ mutationFn: (id: string) => api<VoceTodo[]>(`/todo/${id}`, { method: 'DELETE' }), onSuccess: invalida });
}

// ---------------------------------------- Ore ------------------------------------------

// Registrazione delle ore su un task
export function useRegistraOre(taskId: string) {
  const invalida = useInvalidaTask(taskId);
  return useMutation({ mutationFn: (dati: RegistraOreInput) => api<RegistrazioneOre[]>(`/task/${taskId}/ore`, { method: 'POST', body: dati }), onSuccess: invalida });
}

// Eliminazione di una registrazione di ore
export function useEliminaOre(taskId: string) {
  const invalida = useInvalidaTask(taskId);
  return useMutation({ mutationFn: (id: string) => api<void>(`/ore/${id}`, { method: 'DELETE' }), onSuccess: invalida });
}

// -------------------------------------- Template ---------------------------------------

// Invalida gli elenchi dei template
function useInvalidaTemplate() {
  const qc = useQueryClient();
  return () => void qc.invalidateQueries({ queryKey: chiaviProgetti.template });
}

// Creazione di un template
export function useCreaTemplate() {
  const invalida = useInvalidaTemplate();
  return useMutation({ mutationFn: (dati: CreaTemplateInput) => api<TemplateProgettoDettaglio>('/progetto-template', { method: 'POST', body: dati }), onSuccess: invalida });
}

// Modifica dei dati generali di un template
export function useAggiornaTemplate() {
  const invalida = useInvalidaTemplate();
  return useMutation({
    mutationFn: ({ id, dati }: { id: string; dati: AggiornaTemplateInput }) => api<TemplateProgettoDettaglio>(`/progetto-template/${id}`, { method: 'PATCH', body: dati }),
    onSuccess: invalida,
  });
}

// Salvataggio della struttura (colonne, task e to-do)
export function useSalvaStruttura() {
  const invalida = useInvalidaTemplate();
  return useMutation({
    mutationFn: ({ id, dati }: { id: string; dati: StrutturaTemplateInput }) => api<TemplateProgettoDettaglio>(`/progetto-template/${id}/struttura`, { method: 'PUT', body: dati }),
    onSuccess: invalida,
  });
}

// Eliminazione di un template
export function useEliminaTemplate() {
  const invalida = useInvalidaTemplate();
  return useMutation({ mutationFn: (id: string) => api<void>(`/progetto-template/${id}`, { method: 'DELETE' }), onSuccess: invalida });
}
