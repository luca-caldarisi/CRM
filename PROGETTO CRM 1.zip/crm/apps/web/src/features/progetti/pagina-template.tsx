// =====================================================================================
// Gestione dei template di progetto: elenco, dati generali ed editor della struttura
// =====================================================================================

// Importa gli hook di React
import { useEffect, useState } from 'react';
// Importa le icone
import { ChevronDown, ChevronUp, GripVertical, Plus, Trash2 } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa i tipi condivisi
import type { StrutturaTemplateInput, TemplateProgetto } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input, Textarea } from '@/components/ui/campi';
import { ConfermaDialog, Dialog, PiedeDialog } from '@/components/ui/dialog';
import { Badge, Card, Skeleton } from '@/components/ui/elementi';
import { IntestazionePagina, StatoErrore } from '@/components/common/pagina';
// Importa hook del modulo
import { useAggiornaTemplate, useCreaTemplate, useEliminaTemplate, useSalvaStruttura, useTemplate, useTemplateDettaglio } from './api';
// Importa la notifica degli errori
import { notificaErrore } from '@/lib/errori';

// ------------------------------------- Pagina -------------------------------------------

export function PaginaTemplate() {
  // Elenco completo (anche i disattivati)
  const { data: template, isLoading, isError } = useTemplate(false);
  // Template selezionato per l'editor
  const [selezionato, setSelezionato] = useState<string | null>(null);
  // Finestra di creazione
  const [nuovo, setNuovo] = useState(false);

  return (
    <>
      {/* Intestazione */}
      <IntestazionePagina
        briciole={[{ etichetta: 'Progetti', a: '/progetti' }, { etichetta: 'Template' }]}
        titolo="Template di progetto"
        sottotitolo="Colonne, task e to-do copiati nei nuovi progetti. Modificarli non cambia i progetti già avviati."
        azioni={<Button onClick={() => setNuovo(true)}><Plus /> Nuovo template</Button>}
      />
      {/* Errore */}
      {isError && <StatoErrore />}
      {/* Caricamento */}
      {isLoading && <Skeleton className="h-48" />}
      {/* Elenco in card */}
      {template && (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {template.map((t) => (
            <CardTemplate key={t.id} template={t} onApri={() => setSelezionato(t.id)} />
          ))}
          {/* Nessun template */}
          {template.length === 0 && (
            <Card className="p-8 text-center text-sm text-slate-500 sm:col-span-2 xl:col-span-3">
              Nessun template. Creane uno per far nascere i progetti già con le loro fasi e i task ricorrenti.
            </Card>
          )}
        </div>
      )}
      {/* Finestra di creazione */}
      {nuovo && <DialogNuovoTemplate onChiudi={() => setNuovo(false)} onCreato={(id) => setSelezionato(id)} />}
      {/* Editor della struttura */}
      {selezionato && <DialogEditorTemplate templateId={selezionato} onChiudi={() => setSelezionato(null)} />}
    </>
  );
}

// Card di un template nell'elenco
function CardTemplate({ template, onApri }: { template: TemplateProgetto; onApri: () => void }) {
  return (
    <Card className="flex flex-col p-4">
      {/* Nome e stato */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-slate-900">{template.nome}</p>
          {template.categoria && <p className="mt-0.5 text-xs text-slate-500">{template.categoria}</p>}
        </div>
        {/* I template disattivati non compaiono nella creazione dei progetti */}
        {!template.attivo && <Badge colore="grigio">Disattivato</Badge>}
      </div>
      {/* Descrizione */}
      <p className="mt-2 line-clamp-2 flex-1 text-xs text-slate-500">{template.descrizione || 'Nessuna descrizione'}</p>
      {/* Conteggi e azione */}
      <div className="mt-3 flex items-center justify-between gap-2">
        <span className="text-xs text-slate-500">
          {template.numeroColonne} fasi · {template.numeroTask} task
          {template.durataStimataGg ? ` · ~${template.durataStimataGg} gg` : ''}
        </span>
        <Button variante="secondario" dimensione="piccolo" onClick={onApri}>Apri</Button>
      </div>
    </Card>
  );
}

// ------------------------------- Creazione di un template -------------------------------

// Finestra con i soli dati generali: la struttura si definisce subito dopo nell'editor
function DialogNuovoTemplate({ onChiudi, onCreato }: { onChiudi: () => void; onCreato: (id: string) => void }) {
  // Campi
  const [nome, setNome] = useState('');
  const [categoria, setCategoria] = useState('');
  const [descrizione, setDescrizione] = useState('');
  // Mutation
  const crea = useCreaTemplate();

  // Creazione e apertura dell'editor
  function salva() {
    crea.mutate(
      { nome: nome.trim(), categoria: categoria.trim() || null, descrizione: descrizione.trim() || null, attivo: true },
      {
        onSuccess: (t) => {
          toast.success('Template creato');
          onChiudi();
          // Apre subito l'editor: un template senza struttura non serve a nulla
          onCreato(t.id);
        },
        onError: notificaErrore,
      },
    );
  }

  return (
    <Dialog aperto onChiudi={onChiudi} titolo="Nuovo template" descrizione="Dopo la creazione si definiscono le fasi e i task">
      <div className="grid gap-4">
        {/* Nome */}
        <Campo etichetta="Nome" htmlFor="tpl-nome" obbligatorio>
          <Input id="tpl-nome" autoFocus value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Es. Installazione nuovo server" />
        </Campo>
        {/* Categoria */}
        <Campo etichetta="Categoria" htmlFor="tpl-categoria" aiuto="Serve solo a raggruppare i template nell'elenco">
          <Input id="tpl-categoria" value={categoria} onChange={(e) => setCategoria(e.target.value)} placeholder="Es. Sistemistica" />
        </Campo>
        {/* Descrizione */}
        <Campo etichetta="Descrizione" htmlFor="tpl-descrizione">
          <Textarea id="tpl-descrizione" rows={3} value={descrizione} onChange={(e) => setDescrizione(e.target.value)} />
        </Campo>
      </div>
      {/* Pulsanti */}
      <PiedeDialog>
        <Button variante="secondario" onClick={onChiudi}>Annulla</Button>
        <Button onClick={salva} caricamento={crea.isPending} disabled={nome.trim().length < 2}>Crea e definisci struttura</Button>
      </PiedeDialog>
    </Dialog>
  );
}

// ------------------------------- Editor della struttura ---------------------------------

// Colonna in modifica
interface ColonnaBozza {
  nome: string;
  consideraCompletato: boolean;
}

// Task in modifica
interface TaskBozza {
  titolo: string;
  descrizione: string;
  colonnaIndice: number;
  oreStimate: string;
  todo: string[];
}

// Finestra con i dati generali e l'editor di colonne e task
function DialogEditorTemplate({ templateId, onChiudi }: { templateId: string; onChiudi: () => void }) {
  // Dettaglio con la struttura
  const { data: t, isLoading, isError } = useTemplateDettaglio(templateId);
  // Mutation
  const salvaStruttura = useSalvaStruttura();
  const aggiorna = useAggiornaTemplate();
  const elimina = useEliminaTemplate();
  // Conferma di eliminazione
  const [conferma, setConferma] = useState(false);
  // Bozza della struttura
  const [colonne, setColonne] = useState<ColonnaBozza[]>([]);
  const [task, setTask] = useState<TaskBozza[]>([]);
  // Stato "attivo" dei dati generali
  const [attivo, setAttivo] = useState(true);

  // Carica la bozza dai dati del server
  useEffect(() => {
    // Nessun dato ancora
    if (!t) return;
    // Colonne
    setColonne(t.colonne.map((c) => ({ nome: c.nome, consideraCompletato: c.consideraCompletato })));
    // Task con le loro voci di to-do
    setTask(t.task.map((x) => ({ titolo: x.titolo, descrizione: x.descrizione ?? '', colonnaIndice: x.colonnaIndice, oreStimate: x.oreStimate ?? '', todo: [...x.todo] })));
    // Disponibilità
    setAttivo(t.attivo);
  }, [t]);

  // Salva la struttura completa
  function salva() {
    // Prepara i dati nel formato dello schema condiviso
    const dati: StrutturaTemplateInput = {
      colonne: colonne.map((c) => ({ nome: c.nome.trim(), consideraCompletato: c.consideraCompletato })),
      task: task.map((x) => ({
        titolo: x.titolo.trim(),
        descrizione: x.descrizione.trim() || null,
        // Se la colonna è stata eliminata il task torna nella prima
        colonnaIndice: Math.min(x.colonnaIndice, colonne.length - 1),
        oreStimate: x.oreStimate === '' ? null : Number(x.oreStimate.replace(',', '.')),
        todo: x.todo.map((v) => v.trim()).filter(Boolean),
      })),
    };
    // Invia
    salvaStruttura.mutate({ id: templateId, dati }, { onSuccess: () => toast.success('Struttura salvata'), onError: notificaErrore });
  }

  // Sposta una colonna a sinistra o a destra, portando con sé i task assegnati
  function spostaColonna(indice: number, delta: number) {
    // Nuova posizione
    const destinazione = indice + delta;
    // Fuori dai limiti
    if (destinazione < 0 || destinazione >= colonne.length) return;
    // Scambia le colonne
    setColonne((prec) => {
      const copia = [...prec];
      [copia[indice], copia[destinazione]] = [copia[destinazione]!, copia[indice]!];
      return copia;
    });
    // Aggiorna gli indici dei task interessati dallo scambio
    setTask((prec) =>
      prec.map((x) => (x.colonnaIndice === indice ? { ...x, colonnaIndice: destinazione } : x.colonnaIndice === destinazione ? { ...x, colonnaIndice: indice } : x)),
    );
  }

  // Elimina una colonna e rimappa i task che vi si trovavano
  function eliminaColonna(indice: number) {
    // Servono almeno due colonne
    if (colonne.length <= 2) {
      toast.error('Un template deve avere almeno due fasi');
      return;
    }
    // Rimuove la colonna
    setColonne((prec) => prec.filter((_, i) => i !== indice));
    // I task della colonna eliminata passano alla prima; quelli successivi scalano di uno
    setTask((prec) => prec.map((x) => ({ ...x, colonnaIndice: x.colonnaIndice === indice ? 0 : x.colonnaIndice > indice ? x.colonnaIndice - 1 : x.colonnaIndice })));
  }

  // Caricamento ed errori
  if (isLoading || isError || !t) {
    return (
      <Dialog aperto onChiudi={onChiudi} titolo="Template" larghezza="xl">
        {isError ? <StatoErrore messaggio="Impossibile caricare il template." /> : <Skeleton className="h-64" />}
      </Dialog>
    );
  }

  // Almeno una colonna deve rappresentare il lavoro finito
  const senzaCompletamento = !colonne.some((c) => c.consideraCompletato);
  // Nomi delle colonne vuoti
  const nomiVuoti = colonne.some((c) => !c.nome.trim()) || task.some((x) => x.titolo.trim().length < 2);

  return (
    <Dialog aperto onChiudi={onChiudi} titolo={t.nome} descrizione={t.categoria ?? undefined} larghezza="xl">
      {/* Disponibilità del template */}
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50/60 p-3">
        <div>
          <p className="text-sm font-medium text-slate-800">Disponibile per i nuovi progetti</p>
          <p className="text-xs text-slate-500">Un template disattivato resta nello storico ma non si può più scegliere.</p>
        </div>
        {/* Interruttore realizzato con un pulsante (semplice e accessibile) */}
        <Button
          variante="secondario"
          dimensione="piccolo"
          aria-pressed={attivo}
          onClick={() => {
            // Nuovo valore
            const nuovo = !attivo;
            setAttivo(nuovo);
            // Salva subito i dati generali
            aggiorna.mutate({ id: templateId, dati: { attivo: nuovo } }, { onError: notificaErrore });
          }}
        >
          {attivo ? 'Attivo' : 'Disattivato'}
        </Button>
      </div>

      {/* Colonne della bacheca */}
      <section className="mb-5">
        <h3 className="mb-2 text-sm font-semibold text-slate-900">Fasi della bacheca</h3>
        <ul className="space-y-2">
          {colonne.map((c, i) => (
            <li key={i} className="flex flex-wrap items-center gap-2 rounded-lg border border-slate-200 p-2">
              {/* Maniglia decorativa: l'ordine si cambia con le frecce */}
              <GripVertical className="size-4 shrink-0 text-slate-300" aria-hidden />
              {/* Nome della fase */}
              <Input value={c.nome} onChange={(e) => setColonne((p) => p.map((x, j) => (j === i ? { ...x, nome: e.target.value } : x)))} className="h-8 min-w-40 flex-1" aria-label={`Nome fase ${i + 1}`} />
              {/* Segna la fase come completamento */}
              <label className="inline-flex items-center gap-1.5 text-xs text-slate-600">
                <input
                  type="checkbox"
                  checked={c.consideraCompletato}
                  onChange={(e) => setColonne((p) => p.map((x, j) => (j === i ? { ...x, consideraCompletato: e.target.checked } : x)))}
                  className="size-4 rounded border-slate-300 text-primario-600"
                />
                Conta come completato
              </label>
              {/* Spostamento */}
              <Button variante="fantasma" dimensione="icona" onClick={() => spostaColonna(i, -1)} disabled={i === 0} aria-label="Sposta a sinistra"><ChevronUp /></Button>
              <Button variante="fantasma" dimensione="icona" onClick={() => spostaColonna(i, 1)} disabled={i === colonne.length - 1} aria-label="Sposta a destra"><ChevronDown /></Button>
              {/* Eliminazione */}
              <Button variante="fantasma" dimensione="icona" onClick={() => eliminaColonna(i)} aria-label={`Elimina fase ${c.nome}`}><Trash2 className="text-slate-400" /></Button>
            </li>
          ))}
        </ul>
        {/* Aggiunta di una fase (massimo 8) */}
        <Button
          variante="secondario"
          dimensione="piccolo"
          className="mt-2"
          disabled={colonne.length >= 8}
          onClick={() => setColonne((p) => [...p, { nome: '', consideraCompletato: false }])}
        >
          <Plus /> Aggiungi fase
        </Button>
        {/* Avviso: serve una colonna di completamento per calcolare l'avanzamento */}
        {senzaCompletamento && <p role="alert" className="mt-2 text-xs text-red-600">Indica almeno una fase che conta come completata: serve a calcolare l'avanzamento.</p>}
      </section>

      {/* Task predefiniti */}
      <section>
        <h3 className="mb-2 text-sm font-semibold text-slate-900">Task predefiniti</h3>
        <ul className="space-y-3">
          {task.map((x, i) => (
            <li key={i} className="rounded-lg border border-slate-200 p-3">
              {/* Titolo, fase e ore */}
              <div className="flex flex-wrap items-center gap-2">
                <Input value={x.titolo} onChange={(e) => setTask((p) => p.map((y, j) => (j === i ? { ...y, titolo: e.target.value } : y)))} placeholder="Titolo del task" className="h-8 min-w-48 flex-1" aria-label={`Titolo task ${i + 1}`} />
                {/* Fase iniziale */}
                <select
                  value={x.colonnaIndice}
                  onChange={(e) => setTask((p) => p.map((y, j) => (j === i ? { ...y, colonnaIndice: Number(e.target.value) } : y)))}
                  className="h-8 rounded-lg border border-slate-300 bg-white px-2 text-xs"
                  aria-label={`Fase iniziale del task ${i + 1}`}
                >
                  {colonne.map((c, j) => <option key={j} value={j}>{c.nome || `Fase ${j + 1}`}</option>)}
                </select>
                {/* Ore preventivate */}
                <Input
                  value={x.oreStimate}
                  onChange={(e) => setTask((p) => p.map((y, j) => (j === i ? { ...y, oreStimate: e.target.value } : y)))}
                  placeholder="Ore"
                  className="h-8 w-16"
                  aria-label={`Ore preventivate del task ${i + 1}`}
                />
                {/* Eliminazione del task */}
                <Button variante="fantasma" dimensione="icona" onClick={() => setTask((p) => p.filter((_, j) => j !== i))} aria-label={`Elimina task ${x.titolo}`}><Trash2 className="text-slate-400" /></Button>
              </div>
              {/* Voci di to-do del task */}
              <div className="mt-2 space-y-1.5 pl-2">
                {x.todo.map((v, k) => (
                  <div key={k} className="flex items-center gap-2">
                    {/* Pallino */}
                    <span className="size-1.5 shrink-0 rounded-full bg-slate-300" aria-hidden />
                    {/* Testo della voce */}
                    <Input
                      value={v}
                      onChange={(e) => setTask((p) => p.map((y, j) => (j === i ? { ...y, todo: y.todo.map((z, m) => (m === k ? e.target.value : z)) } : y)))}
                      className="h-7 flex-1 text-xs"
                      aria-label={`Attività ${k + 1} del task ${i + 1}`}
                    />
                    {/* Eliminazione della voce */}
                    <Button
                      variante="fantasma"
                      dimensione="icona"
                      className="size-7"
                      onClick={() => setTask((p) => p.map((y, j) => (j === i ? { ...y, todo: y.todo.filter((_, m) => m !== k) } : y)))}
                      aria-label="Elimina attività"
                    >
                      <Trash2 className="text-slate-400" />
                    </Button>
                  </div>
                ))}
                {/* Aggiunta di una voce (massimo 30) */}
                <Button
                  variante="fantasma"
                  dimensione="piccolo"
                  disabled={x.todo.length >= 30}
                  onClick={() => setTask((p) => p.map((y, j) => (j === i ? { ...y, todo: [...y.todo, ''] } : y)))}
                >
                  <Plus /> Attività
                </Button>
              </div>
            </li>
          ))}
          {/* Nessun task */}
          {task.length === 0 && <li className="rounded-lg border border-dashed border-slate-300 p-6 text-center text-xs text-slate-400">Nessun task predefinito: i progetti nasceranno con la bacheca vuota.</li>}
        </ul>
        {/* Aggiunta di un task (massimo 60) */}
        <Button
          variante="secondario"
          dimensione="piccolo"
          className="mt-3"
          disabled={task.length >= 60}
          onClick={() => setTask((p) => [...p, { titolo: '', descrizione: '', colonnaIndice: 0, oreStimate: '', todo: [] }])}
        >
          <Plus /> Aggiungi task
        </Button>
      </section>

      {/* Pulsanti */}
      <PiedeDialog>
        {/* Eliminazione: possibile solo se nessun progetto ha usato il template (il server verifica) */}
        <Button variante="pericolo" onClick={() => setConferma(true)} className="mr-auto"><Trash2 /> Elimina</Button>
        <Button variante="secondario" onClick={onChiudi}>Chiudi</Button>
        <Button onClick={salva} caricamento={salvaStruttura.isPending} disabled={senzaCompletamento || nomiVuoti || colonne.length < 2}>
          Salva struttura
        </Button>
      </PiedeDialog>

      {/* Conferma di eliminazione */}
      <ConfermaDialog
        aperto={conferma}
        onChiudi={() => setConferma(false)}
        caricamento={elimina.isPending}
        titolo="Eliminare il template?"
        messaggio={<>Il template <strong>{t.nome}</strong> verrà eliminato. Se è già stato usato da qualche progetto il server lo rifiuterà: in quel caso disattivalo.</>}
        onConferma={() =>
          elimina.mutate(templateId, {
            onSuccess: () => {
              toast.success('Template eliminato');
              onChiudi();
            },
            onError: (e) => {
              setConferma(false);
              notificaErrore(e);
            },
          })
        }
      />
    </Dialog>
  );
}
