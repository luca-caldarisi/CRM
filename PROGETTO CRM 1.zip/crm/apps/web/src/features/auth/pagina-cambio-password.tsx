// =====================================================================================
// Pagina di cambio password (obbligatoria al primo accesso, facoltativa in seguito)
// =====================================================================================

// Importa il router
import { Link, useNavigate } from 'react-router';
// Importa il form e l'integrazione Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le notifiche
import { toast } from 'sonner';
// Importa Zod
import { z } from 'zod';
// Importa schema e costanti condivisi
import { cambiaPasswordSchema, PASSWORD_MIN } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input } from '@/components/ui/campi';
// Importa API, autenticazione ed errori
import { api, ErroreApi } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { applicaErroriForm } from '@/lib/errori';

// Schema del form: quello del server più il campo di conferma, che deve coincidere con la nuova password
const schemaForm = z
  .object({ ...cambiaPasswordSchema.shape, conferma: z.string() })
  // La nuova password deve essere diversa dall'attuale (stessa regola del server)
  .refine((v) => v.passwordAttuale !== v.nuovaPassword, { message: 'La nuova password deve essere diversa da quella attuale', path: ['nuovaPassword'] })
  // Le due password devono coincidere
  .refine((v) => v.nuovaPassword === v.conferma, { message: 'Le password non coincidono', path: ['conferma'] });

// Tipo dei valori del form
type ValoriForm = z.input<typeof schemaForm>;

export function PaginaCambioPassword() {
  // Utente e funzioni di sessione
  const { utente, ricaricaProfilo, esci } = useAuth();
  // Navigazione
  const naviga = useNavigate();
  // Cambio obbligatorio (primo accesso o dopo un reset)
  const obbligatorio = utente?.deveCambiarePassword ?? false;

  // Form con validazione condivisa (lunghezza minima, password comuni, diversa dall'attuale)
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<ValoriForm>({ resolver: zodResolver(schemaForm) });

  // Invio
  const invia = handleSubmit(async (dati) => {
    try {
      // Chiamata al server
      await api('/auth/cambia-password', { method: 'POST', body: { passwordAttuale: dati.passwordAttuale, nuovaPassword: dati.nuovaPassword } });
      // Aggiorna il profilo (rimuove l'obbligo)
      await ricaricaProfilo();
      // Conferma
      toast.success('Password aggiornata', { description: 'Le altre sessioni aperte sono state chiuse.' });
      // Alla dashboard
      naviga('/', { replace: true });
    } catch (errore) {
      // Password attuale errata (422) mostrata sul campo; gli altri errori come notifica
      if (errore instanceof ErroreApi && errore.status === 422) {
        setError('passwordAttuale', { message: errore.message });
      } else {
        applicaErroriForm(errore, setError);
      }
    }
  });

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-sm">
        {/* Intestazione */}
        <div className="mb-6 text-center">
          <img src="/favicon.svg" alt="" className="mx-auto size-11" />
          <h1 className="mt-4 text-xl font-semibold tracking-tight text-slate-900">{obbligatorio ? 'Imposta una nuova password' : 'Cambia password'}</h1>
          <p className="mt-1 text-sm text-slate-500">
            {obbligatorio ? 'Per sicurezza devi scegliere una password personale prima di continuare.' : 'Le altre sessioni aperte verranno chiuse.'}
          </p>
        </div>
        {/* Form */}
        <form onSubmit={invia} noValidate className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          {/* Password attuale */}
          <Campo etichetta="Password attuale" htmlFor="passwordAttuale" errore={errors.passwordAttuale?.message}>
            <Input id="passwordAttuale" type="password" autoComplete="current-password" autoFocus aria-invalid={!!errors.passwordAttuale} {...register('passwordAttuale')} />
          </Campo>
          {/* Nuova password */}
          <Campo etichetta="Nuova password" htmlFor="nuovaPassword" errore={errors.nuovaPassword?.message} aiuto={`Almeno ${PASSWORD_MIN} caratteri. Una frase lunga è più sicura e facile da ricordare.`}>
            <Input id="nuovaPassword" type="password" autoComplete="new-password" aria-invalid={!!errors.nuovaPassword} {...register('nuovaPassword')} />
          </Campo>
          {/* Conferma della nuova password */}
          <Campo etichetta="Ripeti la nuova password" htmlFor="conferma" errore={errors.conferma?.message}>
            <Input id="conferma" type="password" autoComplete="new-password" aria-invalid={!!errors.conferma} {...register('conferma')} />
          </Campo>
          {/* Pulsante */}
          <Button type="submit" className="w-full" caricamento={isSubmitting}>
            Salva password
          </Button>
        </form>
        {/* Uscita o ritorno */}
        <p className="mt-6 text-center text-sm">
          {obbligatorio ? (
            <button type="button" onClick={() => void esci()} className="text-slate-500 hover:text-slate-800">
              Esci
            </button>
          ) : (
            <Link to="/" className="text-slate-500 hover:text-slate-800">
              Torna al CRM
            </Link>
          )}
        </p>
      </div>
    </div>
  );
}
