// =====================================================================================
// Pagina di accesso
// =====================================================================================

// Importa i componenti del router
import { Navigate, useLocation } from 'react-router';
// Importa la gestione del form e l'integrazione con Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa lo schema condiviso con il backend
import { loginSchema, type LoginInput } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input } from '@/components/ui/campi';
import { StatoErrore } from '@/components/common/pagina';
// Importa autenticazione e tipi di errore
import { useAuth } from '@/lib/auth';
import { ErroreApi } from '@/lib/api';

export function PaginaLogin() {
  // Stato di autenticazione
  const { stato, utente, accedi } = useAuth();
  // Pagina da cui l'utente è stato rimandato al login
  const posizione = useLocation();
  const destinazione = (posizione.state as { da?: string } | null)?.da ?? '/';

  // Form con validazione tramite lo schema condiviso
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({ resolver: zodResolver(loginSchema) });

  // Già autenticato: va direttamente alla destinazione
  if (stato === 'autenticato' && utente) return <Navigate to={utente.deveCambiarePassword ? '/cambia-password' : destinazione} replace />;

  // Invio del form
  const invia = handleSubmit(async (dati) => {
    try {
      // Esegue il login (il redirect avviene al render successivo)
      await accedi(dati);
    } catch (errore) {
      // Messaggio del server (credenziali errate, account bloccato, troppe richieste) o errore di rete
      const messaggio = errore instanceof ErroreApi ? (errore.problema.detail ?? errore.problema.title) : 'Server non raggiungibile. Riprova.';
      // Errore mostrato sopra il form
      setError('root', { message: messaggio });
    }
  });

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-sm">
        {/* Logo e titolo */}
        <div className="mb-8 text-center">
          <img src="/favicon.svg" alt="" className="mx-auto size-11" />
          <h1 className="mt-4 text-xl font-semibold tracking-tight text-slate-900">Accedi al CRM</h1>
          <p className="mt-1 text-sm text-slate-500">Usa le credenziali fornite dall'amministratore</p>
        </div>
        {/* Card del form */}
        <form onSubmit={invia} noValidate className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          {/* Errore generale */}
          {errors.root?.message && <StatoErrore messaggio={errors.root.message} />}
          {/* Email */}
          <Campo etichetta="Email" htmlFor="email" errore={errors.email?.message}>
            <Input id="email" type="email" autoComplete="username" autoFocus aria-invalid={!!errors.email} {...register('email')} />
          </Campo>
          {/* Password */}
          <Campo etichetta="Password" htmlFor="password" errore={errors.password?.message}>
            <Input id="password" type="password" autoComplete="current-password" aria-invalid={!!errors.password} {...register('password')} />
          </Campo>
          {/* Pulsante di accesso */}
          <Button type="submit" className="w-full" caricamento={isSubmitting}>
            Accedi
          </Button>
        </form>
        {/* Nota per password dimenticata */}
        <p className="mt-6 text-center text-xs text-slate-500">Password dimenticata? Contatta un amministratore per il reset.</p>
      </div>
    </div>
  );
}
