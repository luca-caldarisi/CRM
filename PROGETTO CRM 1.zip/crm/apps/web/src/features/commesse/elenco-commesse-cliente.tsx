// =====================================================================================
// Elenco delle commesse di un cliente (scheda "Commesse" nel dettaglio cliente)
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il router
import { useNavigate } from 'react-router';
// Importa le icone
import { Plus } from 'lucide-react';
// Importa il tipo condiviso
import type { Cliente } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/elementi';
import { Paginazione, Tabella } from '@/components/common/tabella';
// Importa hook
import { useCommesse } from './api';
import { FormCommessa } from './form-commessa';
import { colonneCommesse } from './pagina-commesse';
import { usePermesso } from '@/lib/auth';

export function ElencoCommesseCliente({ cliente }: { cliente: Cliente }) {
  // Navigazione
  const naviga = useNavigate();
  // Pagina corrente
  const [page, setPage] = useState(1);
  // Finestra nuova commessa
  const [nuova, setNuova] = useState(false);
  // Permessi
  const puoCreare = usePermesso('commesse.write');
  const vedeEconomici = usePermesso('economici.read');
  // Commesse del cliente
  const { data, isLoading } = useCommesse({ clienteId: cliente.id, page, pageSize: 10 });

  return (
    <div className="space-y-3">
      {/* Pulsante nuova commessa con cliente già selezionato */}
      {puoCreare && (
        <div className="flex justify-end">
          <Button variante="secondario" dimensione="piccolo" onClick={() => setNuova(true)}>
            <Plus /> Nuova commessa
          </Button>
        </div>
      )}
      {/* Tabella senza la colonna cliente (ridondante) */}
      <Card>
        <Tabella colonne={colonneCommesse(vedeEconomici, false)} righe={data?.data} chiave={(c) => c.id} caricamento={isLoading} onClickRiga={(c) => naviga(`/commesse/${c.id}`)} vuoto="Nessuna commessa per questo cliente" />
        {data && data.meta.total > data.meta.pageSize && <Paginazione {...data.meta} onCambia={setPage} />}
      </Card>
      {/* Finestra */}
      {nuova && <FormCommessa cliente={cliente} onChiudi={() => setNuova(false)} />}
    </div>
  );
}
