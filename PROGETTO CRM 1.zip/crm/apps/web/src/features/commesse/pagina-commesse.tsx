// =====================================================================================
// Elenco commesse con ricerca, filtri per stato e tipo, ordinamento e paginazione
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il router
import { useNavigate } from 'react-router';
// Importa le icone
import { Plus } from 'lucide-react';
// Importa etichette e tipi condivisi
import { STATI_COMMESSA, TIPI_COMMESSA, type Commessa, type StatoCommessa, type TipoCommessa } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Select } from '@/components/ui/campi';
import { Badge, Card, type ColoreBadge } from '@/components/ui/elementi';
import { CampoRicerca, IntestazionePagina, StatoErrore } from '@/components/common/pagina';
import { Paginazione, Tabella, type Colonna } from '@/components/common/tabella';
// Importa hook e utilità
import { useCommesse } from './api';
import { FormCommessa } from './form-commessa';
import { usePermesso } from '@/lib/auth';
import { useFiltriUrl } from '@/lib/hooks';
import { formattaData, formattaEuro, nomeCompleto } from '@/lib/utils';

// Colore del badge per ogni stato
export const COLORE_STATO: Record<StatoCommessa, ColoreBadge> = { aperta: 'verde', sospesa: 'giallo', chiusa: 'grigio', annullata: 'rosso' };

// Badge dello stato di una commessa
export function BadgeStato({ stato }: { stato: StatoCommessa }) {
  return <Badge colore={COLORE_STATO[stato]}>{STATI_COMMESSA[stato]}</Badge>;
}

// Costruisce le colonne (la colonna valore esiste solo per chi vede i dati economici)
export function colonneCommesse(vedeEconomici: boolean, mostraCliente = true): Colonna<Commessa>[] {
  return [
    {
      id: 'titolo',
      titolo: 'Commessa',
      ordinabile: 'codice',
      cella: (c) => (
        <div>
          <p className="font-medium text-slate-900">{c.titolo}</p>
          <p className="text-xs text-slate-500">{c.codice}</p>
        </div>
      ),
    },
    ...(mostraCliente ? [{ id: 'cliente', titolo: 'Cliente', ordinabile: 'cliente', cella: (c: Commessa) => c.cliente.ragioneSociale, className: 'hidden md:table-cell' }] : []),
    { id: 'tipo', titolo: 'Tipo', cella: (c) => TIPI_COMMESSA[c.tipo], className: 'hidden lg:table-cell' },
    { id: 'stato', titolo: 'Stato', ordinabile: 'stato', cella: (c) => <BadgeStato stato={c.stato} /> },
    { id: 'apertura', titolo: 'Apertura', ordinabile: 'dataApertura', cella: (c) => formattaData(c.dataApertura), className: 'hidden sm:table-cell' },
    { id: 'responsabile', titolo: 'Responsabile', cella: (c) => nomeCompleto(c.responsabile), className: 'hidden xl:table-cell' },
    ...(vedeEconomici ? [{ id: 'valore', titolo: 'Valore', ordinabile: 'valore', cella: (c: Commessa) => formattaEuro(c.valore), className: 'text-right tabular-nums hidden md:table-cell' }] : []),
  ];
}

export function PaginaCommesse() {
  // Navigazione
  const naviga = useNavigate();
  // Filtri nell'URL
  const { filtri, page, imposta } = useFiltriUrl(['q', 'sort', 'stato', 'tipo'] as const);
  // Finestra di creazione
  const [nuova, setNuova] = useState(false);
  // Permessi di interfaccia
  const puoCreare = usePermesso('commesse.write');
  const vedeEconomici = usePermesso('economici.read');
  // Dati
  const { data, isLoading, isError } = useCommesse({ q: filtri.q, sort: filtri.sort, stato: filtri.stato as StatoCommessa | '', tipo: filtri.tipo as TipoCommessa | '', page });

  return (
    <>
      {/* Intestazione */}
      <IntestazionePagina
        titolo="Commesse"
        sottotitolo={data ? `${data.meta.total} commesse` : undefined}
        azioni={puoCreare && <Button onClick={() => setNuova(true)}><Plus /> Nuova commessa</Button>}
      />
      {/* Errore */}
      {isError && <StatoErrore />}
      <Card>
        {/* Barra filtri */}
        <div className="flex flex-wrap gap-2 border-b border-slate-200 p-3">
          <CampoRicerca valore={filtri.q} onCambia={(q) => imposta({ q })} segnaposto="Cerca per titolo, codice, cliente…" />
          {/* Filtro stato */}
          <Select value={filtri.stato} onChange={(e) => imposta({ stato: e.target.value })} className="w-auto" aria-label="Filtra per stato">
            <option value="">Tutti gli stati</option>
            {Object.entries(STATI_COMMESSA).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
          </Select>
          {/* Filtro tipo */}
          <Select value={filtri.tipo} onChange={(e) => imposta({ tipo: e.target.value })} className="w-auto" aria-label="Filtra per tipo">
            <option value="">Tutti i tipi</option>
            {Object.entries(TIPI_COMMESSA).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
          </Select>
        </div>
        {/* Tabella */}
        <Tabella
          colonne={colonneCommesse(vedeEconomici)}
          righe={data?.data}
          chiave={(c) => c.id}
          caricamento={isLoading}
          ordinamento={filtri.sort || '-dataApertura'}
          onOrdina={(sort) => imposta({ sort })}
          onClickRiga={(c) => naviga(`/commesse/${c.id}`)}
          vuoto="Nessuna commessa trovata"
        />
        {/* Paginazione */}
        {data && <Paginazione {...data.meta} onCambia={(p) => imposta({ page: p })} />}
      </Card>
      {/* Finestra nuova commessa */}
      {nuova && <FormCommessa onChiudi={() => setNuova(false)} />}
    </>
  );
}
