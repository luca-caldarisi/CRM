// =====================================================================================
// Dettaglio di una commessa
// =====================================================================================

// Importa React
import { useState } from 'react';
// Importa il router
import { Link, useNavigate, useParams, useSearchParams } from 'react-router';
// Importa le icone
import { MoreHorizontal, Pencil, Trash2 } from 'lucide-react';
// Importa le notifiche
import { toast } from 'sonner';
// Importa etichette condivise
import { TIPI_COMMESSA } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { ConfermaDialog } from '@/components/ui/dialog';
import { Badge, Card, CardHeader, Skeleton } from '@/components/ui/elementi';
import { Menu, Tabs } from '@/components/ui/menu-tabs';
import { DatoDettaglio, IntestazionePagina, StatoErrore } from '@/components/common/pagina';
// Importa funzionalità collegate
import { useCommessa, useEliminaCommessa } from './api';
import { FormCommessa } from './form-commessa';
import { BadgeStato } from './pagina-commesse';
import { PannelloAllegati } from '@/features/allegati/pannello-allegati';
import { StoricoAttivita } from '@/features/audit/storico-attivita';
// Importa permessi, errori e utilità
import { ErroreApi } from '@/lib/api';
import { usePermesso } from '@/lib/auth';
// Importa l'elenco dei progetti collegati alla commessa
import { ElencoProgettiCollegati } from '@/features/progetti/elenco-progetti-collegati';
import { notificaErrore } from '@/lib/errori';
import { formattaData, formattaDataOra, formattaEuro, nomeCompleto } from '@/lib/utils';

export function PaginaCommessa() {
  // Identificativo dall'URL
  const { id = '' } = useParams();
  // Navigazione
  const naviga = useNavigate();
  // Scheda attiva nell'URL
  const [params, setParams] = useSearchParams();
  const scheda = params.get('scheda') ?? 'dettagli';
  // Finestre
  const [modifica, setModifica] = useState(false);
  const [conferma, setConferma] = useState(false);
  // Dati
  const { data: c, isLoading, error } = useCommessa(id);
  // Eliminazione
  const elimina = useEliminaCommessa();
  // Permessi di interfaccia
  const puoModificare = usePermesso('commesse.write');
  const puoEliminare = usePermesso('commesse.delete');
  const puoVedereAudit = usePermesso('audit.read');
  // Scheda progetti visibile solo a chi può leggere i progetti
  const puoVedereProgetti = usePermesso('progetti.read');

  // Errori e caricamento
  if (error instanceof ErroreApi && error.status === 404) return <StatoErrore messaggio="Commessa non trovata o non accessibile." />;
  if (error) return <StatoErrore />;
  if (isLoading || !c) return <Skeleton className="h-64" />;

  return (
    <>
      {/* Intestazione */}
      <IntestazionePagina
        briciole={[{ etichetta: 'Commesse', a: '/commesse' }, { etichetta: c.codice }]}
        titolo={c.titolo}
        sottotitolo={
          <span className="flex flex-wrap items-center gap-2">
            <Badge>{c.codice}</Badge>
            <BadgeStato stato={c.stato} />
            {/* Link al cliente */}
            <Link to={`/clienti/${c.cliente.id}`} className="text-primario-700 hover:underline">{c.cliente.ragioneSociale}</Link>
          </span>
        }
        azioni={
          <>
            {puoModificare && <Button variante="secondario" onClick={() => setModifica(true)}><Pencil /> Modifica</Button>}
            <Menu
              grilletto={<Button variante="secondario" dimensione="icona" aria-label="Altre azioni"><MoreHorizontal /></Button>}
              voci={[{ etichetta: 'Elimina commessa', icona: <Trash2 />, onSelect: () => setConferma(true), pericolo: true, nascosta: !puoEliminare }]}
            />
          </>
        }
      />

      {/* Schede */}
      <Tabs
        attiva={scheda}
        onCambia={(s) => setParams({ scheda: s }, { replace: true })}
        schede={[
          {
            id: 'dettagli',
            etichetta: 'Dettagli',
            contenuto: (
              <div className="grid gap-4 lg:grid-cols-3">
                {/* Descrizione */}
                <Card className="lg:col-span-2">
                  <CardHeader titolo="Descrizione" />
                  <p className="whitespace-pre-line p-5 text-sm text-slate-700">{c.descrizione || <span className="text-slate-400">Nessuna descrizione</span>}</p>
                </Card>
                {/* Dati principali */}
                <Card>
                  <CardHeader titolo="Informazioni" />
                  <dl className="grid gap-4 p-5">
                    <DatoDettaglio etichetta="Tipo">{TIPI_COMMESSA[c.tipo]}</DatoDettaglio>
                    <DatoDettaglio etichetta="Responsabile">{c.responsabile && nomeCompleto(c.responsabile)}</DatoDettaglio>
                    <DatoDettaglio etichetta="Apertura">{formattaData(c.dataApertura)}</DatoDettaglio>
                    <DatoDettaglio etichetta="Chiusura">{c.dataChiusura && formattaData(c.dataChiusura)}</DatoDettaglio>
                    {/* Il campo esiste nella risposta solo per chi ha il permesso */}
                    {'valore' in c && <DatoDettaglio etichetta="Valore">{formattaEuro(c.valore)}</DatoDettaglio>}
                    <div className="border-t border-slate-100 pt-3 text-xs text-slate-500">Aggiornata il {formattaDataOra(c.updatedAt)}</div>
                  </dl>
                </Card>
              </div>
            ),
          },
          { id: 'progetti', etichetta: 'Progetti', contenuto: <ElencoProgettiCollegati cliente={c.cliente} commessaId={c.id} />, nascosta: !puoVedereProgetti },
          { id: 'documenti', etichetta: 'Documenti', contenuto: <PannelloAllegati entita="commessa" entitaId={id} modificabile={puoModificare} /> },
          { id: 'attivita', etichetta: 'Attività', contenuto: <StoricoAttivita entita="commessa" entitaId={id} />, nascosta: !puoVedereAudit },
        ]}
      />

      {/* Finestra di modifica */}
      {modifica && <FormCommessa commessa={c} onChiudi={() => setModifica(false)} />}
      {/* Conferma eliminazione */}
      <ConfermaDialog
        aperto={conferma}
        onChiudi={() => setConferma(false)}
        caricamento={elimina.isPending}
        onConferma={() =>
          elimina.mutate(id, {
            onSuccess: () => {
              toast.success('Commessa eliminata');
              naviga('/commesse');
            },
            onError: (e) => {
              setConferma(false);
              notificaErrore(e);
            },
          })
        }
        titolo="Eliminare la commessa?"
        messaggio={<>La commessa <strong>{c.codice}</strong> non sarà più visibile. Lo storico resta nel registro attività.</>}
      />
    </>
  );
}
