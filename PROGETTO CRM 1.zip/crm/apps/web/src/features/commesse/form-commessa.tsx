// =====================================================================================
// Finestra di creazione/modifica di una commessa
// =====================================================================================

// Importa il router
import { useNavigate } from 'react-router';
// Importa il form e l'integrazione Zod
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
// Importa le notifiche
import { toast } from 'sonner';
// Importa i tipi di Zod
import type { z } from 'zod';
// Importa schemi, etichette e tipi condivisi
import { creaCommessaSchema, STATI_COMMESSA, TIPI_COMMESSA, type Commessa } from '@crm/shared';
// Importa componenti
import { Button } from '@/components/ui/button';
import { Campo, Input, Select, Textarea } from '@/components/ui/campi';
import { Dialog, PiedeDialog } from '@/components/ui/dialog';
// Importa hook ed errori
import { useAggiornaCommessa, useCreaCommessa } from './api';
import { useClienti } from '@/features/clienti/api';
import { useOpzioniUtenti } from '@/features/amministrazione-api';
import { useAmbito, usePermesso } from '@/lib/auth';
// Importa l'hook che riallinea le select con opzioni asincrone
import { useAllineaSelect } from '@/lib/hooks';
import { applicaErroriForm } from '@/lib/errori';

// Tipi dei valori del form
type Ingresso = z.input<typeof creaCommessaSchema>;
type Uscita = z.output<typeof creaCommessaSchema>;

// Data odierna in formato AAAA-MM-GG
const oggi = () => new Date().toLocaleDateString('sv-SE');

// Proprietà della finestra
interface ProprietaForm {
  onChiudi: () => void;
  // Commessa da modificare (assente = nuova)
  commessa?: Commessa;
  // Cliente preselezionato (apertura dalla scheda cliente)
  cliente?: { id: string; ragioneSociale: string };
}

export function FormCommessa({ onChiudi, commessa, cliente }: ProprietaForm) {
  // Navigazione
  const naviga = useNavigate();
  // Mutation
  const crea = useCreaCommessa();
  const aggiorna = useAggiornaCommessa(commessa?.id ?? '');
  // Utenti per il responsabile
  const { data: utenti } = useOpzioniUtenti();
  // Clienti per la select (solo se il cliente non è già fissato): i primi 100 in ordine alfabetico
  const clienteFisso = commessa?.cliente ?? cliente;
  const { data: clienti } = useClienti({ pageSize: 100, sort: 'ragioneSociale' });
  // Permessi di interfaccia
  const vedeEconomici = usePermesso('economici.read');
  const puoAssegnare = useAmbito('commesse.write') === 'tutti';

  // Form
  const {
    register,
    setValue,
    getValues,
    handleSubmit,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<Ingresso, unknown, Uscita>({
    resolver: zodResolver(creaCommessaSchema),
    defaultValues: {
      clienteId: clienteFisso?.id ?? '',
      titolo: commessa?.titolo ?? '',
      descrizione: commessa?.descrizione ?? '',
      tipo: commessa?.tipo ?? 'assistenza',
      stato: commessa?.stato ?? 'aperta',
      // Il valore arriva come stringa decimale e va convertito in numero per il form
      valore: commessa?.valore != null ? Number(commessa.valore) : null,
      dataApertura: commessa?.dataApertura ?? oggi(),
      dataChiusura: commessa?.dataChiusura ?? null,
      responsabileId: commessa?.responsabile?.id ?? null,
    },
  });
  // Mostra il valore corretto nelle select anche se le opzioni arrivano dopo l'apertura
  useAllineaSelect(setValue, getValues, ['clienteId', 'responsabileId'], [clienti, utenti]);

  // Invio
  const invia = handleSubmit(async (dati) => {
    // Chi non vede i dati economici non invia il campo (il server rifiuterebbe la richiesta)
    const { valore, clienteId, ...resto } = dati;
    const corpo = vedeEconomici ? { ...resto, valore } : resto;
    try {
      if (commessa) {
        // Modifica (il cliente non è modificabile)
        await aggiorna.mutateAsync(corpo);
        toast.success('Commessa aggiornata');
        onChiudi();
      } else {
        // Creazione e apertura del dettaglio
        const nuova = await crea.mutateAsync({ ...corpo, clienteId });
        toast.success(`Commessa ${nuova.codice} creata`);
        onChiudi();
        naviga(`/commesse/${nuova.id}`);
      }
    } catch (errore) {
      applicaErroriForm(errore, setError);
    }
  });

  return (
    <Dialog aperto onChiudi={onChiudi} titolo={commessa ? 'Modifica commessa' : 'Nuova commessa'} descrizione={commessa?.codice ?? clienteFisso?.ragioneSociale} larghezza="lg">
      <form onSubmit={invia} noValidate>
        <div className="grid gap-4 sm:grid-cols-2">
          {/* Cliente: select solo in creazione senza cliente preselezionato */}
          {!clienteFisso && (
            <Campo etichetta="Cliente" htmlFor="clienteId" obbligatorio errore={errors.clienteId?.message} className="sm:col-span-2">
              <Select id="clienteId" aria-invalid={!!errors.clienteId} {...register('clienteId')}>
                <option value="">— Seleziona un cliente —</option>
                {clienti?.data.map((c) => (
                  <option key={c.id} value={c.id}>{c.ragioneSociale} ({c.codice})</option>
                ))}
              </Select>
            </Campo>
          )}
          {/* Titolo */}
          <Campo etichetta="Titolo" htmlFor="titolo" obbligatorio errore={errors.titolo?.message} className="sm:col-span-2">
            <Input id="titolo" autoFocus aria-invalid={!!errors.titolo} {...register('titolo')} />
          </Campo>
          {/* Tipo e stato */}
          <Campo etichetta="Tipo" htmlFor="tipo" obbligatorio>
            <Select id="tipo" {...register('tipo')}>
              {Object.entries(TIPI_COMMESSA).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
            </Select>
          </Campo>
          <Campo etichetta="Stato" htmlFor="stato" obbligatorio>
            <Select id="stato" {...register('stato')}>
              {Object.entries(STATI_COMMESSA).map(([v, e]) => <option key={v} value={v}>{e}</option>)}
            </Select>
          </Campo>
          {/* Date: stringa vuota convertita in null */}
          <Campo etichetta="Data apertura" htmlFor="dataApertura" obbligatorio errore={errors.dataApertura?.message}>
            <Input id="dataApertura" type="date" aria-invalid={!!errors.dataApertura} {...register('dataApertura')} />
          </Campo>
          <Campo etichetta="Data chiusura" htmlFor="dataChiusura" errore={errors.dataChiusura?.message} aiuto="Impostata automaticamente alla chiusura">
            <Input id="dataChiusura" type="date" aria-invalid={!!errors.dataChiusura} {...register('dataChiusura', { setValueAs: (v: string) => v || null })} />
          </Campo>
          {/* Valore: solo per chi vede i dati economici */}
          {vedeEconomici && (
            <Campo etichetta="Valore (€)" htmlFor="valore" errore={errors.valore?.message}>
              <Input id="valore" type="number" step="0.01" min="0" inputMode="decimal" aria-invalid={!!errors.valore} {...register('valore', { setValueAs: (v: string) => (v === '' || v == null ? null : Number(v)) })} />
            </Campo>
          )}
          {/* Responsabile */}
          {puoAssegnare && (
            <Campo etichetta="Responsabile" htmlFor="responsabileId" errore={errors.responsabileId?.message}>
              <Select id="responsabileId" {...register('responsabileId', { setValueAs: (v: string) => v || null })}>
                <option value="">— Nessuno —</option>
                {utenti?.map((u) => <option key={u.id} value={u.id}>{u.cognome} {u.nome}</option>)}
              </Select>
            </Campo>
          )}
          {/* Descrizione */}
          <Campo etichetta="Descrizione" htmlFor="descrizione" errore={errors.descrizione?.message} className="sm:col-span-2">
            <Textarea id="descrizione" rows={4} {...register('descrizione')} />
          </Campo>
        </div>
        {/* Pulsanti */}
        <PiedeDialog>
          <Button variante="secondario" onClick={onChiudi}>Annulla</Button>
          <Button type="submit" caricamento={isSubmitting}>{commessa ? 'Salva modifiche' : 'Crea commessa'}</Button>
        </PiedeDialog>
      </form>
    </Dialog>
  );
}
