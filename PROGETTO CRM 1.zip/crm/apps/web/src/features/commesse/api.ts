// =====================================================================================
// Hook per leggere e modificare le commesse
// =====================================================================================

// Importa le funzioni di TanStack Query
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
// Importa i tipi condivisi
import type { AggiornaCommessaInput, Commessa, CreaCommessaInput, RispostaPaginata, StatoCommessa, TipoCommessa } from '@crm/shared';
// Importa il client API
import { api } from '@/lib/api';
// Importa le chiavi dei clienti (le commesse influenzano i contatori della lista clienti)
import { chiaviClienti } from '@/features/clienti/api';

// Chiavi della cache
export const chiaviCommesse = {
  tutte: ['commesse'] as const,
  lista: (filtri: object) => ['commesse', 'lista', filtri] as const,
  dettaglio: (id: string) => ['commesse', 'dettaglio', id] as const,
};

// Filtri della lista
export interface FiltriCommesse {
  q?: string;
  page?: number;
  pageSize?: number;
  sort?: string;
  clienteId?: string;
  stato?: StatoCommessa | '';
  tipo?: TipoCommessa | '';
  responsabileId?: string;
}

// Lista paginata
// "abilitato" permette di non eseguire la query (es. utente senza permesso)
export function useCommesse(filtri: FiltriCommesse, abilitato = true) {
  return useQuery({
    enabled: abilitato,
    queryKey: chiaviCommesse.lista(filtri),
    queryFn: ({ signal }) => api<RispostaPaginata<Commessa>>('/commesse', { query: { ...filtri }, signal }),
    placeholderData: keepPreviousData,
  });
}

// Dettaglio
export function useCommessa(id: string) {
  return useQuery({ queryKey: chiaviCommesse.dettaglio(id), queryFn: ({ signal }) => api<Commessa>(`/commesse/${id}`, { signal }) });
}

// Invalida commesse e clienti dopo una modifica
function useInvalida() {
  const qc = useQueryClient();
  return () => {
    void qc.invalidateQueries({ queryKey: chiaviCommesse.tutte });
    void qc.invalidateQueries({ queryKey: chiaviClienti.tutti });
  };
}

// Creazione
export function useCreaCommessa() {
  const invalida = useInvalida();
  return useMutation({ mutationFn: (dati: CreaCommessaInput) => api<Commessa>('/commesse', { method: 'POST', body: dati }), onSuccess: invalida });
}

// Modifica
export function useAggiornaCommessa(id: string) {
  const invalida = useInvalida();
  return useMutation({ mutationFn: (dati: AggiornaCommessaInput) => api<Commessa>(`/commesse/${id}`, { method: 'PATCH', body: dati }), onSuccess: invalida });
}

// Eliminazione
export function useEliminaCommessa() {
  const invalida = useInvalida();
  return useMutation({ mutationFn: (id: string) => api<void>(`/commesse/${id}`, { method: 'DELETE' }), onSuccess: invalida });
}
