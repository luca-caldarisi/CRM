// =====================================================================================
// Hook per utenti, ruoli, catalogo permessi e registro attività
// =====================================================================================

// Importa le funzioni di TanStack Query
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
// Importa i tipi condivisi
import type {
  AggiornaUtenteInput,
  CreaRuoloInput,
  CreaUtenteInput,
  DefinizionePermesso,
  ImpostaPermessiInput,
  OpzioneUtente,
  RispostaPaginata,
  RispostaPasswordTemporanea,
  Ruolo,
  Utente,
  VoceAudit,
} from '@crm/shared';
// Importa il client API
import { api } from '@/lib/api';

// ----------------------------------- Utenti -----------------------------------------

// Elenco leggero degli utenti attivi per le select (responsabile, commerciale)
export function useOpzioniUtenti() {
  return useQuery({
    queryKey: ['utenti', 'opzioni'],
    queryFn: ({ signal }) => api<OpzioneUtente[]>('/utenti/opzioni', { signal }),
    // Cambia raramente: resta in cache 5 minuti
    staleTime: 5 * 60_000,
  });
}

// Lista utenti con filtri
export function useUtenti(filtri: { q?: string; page?: number; ruoloId?: string; attivo?: string; sort?: string }) {
  return useQuery({
    queryKey: ['utenti', 'lista', filtri],
    queryFn: ({ signal }) => api<RispostaPaginata<Utente>>('/utenti', { query: filtri, signal }),
    placeholderData: keepPreviousData,
  });
}

// Creazione utente
export function useCreaUtente() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (dati: CreaUtenteInput) => api<RispostaPasswordTemporanea>('/utenti', { method: 'POST', body: dati }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['utenti'] }),
  });
}

// Modifica utente
export function useAggiornaUtente() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, dati }: { id: string; dati: AggiornaUtenteInput }) => api<Utente>(`/utenti/${id}`, { method: 'PATCH', body: dati }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['utenti'] });
      void qc.invalidateQueries({ queryKey: ['ruoli'] });
    },
  });
}

// Reset password
export function useResetPassword() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api<RispostaPasswordTemporanea>(`/utenti/${id}/reset-password`, { method: 'POST' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['utenti'] }),
  });
}

// ------------------------------------ Ruoli -----------------------------------------

// Tutti i ruoli
export function useRuoli() {
  return useQuery({ queryKey: ['ruoli'], queryFn: ({ signal }) => api<Ruolo[]>('/ruoli', { signal }) });
}

// Catalogo dei permessi
export function useCatalogoPermessi() {
  return useQuery({ queryKey: ['permessi'], queryFn: ({ signal }) => api<DefinizionePermesso[]>('/permessi', { signal }), staleTime: Infinity });
}

// Creazione ruolo
export function useCreaRuolo() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (dati: CreaRuoloInput) => api<Ruolo>('/ruoli', { method: 'POST', body: dati }), onSuccess: () => qc.invalidateQueries({ queryKey: ['ruoli'] }) });
}

// Eliminazione ruolo
export function useEliminaRuolo() {
  const qc = useQueryClient();
  return useMutation({ mutationFn: (id: string) => api<void>(`/ruoli/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['ruoli'] }) });
}

// Salvataggio della matrice permessi
export function useImpostaPermessi() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, dati }: { id: string; dati: ImpostaPermessiInput }) => api<Ruolo>(`/ruoli/${id}/permessi`, { method: 'PUT', body: dati }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['ruoli'] }),
  });
}

// ------------------------------------ Audit -----------------------------------------

// Filtri del registro
export interface FiltriAudit {
  page?: number;
  pageSize?: number;
  entita?: string;
  entitaId?: string;
  utenteId?: string;
  azione?: string;
  dal?: string;
  al?: string;
}

// Voci del registro attività
export function useAudit(filtri: FiltriAudit, abilitato = true) {
  return useQuery({
    queryKey: ['audit', filtri],
    queryFn: ({ signal }) => api<RispostaPaginata<VoceAudit>>('/audit', { query: { ...filtri }, signal }),
    placeholderData: keepPreviousData,
    // Permette di non eseguire la query se l'utente non ha il permesso
    enabled: abilitato,
  });
}
