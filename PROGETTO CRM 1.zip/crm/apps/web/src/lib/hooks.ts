// =====================================================================================
// Hook React riutilizzabili
// =====================================================================================

// Importa le funzioni di React
import { useCallback, useEffect, useMemo, useState } from 'react';
// Importa i tipi di React Hook Form usati da useAllineaSelect
import type { FieldValues, Path, UseFormGetValues, UseFormSetValue } from 'react-hook-form';
// Importa la gestione dei parametri dell'URL
import { useSearchParams } from 'react-router';

// Restituisce il valore solo dopo che è rimasto invariato per "ritardo" millisecondi
// (evita una chiamata al server a ogni tasto premuto nella ricerca)
export function useDebounce<T>(valore: T, ritardo = 300): T {
  // Valore ritardato
  const [ritardato, setRitardato] = useState(valore);
  // A ogni cambio programma l'aggiornamento
  useEffect(() => {
    // Timer
    const t = setTimeout(() => setRitardato(valore), ritardo);
    // Se il valore cambia prima, annulla il timer precedente
    return () => clearTimeout(t);
  }, [valore, ritardo]);
  // Restituisce il valore stabile
  return ritardato;
}

// Filtri di una lista salvati nell'URL (?q=...&page=2&sort=-codice):
// la pagina si può ricaricare, condividere o navigare con "indietro" senza perdere i filtri
export function useFiltriUrl<K extends string>(chiavi: readonly K[]) {
  // Parametri dell'URL
  const [params, setParams] = useSearchParams();

  // Valori correnti dei filtri
  const filtri = useMemo(() => {
    // Oggetto chiave -> valore
    const valori = {} as Record<K, string>;
    // Legge ogni chiave (stringa vuota se assente)
    for (const k of chiavi) valori[k] = params.get(k) ?? '';
    // Restituisce i valori
    return valori;
  }, [params]);

  // Pagina corrente (minimo 1)
  const page = Math.max(1, Number(params.get('page')) || 1);

  // Aggiorna uno o più filtri; ogni cambio di filtro riporta alla pagina 1
  const imposta = useCallback(
    (modifiche: Partial<Record<K | 'page', string | number | null>>) => {
      setParams(
        (attuali) => {
          // Copia dei parametri
          const nuovi = new URLSearchParams(attuali);
          // Applica le modifiche
          for (const [k, v] of Object.entries(modifiche)) {
            // Valori vuoti rimossi dall'URL
            if (v === null || v === '' || v === undefined) nuovi.delete(k);
            else nuovi.set(k, String(v));
          }
          // Se non si sta cambiando esplicitamente pagina, torna alla prima
          if (!('page' in modifiche)) nuovi.delete('page');
          // Nuovi parametri
          return nuovi;
        },
        // Sostituisce la voce della cronologia (non crea una voce per ogni tasto premuto)
        { replace: true },
      );
    },
    [setParams],
  );

  // Restituisce valori e funzione di aggiornamento
  return { filtri, page, imposta };
}

// Riallinea le <select> di un form quando arrivano le loro opzioni dal server.
// Problema risolto: React Hook Form scrive il valore iniziale nella <select> al montaggio,
// ma se le opzioni (utenti, clienti, commesse, ...) non sono ancora caricate il browser
// mostra "— Nessuno —" anche se il record ha già un responsabile. Appena le opzioni
// arrivano, il valore memorizzato nel form viene riscritto nella <select>.
export function useAllineaSelect<T extends FieldValues>(
  // Funzione del form che imposta un valore (aggiorna anche l'elemento HTML)
  setValue: UseFormSetValue<T>,
  // Funzione del form che legge i valori correnti
  getValues: UseFormGetValues<T>,
  // Nomi dei campi <select> con opzioni caricate dal server
  campi: readonly Path<T>[],
  // Elenchi di opzioni: quando cambiano, l'allineamento viene ripetuto
  opzioni: readonly unknown[],
): void {
  useEffect(() => {
    // Per ogni campo riscrive il valore già presente nel form (nessuna modifica ai dati)
    for (const campo of campi) setValue(campo, getValues(campo), { shouldDirty: false });
    // Si riesegue solo quando cambiano gli elenchi di opzioni
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, opzioni);
}
