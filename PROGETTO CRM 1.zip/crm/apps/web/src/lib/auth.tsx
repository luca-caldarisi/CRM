// =====================================================================================
// Stato di autenticazione dell'applicazione (chi è l'utente e cosa può fare)
// =====================================================================================

// Importa le funzioni di React
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
// Importa il client di TanStack Query per svuotare la cache al logout
import { useQueryClient } from '@tanstack/react-query';
// Importa tipi e funzioni condivisi
import { ambitoPermesso, type Ambito, type CodicePermesso, type LoginInput, type RispostaToken, type UtenteSessione } from '@crm/shared';
// Importa il client API
import { api, impostaAccessToken, rinnovaSessione, suSessioneScaduta, suTokenRinnovato } from './api';

// Stato possibile della sessione
type StatoSessione = 'caricamento' | 'anonimo' | 'autenticato';

// Valori esposti dal contesto
interface ValoreAuth {
  // Stato corrente
  stato: StatoSessione;
  // Utente autenticato (null se anonimo)
  utente: UtenteSessione | null;
  // Esegue il login
  accedi: (dati: LoginInput) => Promise<void>;
  // Esegue il logout
  esci: () => Promise<void>;
  // Ricarica il profilo (es. dopo il cambio password)
  ricaricaProfilo: () => Promise<void>;
}

// Contesto React (undefined finché non si è dentro il provider)
const ContestoAuth = createContext<ValoreAuth | undefined>(undefined);

// Provider da inserire alla radice dell'applicazione
export function AuthProvider({ children }: { children: ReactNode }) {
  // Stato della sessione
  const [stato, setStato] = useState<StatoSessione>('caricamento');
  // Profilo utente
  const [utente, setUtente] = useState<UtenteSessione | null>(null);
  // Cache delle query (da svuotare al logout per non mostrare dati del precedente utente)
  const queryClient = useQueryClient();

  // Legge il profilo dal server
  const ricaricaProfilo = useCallback(async () => {
    // Chiamata /auth/me
    const profilo = await api<UtenteSessione>('/auth/me');
    // Aggiorna lo stato
    setUtente(profilo);
    setStato('autenticato');
  }, []);

  // Riporta l'applicazione allo stato anonimo
  const azzera = useCallback(() => {
    // Cancella token, utente e dati in cache
    impostaAccessToken(null);
    setUtente(null);
    setStato('anonimo');
    queryClient.clear();
  }, [queryClient]);

  // All'avvio prova a recuperare la sessione tramite il cookie (es. dopo un ricaricamento della pagina)
  useEffect(() => {
    // Flag per ignorare il risultato se il componente viene smontato
    let annullato = false;
    // Tenta il rinnovo
    rinnovaSessione()
      .then(async (ok) => {
        // Componente smontato
        if (annullato) return;
        // Sessione valida: carica il profilo, altrimenti anonimo
        if (ok) await ricaricaProfilo();
        else setStato('anonimo');
      })
      // Errore di rete: si considera anonimo
      .catch(() => !annullato && setStato('anonimo'));
    // Pulizia
    return () => {
      annullato = true;
    };
  }, [ricaricaProfilo]);

  // Ascolta gli eventi del client API
  useEffect(() => {
    // Sessione scaduta: torna al login
    const via1 = suSessioneScaduta(azzera);
    // Token rinnovato: i permessi potrebbero essere cambiati, ricarica il profilo
    const via2 = suTokenRinnovato(() => {
      ricaricaProfilo().catch(() => undefined);
    });
    // Rimuove gli ascoltatori allo smontaggio
    return () => {
      via1();
      via2();
    };
  }, [azzera, ricaricaProfilo]);

  // Login
  const accedi = useCallback(
    async (dati: LoginInput) => {
      // Invia le credenziali
      const risposta = await api<RispostaToken>('/auth/login', { method: 'POST', body: dati });
      // Salva il token in memoria
      impostaAccessToken(risposta.accessToken);
      // Carica il profilo
      await ricaricaProfilo();
    },
    [ricaricaProfilo],
  );

  // Logout
  const esci = useCallback(async () => {
    try {
      // Revoca la sessione sul server (anche se fallisce, localmente si esce comunque)
      await api('/auth/logout', { method: 'POST' });
    } finally {
      // Pulisce lo stato locale
      azzera();
    }
  }, [azzera]);

  // Oggetto del contesto memorizzato (evita render inutili)
  const valore = useMemo(() => ({ stato, utente, accedi, esci, ricaricaProfilo }), [stato, utente, accedi, esci, ricaricaProfilo]);

  // Rende disponibile il contesto ai figli
  return <ContestoAuth.Provider value={valore}>{children}</ContestoAuth.Provider>;
}

// Hook per accedere allo stato di autenticazione
export function useAuth(): ValoreAuth {
  // Legge il contesto
  const valore = useContext(ContestoAuth);
  // Errore di programmazione se usato fuori dal provider
  if (!valore) throw new Error('useAuth deve essere usato dentro AuthProvider');
  // Restituisce il valore
  return valore;
}

// Hook che restituisce l'ambito di un permesso (null se non concesso)
// ATTENZIONE: serve solo a nascondere pulsanti e voci di menu; la sicurezza vera è sul server
export function useAmbito(codice: CodicePermesso): Ambito | null {
  // Utente corrente
  const { utente } = useAuth();
  // Ambito o null
  return utente ? ambitoPermesso(utente.permessi, codice) : null;
}

// Hook booleano: true se l'utente possiede il permesso
export function usePermesso(codice: CodicePermesso): boolean {
  return useAmbito(codice) !== null;
}
