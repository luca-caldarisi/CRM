// =====================================================================================
// Gestione uniforme degli errori delle API nell'interfaccia
// =====================================================================================

// Importa il tipo della funzione setError di react-hook-form
import type { FieldValues, Path, UseFormSetError } from 'react-hook-form';
// Importa le notifiche
import { toast } from 'sonner';
// Importa l'errore del client API
import { ErroreApi } from './api';

// Mostra un errore generico come notifica
export function notificaErrore(errore: unknown): void {
  // Errore delle API: mostra il dettaglio restituito dal server
  if (errore instanceof ErroreApi) {
    toast.error(errore.problema.title, { description: errore.problema.detail });
    return;
  }
  // Errore di rete o imprevisto
  toast.error('Errore imprevisto', { description: 'Controlla la connessione e riprova.' });
}

// Applica gli errori di validazione del server ai campi del form; gli altri errori diventano notifiche
export function applicaErroriForm<T extends FieldValues>(errore: unknown, setError: UseFormSetError<T>): void {
  // Errori di validazione con dettaglio per campo
  if (errore instanceof ErroreApi && errore.problema.errors?.length) {
    // Associa ogni messaggio al campo corrispondente
    for (const e of errore.problema.errors) setError(e.campo as Path<T>, { type: 'server', message: e.messaggio });
    return;
  }
  // Tutti gli altri errori (conflitti, permessi, regole di business)
  notificaErrore(errore);
}
