// =====================================================================================
// Funzioni di utilità generiche per l'interfaccia
// =====================================================================================

// Importa clsx per comporre classi condizionali
import { clsx, type ClassValue } from 'clsx';
// Importa tailwind-merge per risolvere i conflitti tra classi Tailwind (es. "p-2" e "p-4")
import { twMerge } from 'tailwind-merge';

// Unisce classi CSS: cn('px-2', condizione && 'bg-red-500', props.className)
export function cn(...classi: ClassValue[]): string {
  return twMerge(clsx(classi));
}

// Formattatore date italiane (es. 17/09/2026)
const formatoData = new Intl.DateTimeFormat('it-IT', { day: '2-digit', month: '2-digit', year: 'numeric' });
// Formattatore data e ora (es. 17/09/2026, 14:30)
const formatoDataOra = new Intl.DateTimeFormat('it-IT', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
// Formattatore valuta in euro
const formatoEuro = new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' });

// Formatta una data ISO; restituisce un trattino se assente
export function formattaData(valore: string | null | undefined): string {
  // Valore mancante
  if (!valore) return '—';
  // Le date senza orario (AAAA-MM-GG) vanno interpretate come data locale, non UTC
  const data = /^\d{4}-\d{2}-\d{2}$/.test(valore) ? new Date(`${valore}T00:00:00`) : new Date(valore);
  // Formatta
  return formatoData.format(data);
}

// Formatta data e ora
export function formattaDataOra(valore: string | null | undefined): string {
  return valore ? formatoDataOra.format(new Date(valore)) : '—';
}

// Formatta un importo decimale ricevuto come stringa (es. "1500.00" -> "1.500,00 €")
export function formattaEuro(valore: string | null | undefined): string {
  return valore == null ? '—' : formatoEuro.format(Number(valore));
}

// Nome completo di un utente
export function nomeCompleto(u: { nome: string; cognome: string | null } | null | undefined): string {
  return u ? `${u.nome} ${u.cognome ?? ''}`.trim() : '—';
}

// Iniziali per l'avatar (es. "Mario Rossi" -> "MR")
export function iniziali(nome: string, cognome?: string | null): string {
  return `${nome.charAt(0)}${cognome?.charAt(0) ?? ''}`.toUpperCase();
}

// Dimensione file leggibile (es. 1536 -> "1,5 KB")
export function formattaDimensione(byte: number): string {
  // Unità di misura
  const unita = ['B', 'KB', 'MB', 'GB'];
  // Indice dell'unità adatta
  const i = byte === 0 ? 0 : Math.min(Math.floor(Math.log(byte) / Math.log(1024)), unita.length - 1);
  // Valore formattato con una cifra decimale
  return `${(byte / 1024 ** i).toLocaleString('it-IT', { maximumFractionDigits: 1 })} ${unita[i]}`;
}
