// =====================================================================================
// Client HTTP verso le API del CRM
// -------------------------------------------------------------------------------------
// - aggiunge automaticamente l'access token a ogni richiesta
// - se il token è scaduto (401) rinnova la sessione con il cookie e ripete la richiesta
// - converte gli errori nel tipo ErroreApi con i dettagli restituiti dal server
// L'access token vive SOLO in memoria (variabile JavaScript): non in localStorage,
// dove un eventuale script malevolo potrebbe leggerlo.
// =====================================================================================

// Importa i tipi condivisi con il backend
import { CODICI_ERRORE_AUTH, type ProblemDetails, type RispostaToken } from '@crm/shared';

// Prefisso di tutte le API (stesso dominio del frontend)
const BASE = '/api/v1';

// Access token corrente
let accessToken: string | null = null;
// Promessa del rinnovo in corso: evita che più richieste parallele rinnovino la sessione contemporaneamente
let rinnovoInCorso: Promise<boolean> | null = null;
// Funzioni da avvisare quando la sessione non è più valida
const ascoltatoriSessioneScaduta = new Set<() => void>();
// Funzioni da avvisare quando il token viene rinnovato (i permessi potrebbero essere cambiati)
const ascoltatoriTokenRinnovato = new Set<() => void>();

// Errore restituito dalle API
export class ErroreApi extends Error {
  // Codice di stato HTTP
  readonly status: number;
  // Corpo Problem Details
  readonly problema: ProblemDetails;

  constructor(problema: ProblemDetails) {
    // Messaggio leggibile: dettaglio o titolo
    super(problema.detail ?? problema.title);
    // Salva stato e corpo
    this.status = problema.status;
    this.problema = problema;
  }
}

// Imposta (o cancella) l'access token
export function impostaAccessToken(token: string | null): void {
  accessToken = token;
}

// Registra una funzione chiamata quando la sessione scade; restituisce la funzione per annullare la registrazione
export function suSessioneScaduta(fn: () => void): () => void {
  ascoltatoriSessioneScaduta.add(fn);
  return () => ascoltatoriSessioneScaduta.delete(fn);
}

// Registra una funzione chiamata dopo ogni rinnovo del token
export function suTokenRinnovato(fn: () => void): () => void {
  ascoltatoriTokenRinnovato.add(fn);
  return () => ascoltatoriTokenRinnovato.delete(fn);
}

// Attende il numero di millisecondi indicato
const attendi = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Rinnova la sessione usando il cookie httpOnly; restituisce true se riuscito
export function rinnovaSessione(): Promise<boolean> {
  // Se un rinnovo è già in corso, tutti aspettano lo stesso
  if (rinnovoInCorso) return rinnovoInCorso;
  // Avvia il rinnovo
  rinnovoInCorso = (async () => {
    // Fino a 3 tentativi (in caso di rinnovo concorrente da un'altra scheda)
    for (let tentativo = 0; tentativo < 3; tentativo++) {
      // Chiamata di refresh: il browser allega automaticamente il cookie
      const res = await fetch(`${BASE}/auth/refresh`, { method: 'POST', credentials: 'same-origin' });
      // Successo: salva il nuovo token
      if (res.ok) {
        // Legge la risposta
        const dati = (await res.json()) as RispostaToken;
        // Aggiorna il token in memoria
        accessToken = dati.accessToken;
        // Avvisa chi deve ricaricare i permessi
        ascoltatoriTokenRinnovato.forEach((fn) => fn());
        // Rinnovo riuscito
        return true;
      }
      // Un'altra scheda ha appena rinnovato: aspetta un attimo e riprova con il nuovo cookie
      if (res.status === 409) {
        await attendi(300 * (tentativo + 1));
        continue;
      }
      // Qualsiasi altro errore: sessione non valida
      break;
    }
    // Rinnovo fallito: cancella il token
    accessToken = null;
    return false;
  })().finally(() => {
    // Alla fine libera il blocco
    rinnovoInCorso = null;
  });
  // Restituisce la promessa
  return rinnovoInCorso;
}

// Opzioni di una chiamata API
interface OpzioniRichiesta {
  // Metodo HTTP
  method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  // Corpo JSON
  body?: unknown;
  // Corpo multipart (upload file)
  formData?: FormData;
  // Parametri della query string (i valori vuoti vengono ignorati)
  query?: Record<string, string | number | boolean | null | undefined>;
  // Segnale per annullare la richiesta
  signal?: AbortSignal;
}

// Costruisce l'URL completo con la query string
function costruisciUrl(percorso: string, query?: OpzioniRichiesta['query']): string {
  // Parametri
  const params = new URLSearchParams();
  // Aggiunge solo i valori valorizzati
  for (const [chiave, valore] of Object.entries(query ?? {})) {
    if (valore !== undefined && valore !== null && valore !== '') params.set(chiave, String(valore));
  }
  // Stringa della query
  const qs = params.toString();
  // URL finale
  return `${BASE}${percorso}${qs ? `?${qs}` : ''}`;
}

// Legge il corpo di errore; se non è JSON crea un Problem Details generico
async function leggiErrore(res: Response): Promise<ProblemDetails> {
  try {
    // Prova a leggere il JSON
    return (await res.json()) as ProblemDetails;
  } catch {
    // Risposta non JSON (es. errore del proxy)
    return { type: 'errore', title: 'Errore di comunicazione con il server', status: res.status };
  }
}

// Esegue una richiesta HTTP autenticata (senza interpretare la risposta)
async function eseguiFetch(percorso: string, opzioni: OpzioniRichiesta = {}): Promise<Response> {
  // Funzione che esegue la fetch con il token corrente
  const esegui = () =>
    fetch(costruisciUrl(percorso, opzioni.query), {
      method: opzioni.method ?? 'GET',
      credentials: 'same-origin',
      signal: opzioni.signal,
      headers: {
        // Token di accesso se presente
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        // Content-Type JSON solo quando si invia un corpo JSON (per il multipart lo imposta il browser)
        ...(opzioni.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      },
      // Corpo della richiesta
      body: opzioni.formData ?? (opzioni.body !== undefined ? JSON.stringify(opzioni.body) : undefined),
    });

  // Prima esecuzione
  let res = await esegui();
  // Token scaduto o permessi cambiati: rinnova e riprova una volta (escluse le rotte di autenticazione)
  if (res.status === 401 && !percorso.startsWith('/auth/')) {
    // Tenta il rinnovo
    if (await rinnovaSessione()) {
      // Ripete la richiesta con il nuovo token
      res = await esegui();
    } else {
      // Sessione definitivamente scaduta: avvisa l'applicazione (tornerà al login)
      ascoltatoriSessioneScaduta.forEach((fn) => fn());
    }
  }
  // Restituisce la risposta
  return res;
}

// Esegue una chiamata API e restituisce il JSON della risposta
export async function api<T>(percorso: string, opzioni: OpzioniRichiesta = {}): Promise<T> {
  // Esegue la richiesta
  const res = await eseguiFetch(percorso, opzioni);
  // Gestione errori
  if (!res.ok) {
    // Legge il dettaglio
    const problema = await leggiErrore(res);
    // Cambio password richiesto: la pagina verrà reindirizzata dal gestore di autenticazione
    if (problema.type === CODICI_ERRORE_AUTH.cambioPasswordRichiesto) ascoltatoriTokenRinnovato.forEach((fn) => fn());
    // Lancia l'errore tipizzato
    throw new ErroreApi(problema);
  }
  // 204 No Content: nessun corpo
  if (res.status === 204) return undefined as T;
  // Corpo JSON
  return (await res.json()) as T;
}

// Scarica un file protetto e lo salva sul computer dell'utente
export async function scaricaFile(percorso: string, nomeFile: string): Promise<void> {
  // Richiesta autenticata
  const res = await eseguiFetch(percorso);
  // Errore
  if (!res.ok) throw new ErroreApi(await leggiErrore(res));
  // Contenuto binario
  const blob = await res.blob();
  // URL temporaneo in memoria
  const url = URL.createObjectURL(blob);
  // Link invisibile per avviare il download
  const link = document.createElement('a');
  link.href = url;
  link.download = nomeFile;
  // Avvia il download
  link.click();
  // Libera la memoria
  URL.revokeObjectURL(url);
}
