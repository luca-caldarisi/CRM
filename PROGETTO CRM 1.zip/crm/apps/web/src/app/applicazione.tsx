// =====================================================================================
// Provider globali e definizione delle rotte
// =====================================================================================

// Importa TanStack Query (cache e sincronizzazione dei dati del server)
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
// Importa il router
import { createBrowserRouter, Navigate, RouterProvider } from 'react-router';
// Importa le notifiche
import { Toaster } from 'sonner';
// Importa autenticazione e tipi di errore
import { AuthProvider } from '@/lib/auth';
import { ErroreApi } from '@/lib/api';
// Importa layout e protezioni delle rotte
import { LayoutApplicazione } from './layout';
import { RichiedeAutenticazione, RichiedePermessoRotta } from './protezioni';
// Importa lazy e Suspense per caricare ogni pagina solo quando serve (code splitting)
import { lazy, Suspense, type ComponentType, type ReactNode } from 'react';
// Importa il tipo dei codici permesso
import type { CodicePermesso } from '@crm/shared';
// Importa l'indicatore di caricamento
import { Caricamento } from '@/components/common/pagina';
// Pagine sempre necessarie all'avvio: caricate subito
import { PaginaLogin } from '@/features/auth/pagina-login';
import { PaginaCambioPassword } from '@/features/auth/pagina-cambio-password';
import { PaginaDashboard } from '@/features/dashboard/pagina-dashboard';

// Carica in modo differito un componente esportato con nome (React.lazy vuole l'export "default")
function differita<M, K extends keyof M>(importa: () => Promise<M>, nome: K) {
  // Il file JavaScript della pagina viene scaricato solo alla prima visita
  return lazy(() => importa().then((m) => ({ default: m[nome] as ComponentType })));
}

// Pagine caricate a richiesta: il bundle iniziale resta piccolo e il login è più veloce
const PaginaClienti = differita(() => import('@/features/clienti/pagina-clienti'), 'PaginaClienti');
const PaginaCliente = differita(() => import('@/features/clienti/pagina-cliente'), 'PaginaCliente');
const PaginaCommesse = differita(() => import('@/features/commesse/pagina-commesse'), 'PaginaCommesse');
const PaginaCommessa = differita(() => import('@/features/commesse/pagina-commessa'), 'PaginaCommessa');
const PaginaProgetti = differita(() => import('@/features/progetti/pagina-progetti'), 'PaginaProgetti');
const PaginaProgetto = differita(() => import('@/features/progetti/pagina-progetto'), 'PaginaProgetto');
const PaginaTemplate = differita(() => import('@/features/progetti/pagina-template'), 'PaginaTemplate');
const PaginaUtenti = differita(() => import('@/features/utenti/pagina-utenti'), 'PaginaUtenti');
const PaginaRuoli = differita(() => import('@/features/ruoli/pagina-ruoli'), 'PaginaRuoli');
const PaginaAudit = differita(() => import('@/features/audit/pagina-audit'), 'PaginaAudit');

// Rotta protetta da un permesso, con indicatore mostrato mentre la pagina viene scaricata
// (sostituisce il blocco <RichiedePermessoRotta>…</RichiedePermessoRotta> ripetuto su ogni rotta)
function protetta(path: string, codice: CodicePermesso, pagina: ReactNode) {
  // Oggetto rotta nel formato di React Router
  return { path, element: <RichiedePermessoRotta codice={codice}><Suspense fallback={<Caricamento />}>{pagina}</Suspense></RichiedePermessoRotta> };
}

// Client delle query con impostazioni predefinite
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // I dati restano "freschi" per 30 secondi: niente richieste duplicate navigando avanti e indietro
      staleTime: 30_000,
      // Nessun nuovo tentativo per gli errori 4xx (permessi, non trovato): ripeterli non serve
      retry: (tentativi, errore) => !(errore instanceof ErroreApi && errore.status < 500) && tentativi < 2,
      // Non ricarica tutto quando la finestra torna in primo piano
      refetchOnWindowFocus: false,
    },
  },
});

// Definizione delle rotte
const router = createBrowserRouter([
  // Pagine pubbliche
  { path: '/login', element: <PaginaLogin /> },
  // Cambio password (richiede login ma non il layout completo)
  { path: '/cambia-password', element: <RichiedeAutenticazione consentiCambioPassword><PaginaCambioPassword /></RichiedeAutenticazione> },
  // Area riservata con sidebar
  {
    element: (
      <RichiedeAutenticazione>
        <LayoutApplicazione />
      </RichiedeAutenticazione>
    ),
    children: [
      { index: true, element: <PaginaDashboard /> },
      protetta('clienti', 'clienti.read', <PaginaClienti />),
      protetta('clienti/:id', 'clienti.read', <PaginaCliente />),
      protetta('commesse', 'commesse.read', <PaginaCommesse />),
      protetta('commesse/:id', 'commesse.read', <PaginaCommessa />),
      // I template stanno prima di ":id" per non essere interpretati come identificativo
      protetta('progetti', 'progetti.read', <PaginaProgetti />),
      protetta('progetti/template', 'template.manage', <PaginaTemplate />),
      protetta('progetti/:id', 'progetti.read', <PaginaProgetto />),
      protetta('amministrazione/utenti', 'utenti.manage', <PaginaUtenti />),
      protetta('amministrazione/ruoli', 'ruoli.manage', <PaginaRuoli />),
      protetta('amministrazione/audit', 'audit.read', <PaginaAudit />),
      // Qualsiasi altro indirizzo torna alla dashboard
      { path: '*', element: <Navigate to="/" replace /> },
    ],
  },
]);

// Componente radice
export function Applicazione() {
  return (
    // Cache dei dati del server
    <QueryClientProvider client={queryClient}>
      {/* Stato di autenticazione */}
      <AuthProvider>
        {/* Navigazione */}
        <RouterProvider router={router} />
        {/* Notifiche in basso a destra */}
        <Toaster position="bottom-right" richColors closeButton />
      </AuthProvider>
    </QueryClientProvider>
  );
}
