// =====================================================================================
// Layout dell'area riservata: barra laterale di navigazione + barra superiore + contenuto
// =====================================================================================

// Importa gli hook di React
import { useEffect, useState } from 'react';
// Importa componenti del router
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router';
// Importa le icone
import { Briefcase, Building2, KanbanSquare, KeyRound, LayoutDashboard, LogOut, Menu as IconaMenu, ScrollText, ShieldCheck, Users, X } from 'lucide-react';
// Importa il tipo dei permessi
import type { CodicePermesso } from '@crm/shared';
// Importa componenti e utilità
import { Button } from '@/components/ui/button';
import { Avatar } from '@/components/ui/elementi';
import { Menu } from '@/components/ui/menu-tabs';
import { useAuth } from '@/lib/auth';
import { ambitoPermesso } from '@crm/shared';
import { cn } from '@/lib/utils';

// Voce di navigazione
interface VoceNav {
  a: string;
  etichetta: string;
  icona: typeof LayoutDashboard;
  // Permesso necessario per vedere la voce
  permesso?: CodicePermesso;
}

// Gruppi della barra laterale
const GRUPPI: Array<{ titolo?: string; voci: VoceNav[] }> = [
  { voci: [{ a: '/', etichetta: 'Dashboard', icona: LayoutDashboard }] },
  {
    titolo: 'Anagrafiche',
    voci: [
      { a: '/clienti', etichetta: 'Clienti', icona: Building2, permesso: 'clienti.read' },
      { a: '/commesse', etichetta: 'Commesse', icona: Briefcase, permesso: 'commesse.read' },
    ],
  },
  {
    titolo: 'Lavoro',
    voci: [{ a: '/progetti', etichetta: 'Progetti', icona: KanbanSquare, permesso: 'progetti.read' }],
  },
  {
    titolo: 'Amministrazione',
    voci: [
      { a: '/amministrazione/utenti', etichetta: 'Utenti', icona: Users, permesso: 'utenti.manage' },
      { a: '/amministrazione/ruoli', etichetta: 'Ruoli e permessi', icona: ShieldCheck, permesso: 'ruoli.manage' },
      { a: '/amministrazione/audit', etichetta: 'Registro attività', icona: ScrollText, permesso: 'audit.read' },
    ],
  },
];

// Layout principale
export function LayoutApplicazione() {
  // Utente e funzione di logout
  const { utente, esci } = useAuth();
  // Navigazione programmatica
  const naviga = useNavigate();
  // Posizione corrente
  const posizione = useLocation();
  // Barra laterale aperta su mobile
  const [menuMobile, setMenuMobile] = useState(false);

  // Chiude il menu mobile a ogni cambio pagina
  useEffect(() => setMenuMobile(false), [posizione.pathname]);

  // Il layout è montato solo con utente autenticato (garantito da RichiedeAutenticazione)
  if (!utente) return null;

  // Gruppi filtrati in base ai permessi dell'utente
  const gruppiVisibili = GRUPPI.map((g) => ({ ...g, voci: g.voci.filter((v) => !v.permesso || ambitoPermesso(utente.permessi, v.permesso)) })).filter((g) => g.voci.length > 0);

  // Contenuto della barra laterale (riusato su desktop e mobile)
  const barraLaterale = (
    <div className="flex h-full flex-col">
      {/* Logo */}
      <div className="flex h-14 items-center gap-2.5 border-b border-slate-200 px-5">
        <img src="/favicon.svg" alt="" className="size-7" />
        <span className="text-sm font-semibold tracking-tight text-slate-900">CRM</span>
      </div>
      {/* Navigazione */}
      <nav aria-label="Navigazione principale" className="flex-1 space-y-6 overflow-y-auto px-3 py-4">
        {gruppiVisibili.map((g) => (
          <div key={g.titolo ?? 'principale'}>
            {/* Titolo del gruppo */}
            {g.titolo && <p className="mb-1 px-2 text-[11px] font-semibold uppercase tracking-wider text-slate-400">{g.titolo}</p>}
            {/* Voci */}
            <ul className="space-y-0.5">
              {g.voci.map((v) => (
                <li key={v.a}>
                  <NavLink
                    to={v.a}
                    // "end" sulla dashboard: attiva solo sulla radice esatta
                    end={v.a === '/'}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-2.5 rounded-md px-2 py-1.5 text-sm font-medium transition-colors',
                        isActive ? 'bg-primario-50 text-primario-700' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
                      )
                    }
                  >
                    <v.icona className="size-4" aria-hidden />
                    {v.etichetta}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>
      {/* Utente in fondo alla barra */}
      <div className="border-t border-slate-200 p-3">
        <Menu
          allineamento="start"
          grilletto={
            <button type="button" className="flex w-full items-center gap-2.5 rounded-md p-2 text-left hover:bg-slate-100">
              <Avatar nome={utente.nome} cognome={utente.cognome} />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-medium text-slate-900">{utente.nome} {utente.cognome}</span>
                <span className="block truncate text-xs text-slate-500">{utente.ruolo.nome}</span>
              </span>
            </button>
          }
          voci={[
            { etichetta: 'Cambia password', icona: <KeyRound />, onSelect: () => naviga('/cambia-password') },
            { etichetta: 'Esci', icona: <LogOut />, onSelect: () => void esci(), pericolo: true },
          ]}
        />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      {/* Link per saltare al contenuto (accessibilità da tastiera) */}
      <a href="#contenuto" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded focus:bg-white focus:px-3 focus:py-2">
        Vai al contenuto
      </a>
      {/* Barra laterale fissa su desktop */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 border-r border-slate-200 bg-white lg:block">{barraLaterale}</aside>
      {/* Barra laterale a scomparsa su mobile */}
      {menuMobile && (
        <div className="fixed inset-0 z-40 lg:hidden">
          {/* Sfondo cliccabile per chiudere */}
          <div className="absolute inset-0 bg-slate-900/40" onClick={() => setMenuMobile(false)} aria-hidden />
          {/* Pannello */}
          <aside className="relative h-full w-64 bg-white shadow-xl">
            <Button variante="fantasma" dimensione="icona" className="absolute right-2 top-2.5" onClick={() => setMenuMobile(false)} aria-label="Chiudi menu">
              <X />
            </Button>
            {barraLaterale}
          </aside>
        </div>
      )}
      {/* Colonna del contenuto */}
      <div className="lg:pl-60">
        {/* Barra superiore visibile solo su mobile */}
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-slate-200 bg-white/90 px-4 backdrop-blur lg:hidden">
          <Button variante="fantasma" dimensione="icona" onClick={() => setMenuMobile(true)} aria-label="Apri menu">
            <IconaMenu />
          </Button>
          <span className="text-sm font-semibold">CRM</span>
        </header>
        {/* Contenuto della pagina */}
        <main id="contenuto" className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
