// =====================================================================================
// Protezioni delle rotte lato interfaccia
// -------------------------------------------------------------------------------------
// Servono all'esperienza utente (redirect al login, pagina "accesso negato").
// La protezione reale dei dati è sempre nel backend.
// =====================================================================================

// Importa i tipi di React
import type { ReactNode } from 'react';
// Importa componenti del router
import { Navigate, useLocation } from 'react-router';
// Importa l'icona di caricamento
import { Loader2 } from 'lucide-react';
// Importa il tipo dei permessi
import type { CodicePermesso } from '@crm/shared';
// Importa autenticazione e pagina di accesso negato
import { useAuth, usePermesso } from '@/lib/auth';
import { AccessoNegato } from '@/components/common/pagina';

// Mostra i figli solo agli utenti autenticati
export function RichiedeAutenticazione({ children, consentiCambioPassword = false }: { children: ReactNode; consentiCambioPassword?: boolean }) {
  // Stato della sessione
  const { stato, utente } = useAuth();
  // Posizione corrente (per tornarci dopo il login)
  const posizione = useLocation();

  // Verifica della sessione in corso: schermata di attesa
  if (stato === 'caricamento') {
    return (
      <div className="flex h-screen items-center justify-center" role="status" aria-label="Caricamento">
        <Loader2 className="size-6 animate-spin text-primario-600" />
      </div>
    );
  }
  // Non autenticato: al login, ricordando la pagina richiesta
  if (stato === 'anonimo' || !utente) return <Navigate to="/login" replace state={{ da: posizione.pathname + posizione.search }} />;
  // Cambio password obbligatorio: consentita solo la pagina dedicata
  if (utente.deveCambiarePassword && !consentiCambioPassword) return <Navigate to="/cambia-password" replace />;
  // Accesso consentito
  return children;
}

// Mostra i figli solo se l'utente ha il permesso, altrimenti la pagina di accesso negato
export function RichiedePermessoRotta({ codice, children }: { codice: CodicePermesso; children: ReactNode }) {
  // Verifica il permesso
  const consentito = usePermesso(codice);
  // Contenuto o pagina di cortesia
  return consentito ? children : <AccessoNegato />;
}
