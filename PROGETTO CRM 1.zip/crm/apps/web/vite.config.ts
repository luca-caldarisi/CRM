// Configurazione di Vite: server di sviluppo e build di produzione del frontend

// Importa la funzione per costruire percorsi
import { fileURLToPath, URL } from 'node:url';
// Importa la funzione di configurazione
import { defineConfig } from 'vite';
// Plugin React (JSX e aggiornamento istantaneo dei componenti)
import react from '@vitejs/plugin-react';
// Plugin Tailwind CSS v4
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  // Plugin attivi
  plugins: [react(), tailwindcss()],
  resolve: {
    // Alias "@/..." che punta a src (evita import come "../../../components")
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
  },
  server: {
    // Porta del server di sviluppo
    port: 5173,
    // In sviluppo le chiamate /api vengono inoltrate al backend: stesso dominio, come in produzione con Nginx
    proxy: { '/api': { target: 'http://localhost:3000', changeOrigin: false } },
  },
  build: {
    // Cartella di output
    outDir: 'dist',
    // Niente source map pubbliche in produzione (non si espone il codice sorgente)
    sourcemap: false,
    rollupOptions: {
      output: {
        // Librerie di terze parti in file separati: cambiano raramente, quindi il browser le tiene in cache
        // e dopo un aggiornamento del CRM scarica di nuovo solo il codice applicativo
        manualChunks(percorso) {
          // Il codice del CRM resta nei chunk normali (uno per pagina)
          if (!percorso.includes('node_modules')) return undefined;
          // React e router: base di tutta l'interfaccia
          if (/node_modules\/\.pnpm\/(react|react-dom|react-router|scheduler)@/.test(percorso)) return 'vendor-react';
          // Componenti accessibili Radix (dialog, menu, tab, ...)
          if (percorso.includes('@radix-ui') || percorso.includes('/radix-ui@')) return 'vendor-radix';
          // Validazione e form
          if (/\/(zod|react-hook-form|@hookform)/.test(percorso)) return 'vendor-form';
          // Gestione dei dati del server
          if (percorso.includes('@tanstack')) return 'vendor-query';
          // Tutto il resto (icone, notifiche, utilità) lasciato alla suddivisione automatica
          return undefined;
        },
      },
    },
  },
});
