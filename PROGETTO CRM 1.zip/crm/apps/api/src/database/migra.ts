// =====================================================================================
// Script che applica al database le migrazioni SQL non ancora eseguite
// Uso: "pnpm db:migrate" in sviluppo, "pnpm db:migrate:prod" nel container di produzione
// =====================================================================================

// Importa il percorso assoluto delle cartelle
import { resolve, sep } from 'node:path';
// Carica le variabili d'ambiente dal file .env (in produzione arrivano già da Docker)
import { config } from 'dotenv';
// Importa la funzione di migrazione di Drizzle
import { migrate } from 'drizzle-orm/node-postgres/migrator';
// Importa la creazione della connessione
import { creaDatabase } from './client';

// Funzione principale asincrona
async function main(): Promise<void> {
  // Carica il file .env della radice del monorepo, se esiste
  config({ path: resolve(__dirname, '../../../../.env'), quiet: true });
  // Legge la stringa di connessione
  const url = process.env.DATABASE_URL;
  // Senza connessione non si può procedere
  if (!url) throw new Error('DATABASE_URL non impostata');
  // Apre la connessione
  const { db, pool } = creaDatabase(url);
  // Cerca la cartella drizzle risalendo da src/database (sviluppo) o da dist/src/database (produzione)
  const cartella = __dirname.split(sep).includes('dist') ? resolve(__dirname, '../../../drizzle') : resolve(__dirname, '../../drizzle');
  // Messaggio informativo
  console.log(`Applicazione migrazioni da ${cartella}...`);
  // Applica le migrazioni in ordine, dentro una transazione, registrandole nella tabella __drizzle_migrations
  await migrate(db, { migrationsFolder: cartella });
  // Messaggio di conferma
  console.log('Migrazioni completate');
  // Chiude le connessioni
  await pool.end();
}

// Esegue lo script e termina con codice di errore in caso di problemi
main().catch((errore: unknown) => {
  // Stampa l'errore
  console.error('Migrazione fallita:', errore);
  // Codice di uscita diverso da zero: Docker/CI capiscono che qualcosa è andato storto
  process.exit(1);
});
