// =====================================================================================
// Modulo globale che fornisce la connessione al database a tutti i servizi
// =====================================================================================

// Importa i decoratori e le interfacce di NestJS
import { Global, Inject, Module, type OnApplicationShutdown } from '@nestjs/common';
// Importa il tipo del pool di connessioni
import type { Pool } from 'pg';
// Importa il token e il tipo della configurazione
import { ENV, type Env } from '../config/env';
// Importa la funzione di creazione della connessione
import { creaDatabase } from './client';

// Token con cui si inietta l'istanza Drizzle: @Inject(DB) private readonly db: Database
export const DB = Symbol('DB');
// Token interno per il pool (serve per chiuderlo allo spegnimento)
const POOL = Symbol('POOL');

// @Global rende i provider disponibili in tutti i moduli senza doverlo importare ovunque
@Global()
@Module({
  providers: [
    {
      // Crea la connessione una sola volta all'avvio
      provide: 'CONNESSIONE',
      // Riceve la configurazione validata
      inject: [ENV],
      // Factory che apre il pool
      useFactory: (env: Env) => creaDatabase(env.DATABASE_URL),
    },
    // Espone l'istanza Drizzle
    { provide: DB, inject: ['CONNESSIONE'], useFactory: (c: ReturnType<typeof creaDatabase>) => c.db },
    // Espone il pool
    { provide: POOL, inject: ['CONNESSIONE'], useFactory: (c: ReturnType<typeof creaDatabase>) => c.pool },
  ],
  // Rende DB iniettabile negli altri moduli
  exports: [DB],
})
export class DatabaseModule implements OnApplicationShutdown {
  // Riceve il pool per poterlo chiudere
  constructor(@Inject(POOL) private readonly pool: Pool) {}

  // Chiamato da NestJS allo spegnimento (SIGTERM inviato da systemd): chiude le connessioni in modo pulito
  async onApplicationShutdown(): Promise<void> {
    // Attende la chiusura di tutte le connessioni
    await this.pool.end();
  }
}
