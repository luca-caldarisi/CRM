// =====================================================================================
// Creazione della connessione al database (usata dall'API, dagli script e dai test)
// =====================================================================================

// Importa il driver di Drizzle per node-postgres
import { drizzle, type NodePgDatabase } from 'drizzle-orm/node-postgres';
// Importa il pool di connessioni di node-postgres
import { Pool } from 'pg';
// Importa l'intero schema (tabelle + relazioni) per abilitare le query relazionali
import * as schema from './schema';

// Tipo dell'istanza del database con lo schema del CRM
export type Database = NodePgDatabase<typeof schema>;

// Tipo di una transazione (stessi metodi del database)
export type Transazione = Parameters<Parameters<Database['transaction']>[0]>[0];

// Tipo che accetta sia il database sia una transazione: i service lo usano per partecipare a transazioni esterne
export type DbOTransazione = Database | Transazione;

// Crea pool e istanza Drizzle a partire dalla stringa di connessione
export function creaDatabase(databaseUrl: string): { db: Database; pool: Pool } {
  // Pool di connessioni riutilizzabili (10 sono ampiamente sufficienti per 10 utenti)
  const pool = new Pool({
    // Stringa di connessione
    connectionString: databaseUrl,
    // Numero massimo di connessioni aperte contemporaneamente
    max: 10,
    // Chiude le connessioni inattive dopo 30 secondi
    idleTimeoutMillis: 30_000,
    // Fallisce se non riesce a connettersi entro 5 secondi
    connectionTimeoutMillis: 5_000,
  });
  // Gestisce gli errori delle connessioni inattive (es. riavvio di PostgreSQL):
  // senza questo ascoltatore Node considera l'errore "non gestito" e termina l'intera API.
  // Il pool scarta la connessione guasta e ne apre una nuova alla richiesta successiva.
  pool.on('error', (errore) => {
    // Registra l'evento senza interrompere il processo
    console.warn(`[database] connessione inattiva chiusa: ${errore.message}`);
  });
  // Crea l'istanza Drizzle collegata al pool e allo schema
  const db = drizzle(pool, { schema });
  // Restituisce entrambi: il pool serve per chiudere le connessioni allo spegnimento
  return { db, pool };
}
