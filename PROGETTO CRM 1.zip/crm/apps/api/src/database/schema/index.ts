// =====================================================================================
// Punto di ingresso dello schema del database: tabelle e relazioni
// =====================================================================================

// Importa la funzione per dichiarare le relazioni tra tabelle (usate dalle query con "with")
import { relations } from 'drizzle-orm';
// Importa le tabelle anagrafiche
import { allegati, clienti, commesse, contatti, sedi } from './anagrafiche';
// Importa le tabelle di sicurezza
import { auditLog, permessi, ruoli, ruoliPermessi, sessioni, utenti } from './sicurezza';
// Importa le tabelle dei progetti
import { progetti, progettoColonne, progettoTemplate, registrazioniOre, task, taskTodo, templateColonne, templateTask, templateTodo } from './progetti';

// Riesporta enum e colonne comuni
export * from './comune';
// Riesporta le tabelle di sicurezza
export * from './sicurezza';
// Riesporta le tabelle anagrafiche
export * from './anagrafiche';
// Riesporta le tabelle dei progetti
export * from './progetti';

// --------------------------------- Relazioni ------------------------------------------
// Le relazioni non creano vincoli nel database (quelli sono le references):
// servono a Drizzle per caricare dati collegati in un'unica query.

// Un ruolo ha molti utenti e molti permessi
export const ruoliRelazioni = relations(ruoli, ({ many }) => ({
  utenti: many(utenti),
  permessi: many(ruoliPermessi),
}));

// Ogni riga ruolo-permesso appartiene a un ruolo e a un permesso
export const ruoliPermessiRelazioni = relations(ruoliPermessi, ({ one }) => ({
  ruolo: one(ruoli, { fields: [ruoliPermessi.ruoloId], references: [ruoli.id] }),
  permesso: one(permessi, { fields: [ruoliPermessi.permessoCodice], references: [permessi.codice] }),
}));

// Un utente ha un ruolo e molte sessioni
export const utentiRelazioni = relations(utenti, ({ one, many }) => ({
  ruolo: one(ruoli, { fields: [utenti.ruoloId], references: [ruoli.id] }),
  sessioni: many(sessioni),
}));

// Ogni sessione appartiene a un utente
export const sessioniRelazioni = relations(sessioni, ({ one }) => ({
  utente: one(utenti, { fields: [sessioni.utenteId], references: [utenti.id] }),
}));

// Ogni voce di audit può avere un utente
export const auditRelazioni = relations(auditLog, ({ one }) => ({
  utente: one(utenti, { fields: [auditLog.utenteId], references: [utenti.id] }),
}));

// Un cliente ha un commerciale, molte sedi, contatti e commesse
export const clientiRelazioni = relations(clienti, ({ one, many }) => ({
  commerciale: one(utenti, { fields: [clienti.commercialeId], references: [utenti.id] }),
  sedi: many(sedi),
  contatti: many(contatti),
  commesse: many(commesse),
}));

// Ogni sede appartiene a un cliente
export const sediRelazioni = relations(sedi, ({ one }) => ({
  cliente: one(clienti, { fields: [sedi.clienteId], references: [clienti.id] }),
}));

// Ogni contatto appartiene a un cliente e opzionalmente a una sede
export const contattiRelazioni = relations(contatti, ({ one }) => ({
  cliente: one(clienti, { fields: [contatti.clienteId], references: [clienti.id] }),
  sede: one(sedi, { fields: [contatti.sedeId], references: [sedi.id] }),
}));

// Ogni commessa appartiene a un cliente e ha un responsabile
export const commesseRelazioni = relations(commesse, ({ one }) => ({
  cliente: one(clienti, { fields: [commesse.clienteId], references: [clienti.id] }),
  responsabile: one(utenti, { fields: [commesse.responsabileId], references: [utenti.id] }),
}));

// Ogni allegato ha l'utente che l'ha caricato
export const allegatiRelazioni = relations(allegati, ({ one }) => ({
  caricatoDa: one(utenti, { fields: [allegati.caricatoDaId], references: [utenti.id] }),
}));

// Un template ha colonne e task predefiniti
export const templateRelazioni = relations(progettoTemplate, ({ many }) => ({
  colonne: many(templateColonne),
  task: many(templateTask),
}));

// Ogni colonna del template appartiene a un template
export const templateColonneRelazioni = relations(templateColonne, ({ one }) => ({
  template: one(progettoTemplate, { fields: [templateColonne.templateId], references: [progettoTemplate.id] }),
}));

// Ogni task del template appartiene a un template e ha voci di to-do
export const templateTaskRelazioni = relations(templateTask, ({ one, many }) => ({
  template: one(progettoTemplate, { fields: [templateTask.templateId], references: [progettoTemplate.id] }),
  todo: many(templateTodo),
}));

// Ogni voce di to-do del template appartiene a un task del template
export const templateTodoRelazioni = relations(templateTodo, ({ one }) => ({
  task: one(templateTask, { fields: [templateTodo.templateTaskId], references: [templateTask.id] }),
}));

// Un progetto appartiene a un cliente, ha colonne e task
export const progettiRelazioni = relations(progetti, ({ one, many }) => ({
  cliente: one(clienti, { fields: [progetti.clienteId], references: [clienti.id] }),
  commessa: one(commesse, { fields: [progetti.commessaId], references: [commesse.id] }),
  template: one(progettoTemplate, { fields: [progetti.templateId], references: [progettoTemplate.id] }),
  responsabile: one(utenti, { fields: [progetti.responsabileId], references: [utenti.id] }),
  colonne: many(progettoColonne),
  task: many(task),
}));

// Ogni colonna appartiene a un progetto e contiene task
export const progettoColonneRelazioni = relations(progettoColonne, ({ one, many }) => ({
  progetto: one(progetti, { fields: [progettoColonne.progettoId], references: [progetti.id] }),
  task: many(task),
}));

// Ogni task appartiene a progetto e colonna, ha to-do e registrazioni ore
export const taskRelazioni = relations(task, ({ one, many }) => ({
  progetto: one(progetti, { fields: [task.progettoId], references: [progetti.id] }),
  colonna: one(progettoColonne, { fields: [task.colonnaId], references: [progettoColonne.id] }),
  responsabile: one(utenti, { fields: [task.responsabileId], references: [utenti.id] }),
  todo: many(taskTodo),
  ore: many(registrazioniOre),
}));

// Ogni voce di to-do appartiene a un task
export const taskTodoRelazioni = relations(taskTodo, ({ one }) => ({
  task: one(task, { fields: [taskTodo.taskId], references: [task.id] }),
  assegnatario: one(utenti, { fields: [taskTodo.assegnatarioId], references: [utenti.id] }),
}));

// Ogni registrazione ore appartiene a un task e a un utente
export const registrazioniOreRelazioni = relations(registrazioniOre, ({ one }) => ({
  task: one(task, { fields: [registrazioniOre.taskId], references: [task.id] }),
  utente: one(utenti, { fields: [registrazioniOre.utenteId], references: [utenti.id] }),
}));
