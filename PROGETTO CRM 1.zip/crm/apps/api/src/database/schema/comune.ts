// =====================================================================================
// Colonne ed enum riutilizzati da più tabelle
// =====================================================================================

// Importa i costruttori di colonne ed enum PostgreSQL di Drizzle
import { pgEnum, timestamp, uuid } from 'drizzle-orm/pg-core';
// Importa il generatore di UUID v7
import { uuidv7 } from '../../common/utils/uuidv7';

// ------------------------------------ Enum --------------------------------------------

// Ambito di un permesso concesso a un ruolo
export const ambitoEnum = pgEnum('ambito', ['tutti', 'propri']);
// Tipo di sede di un cliente
export const tipoSedeEnum = pgEnum('tipo_sede', ['legale', 'operativa']);
// Tipo di commessa
export const tipoCommessaEnum = pgEnum('tipo_commessa', ['assistenza', 'progetto', 'fornitura', 'mista']);
// Stato di una commessa
export const statoCommessaEnum = pgEnum('stato_commessa', ['aperta', 'sospesa', 'chiusa', 'annullata']);
// Azioni registrate nell'audit log
export const azioneAuditEnum = pgEnum('azione_audit', [
  'creazione',
  'modifica',
  'eliminazione',
  'login',
  'login_fallito',
  'logout',
  'cambio_password',
  'reset_password',
  'permessi',
]);
// Entità a cui si possono collegare allegati
export const entitaAllegatoEnum = pgEnum('entita_allegato', ['cliente', 'commessa', 'progetto']);
// Stato di un progetto
export const statoProgettoEnum = pgEnum('stato_progetto', ['pianificato', 'in_corso', 'sospeso', 'concluso', 'annullato']);
// Priorità di un task
export const prioritaTaskEnum = pgEnum('priorita_task', ['bassa', 'media', 'alta', 'urgente']);

// ---------------------------------- Colonne -------------------------------------------

// Chiave primaria UUID v7 generata dall'applicazione
export const colonnaId = () => uuid('id').primaryKey().$defaultFn(uuidv7);

// Data di creazione: impostata dal database al momento dell'inserimento
export const colonnaCreatedAt = () => timestamp('created_at', { withTimezone: true, mode: 'date' }).notNull().defaultNow();

// Data di ultima modifica: impostata all'inserimento e aggiornata da Drizzle a ogni update
export const colonnaUpdatedAt = () =>
  timestamp('updated_at', { withTimezone: true, mode: 'date' })
    // Non può essere vuota
    .notNull()
    // Valore iniziale
    .defaultNow()
    // Nuovo valore a ogni aggiornamento eseguito tramite Drizzle
    .$onUpdate(() => new Date());

// Data di eliminazione logica (soft delete): null = record attivo
export const colonnaDeletedAt = () => timestamp('deleted_at', { withTimezone: true, mode: 'date' });
