// =====================================================================================
// Tabelle dei progetti: template, progetti, colonne della bacheca, task, to-do e ore
// =====================================================================================

// Importa i costruttori di tabelle, colonne, indici e vincoli
import { boolean, check, date, index, integer, numeric, pgTable, text, timestamp, uniqueIndex, uuid, varchar } from 'drizzle-orm/pg-core';
// Importa l'helper SQL
import { sql } from 'drizzle-orm';
// Importa colonne ed enum comuni
import { colonnaCreatedAt, colonnaDeletedAt, colonnaId, colonnaUpdatedAt, prioritaTaskEnum, statoProgettoEnum } from './comune';
// Importa le tabelle collegate
import { clienti, commesse } from './anagrafiche';
import { utenti } from './sicurezza';

// ------------------------------ Template di progetto ----------------------------------
// Un template descrive come nasce un progetto tipico (es. "Configurazione nuovo server"):
// colonne della bacheca, task predefiniti e relative to-do.
export const progettoTemplate = pgTable('progetto_template', {
  // Chiave primaria
  id: colonnaId(),
  // Nome del template, univoco
  nome: varchar('nome', { length: 120 }).notNull().unique(),
  // Categoria per raggruppare i template nell'elenco
  categoria: varchar('categoria', { length: 60 }),
  // Descrizione
  descrizione: text('descrizione'),
  // Durata indicativa in giorni
  durataStimataGg: integer('durata_stimata_gg'),
  // Un template disattivato resta nello storico ma non si può più usare per nuovi progetti
  attivo: boolean('attivo').notNull().default(true),
  // Tracciamento
  createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
  updatedById: uuid('updated_by_id').references(() => utenti.id, { onDelete: 'set null' }),
  createdAt: colonnaCreatedAt(),
  updatedAt: colonnaUpdatedAt(),
});

// Colonne della bacheca previste dal template
export const templateColonne = pgTable(
  'template_colonne',
  {
    // Chiave primaria
    id: colonnaId(),
    // Template di appartenenza
    templateId: uuid('template_id')
      .notNull()
      .references(() => progettoTemplate.id, { onDelete: 'cascade' }),
    // Nome della colonna (es. "In lavorazione")
    nome: varchar('nome', { length: 40 }).notNull(),
    // Posizione da sinistra a destra
    ordine: integer('ordine').notNull(),
    // I task in questa colonna contano come completati nel calcolo dell'avanzamento
    consideraCompletato: boolean('considera_completato').notNull().default(false),
  },
  // Una sola colonna per posizione all'interno del template
  (t) => [uniqueIndex('template_colonne_ordine_unique').on(t.templateId, t.ordine)],
);

// Task predefiniti del template
export const templateTask = pgTable(
  'template_task',
  {
    // Chiave primaria
    id: colonnaId(),
    // Template di appartenenza
    templateId: uuid('template_id')
      .notNull()
      .references(() => progettoTemplate.id, { onDelete: 'cascade' }),
    // Colonna iniziale, indicata per posizione (resta valida anche se la colonna viene rinominata)
    colonnaIndice: integer('colonna_indice').notNull().default(0),
    // Titolo
    titolo: varchar('titolo', { length: 200 }).notNull(),
    // Descrizione
    descrizione: text('descrizione'),
    // Ore preventivate
    oreStimate: numeric('ore_stimate', { precision: 6, scale: 2 }),
    // Posizione nell'elenco
    ordine: integer('ordine').notNull(),
  },
  // Task di un template
  (t) => [index('template_task_template_idx').on(t.templateId)],
);

// Voci della to-do previste per un task del template
export const templateTodo = pgTable(
  'template_todo',
  {
    // Chiave primaria
    id: colonnaId(),
    // Task del template
    templateTaskId: uuid('template_task_id')
      .notNull()
      .references(() => templateTask.id, { onDelete: 'cascade' }),
    // Testo della voce
    titolo: varchar('titolo', { length: 200 }).notNull(),
    // Posizione nell'elenco
    ordine: integer('ordine').notNull(),
  },
  // Voci di un task
  (t) => [index('template_todo_task_idx').on(t.templateTaskId)],
);

// ------------------------------------ Progetti ----------------------------------------
export const progetti = pgTable(
  'progetti',
  {
    // Chiave primaria
    id: colonnaId(),
    // Codice leggibile (es. "PR-2026-0001")
    codice: varchar('codice', { length: 20 }).notNull().unique(),
    // Cliente: non si elimina un cliente con progetti
    clienteId: uuid('cliente_id')
      .notNull()
      .references(() => clienti.id, { onDelete: 'restrict' }),
    // Commessa collegata (facoltativa)
    commessaId: uuid('commessa_id').references(() => commesse.id, { onDelete: 'set null' }),
    // Template di origine, solo come riferimento storico
    templateId: uuid('template_id').references(() => progettoTemplate.id, { onDelete: 'set null' }),
    // Nome del progetto
    nome: varchar('nome', { length: 200 }).notNull(),
    // Descrizione
    descrizione: text('descrizione'),
    // Stato del progetto
    stato: statoProgettoEnum('stato').notNull().default('pianificato'),
    // Tecnico responsabile
    responsabileId: uuid('responsabile_id').references(() => utenti.id, { onDelete: 'set null' }),
    // Date
    dataInizio: date('data_inizio', { mode: 'string' }),
    dataFinePrevista: date('data_fine_prevista', { mode: 'string' }),
    dataFineEffettiva: date('data_fine_effettiva', { mode: 'string' }),
    // Note interne
    note: text('note'),
    // Tracciamento
    createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    updatedById: uuid('updated_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
    deletedAt: colonnaDeletedAt(),
  },
  (t) => [
    // Progetti di un cliente
    index('progetti_cliente_idx').on(t.clienteId),
    // Filtro per stato
    index('progetti_stato_idx').on(t.stato),
    // Filtro per responsabile
    index('progetti_responsabile_idx').on(t.responsabileId),
    // Le date devono essere coerenti
    check('progetti_date_check', sql`${t.dataFinePrevista} IS NULL OR ${t.dataInizio} IS NULL OR ${t.dataFinePrevista} >= ${t.dataInizio}`),
  ],
);

// ------------------------- Colonne della bacheca di un progetto ------------------------
// Copiate dal template alla creazione: modificare il template non tocca i progetti in corso
export const progettoColonne = pgTable(
  'progetto_colonne',
  {
    // Chiave primaria
    id: colonnaId(),
    // Progetto di appartenenza
    progettoId: uuid('progetto_id')
      .notNull()
      .references(() => progetti.id, { onDelete: 'cascade' }),
    // Nome della colonna
    nome: varchar('nome', { length: 40 }).notNull(),
    // Posizione da sinistra a destra
    ordine: integer('ordine').notNull(),
    // I task in questa colonna contano come completati
    consideraCompletato: boolean('considera_completato').notNull().default(false),
  },
  // Una sola colonna per posizione all'interno del progetto
  (t) => [uniqueIndex('progetto_colonne_ordine_unique').on(t.progettoId, t.ordine)],
);

// -------------------------------------- Task ------------------------------------------
export const task = pgTable(
  'task',
  {
    // Chiave primaria
    id: colonnaId(),
    // Progetto di appartenenza
    progettoId: uuid('progetto_id')
      .notNull()
      .references(() => progetti.id, { onDelete: 'cascade' }),
    // Colonna della bacheca in cui si trova
    colonnaId: uuid('colonna_id')
      .notNull()
      .references(() => progettoColonne.id, { onDelete: 'cascade' }),
    // Titolo
    titolo: varchar('titolo', { length: 200 }).notNull(),
    // Descrizione
    descrizione: text('descrizione'),
    // Priorità
    priorita: prioritaTaskEnum('priorita').notNull().default('media'),
    // Tecnico responsabile del task
    responsabileId: uuid('responsabile_id').references(() => utenti.id, { onDelete: 'set null' }),
    // Scadenza
    dataScadenza: date('data_scadenza', { mode: 'string' }),
    // Ore preventivate
    oreStimate: numeric('ore_stimate', { precision: 6, scale: 2 }),
    // Posizione nella colonna (0 = in cima)
    ordine: integer('ordine').notNull().default(0),
    // Momento in cui il task è arrivato in una colonna di completamento
    completatoIl: timestamp('completato_il', { withTimezone: true, mode: 'date' }),
    // Tracciamento
    createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    updatedById: uuid('updated_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
  },
  (t) => [
    // Lettura della bacheca: task di un progetto ordinati per colonna e posizione
    index('task_progetto_idx').on(t.progettoId, t.colonnaId, t.ordine),
    // Task assegnati a un tecnico (ambito "propri" e riepiloghi)
    index('task_responsabile_idx').on(t.responsabileId),
  ],
);

// ------------------------------------- To-do ------------------------------------------
export const taskTodo = pgTable(
  'task_todo',
  {
    // Chiave primaria
    id: colonnaId(),
    // Task di appartenenza
    taskId: uuid('task_id')
      .notNull()
      .references(() => task.id, { onDelete: 'cascade' }),
    // Testo della voce
    titolo: varchar('titolo', { length: 200 }).notNull(),
    // Voce completata
    completata: boolean('completata').notNull().default(false),
    // Momento del completamento
    completataIl: timestamp('completata_il', { withTimezone: true, mode: 'date' }),
    // Tecnico incaricato della singola voce (può essere diverso dal responsabile del task)
    assegnatarioId: uuid('assegnatario_id').references(() => utenti.id, { onDelete: 'set null' }),
    // Posizione nell'elenco
    ordine: integer('ordine').notNull().default(0),
    // Tracciamento
    createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    updatedById: uuid('updated_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
  },
  (t) => [
    // Voci di un task
    index('task_todo_task_idx').on(t.taskId, t.ordine),
    // Voci assegnate a un tecnico
    index('task_todo_assegnatario_idx').on(t.assegnatarioId),
  ],
);

// -------------------------------- Registrazioni ore -----------------------------------
// Ore lavorate su un task. Nella Fase 2 la stessa tabella accoglierà anche le ore degli
// interventi di assistenza (che invece scalano dai pacchetti ore dei contratti).
export const registrazioniOre = pgTable(
  'registrazioni_ore',
  {
    // Chiave primaria
    id: colonnaId(),
    // Task a cui si riferiscono le ore
    taskId: uuid('task_id')
      .notNull()
      .references(() => task.id, { onDelete: 'cascade' }),
    // Tecnico che ha lavorato (non eliminabile finché ha ore registrate)
    utenteId: uuid('utente_id')
      .notNull()
      .references(() => utenti.id, { onDelete: 'restrict' }),
    // Giorno di lavoro
    data: date('data', { mode: 'string' }).notNull(),
    // Durata in minuti (numeri interi: nessun errore di arrotondamento)
    minuti: integer('minuti').notNull(),
    // Descrizione dell'attività svolta
    descrizione: varchar('descrizione', { length: 500 }),
    // Tracciamento
    createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
  },
  (t) => [
    // Ore di un task
    index('registrazioni_ore_task_idx').on(t.taskId),
    // Ore di un tecnico in un periodo (riepiloghi e futuri report)
    index('registrazioni_ore_utente_idx').on(t.utenteId, t.data),
    // Durata sensata: da 1 minuto a 24 ore
    check('registrazioni_ore_minuti_check', sql`${t.minuti} > 0 AND ${t.minuti} <= 1440`),
  ],
);
