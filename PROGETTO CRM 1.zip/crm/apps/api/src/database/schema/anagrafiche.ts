// =====================================================================================
// Tabelle anagrafiche: clienti, sedi, contatti, commesse, allegati
// =====================================================================================

// Importa i costruttori di tabelle, colonne, indici e vincoli
import { boolean, check, date, index, integer, numeric, pgTable, text, uniqueIndex, uuid, varchar, char } from 'drizzle-orm/pg-core';
// Importa l'helper SQL
import { sql } from 'drizzle-orm';
// Importa colonne ed enum comuni
import {
  colonnaCreatedAt,
  colonnaDeletedAt,
  colonnaId,
  colonnaUpdatedAt,
  entitaAllegatoEnum,
  statoCommessaEnum,
  tipoCommessaEnum,
  tipoSedeEnum,
} from './comune';
// Importa la tabella utenti per le chiavi esterne
import { utenti } from './sicurezza';

// ----------------------------------- Clienti ------------------------------------------
export const clienti = pgTable(
  'clienti',
  {
    // Chiave primaria
    id: colonnaId(),
    // Codice leggibile progressivo (es. "CL-00001")
    codice: varchar('codice', { length: 20 }).notNull().unique(),
    // Ragione sociale
    ragioneSociale: varchar('ragione_sociale', { length: 200 }).notNull(),
    // Partita IVA
    partitaIva: varchar('partita_iva', { length: 20 }),
    // Codice fiscale
    codiceFiscale: varchar('codice_fiscale', { length: 16 }),
    // Codice destinatario SDI
    codiceSdi: char('codice_sdi', { length: 7 }),
    // PEC
    pec: varchar('pec', { length: 254 }),
    // Email
    email: varchar('email', { length: 254 }),
    // Telefono
    telefono: varchar('telefono', { length: 30 }),
    // Sito web
    sitoWeb: varchar('sito_web', { length: 200 }),
    // Note commerciali
    note: text('note'),
    // Commerciale di riferimento (se l'utente viene rimosso il campo si svuota)
    commercialeId: uuid('commerciale_id').references(() => utenti.id, { onDelete: 'set null' }),
    // Utente che ha creato il record
    createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    // Utente che ha modificato il record per ultimo
    updatedById: uuid('updated_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    // Date di creazione, modifica ed eliminazione logica
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
    deletedAt: colonnaDeletedAt(),
  },
  (t) => [
    // Partita IVA univoca solo tra i clienti non eliminati (indice parziale)
    uniqueIndex('clienti_piva_unique').on(t.partitaIva).where(sql`${t.deletedAt} IS NULL AND ${t.partitaIva} IS NOT NULL`),
    // Ricerca veloce "contiene" sulla ragione sociale (indice trigrammi, estensione pg_trgm)
    index('clienti_ragione_sociale_trgm_idx').using('gin', t.ragioneSociale.op('gin_trgm_ops')),
    // Filtro per commerciale
    index('clienti_commerciale_idx').on(t.commercialeId),
  ],
);

// ------------------------------------ Sedi --------------------------------------------
export const sedi = pgTable(
  'sedi',
  {
    // Chiave primaria
    id: colonnaId(),
    // Cliente di appartenenza
    clienteId: uuid('cliente_id')
      .notNull()
      .references(() => clienti.id, { onDelete: 'cascade' }),
    // Tipo di sede
    tipo: tipoSedeEnum('tipo').notNull(),
    // Nome descrittivo
    nome: varchar('nome', { length: 100 }),
    // Indirizzo
    indirizzo: varchar('indirizzo', { length: 200 }).notNull(),
    // CAP
    cap: varchar('cap', { length: 10 }),
    // Città
    citta: varchar('citta', { length: 100 }).notNull(),
    // Provincia
    provincia: char('provincia', { length: 2 }),
    // Nazione ISO 3166-1 alpha-2
    nazione: char('nazione', { length: 2 }).notNull().default('IT'),
    // Tracciamento
    createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    updatedById: uuid('updated_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
  },
  (t) => [
    // Sedi di un cliente
    index('sedi_cliente_idx').on(t.clienteId),
    // Al massimo una sede legale per cliente
    uniqueIndex('sedi_legale_unique').on(t.clienteId).where(sql`${t.tipo} = 'legale'`),
  ],
);

// ----------------------------------- Contatti -----------------------------------------
export const contatti = pgTable(
  'contatti',
  {
    // Chiave primaria
    id: colonnaId(),
    // Cliente di appartenenza
    clienteId: uuid('cliente_id')
      .notNull()
      .references(() => clienti.id, { onDelete: 'cascade' }),
    // Sede di riferimento (se la sede viene eliminata il contatto resta)
    sedeId: uuid('sede_id').references(() => sedi.id, { onDelete: 'set null' }),
    // Nome
    nome: varchar('nome', { length: 80 }).notNull(),
    // Cognome
    cognome: varchar('cognome', { length: 80 }),
    // Ruolo in azienda
    ruoloAziendale: varchar('ruolo_aziendale', { length: 100 }),
    // Email
    email: varchar('email', { length: 254 }),
    // Telefono
    telefono: varchar('telefono', { length: 30 }),
    // Cellulare
    cellulare: varchar('cellulare', { length: 30 }),
    // Contatto principale
    principale: boolean('principale').notNull().default(false),
    // Note
    note: text('note'),
    // Tracciamento
    createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    updatedById: uuid('updated_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
  },
  (t) => [
    // Contatti di un cliente
    index('contatti_cliente_idx').on(t.clienteId),
    // Al massimo un contatto principale per cliente
    uniqueIndex('contatti_principale_unique').on(t.clienteId).where(sql`${t.principale} = true`),
  ],
);

// ----------------------------------- Commesse -----------------------------------------
export const commesse = pgTable(
  'commesse',
  {
    // Chiave primaria
    id: colonnaId(),
    // Codice leggibile (es. "CM-2026-0001")
    codice: varchar('codice', { length: 20 }).notNull().unique(),
    // Cliente: non si può eliminare fisicamente un cliente con commesse
    clienteId: uuid('cliente_id')
      .notNull()
      .references(() => clienti.id, { onDelete: 'restrict' }),
    // Titolo
    titolo: varchar('titolo', { length: 200 }).notNull(),
    // Descrizione
    descrizione: text('descrizione'),
    // Tipo
    tipo: tipoCommessaEnum('tipo').notNull(),
    // Stato
    stato: statoCommessaEnum('stato').notNull().default('aperta'),
    // Valore economico in euro (restituito da Drizzle come stringa per non perdere precisione)
    valore: numeric('valore', { precision: 12, scale: 2 }),
    // Data di apertura (solo data, senza orario)
    dataApertura: date('data_apertura', { mode: 'string' }).notNull(),
    // Data di chiusura
    dataChiusura: date('data_chiusura', { mode: 'string' }),
    // Responsabile interno
    responsabileId: uuid('responsabile_id').references(() => utenti.id, { onDelete: 'set null' }),
    // Tracciamento
    createdById: uuid('created_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    updatedById: uuid('updated_by_id').references(() => utenti.id, { onDelete: 'set null' }),
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
    deletedAt: colonnaDeletedAt(),
  },
  (t) => [
    // Commesse di un cliente
    index('commesse_cliente_idx').on(t.clienteId),
    // Filtro per stato
    index('commesse_stato_idx').on(t.stato),
    // Filtro per responsabile
    index('commesse_responsabile_idx').on(t.responsabileId),
    // Vincolo: la chiusura non può precedere l'apertura (difesa anche contro bug applicativi)
    check('commesse_date_check', sql`${t.dataChiusura} IS NULL OR ${t.dataChiusura} >= ${t.dataApertura}`),
    // Vincolo: valore non negativo
    check('commesse_valore_check', sql`${t.valore} IS NULL OR ${t.valore} >= 0`),
  ],
);

// ----------------------------------- Allegati -----------------------------------------
export const allegati = pgTable(
  'allegati',
  {
    // Chiave primaria
    id: colonnaId(),
    // Tipo di entità a cui è collegato
    entita: entitaAllegatoEnum('entita').notNull(),
    // Identificativo dell'entità (collegamento generico: il controllo esistenza è applicativo)
    entitaId: uuid('entita_id').notNull(),
    // Nome del file come caricato dall'utente (mostrato solo come testo)
    nomeOriginale: varchar('nome_originale', { length: 255 }).notNull(),
    // Percorso relativo nello storage (nome casuale, mai derivato dal nome originale)
    percorso: varchar('percorso', { length: 200 }).notNull().unique(),
    // Tipo MIME rilevato dal contenuto del file
    mimeType: varchar('mime_type', { length: 100 }).notNull(),
    // Dimensione in byte
    dimensione: integer('dimensione').notNull(),
    // Impronta SHA-256 del contenuto (integrità e individuazione duplicati)
    sha256: char('sha256', { length: 64 }).notNull(),
    // Utente che ha caricato il file
    caricatoDaId: uuid('caricato_da_id')
      .notNull()
      .references(() => utenti.id, { onDelete: 'restrict' }),
    // Data di caricamento
    createdAt: colonnaCreatedAt(),
  },
  // Allegati di una specifica entità
  (t) => [index('allegati_entita_idx').on(t.entita, t.entitaId)],
);
