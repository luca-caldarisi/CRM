// =====================================================================================
// Tabelle di sicurezza: utenti, ruoli, permessi, sessioni, audit log, contatori
// =====================================================================================

// Importa i costruttori di tabelle, colonne, indici e vincoli
import {
  boolean,
  char,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  timestamp,
  uniqueIndex,
  uuid,
  varchar,
} from 'drizzle-orm/pg-core';
// Importa l'helper per scrivere frammenti SQL
import { sql } from 'drizzle-orm';
// Importa colonne ed enum comuni
import { ambitoEnum, azioneAuditEnum, colonnaCreatedAt, colonnaId, colonnaUpdatedAt } from './comune';

// ------------------------------------ Ruoli -------------------------------------------
export const ruoli = pgTable('ruoli', {
  // Chiave primaria
  id: colonnaId(),
  // Nome del ruolo, univoco (es. "Tecnico")
  nome: varchar('nome', { length: 50 }).notNull().unique(),
  // Descrizione facoltativa
  descrizione: varchar('descrizione', { length: 200 }),
  // true solo per il ruolo Admin: non modificabile e non eliminabile
  diSistema: boolean('di_sistema').notNull().default(false),
  // Date di creazione e modifica
  createdAt: colonnaCreatedAt(),
  updatedAt: colonnaUpdatedAt(),
});

// ----------------------------------- Permessi -----------------------------------------
// Copia del catalogo definito in @crm/shared, sincronizzata dal seed
export const permessi = pgTable('permessi', {
  // Codice del permesso come chiave primaria (es. "clienti.read")
  codice: varchar('codice', { length: 64 }).primaryKey(),
  // Modulo di appartenenza
  modulo: varchar('modulo', { length: 50 }).notNull(),
  // Descrizione leggibile
  descrizione: varchar('descrizione', { length: 200 }).notNull(),
});

// -------------------------------- Ruoli-Permessi --------------------------------------
// Tabella ponte: quali permessi, e con quale ambito, ha ogni ruolo
export const ruoliPermessi = pgTable(
  'ruoli_permessi',
  {
    // Ruolo (se il ruolo viene eliminato, spariscono anche i suoi permessi)
    ruoloId: uuid('ruolo_id')
      .notNull()
      .references(() => ruoli.id, { onDelete: 'cascade' }),
    // Permesso (se un codice viene rimosso dal catalogo, sparisce dai ruoli)
    permessoCodice: varchar('permesso_codice', { length: 64 })
      .notNull()
      .references(() => permessi.codice, { onDelete: 'cascade', onUpdate: 'cascade' }),
    // Ambito concesso
    ambito: ambitoEnum('ambito').notNull(),
  },
  // La coppia ruolo+permesso è la chiave primaria: niente duplicati
  (t) => [primaryKey({ columns: [t.ruoloId, t.permessoCodice] })],
);

// ------------------------------------ Utenti ------------------------------------------
export const utenti = pgTable(
  'utenti',
  {
    // Chiave primaria
    id: colonnaId(),
    // Email di accesso (salvata sempre in minuscolo)
    email: varchar('email', { length: 254 }).notNull(),
    // Nome
    nome: varchar('nome', { length: 80 }).notNull(),
    // Cognome
    cognome: varchar('cognome', { length: 80 }).notNull(),
    // Hash argon2id della password (mai la password in chiaro)
    passwordHash: varchar('password_hash', { length: 255 }).notNull(),
    // Ruolo assegnato: non si può eliminare un ruolo ancora in uso
    ruoloId: uuid('ruolo_id')
      .notNull()
      .references(() => ruoli.id, { onDelete: 'restrict' }),
    // Account attivo (gli utenti non si eliminano: si disattivano)
    attivo: boolean('attivo').notNull().default(true),
    // Obbliga al cambio password al prossimo accesso
    deveCambiarePassword: boolean('deve_cambiare_password').notNull().default(true),
    // Versione dei permessi: incrementata quando cambiano ruolo/permessi, invalida i token emessi prima
    permVersion: integer('perm_version').notNull().default(1),
    // Tentativi di login falliti consecutivi
    tentativiFalliti: integer('tentativi_falliti').notNull().default(0),
    // Blocco temporaneo dopo troppi tentativi falliti
    bloccatoFinoA: timestamp('bloccato_fino_a', { withTimezone: true, mode: 'date' }),
    // Data dell'ultimo accesso riuscito
    ultimoAccesso: timestamp('ultimo_accesso', { withTimezone: true, mode: 'date' }),
    // Date di creazione e modifica
    createdAt: colonnaCreatedAt(),
    updatedAt: colonnaUpdatedAt(),
  },
  (t) => [
    // Email univoca (confronto su minuscolo per sicurezza anche contro inserimenti manuali)
    uniqueIndex('utenti_email_unique').on(sql`lower(${t.email})`),
    // Indice per filtrare gli utenti di un ruolo
    index('utenti_ruolo_idx').on(t.ruoloId),
  ],
);

// ----------------------------------- Sessioni -----------------------------------------
// Ogni riga è un refresh token emesso; la "famiglia" raggruppa i token nati dallo stesso login
export const sessioni = pgTable(
  'sessioni',
  {
    // Chiave primaria
    id: colonnaId(),
    // Utente proprietario (eliminando l'utente spariscono le sessioni)
    utenteId: uuid('utente_id')
      .notNull()
      .references(() => utenti.id, { onDelete: 'cascade' }),
    // Identificativo della catena di rotazione nata da un login
    famigliaId: uuid('famiglia_id').notNull(),
    // Hash SHA-256 del refresh token (il token in chiaro esiste solo nel cookie del browser)
    tokenHash: char('token_hash', { length: 64 }).notNull().unique(),
    // Scadenza del token
    scadeIl: timestamp('scade_il', { withTimezone: true, mode: 'date' }).notNull(),
    // Data di revoca (logout, cambio password, furto rilevato)
    revocataIl: timestamp('revocata_il', { withTimezone: true, mode: 'date' }),
    // Data in cui il token è stato sostituito da uno nuovo (rotazione)
    sostituitaIl: timestamp('sostituita_il', { withTimezone: true, mode: 'date' }),
    // Indirizzo IP del client al momento dell'emissione
    ip: varchar('ip', { length: 45 }),
    // Browser/dispositivo
    userAgent: varchar('user_agent', { length: 300 }),
    // Data di creazione
    createdAt: colonnaCreatedAt(),
  },
  (t) => [
    // Ricerca delle sessioni di un utente (es. revoca di tutte le sessioni)
    index('sessioni_utente_idx').on(t.utenteId),
    // Ricerca per famiglia (revoca in caso di riutilizzo di un token)
    index('sessioni_famiglia_idx').on(t.famigliaId),
  ],
);

// ---------------------------------- Audit log -----------------------------------------
// Registro in sola aggiunta: un trigger nel database impedisce UPDATE e DELETE
export const auditLog = pgTable(
  'audit_log',
  {
    // Chiave primaria
    id: colonnaId(),
    // Utente che ha eseguito l'azione (null per eventi anonimi, es. login fallito con email inesistente)
    utenteId: uuid('utente_id').references(() => utenti.id, { onDelete: 'set null' }),
    // Tipo di azione
    azione: azioneAuditEnum('azione').notNull(),
    // Tipo di entità coinvolta (es. "cliente", "utente", "sessione")
    entita: varchar('entita', { length: 50 }).notNull(),
    // Identificativo dell'entità coinvolta
    entitaId: uuid('entita_id'),
    // Descrizione sintetica leggibile (es. ragione sociale o codice)
    descrizione: varchar('descrizione', { length: 300 }),
    // Campi modificati con valore precedente e successivo
    modifiche: jsonb('modifiche').$type<Record<string, { prima: unknown; dopo: unknown }>>(),
    // Indirizzo IP del client
    ip: varchar('ip', { length: 45 }),
    // Data dell'evento
    createdAt: colonnaCreatedAt(),
  },
  (t) => [
    // Storico di una specifica entità (es. scheda cliente > attività)
    index('audit_entita_idx').on(t.entita, t.entitaId),
    // Attività di un utente
    index('audit_utente_idx').on(t.utenteId),
    // Ordinamento cronologico
    index('audit_data_idx').on(t.createdAt),
  ],
);

// ---------------------------------- Contatori -----------------------------------------
// Numeratori progressivi per i codici leggibili (es. chiave "CM-2026" -> ultimo numero usato)
export const contatori = pgTable('contatori', {
  // Chiave del contatore
  chiave: varchar('chiave', { length: 40 }).primaryKey(),
  // Ultimo valore assegnato
  valore: integer('valore').notNull(),
});
