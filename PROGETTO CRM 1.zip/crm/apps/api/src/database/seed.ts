// =====================================================================================
// Seed: dati iniziali indispensabili, eseguibile più volte senza effetti collaterali
// -------------------------------------------------------------------------------------
// 1. sincronizza il catalogo permessi del codice con la tabella "permessi"
// 2. crea/aggiorna il ruolo Admin con tutti i permessi
// 3. crea i ruoli predefiniti SOLO se non esistono (non sovrascrive le modifiche dell'Admin)
// 4. crea il primo utente Admin SOLO se non esiste nessun amministratore
// Uso: "pnpm db:seed" (sviluppo) oppure "pnpm db:seed:prod" (container)
// =====================================================================================

// Importa i percorsi
import { resolve } from 'node:path';
// Importa dotenv
import { config } from 'dotenv';
// Importa gli operatori di query
import { eq, notInArray, sql } from 'drizzle-orm';
// Importa catalogo e ruoli predefiniti
import { CATALOGO_PERMESSI, NOME_RUOLO_ADMIN, passwordSchema, RUOLI_PREDEFINITI } from '@crm/shared';
// Importa connessione e tabelle
import { creaDatabase, type Database } from './client';
import { permessi, progettoTemplate, ruoli, ruoliPermessi, templateColonne, templateTask, templateTodo, utenti } from './schema';
// Importa l'hashing delle password
import { hashPassword } from '../modules/auth/password';

// Dati del primo amministratore
export interface OpzioniSeed {
  adminEmail?: string;
  adminPassword?: string;
  adminNome?: string;
  adminCognome?: string;
}

// Esegue il seed sul database indicato (esportata per poterla usare nei test)
export async function eseguiSeed(db: Database, opzioni: OpzioniSeed, log: (m: string) => void = console.log): Promise<void> {
  // Tutto in una transazione: il database non resta mai in uno stato intermedio
  await db.transaction(async (tx) => {
    // --- 1. Catalogo permessi ---
    // Codici presenti nel codice sorgente
    const codici = CATALOGO_PERMESSI.map((p) => p.codice);
    // Codici già presenti nel database prima di questo seed
    const codiciEsistenti = new Set((await tx.select({ codice: permessi.codice }).from(permessi)).map((p) => p.codice));
    // Permessi introdotti da una nuova versione del CRM (servono al passaggio 3 bis)
    const codiciNuovi = codici.filter((c) => !codiciEsistenti.has(c));
    // Inserisce i permessi nuovi e aggiorna modulo/descrizione di quelli esistenti
    await tx
      .insert(permessi)
      .values(CATALOGO_PERMESSI.map((p) => ({ codice: p.codice, modulo: p.modulo, descrizione: p.descrizione })))
      .onConflictDoUpdate({ target: permessi.codice, set: { modulo: sql`excluded.modulo`, descrizione: sql`excluded.descrizione` } });
    // Rimuove i permessi non più presenti nel catalogo (le associazioni ai ruoli spariscono in cascata)
    await tx.delete(permessi).where(notInArray(permessi.codice, codici));
    // Messaggio
    log(`Permessi sincronizzati: ${codici.length}`);

    // --- 2. Ruolo Admin ---
    // Cerca il ruolo di sistema
    let admin = (await tx.select().from(ruoli).where(eq(ruoli.diSistema, true)).limit(1))[0];
    // Se non esiste lo crea
    if (!admin) {
      // Inserisce il ruolo di sistema e ne legge i dati
      admin = (await tx.insert(ruoli).values({ nome: NOME_RUOLO_ADMIN, descrizione: 'Amministratore con accesso completo', diSistema: true }).returning())[0];
      // Messaggio
      log('Ruolo Admin creato');
    }
    // Assegna tutti i permessi con ambito "tutti" (anche quelli aggiunti di recente al catalogo)
    await tx
      .insert(ruoliPermessi)
      .values(codici.map((codice) => ({ ruoloId: admin!.id, permessoCodice: codice, ambito: 'tutti' as const })))
      .onConflictDoUpdate({ target: [ruoliPermessi.ruoloId, ruoliPermessi.permessoCodice], set: { ambito: 'tutti' } });

    // --- 3. Ruoli predefiniti ---
    for (const predefinito of RUOLI_PREDEFINITI) {
      // Verifica se esiste già un ruolo con lo stesso nome
      const [esistente] = await tx.select({ id: ruoli.id }).from(ruoli).where(eq(ruoli.nome, predefinito.nome)).limit(1);
      // Se esiste non lo tocca: potrebbe essere stato personalizzato dall'Admin
      if (esistente) continue;
      // Crea il ruolo
      const [nuovo] = await tx.insert(ruoli).values({ nome: predefinito.nome, descrizione: predefinito.descrizione }).returning({ id: ruoli.id });
      // Associa i permessi previsti
      const voci = Object.entries(predefinito.permessi).map(([codice, ambito]) => ({ ruoloId: nuovo!.id, permessoCodice: codice, ambito: ambito! }));
      // Inserisce solo se ci sono permessi
      if (voci.length) await tx.insert(ruoliPermessi).values(voci);
      // Messaggio
      log(`Ruolo creato: ${predefinito.nome}`);
    }

    // --- 3 bis. Permessi nuovi sui ruoli predefiniti già esistenti ---
    // Quando una nuova versione introduce un permesso (es. i progetti), i ruoli predefiniti
    // già creati lo ricevono con l'ambito previsto. Gli altri permessi, eventualmente
    // personalizzati dall'Admin, non vengono toccati.
    if (codiciNuovi.length > 0) {
      for (const predefinito of RUOLI_PREDEFINITI) {
        // Permessi nuovi previsti per questo ruolo
        const daAggiungere = codiciNuovi.filter((c) => predefinito.permessi[c as keyof typeof predefinito.permessi]);
        // Nessuna novità per questo ruolo
        if (daAggiungere.length === 0) continue;
        // Ruolo corrispondente nel database
        const [ruolo] = await tx.select({ id: ruoli.id }).from(ruoli).where(eq(ruoli.nome, predefinito.nome)).limit(1);
        // Ruolo eliminato dall'Admin: niente da fare
        if (!ruolo) continue;
        // Inserisce i permessi mancanti senza sovrascrivere quelli già presenti
        await tx
          .insert(ruoliPermessi)
          .values(daAggiungere.map((codice) => ({ ruoloId: ruolo.id, permessoCodice: codice, ambito: predefinito.permessi[codice as keyof typeof predefinito.permessi]! })))
          .onConflictDoNothing();
        // I token degli utenti del ruolo vanno rinnovati per ricevere i nuovi permessi
        await tx.update(utenti).set({ permVersion: sql`${utenti.permVersion} + 1` }).where(eq(utenti.ruoloId, ruolo.id));
        // Messaggio
        log(`Ruolo ${predefinito.nome}: aggiunti ${daAggiungere.length} permessi nuovi`);
      }
    }

    // --- 4. Template di progetto iniziali ---
    // Vengono creati una sola volta, al primo avvio: l'Admin può poi modificarli o eliminarli.
    // Servono a far trovare il modulo Progetti già utilizzabile invece di una pagina vuota.
    await creaTemplateIniziali(tx, log);

    // --- 5. Primo utente Admin ---
    // Cerca almeno un utente con ruolo Admin (attivo o no)
    const adminEsistenti = await tx
      .select({ id: utenti.id })
      .from(utenti)
      .where(eq(utenti.ruoloId, admin!.id))
      .limit(1);
    // Se c'è già un amministratore non fa nulla
    if (adminEsistenti.length > 0) {
      log('Amministratore già presente: nessun utente creato');
      return;
    }
    // Senza email e password non si può creare l'amministratore
    if (!opzioni.adminEmail || !opzioni.adminPassword) {
      throw new Error('Nessun amministratore presente: impostare ADMIN_EMAIL e ADMIN_PASSWORD_INIZIALE');
    }
    // La password iniziale deve rispettare le stesse regole delle altre
    const verifica = passwordSchema.safeParse(opzioni.adminPassword);
    // Password non conforme
    if (!verifica.success) throw new Error(`ADMIN_PASSWORD_INIZIALE non valida: ${verifica.error.issues[0]?.message}`);
    // Crea l'amministratore con obbligo di cambio password al primo accesso
    await tx.insert(utenti).values({
      email: opzioni.adminEmail.trim().toLowerCase(),
      nome: opzioni.adminNome ?? 'Amministratore',
      cognome: opzioni.adminCognome ?? 'Sistema',
      passwordHash: await hashPassword(opzioni.adminPassword),
      ruoloId: admin!.id,
      deveCambiarePassword: true,
    });
    // Messaggio
    log(`Amministratore creato: ${opzioni.adminEmail} (cambio password obbligatorio al primo accesso)`);
  });
}

// -------------------------------------------------------------------------------------
// Template di progetto creati al primo avvio
// -------------------------------------------------------------------------------------

// Struttura di un template iniziale: dati generali, fasi della bacheca e task predefiniti
interface TemplateIniziale {
  nome: string;
  categoria: string;
  descrizione: string;
  durataStimataGg: number;
  // Fasi della bacheca: l'ultima (o quelle marcate) conta come completamento
  colonne: Array<{ nome: string; consideraCompletato: boolean }>;
  // Task predefiniti con la fase iniziale, le ore preventivate e le voci della to-do
  task: Array<{ titolo: string; colonnaIndice: number; oreStimate: number; todo: string[] }>;
}

// Due template realistici per un'azienda di servizi informatici
const TEMPLATE_INIZIALI: TemplateIniziale[] = [
  {
    nome: 'Installazione nuovo server',
    categoria: 'Sistemistica',
    descrizione: 'Fornitura, configurazione e messa in produzione di un server presso il cliente.',
    durataStimataGg: 15,
    colonne: [
      { nome: 'Da fare', consideraCompletato: false },
      { nome: 'In corso', consideraCompletato: false },
      { nome: 'In verifica', consideraCompletato: false },
      { nome: 'Completato', consideraCompletato: true },
    ],
    task: [
      { titolo: 'Sopralluogo e raccolta requisiti', colonnaIndice: 0, oreStimate: 3, todo: ['Verificare spazio nel rack', 'Controllare alimentazione e UPS', 'Rilevare configurazione di rete'] },
      { titolo: 'Ordine hardware e licenze', colonnaIndice: 0, oreStimate: 2, todo: ['Richiedere preventivo al fornitore', 'Inviare conferma al cliente', 'Verificare tempi di consegna'] },
      { titolo: 'Preparazione in laboratorio', colonnaIndice: 0, oreStimate: 8, todo: ['Aggiornare firmware e BIOS', 'Configurare RAID', 'Installare sistema operativo', 'Applicare aggiornamenti'] },
      { titolo: 'Installazione presso il cliente', colonnaIndice: 0, oreStimate: 6, todo: ['Montaggio nel rack', 'Collegamento rete e alimentazione', 'Configurazione indirizzi IP'] },
      { titolo: 'Migrazione dati e servizi', colonnaIndice: 0, oreStimate: 10, todo: ['Copia dei dati', 'Verifica permessi delle cartelle', 'Riconfigurazione dei client'] },
      { titolo: 'Configurazione dei backup', colonnaIndice: 0, oreStimate: 4, todo: ['Impostare i job di backup', 'Eseguire un ripristino di prova', 'Attivare le notifiche di errore'] },
      { titolo: 'Collaudo e consegna', colonnaIndice: 0, oreStimate: 4, todo: ['Test con il cliente', 'Consegna delle credenziali', 'Documentazione finale'] },
    ],
  },
  {
    nome: 'Rinnovo infrastruttura di rete',
    categoria: 'Reti',
    descrizione: 'Sostituzione di switch, access point e firewall con riconfigurazione delle VLAN.',
    durataStimataGg: 20,
    colonne: [
      { nome: 'Analisi', consideraCompletato: false },
      { nome: 'Preparazione', consideraCompletato: false },
      { nome: 'Installazione', consideraCompletato: false },
      { nome: 'Collaudo', consideraCompletato: false },
      { nome: 'Chiuso', consideraCompletato: true },
    ],
    task: [
      { titolo: 'Censimento apparati esistenti', colonnaIndice: 0, oreStimate: 4, todo: ['Elencare switch e access point', 'Rilevare le VLAN in uso', 'Fotografare i cablaggi'] },
      { titolo: 'Progetto della nuova rete', colonnaIndice: 0, oreStimate: 6, todo: ['Schema delle VLAN', 'Piano di indirizzamento', 'Regole del firewall'] },
      { titolo: 'Preconfigurazione degli apparati', colonnaIndice: 1, oreStimate: 8, todo: ['Aggiornare i firmware', 'Caricare le configurazioni', 'Etichettare gli apparati'] },
      { titolo: 'Sostituzione apparati', colonnaIndice: 2, oreStimate: 8, todo: ['Intervento fuori orario', 'Sostituzione switch', 'Installazione access point'] },
      { titolo: 'Verifica copertura Wi-Fi', colonnaIndice: 3, oreStimate: 3, todo: ['Misurare il segnale nei locali', 'Correggere la potenza dei canali'] },
      { titolo: 'Documentazione e consegna', colonnaIndice: 3, oreStimate: 3, todo: ['Schema aggiornato della rete', 'Elenco credenziali consegnate'] },
    ],
  },
];

// Crea i template iniziali soltanto se nel database non ne esiste ancora nessuno
async function creaTemplateIniziali(tx: Parameters<Parameters<Database['transaction']>[0]>[0], log: (m: string) => void): Promise<void> {
  // Verifica se esiste già almeno un template
  const esistenti = await tx.select({ id: progettoTemplate.id }).from(progettoTemplate).limit(1);
  // Template già presenti (o eliminati volutamente dall'utente): non si tocca nulla
  if (esistenti.length > 0) return;
  // Crea ogni template con la sua struttura
  for (const modello of TEMPLATE_INIZIALI) {
    // Dati generali
    const [creato] = await tx
      .insert(progettoTemplate)
      .values({ nome: modello.nome, categoria: modello.categoria, descrizione: modello.descrizione, durataStimataGg: modello.durataStimataGg })
      .returning();
    // Fasi della bacheca
    await tx.insert(templateColonne).values(modello.colonne.map((c, i) => ({ templateId: creato!.id, nome: c.nome, ordine: i, consideraCompletato: c.consideraCompletato })));
    // Task predefiniti
    const task = await tx
      .insert(templateTask)
      .values(
        modello.task.map((t, i) => ({
          templateId: creato!.id,
          titolo: t.titolo,
          colonnaIndice: t.colonnaIndice,
          // Numeric: si passa come stringa con due decimali
          oreStimate: t.oreStimate.toFixed(2),
          ordine: i,
        })),
      )
      .returning();
    // Voci della to-do di tutti i task, in un solo insert
    const voci = modello.task.flatMap((t, i) => t.todo.map((titolo, j) => ({ templateTaskId: task[i]!.id, titolo, ordine: j })));
    // Inserisce le voci se presenti
    if (voci.length > 0) await tx.insert(templateTodo).values(voci);
  }
  // Messaggio
  log(`Template di progetto iniziali creati: ${TEMPLATE_INIZIALI.length}`);
}

// Esecuzione da riga di comando
async function main(): Promise<void> {
  // Carica il file .env della radice (se presente)
  config({ path: resolve(process.cwd(), '../../.env'), quiet: true });
  // Stringa di connessione obbligatoria
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL non impostata');
  // Apre la connessione
  const { db, pool } = creaDatabase(process.env.DATABASE_URL);
  try {
    // Esegue il seed con i dati dell'amministratore presi dall'ambiente
    await eseguiSeed(db, {
      adminEmail: process.env.ADMIN_EMAIL,
      adminPassword: process.env.ADMIN_PASSWORD_INIZIALE,
      adminNome: process.env.ADMIN_NOME,
      adminCognome: process.env.ADMIN_COGNOME,
    });
  } finally {
    // Chiude sempre le connessioni
    await pool.end();
  }
}

// Esegue main solo se il file è lanciato direttamente (non quando è importato dai test)
if (require.main === module) {
  main().catch((errore: unknown) => {
    // Stampa l'errore
    console.error('Seed fallito:', errore instanceof Error ? errore.message : errore);
    // Uscita con errore
    process.exit(1);
  });
}
