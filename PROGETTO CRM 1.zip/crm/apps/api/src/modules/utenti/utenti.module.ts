// Modulo gestione utenti

// Importa il decoratore di NestJS
import { Module } from '@nestjs/common';
// Importa controller e service
import { UtentiController } from './utenti.controller';
import { UtentiService } from './utenti.service';

@Module({
  // Rotte
  controllers: [UtentiController],
  // Servizi
  providers: [UtentiService],
})
export class UtentiModule {}
