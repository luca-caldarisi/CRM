// =====================================================================================
// Gestione utenti (solo Admin o ruoli con permesso utenti.manage)
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { and, asc, count, eq, ilike, ne, or, sql, type SQL } from 'drizzle-orm';
// Importa tipi condivisi
import type { AggiornaUtenteDati, CreaUtenteDati, OpzioneUtente, RispostaPaginata, RispostaPasswordTemporanea, Utente } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { ruoli, utenti } from '../../database/schema';
// Importa eccezioni, tipi e utilità
import { conflitto, nonTrovato, regolaViolata } from '../../common/errori/errori';
import type { ContestoRichiesta } from '../../common/auth/tipi';
import { limitOffset, ordinamento, patternContiene } from '../../common/utils/query';
// Importa servizi collegati
import { AuditService } from '../audit/audit.service';
import { generaPasswordTemporanea, hashPassword } from '../auth/password';
import { SessioniService } from '../auth/sessioni.service';

// Filtri della lista (già validati)
interface FiltriUtenti {
  page: number;
  pageSize: number;
  q?: string;
  sort?: string;
  ruoloId?: string;
  attivo?: boolean;
}

// Colonne selezionate per restituire un utente (mai l'hash della password)
const COLONNE_UTENTE = {
  id: utenti.id,
  email: utenti.email,
  nome: utenti.nome,
  cognome: utenti.cognome,
  attivo: utenti.attivo,
  deveCambiarePassword: utenti.deveCambiarePassword,
  ultimoAccesso: utenti.ultimoAccesso,
  bloccatoFinoA: utenti.bloccatoFinoA,
  createdAt: utenti.createdAt,
  ruoloId: ruoli.id,
  ruoloNome: ruoli.nome,
  ruoloDiSistema: ruoli.diSistema,
};

// Forma di una riga selezionata con COLONNE_UTENTE
interface RigaUtente {
  id: string;
  email: string;
  nome: string;
  cognome: string;
  attivo: boolean;
  deveCambiarePassword: boolean;
  ultimoAccesso: Date | null;
  bloccatoFinoA: Date | null;
  createdAt: Date;
  ruoloId: string;
  ruoloNome: string;
  ruoloDiSistema: boolean;
}

// Converte una riga del database nel formato dell'API
function mappaUtente(r: RigaUtente): Utente {
  return {
    id: r.id,
    email: r.email,
    nome: r.nome,
    cognome: r.cognome,
    attivo: r.attivo,
    deveCambiarePassword: r.deveCambiarePassword,
    // Le date diventano stringhe ISO
    ultimoAccesso: r.ultimoAccesso?.toISOString() ?? null,
    bloccatoFinoA: r.bloccatoFinoA && r.bloccatoFinoA.getTime() > Date.now() ? r.bloccatoFinoA.toISOString() : null,
    ruolo: { id: r.ruoloId, nome: r.ruoloNome, diSistema: r.ruoloDiSistema },
    createdAt: r.createdAt.toISOString(),
  };
}

@Injectable()
export class UtentiService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Registro attività
    private readonly audit: AuditService,
    // Sessioni (per revocarle)
    private readonly sessioni: SessioniService,
  ) {}

  // Elenco paginato
  async lista(filtri: FiltriUtenti): Promise<RispostaPaginata<Utente>> {
    // Condizioni di filtro
    const condizioni: SQL[] = [];
    // Ricerca su nome, cognome ed email
    if (filtri.q) {
      // Pattern "contiene" con caratteri jolly neutralizzati
      const p = patternContiene(filtri.q);
      // OR tra i campi
      condizioni.push(or(ilike(utenti.nome, p), ilike(utenti.cognome, p), ilike(utenti.email, p))!);
    }
    // Filtro per ruolo
    if (filtri.ruoloId) condizioni.push(eq(utenti.ruoloId, filtri.ruoloId));
    // Filtro attivo/disattivo
    if (filtri.attivo !== undefined) condizioni.push(eq(utenti.attivo, filtri.attivo));
    // Combina le condizioni
    const where = condizioni.length ? and(...condizioni) : undefined;
    // Ordinamento consentito
    const ordine = ordinamento(filtri.sort, { nome: utenti.nome, cognome: utenti.cognome, email: utenti.email, ultimoAccesso: utenti.ultimoAccesso, createdAt: utenti.createdAt }, [asc(utenti.cognome), asc(utenti.nome)]);
    // Paginazione
    const { limit, offset } = limitOffset(filtri);
    // Query dati e conteggio in parallelo
    const [righe, [tot]] = await Promise.all([
      this.db.select(COLONNE_UTENTE).from(utenti).innerJoin(ruoli, eq(ruoli.id, utenti.ruoloId)).where(where).orderBy(...ordine).limit(limit).offset(offset),
      this.db.select({ n: count() }).from(utenti).where(where),
    ]);
    // Risposta
    return { data: righe.map(mappaUtente), meta: { page: filtri.page, pageSize: filtri.pageSize, total: tot?.n ?? 0 } };
  }

  // Dettaglio di un utente
  async dettaglio(id: string, tx: DbOTransazione = this.db): Promise<Utente> {
    // Legge l'utente con il ruolo
    const [riga] = await tx.select(COLONNE_UTENTE).from(utenti).innerJoin(ruoli, eq(ruoli.id, utenti.ruoloId)).where(eq(utenti.id, id)).limit(1);
    // Non trovato
    if (!riga) throw nonTrovato('Utente');
    // Converte
    return mappaUtente(riga);
  }

  // Elenco leggero degli utenti attivi per le select (visibile a tutti gli autenticati)
  async opzioni(): Promise<OpzioneUtente[]> {
    // Solo id, nome e cognome: nessun dato sensibile
    return this.db.select({ id: utenti.id, nome: utenti.nome, cognome: utenti.cognome }).from(utenti).where(eq(utenti.attivo, true)).orderBy(asc(utenti.cognome), asc(utenti.nome));
  }

  // Crea un nuovo utente
  async crea(contesto: ContestoRichiesta, dati: CreaUtenteDati): Promise<RispostaPasswordTemporanea> {
    // Se l'Admin non ha indicato una password se ne genera una casuale
    const passwordTemporanea = dati.passwordIniziale ? null : generaPasswordTemporanea();
    // Calcola l'hash prima della transazione (operazione lenta, non deve tenere occupata la connessione)
    const passwordHash = await hashPassword(dati.passwordIniziale ?? passwordTemporanea!);
    // Esegue in transazione
    const utente = await this.db.transaction(async (tx) => {
      // Verifica che il ruolo esista
      await this.ruoloOErrore(tx, dati.ruoloId);
      // Controllo esplicito dell'email per un messaggio chiaro (l'indice univoco resta la garanzia finale)
      const [esistente] = await tx.select({ id: utenti.id }).from(utenti).where(eq(sql`lower(${utenti.email})`, dati.email.toLowerCase())).limit(1);
      // Email già usata
      if (esistente) throw conflitto('Esiste già un utente con questa email');
      // Inserisce l'utente con obbligo di cambio password al primo accesso
      const [nuovo] = await tx
        .insert(utenti)
        .values({ email: dati.email.toLowerCase(), nome: dati.nome, cognome: dati.cognome, ruoloId: dati.ruoloId, passwordHash, deveCambiarePassword: true })
        .returning({ id: utenti.id });
      // Registra la creazione (l'hash è escluso automaticamente dal calcolo delle modifiche)
      await this.audit.registra(tx, contesto, { azione: 'creazione', entita: 'utente', entitaId: nuovo!.id, descrizione: dati.email, dopo: { email: dati.email, nome: dati.nome, cognome: dati.cognome, ruoloId: dati.ruoloId } });
      // Restituisce il dettaglio
      return this.dettaglio(nuovo!.id, tx);
    });
    // La password temporanea viene mostrata una sola volta e non è salvata da nessuna parte
    return { utente, passwordTemporanea };
  }

  // Modifica un utente
  async aggiorna(contesto: ContestoRichiesta, id: string, dati: AggiornaUtenteDati): Promise<Utente> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Legge lo stato attuale con il flag di ruolo di sistema
      const [attuale] = await tx
        .select({ utente: utenti, adminAttuale: ruoli.diSistema })
        .from(utenti)
        .innerJoin(ruoli, eq(ruoli.id, utenti.ruoloId))
        .where(eq(utenti.id, id))
        .limit(1)
        // Blocca la riga fino a fine transazione: evita modifiche concorrenti incoerenti
        .for('update', { of: utenti });
      // Non trovato
      if (!attuale) throw nonTrovato('Utente');

      // Un utente non può disattivare se stesso (rischio di chiudersi fuori)
      if (id === contesto.utente.id && dati.attivo === false) throw regolaViolata('Non puoi disattivare il tuo account');

      // Verifica il nuovo ruolo e se è di sistema
      const nuovoRuoloAdmin = dati.ruoloId ? (await this.ruoloOErrore(tx, dati.ruoloId)).diSistema : attuale.adminAttuale;
      // L'utente resterà un amministratore attivo?
      const restaAdminAttivo = nuovoRuoloAdmin && (dati.attivo ?? attuale.utente.attivo);
      // Se oggi è un amministratore attivo e smetterà di esserlo, deve restarne almeno un altro
      if (attuale.adminAttuale && attuale.utente.attivo && !restaAdminAttivo) {
        await this.verificaAltroAdmin(tx, id);
      }

      // Cambia il ruolo o lo stato: i token già emessi devono diventare obsoleti subito
      const cambiaAccesso = (dati.ruoloId !== undefined && dati.ruoloId !== attuale.utente.ruoloId) || (dati.attivo !== undefined && dati.attivo !== attuale.utente.attivo);
      // Salva le modifiche
      await tx
        .update(utenti)
        .set({ ...dati, ...(cambiaAccesso ? { permVersion: sql`${utenti.permVersion} + 1` } : {}) })
        .where(eq(utenti.id, id));
      // Se l'utente è stato disattivato, chiude tutte le sue sessioni
      if (dati.attivo === false) await this.sessioni.revocaTutteDellUtente(tx, id);
      // Registra le modifiche
      await this.audit.registra(tx, contesto, { azione: 'modifica', entita: 'utente', entitaId: id, descrizione: attuale.utente.email, prima: attuale.utente, dopo: { ...attuale.utente, ...dati } });
      // Restituisce il dettaglio aggiornato
      return this.dettaglio(id, tx);
    });
  }

  // Reimposta la password con una temporanea e sblocca l'account
  async resetPassword(contesto: ContestoRichiesta, id: string): Promise<RispostaPasswordTemporanea> {
    // Genera la password temporanea
    const passwordTemporanea = generaPasswordTemporanea();
    // Calcola l'hash
    const passwordHash = await hashPassword(passwordTemporanea);
    // Esegue in transazione
    const utente = await this.db.transaction(async (tx) => {
      // Aggiorna: nuova password, obbligo di cambio, sblocco, invalidazione dei token
      const aggiornati = await tx
        .update(utenti)
        .set({ passwordHash, deveCambiarePassword: true, tentativiFalliti: 0, bloccatoFinoA: null, permVersion: sql`${utenti.permVersion} + 1` })
        .where(eq(utenti.id, id))
        .returning({ email: utenti.email });
      // Non trovato
      if (aggiornati.length === 0) throw nonTrovato('Utente');
      // Chiude tutte le sessioni esistenti
      await this.sessioni.revocaTutteDellUtente(tx, id);
      // Registra l'evento
      await this.audit.registra(tx, contesto, { azione: 'reset_password', entita: 'utente', entitaId: id, descrizione: aggiornati[0]!.email });
      // Dettaglio aggiornato
      return this.dettaglio(id, tx);
    });
    // Restituisce la password da comunicare all'utente
    return { utente, passwordTemporanea };
  }

  // ------------------------------- Metodi di supporto --------------------------------

  // Legge un ruolo o lancia 422 se non esiste
  private async ruoloOErrore(tx: DbOTransazione, ruoloId: string) {
    // Cerca il ruolo
    const [ruolo] = await tx.select({ id: ruoli.id, diSistema: ruoli.diSistema }).from(ruoli).where(eq(ruoli.id, ruoloId)).limit(1);
    // Ruolo inesistente
    if (!ruolo) throw regolaViolata('Il ruolo indicato non esiste');
    // Restituisce il ruolo
    return ruolo;
  }

  // Verifica che esista almeno un altro amministratore attivo oltre all'utente indicato
  private async verificaAltroAdmin(tx: DbOTransazione, escludiId: string): Promise<void> {
    // Conta gli altri admin attivi
    const [r] = await tx
      .select({ n: count() })
      .from(utenti)
      .innerJoin(ruoli, eq(ruoli.id, utenti.ruoloId))
      .where(and(eq(ruoli.diSistema, true), eq(utenti.attivo, true), ne(utenti.id, escludiId)));
    // Nessun altro admin: operazione bloccata
    if (!r || r.n === 0) throw regolaViolata('Deve restare almeno un amministratore attivo');
  }
}
