// =====================================================================================
// API utenti: /api/v1/utenti
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Get, Param, Patch, Post, Query } from '@nestjs/common';
// Importa la creazione dei DTO
import { createZodDto } from 'nestjs-zod';
// Importa schemi condivisi
import { aggiornaUtenteSchema, creaUtenteSchema, filtriUtentiSchema, parametroIdSchema } from '@crm/shared';
// Importa decoratori di accesso
import { Contesto, RichiedePermesso, SoloAutenticato } from '../../common/auth/decoratori';
import type { ContestoRichiesta } from '../../common/auth/tipi';
// Importa il service
import { UtentiService } from './utenti.service';

// DTO dei filtri
class FiltriUtentiDto extends createZodDto(filtriUtentiSchema) {}
// DTO di creazione
class CreaUtenteDto extends createZodDto(creaUtenteSchema) {}
// DTO di modifica
class AggiornaUtenteDto extends createZodDto(aggiornaUtenteSchema) {}
// DTO del parametro :id (valida che sia un UUID)
class ParametroIdDto extends createZodDto(parametroIdSchema) {}

@Controller('utenti')
export class UtentiController {
  // Riceve il service
  constructor(private readonly utenti: UtentiService) {}

  // GET /api/v1/utenti
  @Get()
  @RichiedePermesso('utenti.manage')
  lista(@Query() filtri: FiltriUtentiDto) {
    return this.utenti.lista(filtri);
  }

  // GET /api/v1/utenti/opzioni — elenco per le select (dichiarato prima di ":id" per non essere confuso con un id)
  @Get('opzioni')
  @SoloAutenticato()
  opzioni() {
    return this.utenti.opzioni();
  }

  // GET /api/v1/utenti/:id
  @Get(':id')
  @RichiedePermesso('utenti.manage')
  dettaglio(@Param() { id }: ParametroIdDto) {
    return this.utenti.dettaglio(id);
  }

  // POST /api/v1/utenti
  @Post()
  @RichiedePermesso('utenti.manage')
  crea(@Contesto() contesto: ContestoRichiesta, @Body() dati: CreaUtenteDto) {
    return this.utenti.crea(contesto, dati);
  }

  // PATCH /api/v1/utenti/:id
  @Patch(':id')
  @RichiedePermesso('utenti.manage')
  aggiorna(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaUtenteDto) {
    return this.utenti.aggiorna(contesto, id, dati);
  }

  // POST /api/v1/utenti/:id/reset-password
  @Post(':id/reset-password')
  @RichiedePermesso('utenti.manage')
  resetPassword(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.utenti.resetPassword(contesto, id);
  }
}
