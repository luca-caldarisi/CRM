// =====================================================================================
// Allegati collegati a clienti e commesse
// -------------------------------------------------------------------------------------
// I permessi sugli allegati sono quelli dell'entità a cui appartengono:
// - vedere/scaricare  = permesso di lettura sull'entità
// - caricare/eliminare = permesso di scrittura sull'entità
// =====================================================================================

// Importa le funzioni crittografiche
import { createHash } from 'node:crypto';
// Importa le funzioni per i percorsi
import { basename, extname } from 'node:path';
// Importa i decoratori di NestJS
import { HttpStatus, Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { and, desc, eq } from 'drizzle-orm';
// Importa costanti e tipi condivisi
import { ALLEGATO_MAX_MB, ESTENSIONI_AMMESSE, type Allegato, type EntitaAllegato } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { allegati, utenti } from '../../database/schema';
// Importa tipi ed eccezioni
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
import { ErroreApi, nonTrovato } from '../../common/errori/errori';
// Importa il registro attività
import { AuditService } from '../audit/audit.service';
// Importa i controlli di accesso delle entità
import { clienteAccessibile } from '../clienti/accesso-clienti';
import { commessaAccessibile } from '../commesse/accesso-commesse';
import { progettoAccessibile } from '../progetti/accesso-progetti';
// Importa verifica del tipo e storage
import { rilevaTipo } from './rileva-tipo';
import { StorageService } from './storage.service';

// File ricevuto da multer (solo i campi usati)
export interface FileCaricato {
  originalname: string;
  size: number;
  buffer: Buffer;
}

// Pulisce il nome originale: niente percorsi, niente caratteri di controllo, lunghezza limitata
function pulisciNome(nome: string): string {
  // basename rimuove eventuali percorsi (es. "C:\\fake\\..\\file.pdf")
  const soloNome = basename(nome.replace(/\\/g, '/'));
  // Rimuove caratteri di controllo e quelli problematici negli header HTTP
  const pulito = soloNome.replace(/[\u0000-\u001f\u007f"<>]/g, '').trim();
  // Lunghezza massima della colonna; nome di ripiego se vuoto
  return (pulito || 'file').slice(0, 255);
}

@Injectable()
export class AllegatiService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Archiviazione file
    private readonly storage: StorageService,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // Verifica l'accesso all'entità padre e restituisce una descrizione per l'audit
  private async verificaEntita(tx: DbOTransazione, utente: UtenteAutenticato, entita: EntitaAllegato, entitaId: string, scrittura: boolean): Promise<string> {
    // Cliente: permessi clienti.read / clienti.write
    if (entita === 'cliente') {
      const c = await clienteAccessibile(tx, utente, scrittura ? 'clienti.write' : 'clienti.read', entitaId);
      return c.ragioneSociale;
    }
    // Progetto: permessi progetti.read / progetti.write
    if (entita === 'progetto') {
      // Per allegare un documento serve poter scrivere sul progetto (quindi esserne responsabile con ambito "propri")
      const p = await progettoAccessibile(tx, utente, scrittura ? 'progetti.write' : 'progetti.read', entitaId, scrittura ? 'responsabile' : 'coinvolto');
      return `${p.codice} ${p.nome}`;
    }
    // Commessa: permessi commesse.read / commesse.write
    const c = await commessaAccessibile(tx, utente, scrittura ? 'commesse.write' : 'commesse.read', entitaId);
    return c.codice;
  }

  // Elenco degli allegati di un'entità
  async lista(utente: UtenteAutenticato, entita: EntitaAllegato, entitaId: string): Promise<Allegato[]> {
    // Verifica l'accesso in lettura
    await this.verificaEntita(this.db, utente, entita, entitaId, false);
    // Legge gli allegati con l'autore del caricamento
    const righe = await this.db
      .select({ allegato: allegati, nome: utenti.nome, cognome: utenti.cognome })
      .from(allegati)
      .innerJoin(utenti, eq(utenti.id, allegati.caricatoDaId))
      .where(and(eq(allegati.entita, entita), eq(allegati.entitaId, entitaId)))
      .orderBy(desc(allegati.createdAt));
    // Converte nel formato API (il percorso interno non viene mai esposto)
    return righe.map(({ allegato: a, nome, cognome }) => ({
      id: a.id,
      entita: a.entita,
      entitaId: a.entitaId,
      nomeOriginale: a.nomeOriginale,
      mimeType: a.mimeType,
      dimensione: a.dimensione,
      caricatoDa: { id: a.caricatoDaId, nome, cognome },
      createdAt: a.createdAt.toISOString(),
    }));
  }

  // Carica un nuovo allegato
  async carica(contesto: ContestoRichiesta, entita: EntitaAllegato, entitaId: string, file: FileCaricato | undefined): Promise<Allegato> {
    // Nessun file nella richiesta
    if (!file) throw new ErroreApi(HttpStatus.BAD_REQUEST, 'file_mancante', 'Richiesta non valida', 'Nessun file ricevuto');
    // File vuoto
    if (file.size === 0) throw new ErroreApi(HttpStatus.BAD_REQUEST, 'file_vuoto', 'Richiesta non valida', 'Il file è vuoto');
    // Doppio controllo sulla dimensione (multer blocca già oltre il limite)
    if (file.size > ALLEGATO_MAX_MB * 1024 * 1024) throw new ErroreApi(HttpStatus.PAYLOAD_TOO_LARGE, 'file_troppo_grande', 'File troppo grande', `Dimensione massima ${ALLEGATO_MAX_MB} MB`);
    // Nome pulito
    const nomeOriginale = pulisciNome(file.originalname);
    // Estensione in minuscolo senza punto
    const estensione = extname(nomeOriginale).slice(1).toLowerCase();
    // Estensione non ammessa
    if (!(ESTENSIONI_AMMESSE as readonly string[]).includes(estensione)) {
      throw new ErroreApi(HttpStatus.UNPROCESSABLE_ENTITY, 'tipo_file_non_ammesso', 'Tipo di file non ammesso', `Estensioni consentite: ${ESTENSIONI_AMMESSE.join(', ')}`);
    }
    // Il contenuto deve corrispondere all'estensione
    const mimeType = rilevaTipo(file.buffer, estensione);
    if (!mimeType) {
      throw new ErroreApi(HttpStatus.UNPROCESSABLE_ENTITY, 'contenuto_non_valido', 'Tipo di file non ammesso', "Il contenuto del file non corrisponde all'estensione");
    }
    // Verifica i permessi PRIMA di scrivere il file su disco
    await this.verificaEntita(this.db, contesto.utente, entita, entitaId, true);
    // Impronta SHA-256 del contenuto
    const sha256 = createHash('sha256').update(file.buffer).digest('hex');
    // Scrive il file
    const percorso = await this.storage.salva(file.buffer);
    try {
      // Salva i metadati in transazione
      const id = await this.db.transaction(async (tx) => {
        // Ricontrolla l'accesso dentro la transazione (l'entità potrebbe essere stata eliminata nel frattempo)
        const descrizione = await this.verificaEntita(tx, contesto.utente, entita, entitaId, true);
        // Inserisce la riga
        const [nuovo] = await tx
          .insert(allegati)
          .values({ entita, entitaId, nomeOriginale, percorso, mimeType, dimensione: file.size, sha256, caricatoDaId: contesto.utente.id })
          .returning({ id: allegati.id });
        // Registra il caricamento
        await this.audit.registra(tx, contesto, { azione: 'creazione', entita: 'allegato', entitaId: nuovo!.id, descrizione: `${descrizione} - ${nomeOriginale}` });
        // Restituisce l'id
        return nuovo!.id;
      });
      // Restituisce l'allegato appena creato
      return (await this.lista(contesto.utente, entita, entitaId)).find((a) => a.id === id)!;
    } catch (errore) {
      // Se il database fallisce, elimina il file per non lasciare file orfani
      await this.storage.elimina(percorso);
      // Rilancia l'errore
      throw errore;
    }
  }

  // Prepara il download verificando i permessi
  async perDownload(utente: UtenteAutenticato, id: string) {
    // Cerca l'allegato
    const [a] = await this.db.select().from(allegati).where(eq(allegati.id, id)).limit(1);
    // Non trovato
    if (!a) throw nonTrovato('Allegato');
    // Verifica la lettura sull'entità padre (404 se fuori ambito)
    await this.verificaEntita(this.db, utente, a.entita, a.entitaId, false);
    // Restituisce metadati e stream del contenuto
    return { nome: a.nomeOriginale, mimeType: a.mimeType, dimensione: a.dimensione, stream: this.storage.apri(a.percorso) };
  }

  // Elimina un allegato
  async elimina(contesto: ContestoRichiesta, id: string): Promise<void> {
    // Cerca l'allegato
    const [a] = await this.db.select().from(allegati).where(eq(allegati.id, id)).limit(1);
    // Non trovato
    if (!a) throw nonTrovato('Allegato');
    // Elimina la riga in transazione
    await this.db.transaction(async (tx) => {
      // Verifica la scrittura sull'entità padre
      const descrizione = await this.verificaEntita(tx, contesto.utente, a.entita, a.entitaId, true);
      // Cancella la riga
      await tx.delete(allegati).where(eq(allegati.id, id));
      // Registra l'eliminazione
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'allegato', entitaId: id, descrizione: `${descrizione} - ${a.nomeOriginale}` });
    });
    // Cancella il file solo dopo il commit (se il commit fallisce il file resta)
    await this.storage.elimina(a.percorso);
  }
}
