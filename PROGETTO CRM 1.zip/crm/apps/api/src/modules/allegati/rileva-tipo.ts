// =====================================================================================
// Verifica del tipo reale di un file tramite la sua "firma" (magic bytes)
// -------------------------------------------------------------------------------------
// Non ci si fida né del nome né del Content-Type inviato dal browser: entrambi sono
// falsificabili. Un eseguibile rinominato "fattura.pdf" viene rifiutato perché i suoi
// primi byte non sono quelli di un PDF.
// =====================================================================================

// Tipi MIME associati alle estensioni ammesse
const MIME_PER_ESTENSIONE: Record<string, string> = {
  pdf: 'application/pdf',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webp: 'image/webp',
  docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  odt: 'application/vnd.oasis.opendocument.text',
  ods: 'application/vnd.oasis.opendocument.spreadsheet',
  zip: 'application/zip',
  doc: 'application/msword',
  xls: 'application/vnd.ms-excel',
  ppt: 'application/vnd.ms-powerpoint',
  txt: 'text/plain',
  csv: 'text/csv',
};

// Verifica se il buffer inizia con la sequenza di byte indicata (a partire da una posizione)
function iniziaCon(buffer: Buffer, firma: number[], posizione = 0): boolean {
  // Il file deve essere abbastanza lungo
  if (buffer.length < posizione + firma.length) return false;
  // Confronta byte per byte
  return firma.every((byte, i) => buffer[posizione + i] === byte);
}

// true se il contenuto è testo UTF-8 valido senza caratteri nulli (tipico dei file binari)
function eTesto(buffer: Buffer): boolean {
  // Un byte 0 indica un file binario
  if (buffer.includes(0)) return false;
  try {
    // Decodifica in modalità rigorosa: fallisce se ci sono sequenze non valide
    new TextDecoder('utf-8', { fatal: true }).decode(buffer);
    // Testo valido
    return true;
  } catch {
    // Non è UTF-8 valido
    return false;
  }
}

// Restituisce il tipo MIME se contenuto ed estensione sono coerenti, altrimenti null
export function rilevaTipo(buffer: Buffer, estensione: string): string | null {
  // Tipo MIME atteso per l'estensione
  const mime = MIME_PER_ESTENSIONE[estensione];
  // Estensione non prevista
  if (!mime) return null;
  // Controllo della firma in base all'estensione
  switch (estensione) {
    // PDF: "%PDF-"
    case 'pdf':
      return iniziaCon(buffer, [0x25, 0x50, 0x44, 0x46, 0x2d]) ? mime : null;
    // PNG: 89 50 4E 47 0D 0A 1A 0A
    case 'png':
      return iniziaCon(buffer, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]) ? mime : null;
    // JPEG: FF D8 FF
    case 'jpg':
    case 'jpeg':
      return iniziaCon(buffer, [0xff, 0xd8, 0xff]) ? mime : null;
    // WEBP: "RIFF" .... "WEBP"
    case 'webp':
      return iniziaCon(buffer, [0x52, 0x49, 0x46, 0x46]) && iniziaCon(buffer, [0x57, 0x45, 0x42, 0x50], 8) ? mime : null;
    // Formati basati su ZIP (Office moderno, OpenDocument, zip): "PK\x03\x04"
    case 'docx':
    case 'xlsx':
    case 'pptx':
    case 'odt':
    case 'ods':
    case 'zip':
      return iniziaCon(buffer, [0x50, 0x4b, 0x03, 0x04]) ? mime : null;
    // Office 97-2003 (formato OLE): D0 CF 11 E0 A1 B1 1A E1
    case 'doc':
    case 'xls':
    case 'ppt':
      return iniziaCon(buffer, [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]) ? mime : null;
    // Testo semplice e CSV: nessuna firma, si verifica che sia testo valido
    case 'txt':
    case 'csv':
      return eTesto(buffer) ? mime : null;
    // Qualsiasi altro caso: rifiutato
    default:
      return null;
  }
}
