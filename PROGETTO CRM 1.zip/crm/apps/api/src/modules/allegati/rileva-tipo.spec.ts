// Test unitari della verifica del contenuto dei file

// Importa la funzione da testare
import { rilevaTipo } from './rileva-tipo';

describe('rilevaTipo', () => {
  it('riconosce i formati con firma corretta', () => {
    // PDF
    expect(rilevaTipo(Buffer.from('%PDF-1.7 ...'), 'pdf')).toBe('application/pdf');
    // PNG
    expect(rilevaTipo(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0]), 'png')).toBe('image/png');
    // DOCX (archivio zip)
    expect(rilevaTipo(Buffer.from([0x50, 0x4b, 0x03, 0x04, 1, 2]), 'docx')).toContain('wordprocessingml');
    // CSV con caratteri accentati
    expect(rilevaTipo(Buffer.from('nome;città\nRossi;Forlì\n'), 'csv')).toBe('text/csv');
  });

  it('rifiuta contenuti che non corrispondono all\'estensione', () => {
    // Eseguibile Windows rinominato
    expect(rilevaTipo(Buffer.from('MZ\x90\x00'), 'pdf')).toBeNull();
    // Immagine rinominata in docx
    expect(rilevaTipo(Buffer.from([0xff, 0xd8, 0xff, 0xe0]), 'docx')).toBeNull();
    // File binario rinominato in txt
    expect(rilevaTipo(Buffer.from([0x41, 0x00, 0x42]), 'txt')).toBeNull();
    // Estensione sconosciuta
    expect(rilevaTipo(Buffer.from('%PDF-'), 'exe')).toBeNull();
  });
});
