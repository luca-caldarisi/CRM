// =====================================================================================
// Archiviazione dei file su disco
// -------------------------------------------------------------------------------------
// Tutti i moduli usano questa interfaccia: passare in futuro a uno storage S3 richiederà
// di modificare solo questo file.
// =====================================================================================

// Importa le funzioni per il file system
import { createReadStream, type ReadStream } from 'node:fs';
import { mkdir, unlink, writeFile } from 'node:fs/promises';
// Importa le funzioni per i percorsi
import { dirname, resolve, sep } from 'node:path';
// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa la configurazione
import { ENV, type Env } from '../../config/env';
// Importa il generatore di UUID
import { uuidv7 } from '../../common/utils/uuidv7';

@Injectable()
export class StorageService {
  // Cartella radice assoluta degli allegati
  private readonly radice: string;

  // Riceve la configurazione
  constructor(@Inject(ENV) env: Env) {
    // Converte il percorso configurato in assoluto
    this.radice = resolve(env.UPLOAD_DIR);
  }

  // Salva un file e restituisce il percorso relativo (es. "2026/09/0191f3a0-....bin")
  async salva(contenuto: Buffer): Promise<string> {
    // Data corrente per organizzare i file in cartelle anno/mese
    const ora = new Date();
    // Percorso relativo con nome casuale: non contiene mai il nome scelto dall'utente
    const relativo = `${ora.getFullYear()}/${String(ora.getMonth() + 1).padStart(2, '0')}/${uuidv7()}.bin`;
    // Percorso assoluto verificato
    const assoluto = this.percorsoSicuro(relativo);
    // Crea le cartelle se non esistono
    await mkdir(dirname(assoluto), { recursive: true });
    // Scrive il file; "wx" fallisce se esiste già (non sovrascrive mai)
    await writeFile(assoluto, contenuto, { flag: 'wx', mode: 0o640 });
    // Restituisce il percorso relativo da salvare nel database
    return relativo;
  }

  // Apre il file in lettura come stream (non carica tutto in memoria)
  apri(relativo: string): ReadStream {
    return createReadStream(this.percorsoSicuro(relativo));
  }

  // Elimina un file; se non esiste non segnala errori
  async elimina(relativo: string): Promise<void> {
    try {
      // Cancella il file
      await unlink(this.percorsoSicuro(relativo));
    } catch (errore) {
      // Ignora solo l'errore "file non trovato"
      if ((errore as NodeJS.ErrnoException).code !== 'ENOENT') throw errore;
    }
  }

  // Converte un percorso relativo in assoluto impedendo di uscire dalla cartella radice ("../../etc/passwd")
  private percorsoSicuro(relativo: string): string {
    // Risolve il percorso
    const assoluto = resolve(this.radice, relativo);
    // Deve trovarsi dentro la radice
    if (!assoluto.startsWith(this.radice + sep)) throw new Error('Percorso di storage non valido');
    // Percorso sicuro
    return assoluto;
  }
}
