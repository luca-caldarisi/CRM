// =====================================================================================
// API allegati: /api/v1/allegati
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Post, Query, Res, StreamableFile, UploadedFile, UseInterceptors } from '@nestjs/common';
// Importa l'interceptor che gestisce l'upload multipart
import { FileInterceptor } from '@nestjs/platform-express';
// Importa la creazione dei DTO
import { createZodDto } from 'nestjs-zod';
// Importa il tipo della risposta di Express
import type { Response } from 'express';
// Importa costanti e schemi condivisi
import { ALLEGATO_MAX_MB, caricaAllegatoSchema, filtriAllegatiSchema, parametroIdSchema } from '@crm/shared';
// Importa decoratori di accesso
import { Contesto, SoloAutenticato, UtenteCorrente } from '../../common/auth/decoratori';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
// Importa il service
import { AllegatiService, type FileCaricato } from './allegati.service';

// DTO
class CaricaAllegatoDto extends createZodDto(caricaAllegatoSchema) {}
class FiltriAllegatiDto extends createZodDto(filtriAllegatiSchema) {}
class ParametroIdDto extends createZodDto(parametroIdSchema) {}

@Controller('allegati')
// I permessi dipendono dall'entità collegata e sono verificati nel service:
// qui si richiede solo l'autenticazione (la scelta è dichiarata esplicitamente)
@SoloAutenticato()
export class AllegatiController {
  // Riceve il service
  constructor(private readonly allegati: AllegatiService) {}

  // GET /api/v1/allegati?entita=cliente&entitaId=...
  @Get()
  lista(@UtenteCorrente() utente: UtenteAutenticato, @Query() filtri: FiltriAllegatiDto) {
    return this.allegati.lista(utente, filtri.entita, filtri.entitaId);
  }

  // POST /api/v1/allegati (multipart/form-data con campi "entita", "entitaId" e "file")
  @Post()
  @UseInterceptors(
    FileInterceptor('file', {
      // Limiti applicati durante la ricezione: il caricamento si interrompe appena superati
      limits: { fileSize: ALLEGATO_MAX_MB * 1024 * 1024, files: 1, fields: 5, parts: 10 },
    }),
  )
  carica(@Contesto() contesto: ContestoRichiesta, @Body() dati: CaricaAllegatoDto, @UploadedFile() file: FileCaricato | undefined) {
    return this.allegati.carica(contesto, dati.entita, dati.entitaId, file);
  }

  // GET /api/v1/allegati/:id/download
  @Get(':id/download')
  async download(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto, @Res({ passthrough: true }) res: Response): Promise<StreamableFile> {
    // Verifica i permessi e apre il file
    const file = await this.allegati.perDownload(utente, id);
    // Header di sicurezza per il download
    res.set({
      // Tipo rilevato dal contenuto al momento del caricamento
      'Content-Type': file.mimeType,
      // Forza il download (mai visualizzato nella pagina) con nome codificato in UTF-8
      'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(file.nome)}`,
      // Impedisce al browser di "indovinare" un tipo diverso
      'X-Content-Type-Options': 'nosniff',
      // Anche se aperto, il contenuto non può eseguire script
      'Content-Security-Policy': "default-src 'none'; sandbox",
      // Non memorizzare in cache documenti riservati
      'Cache-Control': 'private, no-store',
    });
    // Invia il file a pezzi (stream) senza caricarlo tutto in memoria
    return new StreamableFile(file.stream, { length: file.dimensione });
  }

  // DELETE /api/v1/allegati/:id
  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  elimina(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.allegati.elimina(contesto, id);
  }
}
