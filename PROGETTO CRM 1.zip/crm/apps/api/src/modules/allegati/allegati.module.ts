// Modulo allegati

// Importa il decoratore di NestJS
import { Module } from '@nestjs/common';
// Importa controller e service
import { AllegatiController } from './allegati.controller';
import { AllegatiService } from './allegati.service';
import { StorageService } from './storage.service';

@Module({
  // Rotte
  controllers: [AllegatiController],
  // Servizi
  providers: [AllegatiService, StorageService],
})
export class AllegatiModule {}
