// =====================================================================================
// API ruoli e permessi: /api/v1/ruoli e /api/v1/permessi
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post, Put } from '@nestjs/common';
// Importa la creazione dei DTO
import { createZodDto } from 'nestjs-zod';
// Importa schemi condivisi
import { aggiornaRuoloSchema, creaRuoloSchema, impostaPermessiSchema, parametroIdSchema } from '@crm/shared';
// Importa decoratori di accesso
import { Contesto, RichiedePermesso } from '../../common/auth/decoratori';
import type { ContestoRichiesta } from '../../common/auth/tipi';
// Importa il service
import { RuoliService } from './ruoli.service';

// DTO
class CreaRuoloDto extends createZodDto(creaRuoloSchema) {}
class AggiornaRuoloDto extends createZodDto(aggiornaRuoloSchema) {}
class ImpostaPermessiDto extends createZodDto(impostaPermessiSchema) {}
class ParametroIdDto extends createZodDto(parametroIdSchema) {}

// Controller senza prefisso comune: espone sia /ruoli sia /permessi
@Controller()
// Tutte le rotte richiedono la gestione ruoli (decoratore a livello di classe)
@RichiedePermesso('ruoli.manage')
export class RuoliController {
  // Riceve il service
  constructor(private readonly ruoli: RuoliService) {}

  // GET /api/v1/permessi — catalogo dei permessi disponibili
  @Get('permessi')
  catalogo() {
    return this.ruoli.catalogo();
  }

  // GET /api/v1/ruoli
  @Get('ruoli')
  lista() {
    return this.ruoli.lista();
  }

  // GET /api/v1/ruoli/:id
  @Get('ruoli/:id')
  dettaglio(@Param() { id }: ParametroIdDto) {
    return this.ruoli.dettaglio(id);
  }

  // POST /api/v1/ruoli
  @Post('ruoli')
  crea(@Contesto() contesto: ContestoRichiesta, @Body() dati: CreaRuoloDto) {
    return this.ruoli.crea(contesto, dati);
  }

  // PATCH /api/v1/ruoli/:id
  @Patch('ruoli/:id')
  aggiorna(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaRuoloDto) {
    return this.ruoli.aggiorna(contesto, id, dati);
  }

  // DELETE /api/v1/ruoli/:id
  @Delete('ruoli/:id')
  @HttpCode(HttpStatus.NO_CONTENT)
  elimina(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.ruoli.elimina(contesto, id);
  }

  // PUT /api/v1/ruoli/:id/permessi — sostituisce l'intera matrice
  @Put('ruoli/:id/permessi')
  impostaPermessi(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: ImpostaPermessiDto) {
    return this.ruoli.impostaPermessi(contesto, id, dati);
  }
}
