// =====================================================================================
// Gestione ruoli e matrice dei permessi
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { asc, count, desc, eq, sql } from 'drizzle-orm';
// Importa catalogo e tipi condivisi
import { CATALOGO_PERMESSI, type AggiornaRuoloDati, type CreaRuoloDati, type ImpostaPermessiDati, type Ruolo } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { ruoli, ruoliPermessi, utenti } from '../../database/schema';
// Importa eccezioni e tipi
import { nonTrovato, regolaViolata } from '../../common/errori/errori';
import type { ContestoRichiesta } from '../../common/auth/tipi';
// Importa il registro attività
import { AuditService } from '../audit/audit.service';

@Injectable()
export class RuoliService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // Catalogo completo dei permessi (per costruire la matrice nell'interfaccia)
  catalogo() {
    return CATALOGO_PERMESSI;
  }

  // Elenco di tutti i ruoli con numero di utenti e permessi
  async lista(tx: DbOTransazione = this.db): Promise<Ruolo[]> {
    // Tutti i ruoli: Admin per primo, poi in ordine alfabetico
    const righe = await tx
      .select({ id: ruoli.id, nome: ruoli.nome, descrizione: ruoli.descrizione, diSistema: ruoli.diSistema })
      .from(ruoli)
      .orderBy(desc(ruoli.diSistema), asc(ruoli.nome));
    // Numero di utenti per ruolo con un'unica query raggruppata
    const conteggi = await tx.select({ ruoloId: utenti.ruoloId, n: count() }).from(utenti).groupBy(utenti.ruoloId);
    // Mappa ruolo -> numero utenti
    const utentiPerRuolo = new Map(conteggi.map((c) => [c.ruoloId, c.n]));
    // Tutte le associazioni ruolo-permesso
    const permessi = await tx.select().from(ruoliPermessi);
    // Unisce i permessi ai rispettivi ruoli
    return righe.map((r) => ({
      ...r,
      numeroUtenti: utentiPerRuolo.get(r.id) ?? 0,
      permessi: permessi.filter((p) => p.ruoloId === r.id).map((p) => ({ codice: p.permessoCodice as Ruolo['permessi'][number]['codice'], ambito: p.ambito })),
    }));
  }

  // Dettaglio di un ruolo
  async dettaglio(id: string, tx: DbOTransazione = this.db): Promise<Ruolo> {
    // Riusa la lista (i ruoli sono pochi)
    const ruolo = (await this.lista(tx)).find((r) => r.id === id);
    // Non trovato
    if (!ruolo) throw nonTrovato('Ruolo');
    // Restituisce il ruolo
    return ruolo;
  }

  // Crea un ruolo senza permessi (si configurano poi con la matrice)
  async crea(contesto: ContestoRichiesta, dati: CreaRuoloDati): Promise<Ruolo> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Inserisce (un nome duplicato viene gestito dal filtro errori come 409)
      const [nuovo] = await tx.insert(ruoli).values({ nome: dati.nome, descrizione: dati.descrizione ?? null }).returning();
      // Registra la creazione
      await this.audit.registra(tx, contesto, { azione: 'creazione', entita: 'ruolo', entitaId: nuovo!.id, descrizione: nuovo!.nome, dopo: nuovo! });
      // Restituisce il dettaglio
      return this.dettaglio(nuovo!.id, tx);
    });
  }

  // Modifica nome o descrizione
  async aggiorna(contesto: ContestoRichiesta, id: string, dati: AggiornaRuoloDati): Promise<Ruolo> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Legge il ruolo modificabile
      const attuale = await this.ruoloModificabile(tx, id);
      // Salva
      const [aggiornato] = await tx.update(ruoli).set(dati).where(eq(ruoli.id, id)).returning();
      // Registra le modifiche
      await this.audit.registra(tx, contesto, { azione: 'modifica', entita: 'ruolo', entitaId: id, descrizione: aggiornato!.nome, prima: attuale, dopo: aggiornato! });
      // Restituisce il dettaglio
      return this.dettaglio(id, tx);
    });
  }

  // Elimina un ruolo non assegnato a nessun utente
  async elimina(contesto: ContestoRichiesta, id: string): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Legge il ruolo modificabile
      const attuale = await this.ruoloModificabile(tx, id);
      // Conta gli utenti assegnati
      const [r] = await tx.select({ n: count() }).from(utenti).where(eq(utenti.ruoloId, id));
      // Ruolo in uso: non eliminabile
      if (r && r.n > 0) throw regolaViolata(`Il ruolo è assegnato a ${r.n} utenti: riassegnali prima di eliminarlo`);
      // Elimina (i permessi associati si cancellano in cascata)
      await tx.delete(ruoli).where(eq(ruoli.id, id));
      // Registra l'eliminazione
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'ruolo', entitaId: id, descrizione: attuale.nome });
    });
  }

  // Sostituisce l'intera matrice permessi del ruolo
  async impostaPermessi(contesto: ContestoRichiesta, id: string, dati: ImpostaPermessiDati): Promise<Ruolo> {
    // Esegue in transazione: o cambia tutto o non cambia nulla
    return this.db.transaction(async (tx) => {
      // Legge il ruolo modificabile
      const attuale = await this.ruoloModificabile(tx, id);
      // Permessi precedenti come mappa codice -> ambito (per l'audit)
      const prima = Object.fromEntries((await tx.select().from(ruoliPermessi).where(eq(ruoliPermessi.ruoloId, id))).map((p) => [p.permessoCodice, p.ambito]));
      // Rimuove tutti i permessi attuali
      await tx.delete(ruoliPermessi).where(eq(ruoliPermessi.ruoloId, id));
      // Inserisce i nuovi (se l'elenco non è vuoto)
      if (dati.permessi.length > 0) {
        await tx.insert(ruoliPermessi).values(dati.permessi.map((p) => ({ ruoloId: id, permessoCodice: p.codice, ambito: p.ambito })));
      }
      // Invalida i token di tutti gli utenti del ruolo: i nuovi permessi valgono dalla richiesta successiva
      await tx.update(utenti).set({ permVersion: sql`${utenti.permVersion} + 1` }).where(eq(utenti.ruoloId, id));
      // Permessi successivi come mappa
      const dopo = Object.fromEntries(dati.permessi.map((p) => [p.codice, p.ambito]));
      // Registra la modifica con il dettaglio dei permessi cambiati
      await this.audit.registra(tx, contesto, { azione: 'permessi', entita: 'ruolo', entitaId: id, descrizione: attuale.nome, prima, dopo });
      // Restituisce il ruolo aggiornato
      return this.dettaglio(id, tx);
    });
  }

  // Legge un ruolo e verifica che non sia il ruolo di sistema
  private async ruoloModificabile(tx: DbOTransazione, id: string) {
    // Cerca il ruolo
    const [ruolo] = await tx.select().from(ruoli).where(eq(ruoli.id, id)).limit(1);
    // Non trovato
    if (!ruolo) throw nonTrovato('Ruolo');
    // Il ruolo Admin ha sempre tutti i permessi e non si tocca
    if (ruolo.diSistema) throw regolaViolata('Il ruolo Admin di sistema non è modificabile');
    // Restituisce il ruolo
    return ruolo;
  }
}
