// Modulo ruoli e permessi

// Importa il decoratore di NestJS
import { Module } from '@nestjs/common';
// Importa controller e service
import { RuoliController } from './ruoli.controller';
import { RuoliService } from './ruoli.service';

@Module({
  // Rotte
  controllers: [RuoliController],
  // Servizi
  providers: [RuoliService],
})
export class RuoliModule {}
