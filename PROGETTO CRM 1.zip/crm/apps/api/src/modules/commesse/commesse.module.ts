// Modulo commesse

// Importa il decoratore di NestJS
import { Module } from '@nestjs/common';
// Importa controller e service
import { CommesseController } from './commesse.controller';
import { CommesseService } from './commesse.service';

@Module({
  // Rotte
  controllers: [CommesseController],
  // Servizi
  providers: [CommesseService],
})
export class CommesseModule {}
