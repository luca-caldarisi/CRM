// =====================================================================================
// Gestione commesse
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { and, count, desc, eq, ilike, isNull, or, type SQL } from 'drizzle-orm';
// Importa l'helper per gli alias
import { alias } from 'drizzle-orm/pg-core';
// Importa tipi condivisi
import type { AggiornaCommessaDati, Commessa, CreaCommessaDati, RispostaPaginata, StatoCommessa, TipoCommessa } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { clienti, commesse, utenti } from '../../database/schema';
// Importa sicurezza, eccezioni e utilità
import { haPermesso, richiediAmbito } from '../../common/auth/ambito';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
import { nonTrovato, permessoNegato, regolaViolata } from '../../common/errori/errori';
import { prossimoCodiceCommessa } from '../../common/utils/codici';
import { limitOffset, ordinamento, patternContiene } from '../../common/utils/query';
// Importa le utilità comuni (date e verifiche condivise)
import { oggi } from '../../common/utils/date';
import { verificaUtenteAttivo } from '../../common/utils/verifiche';
// Importa il registro attività
import { AuditService } from '../audit/audit.service';
// Importa i controlli di accesso
import { clienteAccessibile } from '../clienti/accesso-clienti';
import { commessaAccessibile, condizioneAmbitoCommesse } from './accesso-commesse';

// Filtri della lista (già validati)
interface FiltriCommesse {
  page: number;
  pageSize: number;
  q?: string;
  sort?: string;
  clienteId?: string;
  stato?: StatoCommessa;
  tipo?: TipoCommessa;
  responsabileId?: string;
}

// Alias della tabella utenti come "responsabile"
const responsabile = alias(utenti, 'responsabile');

// Colonne selezionate per costruire una commessa completa
const COLONNE = {
  commessa: commesse,
  clienteCodice: clienti.codice,
  clienteRagioneSociale: clienti.ragioneSociale,
  responsabileNome: responsabile.nome,
  responsabileCognome: responsabile.cognome,
};

// Forma di una riga selezionata con COLONNE
interface RigaCommessa {
  commessa: typeof commesse.$inferSelect;
  clienteCodice: string;
  clienteRagioneSociale: string;
  responsabileNome: string | null;
  responsabileCognome: string | null;
}


@Injectable()
export class CommesseService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // Converte una riga nel formato API, rimuovendo il valore se l'utente non ha il permesso economici.read
  private mappa(utente: UtenteAutenticato, r: RigaCommessa): Commessa {
    // Estrae la commessa
    const c = r.commessa;
    // Oggetto base senza dati economici
    const risultato: Commessa = {
      id: c.id,
      codice: c.codice,
      cliente: { id: c.clienteId, codice: r.clienteCodice, ragioneSociale: r.clienteRagioneSociale },
      titolo: c.titolo,
      descrizione: c.descrizione,
      tipo: c.tipo,
      stato: c.stato,
      dataApertura: c.dataApertura,
      dataChiusura: c.dataChiusura,
      responsabile: c.responsabileId ? { id: c.responsabileId, nome: r.responsabileNome!, cognome: r.responsabileCognome! } : null,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    };
    // Il valore viene aggiunto solo a chi può vederlo: gli altri non lo ricevono proprio dal server
    if (haPermesso(utente, 'economici.read')) risultato.valore = c.valore;
    // Restituisce la commessa
    return risultato;
  }

  // Elenco paginato
  async lista(utente: UtenteAutenticato, filtri: FiltriCommesse): Promise<RispostaPaginata<Commessa>> {
    // Condizioni fisse: non eliminate, cliente non eliminato, ambito
    const condizioni: (SQL | undefined)[] = [isNull(commesse.deletedAt), isNull(clienti.deletedAt), condizioneAmbitoCommesse(utente, 'commesse.read')];
    // Ricerca su codice, titolo e ragione sociale
    if (filtri.q) {
      // Pattern "contiene"
      const p = patternContiene(filtri.q);
      // OR tra i campi
      condizioni.push(or(ilike(commesse.codice, p), ilike(commesse.titolo, p), ilike(clienti.ragioneSociale, p)));
    }
    // Filtri esatti
    if (filtri.clienteId) condizioni.push(eq(commesse.clienteId, filtri.clienteId));
    if (filtri.stato) condizioni.push(eq(commesse.stato, filtri.stato));
    if (filtri.tipo) condizioni.push(eq(commesse.tipo, filtri.tipo));
    if (filtri.responsabileId) condizioni.push(eq(commesse.responsabileId, filtri.responsabileId));
    // Combina
    const where = and(...condizioni);
    // Ordinamenti consentiti (il valore solo per chi può vederlo, altrimenti si potrebbe dedurre)
    const consentiti = {
      codice: commesse.codice,
      titolo: commesse.titolo,
      dataApertura: commesse.dataApertura,
      stato: commesse.stato,
      cliente: clienti.ragioneSociale,
      updatedAt: commesse.updatedAt,
      ...(haPermesso(utente, 'economici.read') ? { valore: commesse.valore } : {}),
    };
    // Clausole ORDER BY (predefinito: più recenti prima)
    const ordine = ordinamento(filtri.sort, consentiti, [desc(commesse.dataApertura), desc(commesse.codice)]);
    // Paginazione
    const { limit, offset } = limitOffset(filtri);
    // Query dati e conteggio in parallelo
    const [righe, [tot]] = await Promise.all([
      this.db
        .select(COLONNE)
        .from(commesse)
        .innerJoin(clienti, eq(clienti.id, commesse.clienteId))
        .leftJoin(responsabile, eq(responsabile.id, commesse.responsabileId))
        .where(where)
        .orderBy(...ordine)
        .limit(limit)
        .offset(offset),
      this.db.select({ n: count() }).from(commesse).innerJoin(clienti, eq(clienti.id, commesse.clienteId)).where(where),
    ]);
    // Risposta
    return { data: righe.map((r) => this.mappa(utente, r)), meta: { page: filtri.page, pageSize: filtri.pageSize, total: tot?.n ?? 0 } };
  }

  // Dettaglio
  async dettaglio(utente: UtenteAutenticato, id: string, tx: DbOTransazione = this.db): Promise<Commessa> {
    // Legge la commessa con cliente e responsabile
    const [riga] = await tx
      .select(COLONNE)
      .from(commesse)
      .innerJoin(clienti, eq(clienti.id, commesse.clienteId))
      .leftJoin(responsabile, eq(responsabile.id, commesse.responsabileId))
      .where(and(eq(commesse.id, id), isNull(commesse.deletedAt), condizioneAmbitoCommesse(utente, 'commesse.read')))
      .limit(1);
    // Non trovata
    if (!riga) throw nonTrovato('Commessa');
    // Converte
    return this.mappa(utente, riga);
  }

  // Crea una commessa
  async crea(contesto: ContestoRichiesta, dati: CreaCommessaDati): Promise<Commessa> {
    // Ambito di scrittura
    const ambito = richiediAmbito(contesto.utente, 'commesse.write');
    // Solo chi vede i dati economici può impostarli
    this.verificaDatiEconomici(contesto.utente, dati.valore);
    // Con ambito "propri" il responsabile è sempre chi crea la commessa
    const responsabileId = ambito === 'propri' ? contesto.utente.id : (dati.responsabileId ?? null);
    // Una commessa creata già chiusa senza data di chiusura prende la data odierna
    const dataChiusura = dati.dataChiusura ?? (dati.stato === 'chiusa' ? oggi() : null);
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Il cliente deve esistere ed essere visibile all'utente
      const cliente = await clienteAccessibile(tx, contesto.utente, 'clienti.read', dati.clienteId);
      // Verifica il responsabile
      if (responsabileId) await verificaUtenteAttivo(tx, responsabileId, 'Il responsabile indicato non esiste o non è attivo');
      // Genera il codice nell'anno corrente
      const codice = await prossimoCodiceCommessa(tx, new Date().getFullYear());
      // Inserisce la commessa
      const [nuova] = await tx
        .insert(commesse)
        .values({
          codice,
          clienteId: dati.clienteId,
          titolo: dati.titolo,
          descrizione: dati.descrizione ?? null,
          tipo: dati.tipo,
          stato: dati.stato,
          // Numeric: si passa come stringa con due decimali per non perdere precisione
          valore: dati.valore == null ? null : dati.valore.toFixed(2),
          dataApertura: dati.dataApertura,
          dataChiusura,
          responsabileId,
          createdById: contesto.utente.id,
          updatedById: contesto.utente.id,
        })
        .returning();
      // Registra la creazione
      await this.audit.registra(tx, contesto, { azione: 'creazione', entita: 'commessa', entitaId: nuova!.id, descrizione: `${codice} ${cliente.ragioneSociale} - ${nuova!.titolo}`, dopo: nuova! });
      // Restituisce il dettaglio
      return this.dettaglio(contesto.utente, nuova!.id, tx);
    });
  }

  // Modifica una commessa
  async aggiorna(contesto: ContestoRichiesta, id: string, dati: AggiornaCommessaDati): Promise<Commessa> {
    // Ambito di scrittura
    const ambito = richiediAmbito(contesto.utente, 'commesse.write');
    // Controllo sui dati economici
    this.verificaDatiEconomici(contesto.utente, dati.valore);
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Carica la commessa verificando l'accesso in scrittura
      const attuale = await commessaAccessibile(tx, contesto.utente, 'commesse.write', id);
      // Con ambito "propri" non si può passare la commessa a un altro responsabile
      if (ambito === 'propri' && dati.responsabileId !== undefined && dati.responsabileId !== contesto.utente.id) {
        throw permessoNegato('Non puoi assegnare la commessa a un altro responsabile');
      }
      // Verifica il nuovo responsabile
      if (dati.responsabileId) await verificaUtenteAttivo(tx, dati.responsabileId, 'Il responsabile indicato non esiste o non è attivo');
      // Date risultanti dopo la modifica
      const dataApertura = dati.dataApertura ?? attuale.dataApertura;
      // Chiusura: valore esplicito, oppure data odierna se si sta chiudendo ora, altrimenti quella attuale
      let dataChiusura = dati.dataChiusura !== undefined ? dati.dataChiusura : attuale.dataChiusura;
      // Passaggio a "chiusa" senza data: imposta oggi
      if (dati.stato === 'chiusa' && !dataChiusura) dataChiusura = oggi();
      // Coerenza delle date (messaggio chiaro prima del vincolo del database)
      if (dataChiusura && dataChiusura < dataApertura) throw regolaViolata('La data di chiusura non può precedere la data di apertura');
      // Separa il valore (da convertire) dagli altri campi
      const { valore, ...altri } = dati;
      // Salva
      const [aggiornata] = await tx
        .update(commesse)
        .set({
          ...altri,
          dataChiusura,
          // Il valore si aggiorna solo se presente nella richiesta
          ...(valore !== undefined ? { valore: valore === null ? null : valore.toFixed(2) } : {}),
          updatedById: contesto.utente.id,
        })
        .where(eq(commesse.id, id))
        .returning();
      // Registra le differenze
      await this.audit.registra(tx, contesto, { azione: 'modifica', entita: 'commessa', entitaId: id, descrizione: `${attuale.codice} ${aggiornata!.titolo}`, prima: attuale, dopo: aggiornata! });
      // Restituisce il dettaglio
      return this.dettaglio(contesto.utente, id, tx);
    });
  }

  // Eliminazione logica
  async elimina(contesto: ContestoRichiesta, id: string): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Carica verificando il permesso di eliminazione
      const attuale = await commessaAccessibile(tx, contesto.utente, 'commesse.delete', id);
      // Imposta la data di eliminazione
      await tx.update(commesse).set({ deletedAt: new Date(), updatedById: contesto.utente.id }).where(eq(commesse.id, id));
      // Registra
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'commessa', entitaId: id, descrizione: `${attuale.codice} ${attuale.titolo}` });
    });
  }

  // ------------------------------- Metodi di supporto --------------------------------

  // Blocca l'impostazione del valore da parte di chi non ha il permesso sui dati economici
  private verificaDatiEconomici(utente: UtenteAutenticato, valore: number | null | undefined): void {
    // Campo non inviato: nessun controllo
    if (valore === undefined) return;
    // Campo inviato senza permesso: 403 esplicito
    if (!haPermesso(utente, 'economici.read')) throw permessoNegato('Non hai il permesso di gestire i dati economici');
  }

}
