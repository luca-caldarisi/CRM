// =====================================================================================
// Controllo di accesso alle commesse con applicazione dell'ambito
// =====================================================================================

// Importa gli operatori di query
import { and, eq, isNull, type SQL } from 'drizzle-orm';
// Importa il tipo dei codici permesso
import type { CodicePermesso } from '@crm/shared';
// Importa database e tabelle
import type { DbOTransazione } from '../../database/client';
import { commesse } from '../../database/schema';
// Importa ambito ed eccezioni
import { richiediAmbito } from '../../common/auth/ambito';
import type { UtenteAutenticato } from '../../common/auth/tipi';
import { nonTrovato } from '../../common/errori/errori';

// Condizione SQL che limita le commesse all'ambito dell'utente
export function condizioneAmbitoCommesse(utente: UtenteAutenticato, permesso: CodicePermesso): SQL | undefined {
  // Legge l'ambito (403 se il permesso manca)
  const ambito = richiediAmbito(utente, permesso);
  // Ambito "propri": solo le commesse di cui l'utente è responsabile
  return ambito === 'propri' ? eq(commesse.responsabileId, utente.id) : undefined;
}

// Carica una commessa non eliminata e accessibile all'utente; altrimenti 404
export async function commessaAccessibile(tx: DbOTransazione, utente: UtenteAutenticato, permesso: CodicePermesso, commessaId: string) {
  // Cerca applicando id, soft delete e ambito
  const [commessa] = await tx
    .select()
    .from(commesse)
    .where(and(eq(commesse.id, commessaId), isNull(commesse.deletedAt), condizioneAmbitoCommesse(utente, permesso)))
    .limit(1);
  // Inesistente o fuori ambito
  if (!commessa) throw nonTrovato('Commessa');
  // Restituisce la commessa
  return commessa;
}
