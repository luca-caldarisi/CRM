// =====================================================================================
// API commesse: /api/v1/commesse
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post, Query } from '@nestjs/common';
// Importa la creazione dei DTO
import { createZodDto } from 'nestjs-zod';
// Importa schemi condivisi
import { aggiornaCommessaSchema, creaCommessaSchema, filtriCommesseSchema, parametroIdSchema } from '@crm/shared';
// Importa decoratori di accesso
import { Contesto, RichiedePermesso, UtenteCorrente } from '../../common/auth/decoratori';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
// Importa il service
import { CommesseService } from './commesse.service';

// DTO
class FiltriCommesseDto extends createZodDto(filtriCommesseSchema) {}
class CreaCommessaDto extends createZodDto(creaCommessaSchema) {}
class AggiornaCommessaDto extends createZodDto(aggiornaCommessaSchema) {}
class ParametroIdDto extends createZodDto(parametroIdSchema) {}

@Controller('commesse')
export class CommesseController {
  // Riceve il service
  constructor(private readonly commesse: CommesseService) {}

  // GET /api/v1/commesse
  @Get()
  @RichiedePermesso('commesse.read')
  lista(@UtenteCorrente() utente: UtenteAutenticato, @Query() filtri: FiltriCommesseDto) {
    return this.commesse.lista(utente, filtri);
  }

  // GET /api/v1/commesse/:id
  @Get(':id')
  @RichiedePermesso('commesse.read')
  dettaglio(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto) {
    return this.commesse.dettaglio(utente, id);
  }

  // POST /api/v1/commesse
  @Post()
  @RichiedePermesso('commesse.write')
  crea(@Contesto() contesto: ContestoRichiesta, @Body() dati: CreaCommessaDto) {
    return this.commesse.crea(contesto, dati);
  }

  // PATCH /api/v1/commesse/:id
  @Patch(':id')
  @RichiedePermesso('commesse.write')
  aggiorna(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaCommessaDto) {
    return this.commesse.aggiorna(contesto, id, dati);
  }

  // DELETE /api/v1/commesse/:id
  @Delete(':id')
  @RichiedePermesso('commesse.delete')
  @HttpCode(HttpStatus.NO_CONTENT)
  elimina(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.commesse.elimina(contesto, id);
  }
}
