// =====================================================================================
// Servizio del registro attività (audit log)
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { and, count, desc, eq, gte, lt, type SQL } from 'drizzle-orm';
// Importa i tipi condivisi
import type { AzioneAudit, RispostaPaginata, VoceAudit } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { auditLog, utenti } from '../../database/schema';
// Importa i tipi di contesto
import type { ContestoRichiesta } from '../../common/auth/tipi';
// Importa utilità
import { limitOffset } from '../../common/utils/query';
import { calcolaModifiche } from '../../common/utils/diff';

// Dati di una nuova voce di audit
export interface NuovaVoceAudit {
  // Azione eseguita
  azione: AzioneAudit;
  // Tipo di entità
  entita: string;
  // Identificativo dell'entità
  entitaId?: string | null;
  // Descrizione leggibile (es. ragione sociale)
  descrizione?: string | null;
  // Stato precedente del record (per le modifiche)
  prima?: Record<string, unknown> | null;
  // Stato successivo del record
  dopo?: Record<string, unknown> | null;
}

// Filtri del registro (già validati dallo schema condiviso)
export interface FiltriAudit {
  page: number;
  pageSize: number;
  entita?: string;
  entitaId?: string;
  utenteId?: string;
  azione?: AzioneAudit;
  dal?: string;
  al?: string;
}

@Injectable()
export class AuditService {
  // Riceve il database
  constructor(@Inject(DB) private readonly db: Database) {}

  // Registra un'azione eseguita da un utente autenticato
  // "tx" permette di scrivere la voce nella stessa transazione della modifica:
  // se la modifica fallisce, anche la voce viene annullata (e viceversa)
  async registra(tx: DbOTransazione, contesto: ContestoRichiesta, voce: NuovaVoceAudit): Promise<void> {
    // Delega al metodo generico passando utente e IP
    await this.registraEvento(tx, contesto.utente.id, contesto.ip, voce);
  }

  // Registra un evento anche senza utente autenticato (es. login fallito)
  async registraEvento(tx: DbOTransazione, utenteId: string | null, ip: string | null, voce: NuovaVoceAudit): Promise<void> {
    // Calcola i soli campi cambiati tra prima e dopo
    const modifiche = voce.prima !== undefined || voce.dopo !== undefined ? calcolaModifiche(voce.prima ?? null, voce.dopo ?? null) : null;
    // Una modifica senza differenze reali non viene registrata
    if (voce.azione === 'modifica' && modifiche === null) return;
    // Inserisce la voce
    await tx.insert(auditLog).values({
      utenteId,
      azione: voce.azione,
      entita: voce.entita,
      entitaId: voce.entitaId ?? null,
      // Tronca la descrizione alla lunghezza della colonna
      descrizione: voce.descrizione ? voce.descrizione.slice(0, 300) : null,
      modifiche,
      ip,
    });
  }

  // Elenco paginato delle voci con filtri
  async lista(filtri: FiltriAudit): Promise<RispostaPaginata<VoceAudit>> {
    // Condizioni WHERE da combinare
    const condizioni: SQL[] = [];
    // Filtro per tipo di entità
    if (filtri.entita) condizioni.push(eq(auditLog.entita, filtri.entita));
    // Filtro per entità specifica
    if (filtri.entitaId) condizioni.push(eq(auditLog.entitaId, filtri.entitaId));
    // Filtro per utente
    if (filtri.utenteId) condizioni.push(eq(auditLog.utenteId, filtri.utenteId));
    // Filtro per azione
    if (filtri.azione) condizioni.push(eq(auditLog.azione, filtri.azione));
    // Dalla mezzanotte del giorno indicato
    if (filtri.dal) condizioni.push(gte(auditLog.createdAt, new Date(`${filtri.dal}T00:00:00`)));
    // Fino alla mezzanotte del giorno successivo (giorno "al" incluso)
    if (filtri.al) {
      // Data di fine
      const fine = new Date(`${filtri.al}T00:00:00`);
      // Aggiunge un giorno
      fine.setDate(fine.getDate() + 1);
      // Condizione "minore di"
      condizioni.push(lt(auditLog.createdAt, fine));
    }
    // Combina le condizioni con AND (undefined se non ce ne sono)
    const where = condizioni.length ? and(...condizioni) : undefined;
    // Calcola limit e offset
    const { limit, offset } = limitOffset(filtri);

    // Esegue in parallelo la query dei dati e il conteggio totale
    const [righe, [totale]] = await Promise.all([
      this.db
        .select({
          id: auditLog.id,
          azione: auditLog.azione,
          entita: auditLog.entita,
          entitaId: auditLog.entitaId,
          descrizione: auditLog.descrizione,
          modifiche: auditLog.modifiche,
          ip: auditLog.ip,
          createdAt: auditLog.createdAt,
          utenteId: utenti.id,
          utenteNome: utenti.nome,
          utenteCognome: utenti.cognome,
        })
        .from(auditLog)
        // LEFT JOIN: le voci senza utente restano visibili
        .leftJoin(utenti, eq(utenti.id, auditLog.utenteId))
        .where(where)
        // Dalla più recente
        .orderBy(desc(auditLog.createdAt))
        .limit(limit)
        .offset(offset),
      this.db.select({ n: count() }).from(auditLog).where(where),
    ]);

    // Converte le righe nel formato dell'API
    return {
      data: righe.map((r) => ({
        id: r.id,
        azione: r.azione,
        entita: r.entita,
        entitaId: r.entitaId,
        descrizione: r.descrizione,
        modifiche: r.modifiche ?? null,
        ip: r.ip,
        createdAt: r.createdAt.toISOString(),
        utente: r.utenteId ? { id: r.utenteId, nome: r.utenteNome!, cognome: r.utenteCognome! } : null,
      })),
      meta: { page: filtri.page, pageSize: filtri.pageSize, total: totale?.n ?? 0 },
    };
  }
}
