// =====================================================================================
// API del registro attività
// =====================================================================================

// Importa i decoratori di NestJS
import { Controller, Get, Query } from '@nestjs/common';
// Importa la funzione che crea una classe DTO da uno schema Zod
import { createZodDto } from 'nestjs-zod';
// Importa lo schema dei filtri condiviso con il frontend
import { filtriAuditSchema } from '@crm/shared';
// Importa il decoratore dei permessi
import { RichiedePermesso } from '../../common/auth/decoratori';
// Importa il service
import { AuditService } from './audit.service';

// DTO dei filtri: il pipe globale valida la query string con lo schema
class FiltriAuditDto extends createZodDto(filtriAuditSchema) {}

// Tutte le rotte iniziano con /api/v1/audit
@Controller('audit')
export class AuditController {
  // Riceve il service
  constructor(private readonly audit: AuditService) {}

  // GET /api/v1/audit?entita=cliente&entitaId=...&page=1
  @Get()
  // Solo chi ha il permesso di consultare il registro
  @RichiedePermesso('audit.read')
  lista(@Query() filtri: FiltriAuditDto) {
    // Delega al service
    return this.audit.lista(filtri);
  }
}
