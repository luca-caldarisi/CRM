// Modulo del registro attività: globale perché quasi tutti i moduli registrano eventi

// Importa i decoratori di NestJS
import { Global, Module } from '@nestjs/common';
// Importa controller e service
import { AuditController } from './audit.controller';
import { AuditService } from './audit.service';

@Global()
@Module({
  // Rotte esposte
  controllers: [AuditController],
  // Servizi del modulo
  providers: [AuditService],
  // AuditService iniettabile ovunque
  exports: [AuditService],
})
export class AuditModule {}
