// =====================================================================================
// Gestione dei token: emissione access token JWT e rotazione dei refresh token
// -------------------------------------------------------------------------------------
// - Access token: JWT firmato, breve durata (15 min), tenuto solo in memoria dal frontend
// - Refresh token: stringa casuale opaca in cookie httpOnly; nel DB se ne salva solo l'hash.
//   A ogni utilizzo viene sostituito da uno nuovo (rotazione). Se un token già sostituito
//   viene riutilizzato, significa che è stato copiato: si revoca l'intera famiglia.
// =====================================================================================

// Importa le funzioni crittografiche di Node
import { createHash, randomBytes } from 'node:crypto';
// Importa i decoratori di NestJS
import { Inject, Injectable, HttpStatus } from '@nestjs/common';
// Importa il servizio JWT
import { JwtService } from '@nestjs/jwt';
// Importa gli operatori di query
import { and, eq, isNull } from 'drizzle-orm';
// Importa tipi e costanti condivisi
import { CODICI_ERRORE_AUTH, type MappaPermessi } from '@crm/shared';
// Importa configurazione e database
import { ENV, type Env } from '../../config/env';
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { ruoliPermessi, sessioni, utenti } from '../../database/schema';
// Importa eccezioni e tipi
import { ErroreApi, nonAutenticato } from '../../common/errori/errori';
import type { PayloadAccessToken } from '../../common/auth/tipi';
// Importa il generatore di UUID
import { uuidv7 } from '../../common/utils/uuidv7';

// Tempo (ms) entro cui il riutilizzo di un token appena ruotato è considerato una richiesta concorrente
// e non un furto (es. due schede del browser che rinnovano la sessione nello stesso istante)
const FINESTRA_CONCORRENZA_MS = 30_000;

// Coppia di token restituita a login e refresh
export interface CoppiaToken {
  // JWT per l'header Authorization
  accessToken: string;
  // Durata dell'access token in secondi
  scadeTraSecondi: number;
  // Token opaco da mettere nel cookie
  refreshToken: string;
}

// Informazioni sul client che richiede i token
export interface InfoClient {
  ip: string | null;
  userAgent: string | null;
}

// Calcola l'hash SHA-256 esadecimale di un refresh token
// (SHA-256 basta: il token ha 256 bit casuali, non serve un algoritmo lento come per le password)
export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}

@Injectable()
export class SessioniService {
  constructor(
    // Servizio JWT configurato nel modulo
    private readonly jwt: JwtService,
    // Configurazione
    @Inject(ENV) private readonly env: Env,
    // Database
    @Inject(DB) private readonly db: Database,
  ) {}

  // Legge i permessi di un ruolo e li restituisce come mappa codice -> ambito
  async permessiDelRuolo(tx: DbOTransazione, ruoloId: string): Promise<MappaPermessi> {
    // Seleziona le righe della tabella ponte
    const righe = await tx.select({ codice: ruoliPermessi.permessoCodice, ambito: ruoliPermessi.ambito }).from(ruoliPermessi).where(eq(ruoliPermessi.ruoloId, ruoloId));
    // Converte l'elenco in oggetto
    return Object.fromEntries(righe.map((r) => [r.codice, r.ambito])) as MappaPermessi;
  }

  // Firma un nuovo access token per l'utente
  async emettiAccessToken(tx: DbOTransazione, utente: { id: string; ruoloId: string; permVersion: number }): Promise<{ token: string; scadeTraSecondi: number }> {
    // Carica i permessi attuali del ruolo
    const prm = await this.permessiDelRuolo(tx, utente.ruoloId);
    // Contenuto del token
    const payload: PayloadAccessToken = { sub: utente.id, pv: utente.permVersion, rid: utente.ruoloId, prm };
    // Durata in secondi
    const scadeTraSecondi = this.env.JWT_ACCESS_TTL_MIN * 60;
    // Firma il token (algoritmo, issuer e audience sono impostati nel JwtModule)
    const token = await this.jwt.signAsync(payload, { expiresIn: scadeTraSecondi });
    // Restituisce token e durata
    return { token, scadeTraSecondi };
  }

  // Crea una nuova sessione (refresh token) appartenente a una famiglia
  async creaSessione(tx: DbOTransazione, utenteId: string, famigliaId: string, client: InfoClient): Promise<string> {
    // Genera 32 byte casuali codificati in base64url (sicuri da usare in un cookie)
    const refreshToken = randomBytes(32).toString('base64url');
    // Calcola la scadenza
    const scadeIl = new Date(Date.now() + this.env.REFRESH_TTL_GIORNI * 24 * 60 * 60 * 1000);
    // Salva solo l'hash del token
    await tx.insert(sessioni).values({
      utenteId,
      famigliaId,
      tokenHash: hashToken(refreshToken),
      scadeIl,
      ip: client.ip,
      // Tronca lo user agent alla lunghezza della colonna
      userAgent: client.userAgent?.slice(0, 300) ?? null,
    });
    // Restituisce il token in chiaro (andrà solo nel cookie)
    return refreshToken;
  }

  // Emette access token + refresh token per un login riuscito (nuova famiglia di sessioni)
  async emettiPerLogin(tx: DbOTransazione, utente: { id: string; ruoloId: string; permVersion: number }, client: InfoClient): Promise<CoppiaToken> {
    // Crea il refresh token con una nuova famiglia
    const refreshToken = await this.creaSessione(tx, utente.id, uuidv7(), client);
    // Firma l'access token
    const { token, scadeTraSecondi } = await this.emettiAccessToken(tx, utente);
    // Restituisce la coppia
    return { accessToken: token, scadeTraSecondi, refreshToken };
  }

  // Rinnova la sessione a partire da un refresh token (rotazione)
  async ruota(refreshToken: string, client: InfoClient): Promise<CoppiaToken> {
    // Calcola l'hash del token ricevuto
    const tokenHash = hashToken(refreshToken);
    // Esegue tutto in una transazione; restituisce null se è stato rilevato il riutilizzo di un token
    const esito = await this.db.transaction(async (tx): Promise<CoppiaToken | null> => {
      // Cerca la sessione con i dati dell'utente
      const [riga] = await tx
        .select({ sessione: sessioni, utente: { id: utenti.id, ruoloId: utenti.ruoloId, permVersion: utenti.permVersion, attivo: utenti.attivo } })
        .from(sessioni)
        .innerJoin(utenti, eq(utenti.id, sessioni.utenteId))
        .where(eq(sessioni.tokenHash, tokenHash))
        .limit(1);

      // Token sconosciuto
      if (!riga) throw nonAutenticato(CODICI_ERRORE_AUTH.tokenNonValido, 'Sessione non valida');
      // Estrae sessione e utente
      const { sessione, utente } = riga;
      // Adesso
      const ora = Date.now();

      // Sessione revocata (logout, cambio password, disattivazione)
      if (sessione.revocataIl) throw nonAutenticato(CODICI_ERRORE_AUTH.tokenNonValido, 'Sessione terminata');

      // Token già sostituito da uno più recente
      if (sessione.sostituitaIl) {
        // Sostituito da pochi secondi: richiesta concorrente da un'altra scheda, il client deve riprovare
        if (ora - sessione.sostituitaIl.getTime() < FINESTRA_CONCORRENZA_MS) {
          throw new ErroreApi(HttpStatus.CONFLICT, CODICI_ERRORE_AUTH.refreshInCorso, 'Rinnovo in corso', 'Sessione appena rinnovata, riprova');
        }
        // Riutilizzo di un vecchio token: possibile furto. Revoca tutta la famiglia
        await this.revocaFamiglia(tx, sessione.famigliaId);
        // Restituisce null invece di lanciare l'errore: un'eccezione annullerebbe la transazione e quindi anche la revoca
        return null;
      }

      // Token scaduto
      if (sessione.scadeIl.getTime() <= ora) throw nonAutenticato(CODICI_ERRORE_AUTH.tokenNonValido, 'Sessione scaduta');
      // Utente disattivato nel frattempo
      if (!utente.attivo) throw nonAutenticato(CODICI_ERRORE_AUTH.tokenNonValido, 'Account non attivo');

      // Marca il token come sostituito solo se nessun'altra richiesta l'ha appena fatto (update condizionale atomico)
      const aggiornate = await tx
        .update(sessioni)
        .set({ sostituitaIl: new Date(ora) })
        .where(and(eq(sessioni.id, sessione.id), isNull(sessioni.sostituitaIl), isNull(sessioni.revocataIl)))
        .returning({ id: sessioni.id });
      // Un'altra richiesta concorrente ha vinto la corsa
      if (aggiornate.length === 0) {
        throw new ErroreApi(HttpStatus.CONFLICT, CODICI_ERRORE_AUTH.refreshInCorso, 'Rinnovo in corso', 'Sessione appena rinnovata, riprova');
      }

      // Crea il nuovo refresh token nella stessa famiglia
      const nuovoRefresh = await this.creaSessione(tx, utente.id, sessione.famigliaId, client);
      // Firma il nuovo access token con i permessi aggiornati
      const { token, scadeTraSecondi } = await this.emettiAccessToken(tx, utente);
      // Restituisce la nuova coppia
      return { accessToken: token, scadeTraSecondi, refreshToken: nuovoRefresh };
    });
    // Riutilizzo rilevato: la revoca è stata salvata, ora si nega l'accesso
    if (!esito) throw nonAutenticato(CODICI_ERRORE_AUTH.tokenNonValido, 'Sessione non valida');
    // Restituisce la nuova coppia di token
    return esito;
  }

  // Revoca tutte le sessioni di una famiglia (logout o furto rilevato)
  async revocaFamiglia(tx: DbOTransazione, famigliaId: string): Promise<void> {
    // Imposta la data di revoca sulle sessioni non ancora revocate
    await tx.update(sessioni).set({ revocataIl: new Date() }).where(and(eq(sessioni.famigliaId, famigliaId), isNull(sessioni.revocataIl)));
  }

  // Revoca tutte le sessioni di un utente, opzionalmente tranne una famiglia (quella in uso)
  async revocaTutteDellUtente(tx: DbOTransazione, utenteId: string, tranneFamigliaId?: string | null): Promise<void> {
    // Seleziona le sessioni attive dell'utente
    const righe = await tx
      .select({ famigliaId: sessioni.famigliaId })
      .from(sessioni)
      .where(and(eq(sessioni.utenteId, utenteId), isNull(sessioni.revocataIl)));
    // Insieme delle famiglie da revocare
    const famiglie = new Set(righe.map((r) => r.famigliaId));
    // Esclude la famiglia da mantenere
    if (tranneFamigliaId) famiglie.delete(tranneFamigliaId);
    // Revoca ciascuna famiglia
    for (const famigliaId of famiglie) await this.revocaFamiglia(tx, famigliaId);
  }

  // Trova la famiglia a cui appartiene un refresh token (null se sconosciuto)
  async famigliaDelToken(tx: DbOTransazione, refreshToken: string | undefined): Promise<{ famigliaId: string; utenteId: string } | null> {
    // Nessun token
    if (!refreshToken) return null;
    // Cerca per hash
    const [riga] = await tx.select({ famigliaId: sessioni.famigliaId, utenteId: sessioni.utenteId }).from(sessioni).where(eq(sessioni.tokenHash, hashToken(refreshToken))).limit(1);
    // Restituisce la famiglia o null
    return riga ?? null;
  }
}
