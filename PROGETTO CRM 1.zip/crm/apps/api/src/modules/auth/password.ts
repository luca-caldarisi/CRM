// =====================================================================================
// Hashing e verifica delle password con argon2id
// -------------------------------------------------------------------------------------
// argon2id è l'algoritmo raccomandato da OWASP: è lento e usa molta memoria di proposito,
// così un attaccante che ruba il database non può provare miliardi di password al secondo.
// =====================================================================================

// Importa la funzione per generare byte casuali sicuri
import { randomInt } from 'node:crypto';
// Importa la libreria argon2 (modulo nativo)
import * as argon2 from 'argon2';

// Parametri raccomandati da OWASP per argon2id (19 MiB di memoria, 2 iterazioni, 1 thread)
const OPZIONI = {
  // Variante resistente sia ad attacchi GPU sia side-channel
  type: argon2.argon2id as 2,
  // Memoria in KiB
  memoryCost: 19_456,
  // Numero di iterazioni
  timeCost: 2,
  // Grado di parallelismo
  parallelism: 1,
} satisfies argon2.HashOptions;

// Calcola l'hash di una password (il sale casuale è generato e incluso automaticamente nell'hash)
export function hashPassword(password: string): Promise<string> {
  return argon2.hash(password, OPZIONI);
}

// Verifica una password rispetto a un hash salvato
export async function verificaPassword(hash: string, password: string): Promise<boolean> {
  try {
    // Confronto a tempo costante eseguito dalla libreria
    return await argon2.verify(hash, password);
  } catch {
    // Hash malformato: la password non è valida
    return false;
  }
}

// true se l'hash è stato creato con parametri diversi da quelli attuali e va ricalcolato al prossimo login
export function richiedeRehash(hash: string): boolean {
  return argon2.needsRehash(hash, OPZIONI);
}

// Hash fittizio usato quando l'email non esiste: il login impiega lo stesso tempo
// e un attaccante non può capire dai tempi di risposta quali email sono registrate
let hashFittizio: Promise<string> | null = null;
export function ottieniHashFittizio(): Promise<string> {
  // Calcolato una sola volta e riutilizzato
  hashFittizio ??= hashPassword('password-fittizia-per-tempo-costante');
  return hashFittizio;
}

// Caratteri usati per le password temporanee (esclusi quelli ambigui come 0/O e 1/l/I)
const ALFABETO = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';

// Genera una password temporanea casuale e leggibile (es. "Kx7m-Pq3r-Za9w-Hn2b")
export function generaPasswordTemporanea(): string {
  // Quattro gruppi da quattro caratteri
  const gruppi: string[] = [];
  // Genera ogni gruppo
  for (let g = 0; g < 4; g++) {
    // Caratteri del gruppo
    let gruppo = '';
    // Sceglie 4 caratteri con un generatore crittograficamente sicuro
    for (let i = 0; i < 4; i++) gruppo += ALFABETO[randomInt(ALFABETO.length)];
    // Aggiunge il gruppo
    gruppi.push(gruppo);
  }
  // Unisce i gruppi con un trattino: 19 caratteri, circa 92 bit di entropia
  return gruppi.join('-');
}
