// =====================================================================================
// Logica di autenticazione: login, refresh, logout, profilo, cambio password
// =====================================================================================

// Importa i decoratori di NestJS
import { HttpStatus, Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { eq, sql } from 'drizzle-orm';
// Importa tipi condivisi
import type { CambiaPasswordDati, UtenteSessione } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database } from '../../database/client';
import { ruoli, utenti } from '../../database/schema';
// Importa eccezioni e tipi
import { ErroreApi, regolaViolata } from '../../common/errori/errori';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
// Importa il servizio di audit
import { AuditService } from '../audit/audit.service';
// Importa le funzioni per le password
import { hashPassword, ottieniHashFittizio, richiedeRehash, verificaPassword } from './password';
// Importa il servizio delle sessioni
import { type CoppiaToken, type InfoClient, SessioniService } from './sessioni.service';

// Numero di tentativi falliti prima del blocco temporaneo
const TENTATIVI_PRIMA_DEL_BLOCCO = 5;
// Durata del primo blocco in minuti (raddoppia a ogni ulteriore serie di tentativi falliti)
const MINUTI_BLOCCO_BASE = 15;
// Durata massima di un blocco in minuti (24 ore)
const MINUTI_BLOCCO_MAX = 24 * 60;

// Errore generico di credenziali: stesso messaggio per email inesistente e password errata
function credenzialiNonValide(): ErroreApi {
  return new ErroreApi(HttpStatus.UNAUTHORIZED, 'credenziali_non_valide', 'Accesso negato', 'Email o password non corretti');
}

@Injectable()
export class AuthService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Gestione token
    private readonly sessioni: SessioniService,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // Verifica le credenziali e, se corrette, apre una nuova sessione
  async login(email: string, password: string, client: InfoClient): Promise<CoppiaToken> {
    // Cerca l'utente per email (confronto su minuscolo, coerente con l'indice univoco)
    const [utente] = await this.db.select().from(utenti).where(eq(sql`lower(${utenti.email})`, email.toLowerCase())).limit(1);

    // Email inesistente
    if (!utente) {
      // Esegue comunque una verifica argon2 per avere lo stesso tempo di risposta
      await verificaPassword(await ottieniHashFittizio(), password);
      // Registra il tentativo senza utente
      await this.audit.registraEvento(this.db, null, client.ip, { azione: 'login_fallito', entita: 'sessione', descrizione: `Email sconosciuta: ${email}` });
      // Errore generico
      throw credenzialiNonValide();
    }

    // Account bloccato temporaneamente per troppi tentativi
    if (utente.bloccatoFinoA && utente.bloccatoFinoA.getTime() > Date.now()) {
      // Minuti mancanti allo sblocco (arrotondati per eccesso)
      const minuti = Math.ceil((utente.bloccatoFinoA.getTime() - Date.now()) / 60_000);
      // Errore esplicito: aiuta l'utente legittimo a capire cosa succede
      throw new ErroreApi(HttpStatus.UNAUTHORIZED, 'account_bloccato', 'Accesso negato', `Account bloccato per troppi tentativi. Riprova tra ${minuti} minuti o contatta un amministratore.`);
    }

    // Verifica la password
    const valida = await verificaPassword(utente.passwordHash, password);

    // Password errata
    if (!valida) {
      // Nuovo numero di tentativi falliti
      const tentativi = utente.tentativiFalliti + 1;
      // Ogni 5 tentativi scatta un blocco; la durata raddoppia a ogni serie (15, 30, 60 min ...)
      const serie = Math.floor(tentativi / TENTATIVI_PRIMA_DEL_BLOCCO);
      // Calcola la data di sblocco solo quando si completa una serie
      const bloccatoFinoA =
        tentativi % TENTATIVI_PRIMA_DEL_BLOCCO === 0
          ? new Date(Date.now() + Math.min(MINUTI_BLOCCO_BASE * 2 ** (serie - 1), MINUTI_BLOCCO_MAX) * 60_000)
          : utente.bloccatoFinoA;
      // Salva contatore e blocco, e registra l'evento nella stessa transazione
      await this.db.transaction(async (tx) => {
        // Aggiorna l'utente
        await tx.update(utenti).set({ tentativiFalliti: tentativi, bloccatoFinoA }).where(eq(utenti.id, utente.id));
        // Registra il tentativo fallito
        await this.audit.registraEvento(tx, utente.id, client.ip, { azione: 'login_fallito', entita: 'sessione', descrizione: `Password errata (tentativo ${tentativi})` });
      });
      // Errore generico
      throw credenzialiNonValide();
    }

    // Account disattivato: stesso messaggio generico
    if (!utente.attivo) throw credenzialiNonValide();

    // Login riuscito: tutto in una transazione
    return this.db.transaction(async (tx) => {
      // Dati da aggiornare sull'utente
      const aggiornamento: Partial<typeof utenti.$inferInsert> = { tentativiFalliti: 0, bloccatoFinoA: null, ultimoAccesso: new Date() };
      // Se i parametri di hashing sono cambiati, ricalcola l'hash ora che si conosce la password
      if (richiedeRehash(utente.passwordHash)) aggiornamento.passwordHash = await hashPassword(password);
      // Salva
      await tx.update(utenti).set(aggiornamento).where(eq(utenti.id, utente.id));
      // Registra l'accesso
      await this.audit.registraEvento(tx, utente.id, client.ip, { azione: 'login', entita: 'sessione', descrizione: client.userAgent?.slice(0, 200) ?? null });
      // Emette i token
      return this.sessioni.emettiPerLogin(tx, utente, client);
    });
  }

  // Rinnova i token a partire dal refresh token
  refresh(refreshToken: string | undefined, client: InfoClient): Promise<CoppiaToken> {
    // Cookie assente: sessione non valida
    if (!refreshToken) {
      throw new ErroreApi(HttpStatus.UNAUTHORIZED, 'token_non_valido', 'Non autenticato', 'Sessione non presente');
    }
    // Delega la rotazione
    return this.sessioni.ruota(refreshToken, client);
  }

  // Termina la sessione corrente (tutta la famiglia di token nata dallo stesso login)
  async logout(refreshToken: string | undefined, ip: string | null): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Trova la famiglia del token
      const famiglia = await this.sessioni.famigliaDelToken(tx, refreshToken);
      // Token sconosciuto: niente da fare (il logout è comunque considerato riuscito)
      if (!famiglia) return;
      // Revoca la famiglia
      await this.sessioni.revocaFamiglia(tx, famiglia.famigliaId);
      // Registra l'uscita
      await this.audit.registraEvento(tx, famiglia.utenteId, ip, { azione: 'logout', entita: 'sessione' });
    });
  }

  // Profilo dell'utente autenticato
  async profilo(utente: UtenteAutenticato): Promise<UtenteSessione> {
    // Legge i dati del ruolo
    const [ruolo] = await this.db.select({ id: ruoli.id, nome: ruoli.nome, diSistema: ruoli.diSistema }).from(ruoli).where(eq(ruoli.id, utente.ruoloId)).limit(1);
    // Il ruolo esiste sempre (vincolo di chiave esterna)
    if (!ruolo) throw new Error('Ruolo utente non trovato');
    // Compone la risposta
    return {
      id: utente.id,
      email: utente.email,
      nome: utente.nome,
      cognome: utente.cognome,
      ruolo,
      permessi: utente.permessi,
      deveCambiarePassword: utente.deveCambiarePassword,
    };
  }

  // Cambia la password dell'utente autenticato e chiude le sue altre sessioni
  async cambiaPassword(contesto: ContestoRichiesta, dati: CambiaPasswordDati, refreshTokenCorrente: string | undefined): Promise<void> {
    // Legge l'hash attuale
    const [utente] = await this.db.select({ passwordHash: utenti.passwordHash }).from(utenti).where(eq(utenti.id, contesto.utente.id)).limit(1);
    // Verifica la password attuale (protegge da chi trova un computer lasciato sbloccato)
    if (!utente || !(await verificaPassword(utente.passwordHash, dati.passwordAttuale))) {
      throw regolaViolata('La password attuale non è corretta');
    }
    // Calcola l'hash della nuova password
    const nuovoHash = await hashPassword(dati.nuovaPassword);
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Salva il nuovo hash e rimuove l'obbligo di cambio password
      await tx.update(utenti).set({ passwordHash: nuovoHash, deveCambiarePassword: false }).where(eq(utenti.id, contesto.utente.id));
      // Trova la sessione in uso per non disconnettere l'utente che sta cambiando la password
      const corrente = await this.sessioni.famigliaDelToken(tx, refreshTokenCorrente);
      // Revoca tutte le altre sessioni (altri dispositivi, eventuali sessioni rubate)
      await this.sessioni.revocaTutteDellUtente(tx, contesto.utente.id, corrente?.utenteId === contesto.utente.id ? corrente.famigliaId : null);
      // Registra l'evento (senza alcuna informazione sulla password)
      await this.audit.registra(tx, contesto, { azione: 'cambio_password', entita: 'utente', entitaId: contesto.utente.id });
    });
  }
}
