// =====================================================================================
// Modulo di autenticazione
// =====================================================================================

// Importa i decoratori di NestJS
import { Global, Module } from '@nestjs/common';
// Importa il modulo JWT
import { JwtModule } from '@nestjs/jwt';
// Importa configurazione
import { ENV, type Env } from '../../config/env';
// Importa componenti del modulo
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { SessioniService } from './sessioni.service';

// Globale: SessioniService e JwtService servono anche al guard e al modulo utenti
@Global()
@Module({
  imports: [
    // Configura JWT leggendo il segreto dalla configurazione validata
    JwtModule.registerAsync({
      inject: [ENV],
      useFactory: (env: Env) => ({
        // Segreto di firma
        secret: env.JWT_SECRET,
        // Opzioni di firma
        signOptions: { algorithm: 'HS256', issuer: 'crm-api', audience: 'crm-web' },
        // Opzioni di verifica: accetta SOLO HS256 (evita attacchi di confusione dell'algoritmo) e controlla issuer/audience
        verifyOptions: { algorithms: ['HS256'], issuer: 'crm-api', audience: 'crm-web' },
      }),
    }),
  ],
  // Rotte
  controllers: [AuthController],
  // Servizi
  providers: [AuthService, SessioniService],
  // Esportati per guard e altri moduli
  exports: [SessioniService, JwtModule],
})
export class AuthModule {}
