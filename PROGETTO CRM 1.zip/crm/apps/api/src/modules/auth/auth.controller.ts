// =====================================================================================
// API di autenticazione: /api/v1/auth/...
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Get, HttpCode, HttpStatus, Inject, Post, Req, Res } from '@nestjs/common';
// Importa il decoratore per limitare la frequenza delle richieste
import { Throttle } from '@nestjs/throttler';
// Importa la creazione dei DTO da schemi Zod
import { createZodDto } from 'nestjs-zod';
// Importa i tipi di Express
import type { CookieOptions, Request, Response } from 'express';
// Importa schemi e tipi condivisi
import { cambiaPasswordSchema, loginSchema, type RispostaToken, type UtenteSessione } from '@crm/shared';
// Importa configurazione
import { ENV, type Env } from '../../config/env';
// Importa decoratori di accesso
import { ConsentitoConCambioPassword, Contesto, Pubblico, SoloAutenticato, UtenteCorrente } from '../../common/auth/decoratori';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
// Importa l'eccezione di permesso negato
import { permessoNegato } from '../../common/errori/errori';
// Importa il service
import { AuthService } from './auth.service';
import type { CoppiaToken } from './sessioni.service';

// DTO del login
class LoginDto extends createZodDto(loginSchema) {}
// DTO del cambio password
class CambiaPasswordDto extends createZodDto(cambiaPasswordSchema) {}

// Nome del cookie che contiene il refresh token
export const NOME_COOKIE_REFRESH = 'crm_rt';
// Percorso a cui il browser invia il cookie: solo le rotte di autenticazione, non tutte le API
const PERCORSO_COOKIE = '/api/v1/auth';

@Controller('auth')
export class AuthController {
  constructor(
    // Service di autenticazione
    private readonly auth: AuthService,
    // Configurazione
    @Inject(ENV) private readonly env: Env,
  ) {}

  // POST /api/v1/auth/login
  @Post('login')
  // Accessibile senza token
  @Pubblico()
  // Risponde 200 invece del 201 predefinito per le POST
  @HttpCode(HttpStatus.OK)
  // Limite di richieste al minuto per IP contro gli attacchi a forza bruta
  @Throttle({ default: { limit: Number(process.env.LOGIN_RATE_LIMIT ?? 10), ttl: 60_000 } })
  async login(@Body() dati: LoginDto, @Req() req: Request, @Res({ passthrough: true }) res: Response): Promise<RispostaToken> {
    // Verifica credenziali ed emette i token
    const coppia = await this.auth.login(dati.email, dati.password, this.infoClient(req));
    // Imposta il cookie e restituisce l'access token
    return this.rispondiConToken(res, coppia);
  }

  // POST /api/v1/auth/refresh
  @Post('refresh')
  // Accessibile senza access token (che potrebbe essere scaduto): l'autenticazione avviene tramite cookie
  @Pubblico()
  @HttpCode(HttpStatus.OK)
  async refresh(@Req() req: Request, @Res({ passthrough: true }) res: Response): Promise<RispostaToken> {
    // Difesa CSRF aggiuntiva: la richiesta deve provenire dal frontend del CRM
    this.verificaOrigine(req);
    // Legge il cookie
    const token = req.cookies?.[NOME_COOKIE_REFRESH] as string | undefined;
    try {
      // Ruota il token
      const coppia = await this.auth.refresh(token, this.infoClient(req));
      // Imposta il nuovo cookie e restituisce il nuovo access token
      return this.rispondiConToken(res, coppia);
    } catch (errore) {
      // Se la sessione non è valida cancella il cookie (tranne nel caso di richiesta concorrente, che va riprovata)
      if ((errore as { getStatus?: () => number }).getStatus?.() === HttpStatus.UNAUTHORIZED) this.cancellaCookie(res);
      // Rilancia l'errore al filtro globale
      throw errore;
    }
  }

  // POST /api/v1/auth/logout
  @Post('logout')
  @Pubblico()
  // 204: nessun contenuto nella risposta
  @HttpCode(HttpStatus.NO_CONTENT)
  async logout(@Req() req: Request, @Res({ passthrough: true }) res: Response): Promise<void> {
    // Difesa CSRF
    this.verificaOrigine(req);
    // Revoca la sessione indicata dal cookie
    await this.auth.logout(req.cookies?.[NOME_COOKIE_REFRESH] as string | undefined, req.ip ?? null);
    // Cancella il cookie nel browser
    this.cancellaCookie(res);
  }

  // GET /api/v1/auth/me
  @Get('me')
  // Qualsiasi utente autenticato
  @SoloAutenticato()
  // Serve anche quando la password deve essere cambiata (il frontend decide dove mandare l'utente)
  @ConsentitoConCambioPassword()
  me(@UtenteCorrente() utente: UtenteAutenticato): Promise<UtenteSessione> {
    // Restituisce il profilo
    return this.auth.profilo(utente);
  }

  // POST /api/v1/auth/cambia-password
  @Post('cambia-password')
  @SoloAutenticato()
  @ConsentitoConCambioPassword()
  @HttpCode(HttpStatus.NO_CONTENT)
  // Limite anti forza bruta sulla password attuale
  @Throttle({ default: { limit: 10, ttl: 60_000 } })
  async cambiaPassword(@Contesto() contesto: ContestoRichiesta, @Body() dati: CambiaPasswordDto, @Req() req: Request): Promise<void> {
    // Esegue il cambio mantenendo la sessione corrente
    await this.auth.cambiaPassword(contesto, dati, req.cookies?.[NOME_COOKIE_REFRESH] as string | undefined);
  }

  // ------------------------------- Metodi di supporto --------------------------------

  // Opzioni del cookie di sessione
  private opzioniCookie(): CookieOptions {
    return {
      // Non leggibile da JavaScript: un attacco XSS non può rubarlo
      httpOnly: true,
      // Inviato solo su HTTPS (in produzione)
      secure: this.env.COOKIE_SECURE,
      // Mai inviato da richieste provenienti da altri siti (protezione CSRF)
      sameSite: 'strict',
      // Inviato solo alle rotte di autenticazione
      path: PERCORSO_COOKIE,
    };
  }

  // Imposta il cookie del refresh token e restituisce il corpo della risposta
  private rispondiConToken(res: Response, coppia: CoppiaToken): RispostaToken {
    // Scrive il cookie con durata pari a quella della sessione
    res.cookie(NOME_COOKIE_REFRESH, coppia.refreshToken, { ...this.opzioniCookie(), maxAge: this.env.REFRESH_TTL_GIORNI * 24 * 60 * 60 * 1000 });
    // Evita che proxy o browser memorizzino la risposta con il token
    res.setHeader('Cache-Control', 'no-store');
    // L'access token va nel corpo: il frontend lo tiene solo in memoria
    return { accessToken: coppia.accessToken, scadeTraSecondi: coppia.scadeTraSecondi };
  }

  // Cancella il cookie del refresh token
  private cancellaCookie(res: Response): void {
    // Per cancellarlo servono le stesse opzioni (in particolare il path)
    res.clearCookie(NOME_COOKIE_REFRESH, this.opzioniCookie());
  }

  // Estrae IP e user agent del client
  private infoClient(req: Request) {
    return { ip: req.ip ?? null, userAgent: req.headers['user-agent'] ?? null };
  }

  // Rifiuta richieste che dichiarano un'origine diversa da quella del frontend
  private verificaOrigine(req: Request): void {
    // Header Origin inviato dai browser per le richieste POST
    const origine = req.headers.origin;
    // Se presente deve coincidere con APP_ORIGIN
    if (origine && origine !== this.env.APP_ORIGIN) throw permessoNegato('Origine della richiesta non consentita');
  }
}
