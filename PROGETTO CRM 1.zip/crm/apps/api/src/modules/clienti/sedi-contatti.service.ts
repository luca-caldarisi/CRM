// =====================================================================================
// Sedi e contatti di un cliente
// -------------------------------------------------------------------------------------
// Non hanno permessi propri: si leggono con clienti.read e si modificano con clienti.write
// sul cliente di appartenenza (ambito incluso).
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { and, asc, desc, eq, ne } from 'drizzle-orm';
// Importa tipi condivisi
import type { AggiornaContattoDati, AggiornaSedeDati, Contatto, CreaContattoDati, CreaSedeDati, Sede } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { contatti, sedi } from '../../database/schema';
// Importa tipi ed eccezioni
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
import { nonTrovato, regolaViolata } from '../../common/errori/errori';
// Importa il registro attività
import { AuditService } from '../audit/audit.service';
// Importa il controllo di accesso ai clienti
import { clienteAccessibile } from './accesso-clienti';

// Converte una riga sede nel formato API (rimuove i campi di tracciamento)
function mappaSede(s: typeof sedi.$inferSelect): Sede {
  return { id: s.id, clienteId: s.clienteId, tipo: s.tipo, nome: s.nome, indirizzo: s.indirizzo, cap: s.cap, citta: s.citta, provincia: s.provincia, nazione: s.nazione };
}

// Converte una riga contatto nel formato API
function mappaContatto(c: typeof contatti.$inferSelect): Contatto {
  return {
    id: c.id,
    clienteId: c.clienteId,
    nome: c.nome,
    cognome: c.cognome,
    ruoloAziendale: c.ruoloAziendale,
    email: c.email,
    telefono: c.telefono,
    cellulare: c.cellulare,
    principale: c.principale,
    sedeId: c.sedeId,
    note: c.note,
  };
}

@Injectable()
export class SediContattiService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // ------------------------------------- Sedi -----------------------------------------

  // Sedi di un cliente (prima la sede legale)
  async listaSedi(utente: UtenteAutenticato, clienteId: string): Promise<Sede[]> {
    // Verifica l'accesso in lettura al cliente
    await clienteAccessibile(this.db, utente, 'clienti.read', clienteId);
    // Legge le sedi ordinate: "legale" viene prima di "operativa" nell'enum
    const righe = await this.db.select().from(sedi).where(eq(sedi.clienteId, clienteId)).orderBy(asc(sedi.tipo), asc(sedi.citta));
    // Converte
    return righe.map(mappaSede);
  }

  // Crea una sede
  async creaSede(contesto: ContestoRichiesta, clienteId: string, dati: CreaSedeDati): Promise<Sede> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Verifica l'accesso in scrittura al cliente
      const cliente = await clienteAccessibile(tx, contesto.utente, 'clienti.write', clienteId);
      // Inserisce la sede (una seconda sede legale viene bloccata dall'indice univoco parziale -> 409)
      const [nuova] = await tx
        .insert(sedi)
        .values({ ...dati, clienteId, nome: dati.nome ?? null, cap: dati.cap ?? null, provincia: dati.provincia ?? null, nazione: dati.nazione ?? 'IT', createdById: contesto.utente.id, updatedById: contesto.utente.id })
        .returning();
      // Registra la creazione
      await this.audit.registra(tx, contesto, { azione: 'creazione', entita: 'sede', entitaId: nuova!.id, descrizione: `${cliente.ragioneSociale} - ${nuova!.citta}`, dopo: nuova! });
      // Restituisce la sede
      return mappaSede(nuova!);
    });
  }

  // Modifica una sede
  async aggiornaSede(contesto: ContestoRichiesta, id: string, dati: AggiornaSedeDati): Promise<Sede> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Carica la sede e verifica l'accesso al cliente
      const { sede, cliente } = await this.sedeAccessibile(tx, contesto.utente, id);
      // Salva
      const [aggiornata] = await tx.update(sedi).set({ ...dati, updatedById: contesto.utente.id }).where(eq(sedi.id, id)).returning();
      // Registra le modifiche
      await this.audit.registra(tx, contesto, { azione: 'modifica', entita: 'sede', entitaId: id, descrizione: `${cliente.ragioneSociale} - ${aggiornata!.citta}`, prima: sede, dopo: aggiornata! });
      // Restituisce la sede aggiornata
      return mappaSede(aggiornata!);
    });
  }

  // Elimina una sede (i contatti collegati restano, senza sede)
  async eliminaSede(contesto: ContestoRichiesta, id: string): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Carica la sede e verifica l'accesso
      const { sede, cliente } = await this.sedeAccessibile(tx, contesto.utente, id);
      // Elimina fisicamente
      await tx.delete(sedi).where(eq(sedi.id, id));
      // Registra l'eliminazione con i dati della sede (utile per ricostruire lo storico)
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'sede', entitaId: id, descrizione: `${cliente.ragioneSociale} - ${sede.citta}`, prima: sede, dopo: null });
    });
  }

  // ----------------------------------- Contatti ---------------------------------------

  // Contatti di un cliente (prima il principale)
  async listaContatti(utente: UtenteAutenticato, clienteId: string): Promise<Contatto[]> {
    // Verifica l'accesso in lettura
    await clienteAccessibile(this.db, utente, 'clienti.read', clienteId);
    // Legge i contatti ordinati
    const righe = await this.db.select().from(contatti).where(eq(contatti.clienteId, clienteId)).orderBy(desc(contatti.principale), asc(contatti.cognome), asc(contatti.nome));
    // Converte
    return righe.map(mappaContatto);
  }

  // Crea un contatto
  async creaContatto(contesto: ContestoRichiesta, clienteId: string, dati: CreaContattoDati): Promise<Contatto> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Verifica l'accesso in scrittura
      const cliente = await clienteAccessibile(tx, contesto.utente, 'clienti.write', clienteId);
      // La sede, se indicata, deve appartenere allo stesso cliente
      if (dati.sedeId) await this.verificaSedeDelCliente(tx, dati.sedeId, clienteId);
      // Un nuovo contatto principale sostituisce il precedente
      if (dati.principale) await tx.update(contatti).set({ principale: false }).where(and(eq(contatti.clienteId, clienteId), eq(contatti.principale, true)));
      // Inserisce il contatto
      const [nuovo] = await tx
        .insert(contatti)
        .values({
          clienteId,
          nome: dati.nome,
          cognome: dati.cognome ?? null,
          ruoloAziendale: dati.ruoloAziendale ?? null,
          email: dati.email ?? null,
          telefono: dati.telefono ?? null,
          cellulare: dati.cellulare ?? null,
          principale: dati.principale ?? false,
          sedeId: dati.sedeId ?? null,
          note: dati.note ?? null,
          createdById: contesto.utente.id,
          updatedById: contesto.utente.id,
        })
        .returning();
      // Registra la creazione
      await this.audit.registra(tx, contesto, { azione: 'creazione', entita: 'contatto', entitaId: nuovo!.id, descrizione: `${cliente.ragioneSociale} - ${nuovo!.nome} ${nuovo!.cognome ?? ''}`.trim(), dopo: nuovo! });
      // Restituisce il contatto
      return mappaContatto(nuovo!);
    });
  }

  // Modifica un contatto
  async aggiornaContatto(contesto: ContestoRichiesta, id: string, dati: AggiornaContattoDati): Promise<Contatto> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Carica il contatto e verifica l'accesso
      const { contatto, cliente } = await this.contattoAccessibile(tx, contesto.utente, id);
      // Verifica la nuova sede
      if (dati.sedeId) await this.verificaSedeDelCliente(tx, dati.sedeId, contatto.clienteId);
      // Se diventa principale, toglie il flag agli altri contatti del cliente
      if (dati.principale) {
        await tx.update(contatti).set({ principale: false }).where(and(eq(contatti.clienteId, contatto.clienteId), eq(contatti.principale, true), ne(contatti.id, id)));
      }
      // Salva
      const [aggiornato] = await tx.update(contatti).set({ ...dati, updatedById: contesto.utente.id }).where(eq(contatti.id, id)).returning();
      // Registra le modifiche
      await this.audit.registra(tx, contesto, { azione: 'modifica', entita: 'contatto', entitaId: id, descrizione: `${cliente.ragioneSociale} - ${aggiornato!.nome}`, prima: contatto, dopo: aggiornato! });
      // Restituisce il contatto aggiornato
      return mappaContatto(aggiornato!);
    });
  }

  // Elimina un contatto (eliminazione fisica: diritto alla cancellazione GDPR)
  async eliminaContatto(contesto: ContestoRichiesta, id: string): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Carica il contatto e verifica l'accesso
      const { cliente } = await this.contattoAccessibile(tx, contesto.utente, id);
      // Elimina
      await tx.delete(contatti).where(eq(contatti.id, id));
      // Registra solo il fatto, senza i dati personali del contatto eliminato
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'contatto', entitaId: id, descrizione: cliente.ragioneSociale });
    });
  }

  // ------------------------------- Metodi di supporto --------------------------------

  // Carica una sede e verifica l'accesso in scrittura al suo cliente
  private async sedeAccessibile(tx: DbOTransazione, utente: UtenteAutenticato, id: string) {
    // Cerca la sede
    const [sede] = await tx.select().from(sedi).where(eq(sedi.id, id)).limit(1);
    // Non trovata
    if (!sede) throw nonTrovato('Sede');
    // Verifica il cliente (se fuori ambito risponde 404 anche per la sede)
    const cliente = await clienteAccessibile(tx, utente, 'clienti.write', sede.clienteId);
    // Restituisce entrambi
    return { sede, cliente };
  }

  // Carica un contatto e verifica l'accesso in scrittura al suo cliente
  private async contattoAccessibile(tx: DbOTransazione, utente: UtenteAutenticato, id: string) {
    // Cerca il contatto
    const [contatto] = await tx.select().from(contatti).where(eq(contatti.id, id)).limit(1);
    // Non trovato
    if (!contatto) throw nonTrovato('Contatto');
    // Verifica il cliente
    const cliente = await clienteAccessibile(tx, utente, 'clienti.write', contatto.clienteId);
    // Restituisce entrambi
    return { contatto, cliente };
  }

  // Verifica che una sede appartenga al cliente indicato
  private async verificaSedeDelCliente(tx: DbOTransazione, sedeId: string, clienteId: string): Promise<void> {
    // Cerca la sede con entrambe le condizioni
    const [s] = await tx.select({ id: sedi.id }).from(sedi).where(and(eq(sedi.id, sedeId), eq(sedi.clienteId, clienteId))).limit(1);
    // Sede di un altro cliente o inesistente
    if (!s) throw regolaViolata('La sede indicata non appartiene a questo cliente');
  }
}
