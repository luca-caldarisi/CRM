// =====================================================================================
// Anagrafica clienti
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { and, asc, count, eq, ilike, inArray, isNull, or, sql, type SQL } from 'drizzle-orm';
// Importa l'helper per creare alias di tabella
import { alias } from 'drizzle-orm/pg-core';
// Importa tipi condivisi
import type { AggiornaClienteDati, Cliente, ClienteLista, CreaClienteDati, RispostaPaginata } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { clienti, commesse, progetti, sedi, utenti } from '../../database/schema';
// Importa sicurezza, eccezioni e utilità
import { richiediAmbito } from '../../common/auth/ambito';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
import { nonTrovato, permessoNegato, regolaViolata } from '../../common/errori/errori';
import { prossimoCodiceCliente } from '../../common/utils/codici';
import { limitOffset, ordinamento, patternContiene } from '../../common/utils/query';
// Importa le utilità comuni (date e verifiche condivise)
import { verificaUtenteAttivo } from '../../common/utils/verifiche';
// Importa il registro attività
import { AuditService } from '../audit/audit.service';
// Importa il controllo di accesso
import { clienteAccessibile, condizioneAmbitoClienti } from './accesso-clienti';

// Filtri della lista (già validati)
interface FiltriClienti {
  page: number;
  pageSize: number;
  q?: string;
  sort?: string;
  commercialeId?: string;
}

// Stati che rendono una commessa "attiva"
const STATI_COMMESSA_ATTIVI = ['aperta', 'sospesa'] as const;
// Stati che rendono un progetto "attivo" (lavoro ancora da svolgere)
const STATI_PROGETTO_ATTIVI = ['pianificato', 'in_corso', 'sospeso'] as const;

// Alias della tabella utenti usata come "commerciale" nelle join
const commerciale = alias(utenti, 'commerciale');

@Injectable()
export class ClientiService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // Elenco paginato con ricerca e filtri
  async lista(utente: UtenteAutenticato, filtri: FiltriClienti): Promise<RispostaPaginata<ClienteLista>> {
    // Condizioni sempre presenti: non eliminati e ambito dell'utente
    const condizioni: (SQL | undefined)[] = [isNull(clienti.deletedAt), condizioneAmbitoClienti(utente, 'clienti.read')];
    // Ricerca libera su ragione sociale, codice, P.IVA ed email
    if (filtri.q) {
      // Pattern "contiene"
      const p = patternContiene(filtri.q);
      // OR tra i campi
      condizioni.push(or(ilike(clienti.ragioneSociale, p), ilike(clienti.codice, p), ilike(clienti.partitaIva, p), ilike(clienti.email, p)));
    }
    // Filtro per commerciale
    if (filtri.commercialeId) condizioni.push(eq(clienti.commercialeId, filtri.commercialeId));
    // Combina con AND (and() ignora gli undefined)
    const where = and(...condizioni);
    // Ordinamento consentito
    const ordine = ordinamento(filtri.sort, { ragioneSociale: clienti.ragioneSociale, codice: clienti.codice, createdAt: clienti.createdAt, updatedAt: clienti.updatedAt }, [asc(clienti.ragioneSociale)]);
    // Paginazione
    const { limit, offset } = limitOffset(filtri);

    // Query dati e conteggio in parallelo
    const [righe, [tot]] = await Promise.all([
      this.db
        .select({
          id: clienti.id,
          codice: clienti.codice,
          ragioneSociale: clienti.ragioneSociale,
          partitaIva: clienti.partitaIva,
          email: clienti.email,
          telefono: clienti.telefono,
          updatedAt: clienti.updatedAt,
          // Città della sede legale (LEFT JOIN: il cliente può non avere sedi)
          citta: sedi.citta,
          commercialeId: commerciale.id,
          commercialeNome: commerciale.nome,
          commercialeCognome: commerciale.cognome,
          // Numero di commesse attive calcolato con una subquery
          numeroCommesseAperte: sql<number>`(SELECT count(*)::int FROM ${commesse} WHERE ${commesse.clienteId} = ${clienti.id} AND ${commesse.deletedAt} IS NULL AND ${inArray(commesse.stato, [...STATI_COMMESSA_ATTIVI])})`,
        })
        .from(clienti)
        .leftJoin(sedi, and(eq(sedi.clienteId, clienti.id), eq(sedi.tipo, 'legale')))
        .leftJoin(commerciale, eq(commerciale.id, clienti.commercialeId))
        .where(where)
        .orderBy(...ordine)
        .limit(limit)
        .offset(offset),
      this.db.select({ n: count() }).from(clienti).where(where),
    ]);

    // Converte nel formato dell'API
    return {
      data: righe.map((r) => ({
        id: r.id,
        codice: r.codice,
        ragioneSociale: r.ragioneSociale,
        partitaIva: r.partitaIva,
        email: r.email,
        telefono: r.telefono,
        citta: r.citta,
        commerciale: r.commercialeId ? { id: r.commercialeId, nome: r.commercialeNome!, cognome: r.commercialeCognome! } : null,
        numeroCommesseAperte: r.numeroCommesseAperte,
        updatedAt: r.updatedAt.toISOString(),
      })),
      meta: { page: filtri.page, pageSize: filtri.pageSize, total: tot?.n ?? 0 },
    };
  }

  // Dettaglio di un cliente
  async dettaglio(utente: UtenteAutenticato, id: string, tx: DbOTransazione = this.db): Promise<Cliente> {
    // Legge il cliente con il commerciale, applicando soft delete e ambito
    const [r] = await tx
      .select({ cliente: clienti, commercialeNome: commerciale.nome, commercialeCognome: commerciale.cognome })
      .from(clienti)
      .leftJoin(commerciale, eq(commerciale.id, clienti.commercialeId))
      .where(and(eq(clienti.id, id), isNull(clienti.deletedAt), condizioneAmbitoClienti(utente, 'clienti.read')))
      .limit(1);
    // Non trovato o fuori ambito
    if (!r) throw nonTrovato('Cliente');
    // Estrae il cliente
    const c = r.cliente;
    // Converte nel formato dell'API
    return {
      id: c.id,
      codice: c.codice,
      ragioneSociale: c.ragioneSociale,
      partitaIva: c.partitaIva,
      codiceFiscale: c.codiceFiscale,
      codiceSdi: c.codiceSdi,
      pec: c.pec,
      email: c.email,
      telefono: c.telefono,
      sitoWeb: c.sitoWeb,
      note: c.note,
      commerciale: c.commercialeId ? { id: c.commercialeId, nome: r.commercialeNome!, cognome: r.commercialeCognome! } : null,
      createdAt: c.createdAt.toISOString(),
      updatedAt: c.updatedAt.toISOString(),
    };
  }

  // Crea un cliente
  async crea(contesto: ContestoRichiesta, dati: CreaClienteDati): Promise<Cliente> {
    // Ambito del permesso di scrittura
    const ambito = richiediAmbito(contesto.utente, 'clienti.write');
    // Con ambito "propri" il cliente viene sempre assegnato a chi lo crea
    const commercialeId = ambito === 'propri' ? contesto.utente.id : (dati.commercialeId ?? null);
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Verifica che il commerciale indicato sia un utente attivo
      if (commercialeId) await verificaUtenteAttivo(tx, commercialeId, 'Il commerciale indicato non esiste o non è attivo');
      // Genera il codice progressivo
      const codice = await prossimoCodiceCliente(tx);
      // Inserisce il cliente
      const [nuovo] = await tx
        .insert(clienti)
        .values({
          codice,
          ragioneSociale: dati.ragioneSociale,
          partitaIva: dati.partitaIva ?? null,
          codiceFiscale: dati.codiceFiscale ?? null,
          codiceSdi: dati.codiceSdi ?? null,
          pec: dati.pec ?? null,
          email: dati.email ?? null,
          telefono: dati.telefono ?? null,
          sitoWeb: dati.sitoWeb ?? null,
          note: dati.note ?? null,
          commercialeId,
          createdById: contesto.utente.id,
          updatedById: contesto.utente.id,
        })
        .returning();
      // Registra la creazione
      await this.audit.registra(tx, contesto, { azione: 'creazione', entita: 'cliente', entitaId: nuovo!.id, descrizione: `${codice} ${nuovo!.ragioneSociale}`, dopo: nuovo! });
      // Restituisce il dettaglio
      return this.dettaglio(contesto.utente, nuovo!.id, tx);
    });
  }

  // Modifica un cliente
  async aggiorna(contesto: ContestoRichiesta, id: string, dati: AggiornaClienteDati): Promise<Cliente> {
    // Ambito del permesso di scrittura
    const ambito = richiediAmbito(contesto.utente, 'clienti.write');
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Carica il cliente verificando l'accesso in scrittura
      const attuale = await clienteAccessibile(tx, contesto.utente, 'clienti.write', id);
      // Chi ha ambito "propri" non può riassegnare il cliente ad altri
      if (ambito === 'propri' && dati.commercialeId !== undefined && dati.commercialeId !== contesto.utente.id) {
        throw permessoNegato('Non puoi assegnare il cliente a un altro commerciale');
      }
      // Verifica il nuovo commerciale
      if (dati.commercialeId) await verificaUtenteAttivo(tx, dati.commercialeId, 'Il commerciale indicato non esiste o non è attivo');
      // Salva le modifiche
      const [aggiornato] = await tx
        .update(clienti)
        .set({ ...dati, updatedById: contesto.utente.id })
        .where(eq(clienti.id, id))
        .returning();
      // Registra le differenze
      await this.audit.registra(tx, contesto, { azione: 'modifica', entita: 'cliente', entitaId: id, descrizione: `${attuale.codice} ${aggiornato!.ragioneSociale}`, prima: attuale, dopo: aggiornato! });
      // Restituisce il dettaglio
      return this.dettaglio(contesto.utente, id, tx);
    });
  }

  // Eliminazione logica di un cliente
  async elimina(contesto: ContestoRichiesta, id: string): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Carica il cliente verificando il permesso di eliminazione
      const attuale = await clienteAccessibile(tx, contesto.utente, 'clienti.delete', id);
      // Conta le commesse ancora attive
      const [r] = await tx
        .select({ n: count() })
        .from(commesse)
        .where(and(eq(commesse.clienteId, id), isNull(commesse.deletedAt), inArray(commesse.stato, [...STATI_COMMESSA_ATTIVI])));
      // Non si elimina un cliente con lavori in corso
      if (r && r.n > 0) throw regolaViolata(`Il cliente ha ${r.n} commesse aperte o sospese: chiudile prima di eliminarlo`);
      // Conta i progetti non ancora conclusi o annullati
      const [rp] = await tx
        .select({ n: count() })
        .from(progetti)
        .where(and(eq(progetti.clienteId, id), isNull(progetti.deletedAt), inArray(progetti.stato, [...STATI_PROGETTO_ATTIVI])));
      // Senza questo controllo i progetti in corso sparirebbero dagli elenchi restando raggiungibili via URL
      if (rp && rp.n > 0) throw regolaViolata(`Il cliente ha ${rp.n} progetti in corso: concludili o annullali prima di eliminarlo`);
      // Imposta la data di eliminazione (il record resta nel database per storico e audit)
      await tx.update(clienti).set({ deletedAt: new Date(), updatedById: contesto.utente.id }).where(eq(clienti.id, id));
      // Registra l'eliminazione
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'cliente', entitaId: id, descrizione: `${attuale.codice} ${attuale.ragioneSociale}` });
    });
  }

}
