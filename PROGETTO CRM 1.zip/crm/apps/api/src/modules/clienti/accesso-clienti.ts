// =====================================================================================
// Controllo di accesso ai clienti con applicazione dell'ambito ("tutti" / "propri")
// -------------------------------------------------------------------------------------
// Funzioni riutilizzate da clienti, sedi, contatti, commesse e allegati: il controllo
// è scritto una sola volta, quindi non può essere dimenticato o implementato diversamente.
// =====================================================================================

// Importa gli operatori di query
import { and, eq, isNull, type SQL } from 'drizzle-orm';
// Importa il tipo dei codici permesso
import type { CodicePermesso } from '@crm/shared';
// Importa database e tabelle
import type { DbOTransazione } from '../../database/client';
import { clienti } from '../../database/schema';
// Importa ambito ed eccezioni
import { richiediAmbito } from '../../common/auth/ambito';
import type { UtenteAutenticato } from '../../common/auth/tipi';
import { nonTrovato } from '../../common/errori/errori';

// Condizione SQL che limita i clienti all'ambito dell'utente per il permesso indicato
export function condizioneAmbitoClienti(utente: UtenteAutenticato, permesso: CodicePermesso): SQL | undefined {
  // Legge l'ambito (lancia 403 se il permesso manca)
  const ambito = richiediAmbito(utente, permesso);
  // Ambito "propri": solo i clienti di cui l'utente è il commerciale di riferimento
  return ambito === 'propri' ? eq(clienti.commercialeId, utente.id) : undefined;
}

// Carica un cliente non eliminato e accessibile all'utente; altrimenti 404
export async function clienteAccessibile(tx: DbOTransazione, utente: UtenteAutenticato, permesso: CodicePermesso, clienteId: string) {
  // Cerca il cliente applicando id, soft delete e ambito
  const [cliente] = await tx
    .select()
    .from(clienti)
    .where(and(eq(clienti.id, clienteId), isNull(clienti.deletedAt), condizioneAmbitoClienti(utente, permesso)))
    .limit(1);
  // Inesistente o fuori ambito: stessa risposta, per non rivelare l'esistenza di clienti altrui
  if (!cliente) throw nonTrovato('Cliente');
  // Restituisce il cliente
  return cliente;
}
