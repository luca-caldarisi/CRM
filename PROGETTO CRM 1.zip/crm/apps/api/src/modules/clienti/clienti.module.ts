// Modulo clienti, sedi e contatti

// Importa il decoratore di NestJS
import { Module } from '@nestjs/common';
// Importa controller e service
import { ClientiController } from './clienti.controller';
import { ClientiService } from './clienti.service';
import { SediContattiService } from './sedi-contatti.service';

@Module({
  // Rotte
  controllers: [ClientiController],
  // Servizi
  providers: [ClientiService, SediContattiService],
})
export class ClientiModule {}
