// =====================================================================================
// API clienti, sedi e contatti
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post, Query } from '@nestjs/common';
// Importa la creazione dei DTO
import { createZodDto } from 'nestjs-zod';
// Importa schemi condivisi
import {
  aggiornaClienteSchema,
  aggiornaContattoSchema,
  aggiornaSedeSchema,
  creaClienteSchema,
  creaContattoSchema,
  creaSedeSchema,
  filtriClientiSchema,
  parametroIdSchema,
} from '@crm/shared';
// Importa decoratori di accesso
import { Contesto, RichiedePermesso, UtenteCorrente } from '../../common/auth/decoratori';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
// Importa i service
import { ClientiService } from './clienti.service';
import { SediContattiService } from './sedi-contatti.service';

// DTO
class FiltriClientiDto extends createZodDto(filtriClientiSchema) {}
class CreaClienteDto extends createZodDto(creaClienteSchema) {}
class AggiornaClienteDto extends createZodDto(aggiornaClienteSchema) {}
class CreaSedeDto extends createZodDto(creaSedeSchema) {}
class AggiornaSedeDto extends createZodDto(aggiornaSedeSchema) {}
class CreaContattoDto extends createZodDto(creaContattoSchema) {}
class AggiornaContattoDto extends createZodDto(aggiornaContattoSchema) {}
class ParametroIdDto extends createZodDto(parametroIdSchema) {}

@Controller()
export class ClientiController {
  constructor(
    // Service clienti
    private readonly clienti: ClientiService,
    // Service sedi e contatti
    private readonly sediContatti: SediContattiService,
  ) {}

  // ----------------------------------- Clienti ----------------------------------------

  // GET /api/v1/clienti?q=&page=&pageSize=&sort=&commercialeId=
  @Get('clienti')
  @RichiedePermesso('clienti.read')
  lista(@UtenteCorrente() utente: UtenteAutenticato, @Query() filtri: FiltriClientiDto) {
    return this.clienti.lista(utente, filtri);
  }

  // GET /api/v1/clienti/:id
  @Get('clienti/:id')
  @RichiedePermesso('clienti.read')
  dettaglio(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto) {
    return this.clienti.dettaglio(utente, id);
  }

  // POST /api/v1/clienti
  @Post('clienti')
  @RichiedePermesso('clienti.write')
  crea(@Contesto() contesto: ContestoRichiesta, @Body() dati: CreaClienteDto) {
    return this.clienti.crea(contesto, dati);
  }

  // PATCH /api/v1/clienti/:id
  @Patch('clienti/:id')
  @RichiedePermesso('clienti.write')
  aggiorna(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaClienteDto) {
    return this.clienti.aggiorna(contesto, id, dati);
  }

  // DELETE /api/v1/clienti/:id
  @Delete('clienti/:id')
  @RichiedePermesso('clienti.delete')
  @HttpCode(HttpStatus.NO_CONTENT)
  elimina(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.clienti.elimina(contesto, id);
  }

  // ------------------------------------- Sedi -----------------------------------------

  // GET /api/v1/clienti/:id/sedi
  @Get('clienti/:id/sedi')
  @RichiedePermesso('clienti.read')
  listaSedi(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto) {
    return this.sediContatti.listaSedi(utente, id);
  }

  // POST /api/v1/clienti/:id/sedi
  @Post('clienti/:id/sedi')
  @RichiedePermesso('clienti.write')
  creaSede(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: CreaSedeDto) {
    return this.sediContatti.creaSede(contesto, id, dati);
  }

  // PATCH /api/v1/sedi/:id
  @Patch('sedi/:id')
  @RichiedePermesso('clienti.write')
  aggiornaSede(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaSedeDto) {
    return this.sediContatti.aggiornaSede(contesto, id, dati);
  }

  // DELETE /api/v1/sedi/:id
  @Delete('sedi/:id')
  @RichiedePermesso('clienti.write')
  @HttpCode(HttpStatus.NO_CONTENT)
  eliminaSede(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.sediContatti.eliminaSede(contesto, id);
  }

  // ----------------------------------- Contatti ---------------------------------------

  // GET /api/v1/clienti/:id/contatti
  @Get('clienti/:id/contatti')
  @RichiedePermesso('clienti.read')
  listaContatti(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto) {
    return this.sediContatti.listaContatti(utente, id);
  }

  // POST /api/v1/clienti/:id/contatti
  @Post('clienti/:id/contatti')
  @RichiedePermesso('clienti.write')
  creaContatto(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: CreaContattoDto) {
    return this.sediContatti.creaContatto(contesto, id, dati);
  }

  // PATCH /api/v1/contatti/:id
  @Patch('contatti/:id')
  @RichiedePermesso('clienti.write')
  aggiornaContatto(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaContattoDto) {
    return this.sediContatti.aggiornaContatto(contesto, id, dati);
  }

  // DELETE /api/v1/contatti/:id
  @Delete('contatti/:id')
  @RichiedePermesso('clienti.write')
  @HttpCode(HttpStatus.NO_CONTENT)
  eliminaContatto(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.sediContatti.eliminaContatto(contesto, id);
  }
}
