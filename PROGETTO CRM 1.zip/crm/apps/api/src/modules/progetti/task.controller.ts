// =====================================================================================
// API dei task: /api/v1/task, /api/v1/todo, /api/v1/ore
// -------------------------------------------------------------------------------------
// I task hanno rotte proprie (e non annidate sotto il progetto) perché si raggiungono
// sempre dal loro identificativo: il progetto viene ricavato dal task lato server.
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post } from '@nestjs/common';
// Importa la creazione dei DTO dagli schemi Zod
import { createZodDto } from 'nestjs-zod';
// Importa schemi condivisi
import { aggiornaTaskSchema, aggiornaTodoSchema, creaTodoSchema, parametroIdSchema, registraOreSchema, spostaTaskSchema } from '@crm/shared';
// Importa decoratori di accesso
import { Contesto, RichiedePermesso, UtenteCorrente } from '../../common/auth/decoratori';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
// Importa il service
import { TaskService } from './task.service';

// DTO
class AggiornaTaskDto extends createZodDto(aggiornaTaskSchema) {}
class SpostaTaskDto extends createZodDto(spostaTaskSchema) {}
class CreaTodoDto extends createZodDto(creaTodoSchema) {}
class AggiornaTodoDto extends createZodDto(aggiornaTodoSchema) {}
class RegistraOreDto extends createZodDto(registraOreSchema) {}
class ParametroIdDto extends createZodDto(parametroIdSchema) {}

@Controller()
export class TaskController {
  // Riceve il service
  constructor(private readonly task: TaskService) {}

  // GET /api/v1/task/:id - dettaglio con to-do e ore
  @Get('task/:id')
  @RichiedePermesso('progetti.read')
  dettaglio(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto) {
    return this.task.dettaglio(utente, id);
  }

  // PATCH /api/v1/task/:id - modifica i dati del task
  @Patch('task/:id')
  @RichiedePermesso('task.write')
  aggiorna(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaTaskDto) {
    return this.task.aggiorna(contesto, id, dati);
  }

  // POST /api/v1/task/:id/sposta - spostamento nella bacheca (trascinamento)
  @Post('task/:id/sposta')
  @RichiedePermesso('task.write')
  sposta(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: SpostaTaskDto) {
    return this.task.sposta(contesto, id, dati.colonnaId, dati.posizione);
  }

  // DELETE /api/v1/task/:id - eliminazione definitiva (richiede il permesso di eliminare i progetti)
  @Delete('task/:id')
  @RichiedePermesso('progetti.delete')
  @HttpCode(HttpStatus.NO_CONTENT)
  elimina(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.task.elimina(contesto, id);
  }

  // POST /api/v1/task/:id/todo - aggiunge una voce alla to-do
  @Post('task/:id/todo')
  @RichiedePermesso('task.write')
  aggiungiTodo(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: CreaTodoDto) {
    return this.task.aggiungiTodo(contesto, id, dati);
  }

  // PATCH /api/v1/todo/:id - spunta o modifica una voce della to-do
  @Patch('todo/:id')
  @RichiedePermesso('task.write')
  aggiornaTodo(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaTodoDto) {
    return this.task.aggiornaTodo(contesto, id, dati);
  }

  // DELETE /api/v1/todo/:id - elimina una voce della to-do
  @Delete('todo/:id')
  @RichiedePermesso('task.write')
  eliminaTodo(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.task.eliminaTodo(contesto, id);
  }

  // POST /api/v1/task/:id/ore - registra le ore lavorate sul task
  @Post('task/:id/ore')
  @RichiedePermesso('ore.write')
  registraOre(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: RegistraOreDto) {
    return this.task.registraOre(contesto, id, dati);
  }

  // DELETE /api/v1/ore/:id - elimina una registrazione di ore
  @Delete('ore/:id')
  @RichiedePermesso('ore.write')
  @HttpCode(HttpStatus.NO_CONTENT)
  eliminaOre(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.task.eliminaOre(contesto, id);
  }
}
