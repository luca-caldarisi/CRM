// =====================================================================================
// Gestione dei task di un progetto: creazione, modifica, spostamento nella bacheca,
// voci della to-do e registrazione delle ore lavorate
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { and, asc, desc, eq, gt, gte, lt, lte, ne, sql, type SQL } from 'drizzle-orm';
// Importa l'helper per gli alias di tabella
import { alias } from 'drizzle-orm/pg-core';
// Importa tipi condivisi
import type {
  AggiornaTaskDati,
  AggiornaTodoDati,
  CreaTaskDati,
  CreaTodoDati,
  RegistraOreDati,
  RegistrazioneOre,
  TaskDettaglio,
  VoceTodo,
} from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { registrazioniOre, task, taskTodo, utenti } from '../../database/schema';
// Importa sicurezza, eccezioni e utilità
import { richiediAmbito } from '../../common/auth/ambito';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
import { nonTrovato, permessoNegato, regolaViolata } from '../../common/errori/errori';
// Importa le utilità comuni (date e verifiche condivise)
import { oggi } from '../../common/utils/date';
import { verificaUtenteAttivo } from '../../common/utils/verifiche';
// Importa il registro attività
import { AuditService } from '../audit/audit.service';
// Importa i controlli di accesso
import { colonnaDelProgetto, progettoAccessibile, taskAccessibile, verificaTaskModificabile } from './accesso-progetti';

// Alias della tabella utenti usata come assegnatario di una voce della to-do
// (serve perché nella stessa query "utenti" compare anche con altri ruoli)
const assegnatario = alias(utenti, 'assegnatario_todo');

// Filtri dell'elenco ore (già validati)
interface FiltriOre {
  utenteId?: string;
  dal?: string;
  al?: string;
}

@Injectable()
export class TaskService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // ----------------------------------- Dettaglio --------------------------------------

  // Dettaglio completo di un task: dati, voci della to-do e registrazioni ore
  async dettaglio(utente: UtenteAutenticato, taskId: string, tx: DbOTransazione = this.db): Promise<TaskDettaglio> {
    // Carica il task verificando l'accesso al progetto
    const { task: t } = await taskAccessibile(tx, utente, 'progetti.read', taskId);
    // Letture in sequenza: dentro una transazione c'è una sola connessione e le query parallele
    // sullo stesso client sono deprecate da pg (verranno rimosse in pg@9)
    // Responsabile del task (se assegnato)
    const responsabile = t.responsabileId
      ? await tx.select({ id: utenti.id, nome: utenti.nome, cognome: utenti.cognome }).from(utenti).where(eq(utenti.id, t.responsabileId)).limit(1)
      : [];
    // Voci della to-do con l'assegnatario
    const todo = await this.elencoTodo(tx, taskId);
    // Registrazioni ore con l'autore (tutte, senza limite)
    const ore = await this.elencoOre(tx, taskId);
    // Compone la risposta
    return {
      id: t.id,
      progettoId: t.progettoId,
      colonnaId: t.colonnaId,
      titolo: t.titolo,
      descrizione: t.descrizione,
      priorita: t.priorita,
      dataScadenza: t.dataScadenza,
      oreStimate: t.oreStimate,
      minutiRegistrati: ore.reduce((somma, r) => somma + r.minuti, 0),
      responsabile: responsabile[0] ?? null,
      todoTotali: todo.length,
      todoCompletate: todo.filter((v) => v.completata).length,
      ordine: t.ordine,
      completatoIl: t.completatoIl ? t.completatoIl.toISOString() : null,
      todo,
      ore,
      createdAt: t.createdAt.toISOString(),
      updatedAt: t.updatedAt.toISOString(),
    };
  }

  // ------------------------------------ Creazione -------------------------------------

  // Crea un task nella colonna indicata
  async crea(contesto: ContestoRichiesta, progettoId: string, dati: CreaTaskDati): Promise<TaskDettaglio> {
    // Ambito di scrittura dei task
    const ambito = richiediAmbito(contesto.utente, 'task.write');
    // Con ambito "propri" il task nasce assegnato a chi lo crea: non si creano task per altri
    const responsabileId = ambito === 'propri' ? contesto.utente.id : (dati.responsabileId ?? null);
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Il progetto deve essere accessibile in lettura all'utente (coinvolgimento)
      const progetto = await progettoAccessibile(tx, contesto.utente, 'progetti.read', progettoId);
      // Non si aggiungono task a progetti chiusi
      if (progetto.stato === 'concluso' || progetto.stato === 'annullato') throw regolaViolata('Il progetto è chiuso: non si possono aggiungere task');
      // La colonna deve appartenere a questo progetto
      const colonna = await colonnaDelProgetto(tx, progettoId, dati.colonnaId);
      // Il responsabile indicato deve essere un utente attivo
      if (responsabileId) await verificaUtenteAttivo(tx, responsabileId);
      // Posizione: in fondo alla colonna
      const ordine = await this.ultimaPosizione(tx, dati.colonnaId);
      // Inserisce il task
      const [nuovo] = await tx
        .insert(task)
        .values({
          progettoId,
          colonnaId: dati.colonnaId,
          titolo: dati.titolo,
          descrizione: dati.descrizione ?? null,
          priorita: dati.priorita,
          responsabileId,
          dataScadenza: dati.dataScadenza ?? null,
          // Numeric: si passa come stringa per non perdere precisione
          oreStimate: dati.oreStimate == null ? null : dati.oreStimate.toFixed(2),
          ordine,
          // Se nasce già in una colonna di completamento, registra il momento
          completatoIl: colonna.consideraCompletato ? new Date() : null,
          createdById: contesto.utente.id,
          updatedById: contesto.utente.id,
        })
        .returning();
      // Registra la creazione
      await this.audit.registra(tx, contesto, {
        azione: 'creazione',
        entita: 'task',
        entitaId: nuovo!.id,
        descrizione: `${progetto.codice} - ${nuovo!.titolo}`,
        dopo: nuovo!,
      });
      // Restituisce il dettaglio
      return this.dettaglio(contesto.utente, nuovo!.id, tx);
    });
  }

  // ------------------------------------ Modifica --------------------------------------

  // Modifica i dati di un task (non la colonna: per quella c'è lo spostamento)
  async aggiorna(contesto: ContestoRichiesta, taskId: string, dati: AggiornaTaskDati): Promise<TaskDettaglio> {
    // Ambito di scrittura
    const ambito = richiediAmbito(contesto.utente, 'task.write');
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Carica il task verificando l'accesso al progetto
      const { task: attuale, progetto } = await taskAccessibile(tx, contesto.utente, 'task.write', taskId);
      // Con ambito "propri" si possono modificare solo i propri task
      verificaTaskModificabile(contesto.utente, attuale);
      // Con ambito "propri" non si passa il task a un altro tecnico
      if (ambito === 'propri' && dati.responsabileId !== undefined && dati.responsabileId !== contesto.utente.id) {
        throw permessoNegato('Non puoi assegnare il task a un altro tecnico');
      }
      // Il nuovo responsabile deve essere attivo
      if (dati.responsabileId) await verificaUtenteAttivo(tx, dati.responsabileId);
      // Separa le ore stimate (da convertire in stringa) dagli altri campi
      const { oreStimate, ...altri } = dati;
      // Salva le modifiche
      const [aggiornato] = await tx
        .update(task)
        .set({
          ...altri,
          // Le ore stimate si aggiornano solo se presenti nella richiesta
          ...(oreStimate !== undefined ? { oreStimate: oreStimate === null ? null : oreStimate.toFixed(2) } : {}),
          updatedById: contesto.utente.id,
        })
        .where(eq(task.id, taskId))
        .returning();
      // Registra le differenze
      await this.audit.registra(tx, contesto, {
        azione: 'modifica',
        entita: 'task',
        entitaId: taskId,
        descrizione: `${progetto.codice} - ${aggiornato!.titolo}`,
        prima: attuale,
        dopo: aggiornato!,
      });
      // Restituisce il dettaglio aggiornato
      return this.dettaglio(contesto.utente, taskId, tx);
    });
  }

  // ---------------------------------- Spostamento -------------------------------------

  // Sposta un task in una colonna e in una posizione (trascinamento nella bacheca)
  async sposta(contesto: ContestoRichiesta, taskId: string, colonnaId: string, posizione: number): Promise<TaskDettaglio> {
    // Esegue in transazione: la rinumerazione delle posizioni deve essere atomica
    return this.db.transaction(async (tx) => {
      // Carica il task verificando l'accesso
      const { task: attuale, progetto } = await taskAccessibile(tx, contesto.utente, 'task.write', taskId);
      // Con ambito "propri" si possono spostare solo i propri task
      verificaTaskModificabile(contesto.utente, attuale);
      // La colonna di destinazione deve appartenere allo stesso progetto
      const destinazione = await colonnaDelProgetto(tx, attuale.progettoId, colonnaId);
      // Colonna di partenza
      const origine = attuale.colonnaId;
      // Numero di task già presenti nella colonna di destinazione, escluso quello che si sta spostando
      const [contati] = await tx
        .select({ n: sql<number>`COUNT(*)::int` })
        .from(task)
        .where(and(eq(task.colonnaId, colonnaId), ne(task.id, taskId)));
      // Posizione finale: non oltre la fine della colonna
      const nuovaPosizione = Math.min(posizione, contati?.n ?? 0);
      // Spostamento nella stessa colonna: si riordina compattando le posizioni
      if (origine === colonnaId) {
        // Posizione attuale
        const vecchia = attuale.ordine;
        // Nessun movimento reale: restituisce il dettaglio senza scrivere
        if (vecchia === nuovaPosizione) return this.dettaglio(contesto.utente, taskId, tx);
        // Spostamento verso il basso: i task in mezzo salgono di una posizione
        if (nuovaPosizione > vecchia) {
          await tx
            .update(task)
            .set({ ordine: sql`${task.ordine} - 1` })
            .where(and(eq(task.colonnaId, colonnaId), gt(task.ordine, vecchia), lte(task.ordine, nuovaPosizione)));
        } else {
          // Spostamento verso l'alto: i task in mezzo scendono di una posizione
          await tx
            .update(task)
            .set({ ordine: sql`${task.ordine} + 1` })
            .where(and(eq(task.colonnaId, colonnaId), gte(task.ordine, nuovaPosizione), lt(task.ordine, vecchia)));
        }
      } else {
        // Cambio di colonna: nella colonna di origine i task successivi risalgono
        await tx
          .update(task)
          .set({ ordine: sql`${task.ordine} - 1` })
          .where(and(eq(task.colonnaId, origine), gt(task.ordine, attuale.ordine)));
        // Nella colonna di destinazione i task dalla posizione in poi scendono
        await tx
          .update(task)
          .set({ ordine: sql`${task.ordine} + 1` })
          .where(and(eq(task.colonnaId, colonnaId), gte(task.ordine, nuovaPosizione)));
      }
      // Momento di completamento: conservato se il task era già completato, impostato entrando
      // in una colonna di completamento, azzerato uscendone (niente query extra sulla colonna di origine)
      const completatoIl = destinazione.consideraCompletato ? (attuale.completatoIl ?? new Date()) : null;
      // Aggiorna il task spostato
      const [aggiornato] = await tx
        .update(task)
        .set({ colonnaId, ordine: nuovaPosizione, completatoIl, updatedById: contesto.utente.id })
        .where(eq(task.id, taskId))
        .returning();
      // Registra lo spostamento con il nome delle colonne (più leggibile degli id nel registro)
      await this.audit.registra(tx, contesto, {
        azione: 'modifica',
        entita: 'task',
        entitaId: taskId,
        descrizione: `${progetto.codice} - ${attuale.titolo}: spostato in "${destinazione.nome}"`,
        prima: { colonnaId: origine, ordine: attuale.ordine },
        dopo: { colonnaId: aggiornato!.colonnaId, ordine: aggiornato!.ordine },
      });
      // Restituisce il dettaglio aggiornato
      return this.dettaglio(contesto.utente, taskId, tx);
    });
  }

  // Eliminazione definitiva di un task (con to-do e ore, per vincolo ON DELETE CASCADE)
  async elimina(contesto: ContestoRichiesta, taskId: string): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Solo chi può eliminare i progetti può eliminare i task: l'operazione cancella anche le ore registrate
      const { task: attuale, progetto } = await taskAccessibile(tx, contesto.utente, 'progetti.delete', taskId);
      // Elimina il task (il database elimina a cascata to-do e registrazioni ore)
      await tx.delete(task).where(eq(task.id, taskId));
      // Compatta le posizioni dei task rimasti nella colonna
      await tx
        .update(task)
        .set({ ordine: sql`${task.ordine} - 1` })
        .where(and(eq(task.colonnaId, attuale.colonnaId), gt(task.ordine, attuale.ordine)));
      // Registra l'eliminazione
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'task', entitaId: taskId, descrizione: `${progetto.codice} - ${attuale.titolo}` });
    });
  }

  // -------------------------------------- To-do ---------------------------------------

  // Aggiunge una voce alla to-do di un task
  async aggiungiTodo(contesto: ContestoRichiesta, taskId: string, dati: CreaTodoDati): Promise<VoceTodo[]> {
    // Ambito di scrittura dei task
    richiediAmbito(contesto.utente, 'task.write');
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Carica il task verificando l'accesso
      const { task: t, progetto } = await taskAccessibile(tx, contesto.utente, 'task.write', taskId);
      // Con ambito "propri" si possono aggiungere voci solo ai propri task
      verificaTaskModificabile(contesto.utente, t);
      // L'assegnatario, se indicato, deve essere un utente attivo
      if (dati.assegnatarioId) await verificaUtenteAttivo(tx, dati.assegnatarioId);
      // Posizione: in fondo all'elenco
      const [ultima] = await tx
        .select({ prossimo: sql<number>`COALESCE(MAX(${taskTodo.ordine}) + 1, 0)::int` })
        .from(taskTodo)
        .where(eq(taskTodo.taskId, taskId));
      // Posizione da usare (0 se l'elenco è vuoto)
      const prossimo = ultima?.prossimo ?? 0;
      // Inserisce la voce
      const [nuova] = await tx
        .insert(taskTodo)
        .values({
          taskId,
          titolo: dati.titolo,
          assegnatarioId: dati.assegnatarioId ?? null,
          ordine: prossimo,
          createdById: contesto.utente.id,
          updatedById: contesto.utente.id,
        })
        .returning();
      // Registra la creazione
      await this.audit.registra(tx, contesto, {
        azione: 'creazione',
        entita: 'task_todo',
        entitaId: nuova!.id,
        descrizione: `${progetto.codice} - ${t.titolo}: "${nuova!.titolo}"`,
        dopo: nuova!,
      });
      // Restituisce l'elenco aggiornato
      return this.elencoTodo(tx, taskId);
    });
  }

  // Modifica una voce della to-do (testo, assegnatario, completamento)
  async aggiornaTodo(contesto: ContestoRichiesta, todoId: string, dati: AggiornaTodoDati): Promise<VoceTodo[]> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Legge la voce
      const [voce] = await tx.select().from(taskTodo).where(eq(taskTodo.id, todoId)).limit(1);
      // Voce inesistente
      if (!voce) throw nonTrovato('Voce');
      // Carica il task verificando l'accesso al progetto
      const { task: t, progetto } = await taskAccessibile(tx, contesto.utente, 'task.write', voce.taskId);
      // Chi ha ambito "propri" può agire sulle voci dei propri task oppure su quelle assegnate a sé
      this.verificaTodoModificabile(contesto.utente, t, voce);
      // Il nuovo assegnatario deve essere attivo
      if (dati.assegnatarioId) await verificaUtenteAttivo(tx, dati.assegnatarioId);
      // Momento del completamento: impostato quando si spunta, azzerato quando si despunta
      const completataIl = dati.completata === undefined ? voce.completataIl : dati.completata ? (voce.completata ? voce.completataIl : new Date()) : null;
      // Salva
      const [aggiornata] = await tx
        .update(taskTodo)
        .set({ ...dati, completataIl, updatedById: contesto.utente.id })
        .where(eq(taskTodo.id, todoId))
        .returning();
      // Registra le differenze
      await this.audit.registra(tx, contesto, {
        azione: 'modifica',
        entita: 'task_todo',
        entitaId: todoId,
        descrizione: `${progetto.codice} - ${t.titolo}: "${aggiornata!.titolo}"`,
        prima: voce,
        dopo: aggiornata!,
      });
      // Restituisce l'elenco aggiornato
      return this.elencoTodo(tx, voce.taskId);
    });
  }

  // Elimina una voce della to-do
  async eliminaTodo(contesto: ContestoRichiesta, todoId: string): Promise<VoceTodo[]> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Legge la voce
      const [voce] = await tx.select().from(taskTodo).where(eq(taskTodo.id, todoId)).limit(1);
      // Voce inesistente
      if (!voce) throw nonTrovato('Voce');
      // Carica il task verificando l'accesso
      const { task: t, progetto } = await taskAccessibile(tx, contesto.utente, 'task.write', voce.taskId);
      // Con ambito "propri" solo sui propri task (eliminare una voce non è un'azione dell'assegnatario)
      verificaTaskModificabile(contesto.utente, t);
      // Elimina la voce
      await tx.delete(taskTodo).where(eq(taskTodo.id, todoId));
      // Compatta le posizioni rimaste
      await tx
        .update(taskTodo)
        .set({ ordine: sql`${taskTodo.ordine} - 1` })
        .where(and(eq(taskTodo.taskId, voce.taskId), gt(taskTodo.ordine, voce.ordine)));
      // Registra l'eliminazione
      await this.audit.registra(tx, contesto, {
        azione: 'eliminazione',
        entita: 'task_todo',
        entitaId: todoId,
        descrizione: `${progetto.codice} - ${t.titolo}: "${voce.titolo}"`,
      });
      // Restituisce l'elenco aggiornato
      return this.elencoTodo(tx, voce.taskId);
    });
  }

  // ------------------------------------- Ore ------------------------------------------

  // Registra le ore lavorate su un task
  async registraOre(contesto: ContestoRichiesta, taskId: string, dati: RegistraOreDati): Promise<RegistrazioneOre[]> {
    // Ambito di registrazione delle ore
    const ambito = richiediAmbito(contesto.utente, 'ore.write');
    // Con ambito "propri" le ore sono sempre a proprio nome; con "tutti" si può indicare un altro tecnico
    const utenteId = ambito === 'propri' ? contesto.utente.id : (dati.utenteId ?? contesto.utente.id);
    // La data non può essere nel futuro: si registra il lavoro già svolto
    if (dati.data > oggi()) throw regolaViolata('Non si possono registrare ore con data futura');
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Carica il task verificando l'accesso al progetto
      const { task: t, progetto } = await taskAccessibile(tx, contesto.utente, 'progetti.read', taskId);
      // Non si registrano ore su progetti annullati
      if (progetto.stato === 'annullato') throw regolaViolata('Il progetto è annullato: non si possono registrare ore');
      // Il tecnico indicato deve essere attivo
      if (utenteId !== contesto.utente.id) await verificaUtenteAttivo(tx, utenteId);
      // Inserisce la registrazione (i minuti sono già validati dallo schema: 1 minuto - 24 ore)
      const [nuova] = await tx
        .insert(registrazioniOre)
        .values({
          taskId,
          utenteId,
          data: dati.data,
          minuti: dati.durata,
          descrizione: dati.descrizione ?? null,
          createdById: contesto.utente.id,
        })
        .returning();
      // Registra l'operazione
      await this.audit.registra(tx, contesto, {
        azione: 'creazione',
        entita: 'registrazione_ore',
        entitaId: nuova!.id,
        descrizione: `${progetto.codice} - ${t.titolo}: ${dati.durata} minuti del ${dati.data}`,
        dopo: nuova!,
      });
      // Restituisce l'elenco aggiornato delle ore del task
      return this.elencoOre(tx, taskId);
    });
  }

  // Elimina una registrazione di ore
  async eliminaOre(contesto: ContestoRichiesta, oreId: string): Promise<void> {
    // Ambito di registrazione delle ore
    const ambito = richiediAmbito(contesto.utente, 'ore.write');
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Legge la registrazione
      const [riga] = await tx.select().from(registrazioniOre).where(eq(registrazioniOre.id, oreId)).limit(1);
      // Registrazione inesistente
      if (!riga) throw nonTrovato('Registrazione');
      // Verifica l'accesso al progetto del task
      const { task: t, progetto } = await taskAccessibile(tx, contesto.utente, 'progetti.read', riga.taskId);
      // Con ambito "propri" si possono eliminare solo le proprie registrazioni
      if (ambito === 'propri' && riga.utenteId !== contesto.utente.id) throw permessoNegato('Puoi eliminare solo le ore che hai registrato tu');
      // Elimina la registrazione
      await tx.delete(registrazioniOre).where(eq(registrazioniOre.id, oreId));
      // Registra l'eliminazione
      await this.audit.registra(tx, contesto, {
        azione: 'eliminazione',
        entita: 'registrazione_ore',
        entitaId: oreId,
        descrizione: `${progetto.codice} - ${t.titolo}: ${riga.minuti} minuti del ${riga.data}`,
      });
    });
  }

  // Elenco delle ore registrate su un intero progetto, con filtri
  async oreProgetto(utente: UtenteAutenticato, progettoId: string, filtri: FiltriOre): Promise<RegistrazioneOre[]> {
    // Verifica l'accesso al progetto
    await progettoAccessibile(this.db, utente, 'progetti.read', progettoId);
    // Condizioni: ore dei task del progetto più i filtri richiesti
    const condizioni: (SQL | undefined)[] = [eq(task.progettoId, progettoId)];
    // Filtro per tecnico
    if (filtri.utenteId) condizioni.push(eq(registrazioniOre.utenteId, filtri.utenteId));
    // Intervallo di date
    if (filtri.dal) condizioni.push(gte(registrazioniOre.data, filtri.dal));
    if (filtri.al) condizioni.push(lte(registrazioniOre.data, filtri.al));
    // Legge le registrazioni con l'autore
    const righe = await this.db
      .select({ ore: registrazioniOre, nome: utenti.nome, cognome: utenti.cognome })
      .from(registrazioniOre)
      .innerJoin(task, eq(task.id, registrazioniOre.taskId))
      .innerJoin(utenti, eq(utenti.id, registrazioniOre.utenteId))
      .where(and(...condizioni))
      .orderBy(desc(registrazioniOre.data), desc(registrazioniOre.createdAt));
    // Converte nel formato dell'API
    return righe.map((r) => this.mappaOre(r));
  }

  // ------------------------------- Metodi di supporto ---------------------------------

  // Elenco delle voci della to-do di un task, in ordine
  private async elencoTodo(tx: DbOTransazione, taskId: string): Promise<VoceTodo[]> {
    // Legge le voci con l'assegnatario
    const righe = await tx
      .select({ voce: taskTodo, nome: assegnatario.nome, cognome: assegnatario.cognome })
      .from(taskTodo)
      .leftJoin(assegnatario, eq(assegnatario.id, taskTodo.assegnatarioId))
      .where(eq(taskTodo.taskId, taskId))
      .orderBy(asc(taskTodo.ordine), asc(taskTodo.createdAt));
    // Converte nel formato dell'API
    return righe.map((r) => ({
      id: r.voce.id,
      taskId: r.voce.taskId,
      titolo: r.voce.titolo,
      completata: r.voce.completata,
      completataIl: r.voce.completataIl ? r.voce.completataIl.toISOString() : null,
      assegnatario: r.voce.assegnatarioId ? { id: r.voce.assegnatarioId, nome: r.nome!, cognome: r.cognome! } : null,
      ordine: r.voce.ordine,
    }));
  }

  // Elenco delle registrazioni ore di un task
  private async elencoOre(tx: DbOTransazione, taskId: string): Promise<RegistrazioneOre[]> {
    // Legge le registrazioni con l'autore
    const righe = await tx
      .select({ ore: registrazioniOre, nome: utenti.nome, cognome: utenti.cognome })
      .from(registrazioniOre)
      .innerJoin(utenti, eq(utenti.id, registrazioniOre.utenteId))
      .where(eq(registrazioniOre.taskId, taskId))
      .orderBy(desc(registrazioniOre.data), desc(registrazioniOre.createdAt));
    // Converte nel formato dell'API
    return righe.map((r) => this.mappaOre(r));
  }

  // Converte una riga di registrazione ore nel formato dell'API
  private mappaOre(r: { ore: typeof registrazioniOre.$inferSelect; nome: string; cognome: string }): RegistrazioneOre {
    // Oggetto della risposta
    return {
      id: r.ore.id,
      taskId: r.ore.taskId,
      data: r.ore.data,
      minuti: r.ore.minuti,
      descrizione: r.ore.descrizione,
      utente: { id: r.ore.utenteId, nome: r.nome, cognome: r.cognome },
      createdAt: r.ore.createdAt.toISOString(),
    };
  }

  // Prima posizione libera in fondo a una colonna
  private async ultimaPosizione(tx: DbOTransazione, colonnaId: string): Promise<number> {
    // MAX(ordine) + 1, oppure 0 se la colonna è vuota
    const [ultimo] = await tx
      .select({ prossimo: sql<number>`COALESCE(MAX(${task.ordine}) + 1, 0)::int` })
      .from(task)
      .where(eq(task.colonnaId, colonnaId));
    // Posizione da usare (0 se la colonna è vuota)
    return ultimo?.prossimo ?? 0;
  }

  // Con ambito "propri" una voce di to-do è modificabile dal responsabile del task o dal suo assegnatario
  private verificaTodoModificabile(utente: UtenteAutenticato, t: { responsabileId: string | null }, voce: { assegnatarioId: string | null }): void {
    // Ambito concesso
    const ambito = richiediAmbito(utente, 'task.write');
    // Ambito "tutti": nessun ulteriore controllo
    if (ambito === 'tutti') return;
    // Responsabile del task: può sempre agire
    if (t.responsabileId === utente.id) return;
    // Assegnatario della voce: può spuntarla e modificarla
    if (voce.assegnatarioId === utente.id) return;
    // Altrimenti niente
    throw permessoNegato('Puoi modificare solo le voci dei tuoi task o quelle assegnate a te');
  }


}
