// =====================================================================================
// Controllo di accesso a progetti e task con applicazione dell'ambito
// -------------------------------------------------------------------------------------
// Regole applicate qui (e SOLO qui, così restano coerenti in tutto il modulo):
//
//  progetti.read   ambito "propri" -> progetti in cui l'utente è COINVOLTO, cioè:
//                                     è responsabile del progetto, oppure responsabile
//                                     di almeno un task, oppure assegnatario di almeno
//                                     una voce di to-do.
//  progetti.write  ambito "propri" -> solo i progetti di cui è responsabile
//  progetti.delete ambito "propri" -> solo i progetti di cui è responsabile
//  task.write      ambito "propri" -> può operare nei progetti in cui è coinvolto, ma
//                                     solo sui task di cui è responsabile (vedi
//                                     verificaTaskModificabile); i task che crea vengono
//                                     assegnati a lui stesso.
//  ore.write       ambito "propri" -> può registrare ore solo a proprio nome
// =====================================================================================

// Importa gli operatori di query
import { and, eq, isNull, or, sql, type SQL } from 'drizzle-orm';
// Importa il tipo dei codici permesso
import type { CodicePermesso } from '@crm/shared';
// Importa il tipo del database/transazione
import type { DbOTransazione } from '../../database/client';
// Importa le tabelle
import { progetti, progettoColonne, task, taskTodo } from '../../database/schema';
// Importa ambito ed eccezioni
import { richiediAmbito } from '../../common/auth/ambito';
import type { UtenteAutenticato } from '../../common/auth/tipi';
import { nonTrovato, permessoNegato } from '../../common/errori/errori';

// Modi di applicare l'ambito "propri" su un progetto
// - "coinvolto"    : responsabile del progetto, di un task o assegnatario di una to-do (lettura e operatività)
// - "responsabile" : solo responsabile del progetto (modifica ed eliminazione del progetto)
export type ModoAmbito = 'coinvolto' | 'responsabile';

// Condizione SQL che limita i progetti all'ambito dell'utente.
// Restituisce undefined con ambito "tutti": nessun filtro aggiuntivo.
export function condizioneAmbitoProgetti(utente: UtenteAutenticato, permesso: CodicePermesso, modo: ModoAmbito = 'coinvolto'): SQL | undefined {
  // Legge l'ambito concesso (403 se il permesso manca del tutto)
  const ambito = richiediAmbito(utente, permesso);
  // Ambito "tutti": nessuna restrizione
  if (ambito === 'tutti') return undefined;
  // L'utente è responsabile del progetto
  const responsabileProgetto = eq(progetti.responsabileId, utente.id);
  // Modo "responsabile": si ferma qui
  if (modo === 'responsabile') return responsabileProgetto;
  // Esiste almeno un task di questo progetto assegnato all'utente
  // (sottoquery correlata: ${progetti.id} si riferisce alla riga esterna; i valori sono parametrizzati)
  const haTaskAssegnato = sql`EXISTS (
    SELECT 1 FROM ${task}
    WHERE ${task.progettoId} = ${progetti.id} AND ${task.responsabileId} = ${utente.id}
  )`;
  // Esiste almeno una voce di to-do di questo progetto assegnata all'utente
  const haTodoAssegnata = sql`EXISTS (
    SELECT 1 FROM ${taskTodo}
    JOIN ${task} ON ${task.id} = ${taskTodo.taskId}
    WHERE ${task.progettoId} = ${progetti.id} AND ${taskTodo.assegnatarioId} = ${utente.id}
  )`;
  // Coinvolto = una qualsiasi delle tre condizioni
  return or(responsabileProgetto, haTaskAssegnato, haTodoAssegnata);
}

// Carica un progetto non eliminato e accessibile all'utente; altrimenti 404
export async function progettoAccessibile(
  tx: DbOTransazione,
  utente: UtenteAutenticato,
  permesso: CodicePermesso,
  progettoId: string,
  modo: ModoAmbito = 'coinvolto',
) {
  // Cerca applicando id, eliminazione logica e ambito
  const [progetto] = await tx
    .select()
    .from(progetti)
    .where(and(eq(progetti.id, progettoId), isNull(progetti.deletedAt), condizioneAmbitoProgetti(utente, permesso, modo)))
    .limit(1);
  // Inesistente o fuori ambito: stessa risposta, per non rivelare l'esistenza del record
  if (!progetto) throw nonTrovato('Progetto');
  // Restituisce il progetto
  return progetto;
}

// Carica un task verificando l'accesso al progetto che lo contiene
export async function taskAccessibile(tx: DbOTransazione, utente: UtenteAutenticato, permesso: CodicePermesso, taskId: string) {
  // Legge il task insieme al progetto (che serve per i controlli successivi)
  const [riga] = await tx
    .select({ task, progetto: progetti })
    .from(task)
    .innerJoin(progetti, eq(progetti.id, task.progettoId))
    .where(and(eq(task.id, taskId), isNull(progetti.deletedAt), condizioneAmbitoProgetti(utente, permesso)))
    .limit(1);
  // Inesistente o fuori ambito
  if (!riga) throw nonTrovato('Task');
  // Restituisce task e progetto
  return riga;
}

// Verifica che l'utente possa MODIFICARE questo specifico task.
// Con ambito "propri" può agire solo sui task di cui è responsabile.
export function verificaTaskModificabile(utente: UtenteAutenticato, t: { responsabileId: string | null }): void {
  // Ambito concesso per la scrittura dei task
  const ambito = richiediAmbito(utente, 'task.write');
  // Ambito "tutti": nessun ulteriore controllo
  if (ambito === 'tutti') return;
  // Ambito "propri": deve essere il responsabile del task
  if (t.responsabileId !== utente.id) throw permessoNegato('Puoi modificare solo i task di cui sei responsabile');
}

// Verifica che una colonna appartenga al progetto indicato e la restituisce
export async function colonnaDelProgetto(tx: DbOTransazione, progettoId: string, colonnaId: string) {
  // Cerca la colonna vincolandola al progetto: impedisce di spostare un task in un'altra bacheca
  const [colonna] = await tx
    .select()
    .from(progettoColonne)
    .where(and(eq(progettoColonne.id, colonnaId), eq(progettoColonne.progettoId, progettoId)))
    .limit(1);
  // Colonna inesistente o appartenente a un altro progetto
  if (!colonna) throw nonTrovato('Colonna');
  // Restituisce la colonna
  return colonna;
}
