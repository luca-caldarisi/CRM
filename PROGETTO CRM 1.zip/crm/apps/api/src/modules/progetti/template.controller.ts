// =====================================================================================
// API dei template di progetto: /api/v1/progetto-template
// -------------------------------------------------------------------------------------
// La lettura è aperta a chi può creare progetti (deve poter scegliere un template);
// la gestione richiede il permesso dedicato "template.manage".
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post, Put, Query } from '@nestjs/common';
// Importa la creazione dei DTO dagli schemi Zod
import { createZodDto } from 'nestjs-zod';
// Importa Zod e gli schemi condivisi
import { z } from 'zod';
import { aggiornaTemplateSchema, booleanQuerySchema, creaTemplateSchema, parametroIdSchema, strutturaTemplateSchema } from '@crm/shared';
// Importa decoratori di accesso
import { Contesto, RichiedePermesso } from '../../common/auth/decoratori';
import type { ContestoRichiesta } from '../../common/auth/tipi';
// Importa il service
import { TemplateService } from './template.service';

// Filtro dell'elenco: "?attivi=true" mostra solo i template utilizzabili
const filtriTemplateSchema = z.object({ attivi: booleanQuerySchema.optional() });

// DTO
class FiltriTemplateDto extends createZodDto(filtriTemplateSchema) {}
class CreaTemplateDto extends createZodDto(creaTemplateSchema) {}
class AggiornaTemplateDto extends createZodDto(aggiornaTemplateSchema) {}
class StrutturaTemplateDto extends createZodDto(strutturaTemplateSchema) {}
class ParametroIdDto extends createZodDto(parametroIdSchema) {}

@Controller('progetto-template')
export class TemplateController {
  // Riceve il service
  constructor(private readonly template: TemplateService) {}

  // GET /api/v1/progetto-template - elenco dei template
  @Get()
  @RichiedePermesso('progetti.read')
  lista(@Query() filtri: FiltriTemplateDto) {
    return this.template.lista(filtri.attivi === true);
  }

  // GET /api/v1/progetto-template/:id - dettaglio con la struttura completa
  @Get(':id')
  @RichiedePermesso('progetti.read')
  dettaglio(@Param() { id }: ParametroIdDto) {
    return this.template.dettaglio(id);
  }

  // POST /api/v1/progetto-template - crea un template con la struttura di base
  @Post()
  @RichiedePermesso('template.manage')
  crea(@Contesto() contesto: ContestoRichiesta, @Body() dati: CreaTemplateDto) {
    return this.template.crea(contesto, dati);
  }

  // PATCH /api/v1/progetto-template/:id - modifica i dati generali
  @Patch(':id')
  @RichiedePermesso('template.manage')
  aggiorna(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaTemplateDto) {
    return this.template.aggiorna(contesto, id, dati);
  }

  // PUT /api/v1/progetto-template/:id/struttura - sostituisce colonne, task e to-do
  // È un PUT perché l'editor invia sempre la struttura completa, non una modifica parziale
  @Put(':id/struttura')
  @RichiedePermesso('template.manage')
  salvaStruttura(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: StrutturaTemplateDto) {
    return this.template.salvaStruttura(contesto, id, dati);
  }

  // DELETE /api/v1/progetto-template/:id - elimina un template non ancora usato
  @Delete(':id')
  @RichiedePermesso('template.manage')
  @HttpCode(HttpStatus.NO_CONTENT)
  elimina(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.template.elimina(contesto, id);
  }
}
