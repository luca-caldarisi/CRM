// =====================================================================================
// Gestione progetti: anagrafica, creazione da template, bacheca e riepilogo avanzamento
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { and, asc, count, desc, eq, ilike, inArray, isNull, or, sql, type SQL } from 'drizzle-orm';
// Importa l'helper per gli alias di tabella
import { alias } from 'drizzle-orm/pg-core';
// Importa tipi condivisi
import type {
  AggiornaProgettoDati,
  Bacheca,
  ColonnaProgetto,
  CreaProgettoDati,
  Progetto,
  ProgettoLista,
  RiepilogoProgetto,
  RispostaPaginata,
  StatoProgetto,
  TaskBacheca,
} from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import {
  clienti,
  commesse,
  progetti,
  progettoColonne,
  progettoTemplate,
  registrazioniOre,
  task,
  taskTodo,
  templateColonne,
  templateTask,
  templateTodo,
  utenti,
} from '../../database/schema';
// Importa sicurezza, eccezioni e utilità
import { richiediAmbito } from '../../common/auth/ambito';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
import { nonTrovato, regolaViolata } from '../../common/errori/errori';
import { prossimoCodiceProgetto } from '../../common/utils/codici';
import { limitOffset, ordinamento, patternContiene } from '../../common/utils/query';
// Importa le utilità comuni (date e verifiche condivise)
import { oggi } from '../../common/utils/date';
import { verificaUtenteAttivo } from '../../common/utils/verifiche';
// Importa il registro attività
import { AuditService } from '../audit/audit.service';
// Importa i controlli di accesso
import { clienteAccessibile } from '../clienti/accesso-clienti';
import { condizioneAmbitoProgetti, progettoAccessibile } from './accesso-progetti';

// Filtri della lista (già validati dallo schema condiviso)
interface FiltriProgetti {
  page: number;
  pageSize: number;
  q?: string;
  sort?: string;
  clienteId?: string;
  commessaId?: string;
  responsabileId?: string;
  stato?: StatoProgetto;
}

// Alias della tabella utenti usata come responsabile del progetto
const responsabile = alias(utenti, 'responsabile_progetto');
// Alias della tabella utenti usata come responsabile del task
const responsabileTask = alias(utenti, 'responsabile_task');

// Numero di task del progetto della riga corrente (sottoquery correlata)
const contaTask = sql<number>`(SELECT COUNT(*)::int FROM ${task} WHERE ${task.progettoId} = ${progetti.id})`;
// Numero di task che si trovano in una colonna marcata come "di completamento"
const contaTaskCompletati = sql<number>`(
  SELECT COUNT(*)::int FROM ${task}
  JOIN ${progettoColonne} ON ${progettoColonne.id} = ${task.colonnaId}
  WHERE ${task.progettoId} = ${progetti.id} AND ${progettoColonne.consideraCompletato}
)`;

// Calcola la percentuale di avanzamento: task completati sul totale, arrotondata all'intero
function percentuale(completati: number, totali: number): number {
  // Un progetto senza task è allo 0%: evita anche la divisione per zero
  if (totali === 0) return 0;
  // Percentuale arrotondata
  return Math.round((completati / totali) * 100);
}


@Injectable()
export class ProgettiService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // ---------------------------------- Elenco ------------------------------------------

  // Elenco paginato dei progetti con avanzamento calcolato
  async lista(utente: UtenteAutenticato, filtri: FiltriProgetti): Promise<RispostaPaginata<ProgettoLista>> {
    // Condizioni fisse: non eliminati, cliente non eliminato, ambito dell'utente
    const condizioni: (SQL | undefined)[] = [isNull(progetti.deletedAt), isNull(clienti.deletedAt), condizioneAmbitoProgetti(utente, 'progetti.read')];
    // Ricerca libera su codice, nome e ragione sociale del cliente
    if (filtri.q) {
      // Pattern "contiene" con caratteri jolly neutralizzati
      const p = patternContiene(filtri.q);
      // OR tra i campi cercabili
      condizioni.push(or(ilike(progetti.codice, p), ilike(progetti.nome, p), ilike(clienti.ragioneSociale, p)));
    }
    // Filtri esatti
    if (filtri.clienteId) condizioni.push(eq(progetti.clienteId, filtri.clienteId));
    if (filtri.commessaId) condizioni.push(eq(progetti.commessaId, filtri.commessaId));
    if (filtri.responsabileId) condizioni.push(eq(progetti.responsabileId, filtri.responsabileId));
    if (filtri.stato) condizioni.push(eq(progetti.stato, filtri.stato));
    // Combina tutte le condizioni in AND
    const where = and(...condizioni);
    // Campi su cui è consentito ordinare (whitelist: il client non sceglie colonne arbitrarie)
    const consentiti = {
      codice: progetti.codice,
      nome: progetti.nome,
      stato: progetti.stato,
      cliente: clienti.ragioneSociale,
      dataInizio: progetti.dataInizio,
      dataFinePrevista: progetti.dataFinePrevista,
      updatedAt: progetti.updatedAt,
    };
    // Clausole ORDER BY (predefinito: più recenti prima)
    const ordine = ordinamento(filtri.sort, consentiti, [desc(progetti.codice)]);
    // Paginazione
    const { limit, offset } = limitOffset(filtri);
    // Query dati e conteggio totale in parallelo
    const [righe, [tot]] = await Promise.all([
      this.db
        .select({
          progetto: progetti,
          clienteRagioneSociale: clienti.ragioneSociale,
          responsabileNome: responsabile.nome,
          responsabileCognome: responsabile.cognome,
          taskTotali: contaTask,
          taskCompletati: contaTaskCompletati,
        })
        .from(progetti)
        .innerJoin(clienti, eq(clienti.id, progetti.clienteId))
        .leftJoin(responsabile, eq(responsabile.id, progetti.responsabileId))
        .where(where)
        .orderBy(...ordine)
        .limit(limit)
        .offset(offset),
      this.db.select({ n: count() }).from(progetti).innerJoin(clienti, eq(clienti.id, progetti.clienteId)).where(where),
    ]);
    // Converte le righe nel formato dell'API
    const data: ProgettoLista[] = righe.map((r) => ({
      id: r.progetto.id,
      codice: r.progetto.codice,
      nome: r.progetto.nome,
      stato: r.progetto.stato,
      cliente: { id: r.progetto.clienteId, ragioneSociale: r.clienteRagioneSociale },
      responsabile: r.progetto.responsabileId ? { id: r.progetto.responsabileId, nome: r.responsabileNome!, cognome: r.responsabileCognome! } : null,
      dataInizio: r.progetto.dataInizio,
      dataFinePrevista: r.progetto.dataFinePrevista,
      taskTotali: r.taskTotali,
      taskCompletati: r.taskCompletati,
      avanzamento: percentuale(r.taskCompletati, r.taskTotali),
    }));
    // Risposta paginata
    return { data, meta: { page: filtri.page, pageSize: filtri.pageSize, total: tot?.n ?? 0 } };
  }

  // --------------------------------- Dettaglio ----------------------------------------

  // Dettaglio di un progetto con le colonne della sua bacheca
  async dettaglio(utente: UtenteAutenticato, id: string, tx: DbOTransazione = this.db): Promise<Progetto> {
    // Legge il progetto con cliente, commessa, template e responsabile
    const [riga] = await tx
      .select({
        progetto: progetti,
        clienteRagioneSociale: clienti.ragioneSociale,
        commessaCodice: commesse.codice,
        commessaTitolo: commesse.titolo,
        templateNome: progettoTemplate.nome,
        responsabileNome: responsabile.nome,
        responsabileCognome: responsabile.cognome,
      })
      .from(progetti)
      .innerJoin(clienti, eq(clienti.id, progetti.clienteId))
      .leftJoin(commesse, eq(commesse.id, progetti.commessaId))
      .leftJoin(progettoTemplate, eq(progettoTemplate.id, progetti.templateId))
      .leftJoin(responsabile, eq(responsabile.id, progetti.responsabileId))
      .where(and(eq(progetti.id, id), isNull(progetti.deletedAt), condizioneAmbitoProgetti(utente, 'progetti.read')))
      .limit(1);
    // Progetto inesistente o fuori ambito
    if (!riga) throw nonTrovato('Progetto');
    // Colonne della bacheca, da sinistra a destra
    const colonne = await this.colonne(tx, id);
    // Compone la risposta
    const p = riga.progetto;
    return {
      id: p.id,
      codice: p.codice,
      nome: p.nome,
      descrizione: p.descrizione,
      stato: p.stato,
      cliente: { id: p.clienteId, ragioneSociale: riga.clienteRagioneSociale },
      commessa: p.commessaId ? { id: p.commessaId, codice: riga.commessaCodice!, titolo: riga.commessaTitolo! } : null,
      template: p.templateId ? { id: p.templateId, nome: riga.templateNome! } : null,
      responsabile: p.responsabileId ? { id: p.responsabileId, nome: riga.responsabileNome!, cognome: riga.responsabileCognome! } : null,
      dataInizio: p.dataInizio,
      dataFinePrevista: p.dataFinePrevista,
      dataFineEffettiva: p.dataFineEffettiva,
      note: p.note,
      colonne,
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    };
  }

  // Colonne della bacheca di un progetto, ordinate da sinistra a destra
  private async colonne(tx: DbOTransazione, progettoId: string): Promise<ColonnaProgetto[]> {
    // Legge le colonne del progetto
    return tx
      .select({ id: progettoColonne.id, nome: progettoColonne.nome, ordine: progettoColonne.ordine, consideraCompletato: progettoColonne.consideraCompletato })
      .from(progettoColonne)
      .where(eq(progettoColonne.progettoId, progettoId))
      .orderBy(asc(progettoColonne.ordine));
  }

  // ---------------------------------- Creazione ---------------------------------------

  // Crea un progetto, eventualmente copiando colonne, task e to-do da un template
  async crea(contesto: ContestoRichiesta, dati: CreaProgettoDati): Promise<Progetto> {
    // Ambito di scrittura (403 se il permesso manca)
    const ambito = richiediAmbito(contesto.utente, 'progetti.write');
    // Con ambito "propri" il responsabile è sempre chi crea il progetto
    const responsabileId = ambito === 'propri' ? contesto.utente.id : (dati.responsabileId ?? null);
    // Un progetto creato già concluso senza data di fine effettiva prende la data odierna
    const dataFineEffettiva = dati.dataFineEffettiva ?? (dati.stato === 'concluso' ? oggi() : null);
    // Tutta la creazione avviene in un'unica transazione: o nasce completa, o non nasce
    return this.db.transaction(async (tx) => {
      // Il cliente deve esistere ed essere visibile all'utente
      const cliente = await clienteAccessibile(tx, contesto.utente, 'clienti.read', dati.clienteId);
      // La commessa, se indicata, deve appartenere allo stesso cliente
      if (dati.commessaId) await this.verificaCommessa(tx, dati.commessaId, dati.clienteId);
      // Il responsabile, se indicato, deve essere un utente attivo
      if (responsabileId) await verificaUtenteAttivo(tx, responsabileId);
      // Codice progressivo dell'anno corrente
      const codice = await prossimoCodiceProgetto(tx, new Date().getFullYear());
      // Inserisce il progetto
      const [nuovo] = await tx
        .insert(progetti)
        .values({
          codice,
          clienteId: dati.clienteId,
          commessaId: dati.commessaId ?? null,
          templateId: dati.templateId ?? null,
          nome: dati.nome,
          descrizione: dati.descrizione ?? null,
          stato: dati.stato,
          responsabileId,
          dataInizio: dati.dataInizio ?? null,
          dataFinePrevista: dati.dataFinePrevista ?? null,
          dataFineEffettiva,
          note: dati.note ?? null,
          createdById: contesto.utente.id,
          updatedById: contesto.utente.id,
        })
        .returning();
      // Crea la bacheca: dal template se indicato, altrimenti con le colonne predefinite
      await this.creaBacheca(tx, contesto, nuovo!.id, dati.templateId ?? null, responsabileId);
      // Registra la creazione nel registro attività
      await this.audit.registra(tx, contesto, {
        azione: 'creazione',
        entita: 'progetto',
        entitaId: nuovo!.id,
        descrizione: `${codice} ${cliente.ragioneSociale} - ${nuovo!.nome}`,
        dopo: nuovo!,
      });
      // Restituisce il dettaglio appena creato
      return this.dettaglio(contesto.utente, nuovo!.id, tx);
    });
  }

  // Colonne usate quando il progetto non parte da un template
  private static readonly COLONNE_PREDEFINITE = [
    // Lavoro ancora da iniziare
    { nome: 'Da fare', consideraCompletato: false },
    // Lavoro in corso
    { nome: 'In corso', consideraCompletato: false },
    // In attesa di verifica o del cliente
    { nome: 'In verifica', consideraCompletato: false },
    // Lavoro concluso: conta nell'avanzamento
    { nome: 'Completato', consideraCompletato: true },
  ];

  // Crea colonne, task e to-do iniziali del progetto
  private async creaBacheca(tx: DbOTransazione, contesto: ContestoRichiesta, progettoId: string, templateId: string | null, responsabileId: string | null): Promise<void> {
    // Nessun template: usa le colonne predefinite e nessun task
    if (!templateId) {
      // Inserisce le colonne predefinite nell'ordine dichiarato
      await tx.insert(progettoColonne).values(
        ProgettiService.COLONNE_PREDEFINITE.map((c, i) => ({ progettoId, nome: c.nome, ordine: i, consideraCompletato: c.consideraCompletato })),
      );
      // Bacheca vuota: si finisce qui
      return;
    }
    // Verifica che il template esista e sia utilizzabile
    const [modello] = await tx.select().from(progettoTemplate).where(eq(progettoTemplate.id, templateId)).limit(1);
    // Template inesistente
    if (!modello) throw regolaViolata('Il template indicato non esiste');
    // Template disattivato: non si possono creare nuovi progetti
    if (!modello.attivo) throw regolaViolata('Il template indicato non è più attivo');
    // Legge le colonne del template, in ordine
    const colonneModello = await tx.select().from(templateColonne).where(eq(templateColonne.templateId, templateId)).orderBy(asc(templateColonne.ordine));
    // Un template senza colonne non può generare una bacheca valida
    if (colonneModello.length === 0) throw regolaViolata('Il template non ha ancora una struttura: definire almeno due colonne');
    // Copia (snapshot) le colonne nel progetto: modificare il template in futuro non toccherà questo progetto
    const colonneCreate = await tx
      .insert(progettoColonne)
      .values(colonneModello.map((c, i) => ({ progettoId, nome: c.nome, ordine: i, consideraCompletato: c.consideraCompletato })))
      .returning();
    // Mappa indice colonna -> id della colonna creata
    const idPerIndice = new Map(colonneCreate.map((c) => [c.ordine, c.id]));
    // Legge i task del template, in ordine
    const taskModello = await tx.select().from(templateTask).where(eq(templateTask.templateId, templateId)).orderBy(asc(templateTask.ordine));
    // Nessun task predefinito: la bacheca nasce vuota
    if (taskModello.length === 0) return;
    // Crea i task copiando titolo, descrizione, ore stimate e colonna iniziale
    const taskCreati = await tx
      .insert(task)
      .values(
        taskModello.map((t, i) => ({
          progettoId,
          // Se l'indice di colonna del template non esiste più, ripiega sulla prima colonna
          colonnaId: idPerIndice.get(t.colonnaIndice) ?? colonneCreate[0]!.id,
          titolo: t.titolo,
          descrizione: t.descrizione,
          oreStimate: t.oreStimate,
          // Il responsabile del progetto diventa responsabile iniziale dei task generati
          responsabileId,
          // Posizione nella colonna, nell'ordine previsto dal template
          ordine: i,
          createdById: contesto.utente.id,
          updatedById: contesto.utente.id,
        })),
      )
      .returning();
    // Mappa id del task del template -> id del task creato
    const idTaskPerModello = new Map(taskModello.map((t, i) => [t.id, taskCreati[i]!.id]));
    // Legge tutte le voci di to-do dei task del template in una sola query
    const todoModello = await tx
      .select()
      .from(templateTodo)
      // IN (...) sugli id dei task del template
      .where(inArray(templateTodo.templateTaskId, taskModello.map((t) => t.id)))
      .orderBy(asc(templateTodo.ordine));
    // Nessuna voce da copiare
    if (todoModello.length === 0) return;
    // Copia le voci di to-do sui task appena creati
    await tx.insert(taskTodo).values(
      todoModello.map((v) => ({
        taskId: idTaskPerModello.get(v.templateTaskId)!,
        titolo: v.titolo,
        ordine: v.ordine,
        createdById: contesto.utente.id,
        updatedById: contesto.utente.id,
      })),
    );
  }

  // ---------------------------------- Modifica ----------------------------------------

  // Modifica i dati generali di un progetto
  async aggiorna(contesto: ContestoRichiesta, id: string, dati: AggiornaProgettoDati): Promise<Progetto> {
    // Ambito di scrittura
    const ambito = richiediAmbito(contesto.utente, 'progetti.write');
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Carica il progetto verificando l'accesso in scrittura (solo il responsabile con ambito "propri")
      const attuale = await progettoAccessibile(tx, contesto.utente, 'progetti.write', id, 'responsabile');
      // Con ambito "propri" non si può passare il progetto a un altro responsabile
      if (ambito === 'propri' && dati.responsabileId !== undefined && dati.responsabileId !== contesto.utente.id) {
        throw regolaViolata('Non puoi assegnare il progetto a un altro responsabile');
      }
      // La commessa, se cambiata, deve appartenere allo stesso cliente
      if (dati.commessaId) await this.verificaCommessa(tx, dati.commessaId, attuale.clienteId);
      // Il nuovo responsabile deve essere attivo
      if (dati.responsabileId) await verificaUtenteAttivo(tx, dati.responsabileId);
      // Date risultanti dopo la modifica
      const dataInizio = dati.dataInizio !== undefined ? dati.dataInizio : attuale.dataInizio;
      const dataFinePrevista = dati.dataFinePrevista !== undefined ? dati.dataFinePrevista : attuale.dataFinePrevista;
      // Fine effettiva: valore esplicito, oppure oggi se il progetto viene concluso ora
      let dataFineEffettiva = dati.dataFineEffettiva !== undefined ? dati.dataFineEffettiva : attuale.dataFineEffettiva;
      // Passaggio a "concluso" senza data: imposta oggi
      if (dati.stato === 'concluso' && !dataFineEffettiva) dataFineEffettiva = oggi();
      // Coerenza delle date con messaggio chiaro, prima che intervenga il vincolo del database
      if (dataInizio && dataFinePrevista && dataFinePrevista < dataInizio) throw regolaViolata("La fine prevista non può precedere l'inizio");
      // Salva le modifiche
      const [aggiornato] = await tx
        .update(progetti)
        .set({
          ...dati,
          dataInizio: dataInizio ?? null,
          dataFinePrevista: dataFinePrevista ?? null,
          dataFineEffettiva: dataFineEffettiva ?? null,
          updatedById: contesto.utente.id,
        })
        .where(eq(progetti.id, id))
        .returning();
      // Registra le differenze nel registro attività
      await this.audit.registra(tx, contesto, {
        azione: 'modifica',
        entita: 'progetto',
        entitaId: id,
        descrizione: `${attuale.codice} ${aggiornato!.nome}`,
        prima: attuale,
        dopo: aggiornato!,
      });
      // Restituisce il dettaglio aggiornato
      return this.dettaglio(contesto.utente, id, tx);
    });
  }

  // Eliminazione logica del progetto (i task restano nel database ma non sono più raggiungibili)
  async elimina(contesto: ContestoRichiesta, id: string): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Carica verificando il permesso di eliminazione
      const attuale = await progettoAccessibile(tx, contesto.utente, 'progetti.delete', id, 'responsabile');
      // Imposta la data di eliminazione
      await tx.update(progetti).set({ deletedAt: new Date(), updatedById: contesto.utente.id }).where(eq(progetti.id, id));
      // Registra l'eliminazione
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'progetto', entitaId: id, descrizione: `${attuale.codice} ${attuale.nome}` });
    });
  }

  // ----------------------------------- Bacheca ----------------------------------------

  // Bacheca completa: colonne con i rispettivi task, pronta per il Kanban
  async bacheca(utente: UtenteAutenticato, progettoId: string): Promise<Bacheca> {
    // Verifica l'accesso al progetto
    await progettoAccessibile(this.db, utente, 'progetti.read', progettoId);
    // Colonne della bacheca
    const colonne = await this.colonne(this.db, progettoId);
    // Task del progetto con responsabile, minuti registrati e conteggio delle to-do
    const righe = await this.db
      .select({
        task,
        responsabileNome: responsabileTask.nome,
        responsabileCognome: responsabileTask.cognome,
        // Minuti totali registrati sul task
        minutiRegistrati: sql<number>`COALESCE((SELECT SUM(${registrazioniOre.minuti})::int FROM ${registrazioniOre} WHERE ${registrazioniOre.taskId} = ${task.id}), 0)`,
        // Numero di voci della to-do
        todoTotali: sql<number>`(SELECT COUNT(*)::int FROM ${taskTodo} WHERE ${taskTodo.taskId} = ${task.id})`,
        // Numero di voci completate
        todoCompletate: sql<number>`(SELECT COUNT(*)::int FROM ${taskTodo} WHERE ${taskTodo.taskId} = ${task.id} AND ${taskTodo.completata})`,
      })
      .from(task)
      .leftJoin(responsabileTask, eq(responsabileTask.id, task.responsabileId))
      .where(eq(task.progettoId, progettoId))
      // Ordine di visualizzazione nella colonna
      .orderBy(asc(task.ordine), asc(task.createdAt));
    // Raggruppa i task per colonna
    const perColonna = new Map<string, TaskBacheca[]>();
    // Scorre le righe e le inserisce nel gruppo della propria colonna
    for (const r of righe) {
      // Elenco della colonna (creato alla prima occorrenza)
      const elenco = perColonna.get(r.task.colonnaId) ?? [];
      // Aggiunge il task convertito nel formato dell'API
      elenco.push({
        id: r.task.id,
        colonnaId: r.task.colonnaId,
        titolo: r.task.titolo,
        priorita: r.task.priorita,
        dataScadenza: r.task.dataScadenza,
        oreStimate: r.task.oreStimate,
        minutiRegistrati: r.minutiRegistrati,
        responsabile: r.task.responsabileId ? { id: r.task.responsabileId, nome: r.responsabileNome!, cognome: r.responsabileCognome! } : null,
        todoTotali: r.todoTotali,
        todoCompletate: r.todoCompletate,
        ordine: r.task.ordine,
      });
      // Rimette l'elenco nella mappa
      perColonna.set(r.task.colonnaId, elenco);
    }
    // Compone la bacheca nell'ordine delle colonne
    return { colonne: colonne.map((c) => ({ ...c, task: perColonna.get(c.id) ?? [] })) };
  }

  // ---------------------------------- Riepilogo ---------------------------------------

  // Riepilogo dell'avanzamento del progetto
  async riepilogo(utente: UtenteAutenticato, progettoId: string): Promise<RiepilogoProgetto> {
    // Verifica l'accesso al progetto
    await progettoAccessibile(this.db, utente, 'progetti.read', progettoId);
    // Data odierna per il calcolo dei ritardi
    const adesso = oggi();
    // Esegue in parallelo le query indipendenti del riepilogo
    const [totali, perColonna, perTecnico, todo, ultimeOre] = await Promise.all([
      // Totali generali: task, task completati, task in ritardo, minuti stimati e registrati
      this.db
        .select({
          taskTotali: count(),
          // Task in una colonna di completamento
          taskCompletati: sql<number>`COUNT(*) FILTER (WHERE ${progettoColonne.consideraCompletato})::int`,
          // Task non completati con scadenza già passata
          taskInRitardo: sql<number>`COUNT(*) FILTER (WHERE NOT ${progettoColonne.consideraCompletato} AND ${task.dataScadenza} IS NOT NULL AND ${task.dataScadenza} < ${adesso})::int`,
          // Ore stimate convertite in minuti (le ore sono decimali: 1,5 -> 90)
          minutiStimati: sql<number>`COALESCE(SUM(${task.oreStimate}) * 60, 0)::int`,
        })
        .from(task)
        .innerJoin(progettoColonne, eq(progettoColonne.id, task.colonnaId))
        .where(eq(task.progettoId, progettoId)),
      // Numero di task per colonna (anche le colonne vuote, grazie alla LEFT JOIN)
      this.db
        .select({
          colonnaId: progettoColonne.id,
          nome: progettoColonne.nome,
          consideraCompletato: progettoColonne.consideraCompletato,
          ordine: progettoColonne.ordine,
          task: sql<number>`COUNT(${task.id})::int`,
        })
        .from(progettoColonne)
        .leftJoin(task, eq(task.colonnaId, progettoColonne.id))
        .where(eq(progettoColonne.progettoId, progettoId))
        .groupBy(progettoColonne.id, progettoColonne.nome, progettoColonne.consideraCompletato, progettoColonne.ordine)
        .orderBy(asc(progettoColonne.ordine)),
      // Ore registrate per tecnico
      this.db
        .select({
          id: utenti.id,
          nome: utenti.nome,
          cognome: utenti.cognome,
          minuti: sql<number>`SUM(${registrazioniOre.minuti})::int`,
          task: sql<number>`COUNT(DISTINCT ${registrazioniOre.taskId})::int`,
        })
        .from(registrazioniOre)
        .innerJoin(task, eq(task.id, registrazioniOre.taskId))
        .innerJoin(utenti, eq(utenti.id, registrazioniOre.utenteId))
        .where(eq(task.progettoId, progettoId))
        .groupBy(utenti.id, utenti.nome, utenti.cognome)
        .orderBy(desc(sql`SUM(${registrazioniOre.minuti})`)),
      // Voci della to-do: totale e completate
      this.db
        .select({
          totali: count(),
          completate: sql<number>`COUNT(*) FILTER (WHERE ${taskTodo.completata})::int`,
        })
        .from(taskTodo)
        .innerJoin(task, eq(task.id, taskTodo.taskId))
        .where(eq(task.progettoId, progettoId)),
      // Ultime 10 registrazioni di ore, per la timeline del riepilogo
      this.db
        .select({ ore: registrazioniOre, nome: utenti.nome, cognome: utenti.cognome })
        .from(registrazioniOre)
        .innerJoin(task, eq(task.id, registrazioniOre.taskId))
        .innerJoin(utenti, eq(utenti.id, registrazioniOre.utenteId))
        .where(eq(task.progettoId, progettoId))
        .orderBy(desc(registrazioniOre.data), desc(registrazioniOre.createdAt))
        .limit(10),
    ]);
    // Riga dei totali (una sola, anche senza task)
    const t = totali[0] ?? { taskTotali: 0, taskCompletati: 0, taskInRitardo: 0, minutiStimati: 0 };
    // Somma dei minuti registrati su tutti i tecnici
    const minutiRegistrati = perTecnico.reduce((somma, r) => somma + r.minuti, 0);
    // Compone il riepilogo
    return {
      avanzamento: percentuale(t.taskCompletati, t.taskTotali),
      taskTotali: t.taskTotali,
      taskCompletati: t.taskCompletati,
      taskInRitardo: t.taskInRitardo,
      minutiStimati: t.minutiStimati,
      minutiRegistrati,
      perColonna: perColonna.map((c) => ({ colonnaId: c.colonnaId, nome: c.nome, consideraCompletato: c.consideraCompletato, task: c.task })),
      perTecnico: perTecnico.map((r) => ({ utente: { id: r.id, nome: r.nome, cognome: r.cognome }, minuti: r.minuti, task: r.task })),
      todoTotali: todo[0]?.totali ?? 0,
      todoCompletate: todo[0]?.completate ?? 0,
      ultimeOre: ultimeOre.map((r) => ({
        id: r.ore.id,
        taskId: r.ore.taskId,
        data: r.ore.data,
        minuti: r.ore.minuti,
        descrizione: r.ore.descrizione,
        utente: { id: r.ore.utenteId, nome: r.nome, cognome: r.cognome },
        createdAt: r.ore.createdAt.toISOString(),
      })),
    };
  }

  // ------------------------------- Metodi di supporto ---------------------------------

  // Verifica che la commessa esista, non sia eliminata e appartenga allo stesso cliente
  private async verificaCommessa(tx: DbOTransazione, commessaId: string, clienteId: string): Promise<void> {
    // Cerca la commessa attiva del cliente
    const [c] = await tx
      .select({ id: commesse.id })
      .from(commesse)
      .where(and(eq(commesse.id, commessaId), eq(commesse.clienteId, clienteId), isNull(commesse.deletedAt)))
      .limit(1);
    // Commessa inesistente o di un altro cliente
    if (!c) throw regolaViolata('La commessa indicata non esiste o non appartiene a questo cliente');
  }

}
