// =====================================================================================
// API progetti: /api/v1/progetti
// =====================================================================================

// Importa i decoratori di NestJS
import { Body, Controller, Delete, Get, HttpCode, HttpStatus, Param, Patch, Post, Query } from '@nestjs/common';
// Importa la creazione dei DTO dagli schemi Zod
import { createZodDto } from 'nestjs-zod';
// Importa schemi condivisi
import { aggiornaProgettoSchema, creaProgettoSchema, creaTaskSchema, filtriOreSchema, filtriProgettiSchema, parametroIdSchema } from '@crm/shared';
// Importa decoratori di accesso
import { Contesto, RichiedePermesso, UtenteCorrente } from '../../common/auth/decoratori';
import type { ContestoRichiesta, UtenteAutenticato } from '../../common/auth/tipi';
// Importa i service
import { ProgettiService } from './progetti.service';
import { TaskService } from './task.service';

// DTO generati dagli schemi condivisi: la validazione è identica a quella del frontend
class FiltriProgettiDto extends createZodDto(filtriProgettiSchema) {}
class CreaProgettoDto extends createZodDto(creaProgettoSchema) {}
class AggiornaProgettoDto extends createZodDto(aggiornaProgettoSchema) {}
class CreaTaskDto extends createZodDto(creaTaskSchema) {}
class FiltriOreDto extends createZodDto(filtriOreSchema) {}
class ParametroIdDto extends createZodDto(parametroIdSchema) {}

@Controller('progetti')
export class ProgettiController {
  constructor(
    // Service dei progetti
    private readonly progetti: ProgettiService,
    // Service dei task (serve per creare un task dentro un progetto)
    private readonly task: TaskService,
  ) {}

  // GET /api/v1/progetti - elenco paginato con avanzamento
  @Get()
  @RichiedePermesso('progetti.read')
  lista(@UtenteCorrente() utente: UtenteAutenticato, @Query() filtri: FiltriProgettiDto) {
    return this.progetti.lista(utente, filtri);
  }

  // GET /api/v1/progetti/:id - dettaglio con le colonne della bacheca
  @Get(':id')
  @RichiedePermesso('progetti.read')
  dettaglio(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto) {
    return this.progetti.dettaglio(utente, id);
  }

  // GET /api/v1/progetti/:id/bacheca - colonne con i rispettivi task (Kanban)
  @Get(':id/bacheca')
  @RichiedePermesso('progetti.read')
  bacheca(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto) {
    return this.progetti.bacheca(utente, id);
  }

  // GET /api/v1/progetti/:id/riepilogo - avanzamento, ritardi e ore
  @Get(':id/riepilogo')
  @RichiedePermesso('progetti.read')
  riepilogo(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto) {
    return this.progetti.riepilogo(utente, id);
  }

  // GET /api/v1/progetti/:id/ore - registrazioni ore di tutto il progetto, con filtri
  @Get(':id/ore')
  @RichiedePermesso('progetti.read')
  ore(@UtenteCorrente() utente: UtenteAutenticato, @Param() { id }: ParametroIdDto, @Query() filtri: FiltriOreDto) {
    return this.task.oreProgetto(utente, id, filtri);
  }

  // POST /api/v1/progetti - crea un progetto (eventualmente da un template)
  @Post()
  @RichiedePermesso('progetti.write')
  crea(@Contesto() contesto: ContestoRichiesta, @Body() dati: CreaProgettoDto) {
    return this.progetti.crea(contesto, dati);
  }

  // POST /api/v1/progetti/:id/task - aggiunge un task alla bacheca
  @Post(':id/task')
  @RichiedePermesso('task.write')
  creaTask(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: CreaTaskDto) {
    return this.task.crea(contesto, id, dati);
  }

  // PATCH /api/v1/progetti/:id - modifica i dati generali
  @Patch(':id')
  @RichiedePermesso('progetti.write')
  aggiorna(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto, @Body() dati: AggiornaProgettoDto) {
    return this.progetti.aggiorna(contesto, id, dati);
  }

  // DELETE /api/v1/progetti/:id - eliminazione logica
  @Delete(':id')
  @RichiedePermesso('progetti.delete')
  @HttpCode(HttpStatus.NO_CONTENT)
  elimina(@Contesto() contesto: ContestoRichiesta, @Param() { id }: ParametroIdDto) {
    return this.progetti.elimina(contesto, id);
  }
}
