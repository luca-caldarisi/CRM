// =====================================================================================
// Gestione dei template di progetto: dati generali e struttura (colonne + task + to-do)
// -------------------------------------------------------------------------------------
// Un template è lo "stampo" da cui nasce un progetto. Alla creazione del progetto la
// struttura viene COPIATA (snapshot): modificare il template non tocca i progetti in corso.
// =====================================================================================

// Importa i decoratori di NestJS
import { Inject, Injectable } from '@nestjs/common';
// Importa gli operatori di query
import { asc, eq, inArray, sql } from 'drizzle-orm';
// Importa tipi condivisi
import type { AggiornaTemplateDati, CreaTemplateDati, StrutturaTemplateDati, TemplateProgetto, TemplateProgettoDettaglio } from '@crm/shared';
// Importa database e tabelle
import { DB } from '../../database/database.module';
import type { Database, DbOTransazione } from '../../database/client';
import { progetti, progettoTemplate, templateColonne, templateTask, templateTodo } from '../../database/schema';
// Importa eccezioni
import type { ContestoRichiesta } from '../../common/auth/tipi';
import { nonTrovato, regolaViolata } from '../../common/errori/errori';
// Importa il registro attività
import { AuditService } from '../audit/audit.service';

// Conteggio delle colonne del template della riga corrente (sottoquery correlata)
const contaColonne = sql<number>`(SELECT COUNT(*)::int FROM ${templateColonne} WHERE ${templateColonne.templateId} = ${progettoTemplate.id})`;
// Conteggio dei task predefiniti del template
const contaTask = sql<number>`(SELECT COUNT(*)::int FROM ${templateTask} WHERE ${templateTask.templateId} = ${progettoTemplate.id})`;

@Injectable()
export class TemplateService {
  constructor(
    // Database
    @Inject(DB) private readonly db: Database,
    // Registro attività
    private readonly audit: AuditService,
  ) {}

  // Elenco completo dei template (sono pochi: non serve paginazione)
  // "soloAttivi" viene usato dalla creazione progetto, che non deve proporre template dismessi
  async lista(soloAttivi = false): Promise<TemplateProgetto[]> {
    // Legge i template con il numero di colonne e task
    const righe = await this.db
      .select({ t: progettoTemplate, numeroColonne: contaColonne, numeroTask: contaTask })
      .from(progettoTemplate)
      // Filtra i disattivati solo se richiesto
      .where(soloAttivi ? eq(progettoTemplate.attivo, true) : undefined)
      .orderBy(asc(progettoTemplate.categoria), asc(progettoTemplate.nome));
    // Converte nel formato dell'API
    return righe.map((r) => ({
      id: r.t.id,
      nome: r.t.nome,
      categoria: r.t.categoria,
      descrizione: r.t.descrizione,
      durataStimataGg: r.t.durataStimataGg,
      attivo: r.t.attivo,
      numeroColonne: r.numeroColonne,
      numeroTask: r.numeroTask,
    }));
  }

  // Dettaglio di un template con la struttura completa
  async dettaglio(id: string, tx: DbOTransazione = this.db): Promise<TemplateProgettoDettaglio> {
    // Legge il template con i conteggi
    const [riga] = await tx
      .select({ t: progettoTemplate, numeroColonne: contaColonne, numeroTask: contaTask })
      .from(progettoTemplate)
      .where(eq(progettoTemplate.id, id))
      .limit(1);
    // Template inesistente
    if (!riga) throw nonTrovato('Template');
    // Colonne, in ordine
    const colonne = await tx
      .select({ id: templateColonne.id, nome: templateColonne.nome, ordine: templateColonne.ordine, consideraCompletato: templateColonne.consideraCompletato })
      .from(templateColonne)
      .where(eq(templateColonne.templateId, id))
      .orderBy(asc(templateColonne.ordine));
    // Task predefiniti, in ordine
    const task = await tx.select().from(templateTask).where(eq(templateTask.templateId, id)).orderBy(asc(templateTask.ordine));
    // Voci di to-do di tutti i task, lette in un'unica query
    const voci = task.length
      ? await tx
          .select()
          .from(templateTodo)
          .where(inArray(templateTodo.templateTaskId, task.map((t) => t.id)))
          .orderBy(asc(templateTodo.ordine))
      : [];
    // Compone la risposta
    return {
      id: riga.t.id,
      nome: riga.t.nome,
      categoria: riga.t.categoria,
      descrizione: riga.t.descrizione,
      durataStimataGg: riga.t.durataStimataGg,
      attivo: riga.t.attivo,
      numeroColonne: riga.numeroColonne,
      numeroTask: riga.numeroTask,
      colonne,
      task: task.map((t) => ({
        id: t.id,
        titolo: t.titolo,
        descrizione: t.descrizione,
        colonnaIndice: t.colonnaIndice,
        oreStimate: t.oreStimate,
        ordine: t.ordine,
        // Solo i testi delle voci: nel template non esistono assegnazioni
        todo: voci.filter((v) => v.templateTaskId === t.id).map((v) => v.titolo),
      })),
    };
  }

  // Crea un template con la struttura predefinita di base
  async crea(contesto: ContestoRichiesta, dati: CreaTemplateDati): Promise<TemplateProgettoDettaglio> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Inserisce i dati generali (il nome è univoco: un duplicato diventa un 409 nel filtro errori)
      const [nuovo] = await tx
        .insert(progettoTemplate)
        .values({
          nome: dati.nome,
          categoria: dati.categoria ?? null,
          descrizione: dati.descrizione ?? null,
          durataStimataGg: dati.durataStimataGg ?? null,
          attivo: dati.attivo,
          createdById: contesto.utente.id,
          updatedById: contesto.utente.id,
        })
        .returning();
      // Colonne iniziali: un template nasce già utilizzabile, poi si personalizza
      await tx.insert(templateColonne).values([
        { templateId: nuovo!.id, nome: 'Da fare', ordine: 0, consideraCompletato: false },
        { templateId: nuovo!.id, nome: 'In corso', ordine: 1, consideraCompletato: false },
        { templateId: nuovo!.id, nome: 'Completato', ordine: 2, consideraCompletato: true },
      ]);
      // Registra la creazione
      await this.audit.registra(tx, contesto, { azione: 'creazione', entita: 'progetto_template', entitaId: nuovo!.id, descrizione: nuovo!.nome, dopo: nuovo! });
      // Restituisce il dettaglio
      return this.dettaglio(nuovo!.id, tx);
    });
  }

  // Modifica i dati generali di un template
  async aggiorna(contesto: ContestoRichiesta, id: string, dati: AggiornaTemplateDati): Promise<TemplateProgettoDettaglio> {
    // Esegue in transazione
    return this.db.transaction(async (tx) => {
      // Legge lo stato attuale
      const [attuale] = await tx.select().from(progettoTemplate).where(eq(progettoTemplate.id, id)).limit(1);
      // Template inesistente
      if (!attuale) throw nonTrovato('Template');
      // Salva le modifiche
      const [aggiornato] = await tx
        .update(progettoTemplate)
        .set({ ...dati, updatedById: contesto.utente.id })
        .where(eq(progettoTemplate.id, id))
        .returning();
      // Registra le differenze
      await this.audit.registra(tx, contesto, { azione: 'modifica', entita: 'progetto_template', entitaId: id, descrizione: aggiornato!.nome, prima: attuale, dopo: aggiornato! });
      // Restituisce il dettaglio
      return this.dettaglio(id, tx);
    });
  }

  // Sostituisce la struttura del template (colonne, task e to-do)
  // L'editor invia sempre la struttura completa: più semplice e meno soggetto a incoerenze
  // rispetto a una serie di modifiche parziali.
  async salvaStruttura(contesto: ContestoRichiesta, id: string, dati: StrutturaTemplateDati): Promise<TemplateProgettoDettaglio> {
    // Ogni task deve riferirsi a una colonna esistente nella nuova struttura
    for (const t of dati.task) {
      // Indice fuori dall'elenco delle colonne inviate
      if (t.colonnaIndice >= dati.colonne.length) throw regolaViolata(`Il task "${t.titolo}" fa riferimento a una colonna che non esiste`);
    }
    // Esegue in transazione: la struttura non deve mai restare a metà
    return this.db.transaction(async (tx) => {
      // Il template deve esistere
      const [attuale] = await tx.select().from(progettoTemplate).where(eq(progettoTemplate.id, id)).limit(1);
      // Template inesistente
      if (!attuale) throw nonTrovato('Template');
      // Cancella la struttura precedente (le voci di to-do seguono i task per ON DELETE CASCADE)
      await tx.delete(templateTask).where(eq(templateTask.templateId, id));
      await tx.delete(templateColonne).where(eq(templateColonne.templateId, id));
      // Reinserisce le colonne nell'ordine ricevuto
      await tx.insert(templateColonne).values(dati.colonne.map((c, i) => ({ templateId: id, nome: c.nome, ordine: i, consideraCompletato: c.consideraCompletato })));
      // Reinserisce i task, se presenti
      if (dati.task.length > 0) {
        // Inserisce i task e recupera gli id generati
        const creati = await tx
          .insert(templateTask)
          .values(
            dati.task.map((t, i) => ({
              templateId: id,
              titolo: t.titolo,
              descrizione: t.descrizione ?? null,
              colonnaIndice: t.colonnaIndice,
              // Numeric: stringa con due decimali
              oreStimate: t.oreStimate == null ? null : t.oreStimate.toFixed(2),
              ordine: i,
            })),
          )
          .returning();
        // Voci di to-do di tutti i task, appiattite in un solo insert
        const voci = dati.task.flatMap((t, i) => t.todo.map((titolo, j) => ({ templateTaskId: creati[i]!.id, titolo, ordine: j })));
        // Inserisce le voci se ce ne sono
        if (voci.length > 0) await tx.insert(templateTodo).values(voci);
      }
      // Registra la modifica della struttura
      await this.audit.registra(tx, contesto, {
        azione: 'modifica',
        entita: 'progetto_template',
        entitaId: id,
        descrizione: `Struttura di "${attuale.nome}": ${dati.colonne.length} colonne, ${dati.task.length} task`,
      });
      // Restituisce il dettaglio aggiornato
      return this.dettaglio(id, tx);
    });
  }

  // Elimina un template, solo se nessun progetto lo ha usato
  async elimina(contesto: ContestoRichiesta, id: string): Promise<void> {
    // Esegue in transazione
    await this.db.transaction(async (tx) => {
      // Il template deve esistere
      const [attuale] = await tx.select().from(progettoTemplate).where(eq(progettoTemplate.id, id)).limit(1);
      // Template inesistente
      if (!attuale) throw nonTrovato('Template');
      // Conta i progetti nati da questo template (anche quelli eliminati logicamente)
      const [{ n } = { n: 0 }] = await tx.select({ n: sql<number>`COUNT(*)::int` }).from(progetti).where(eq(progetti.templateId, id));
      // Template già usato: si disattiva invece di eliminarlo, per non perdere il riferimento storico
      if (n > 0) throw regolaViolata(`Il template è stato usato da ${n} progetti: disattivalo invece di eliminarlo`);
      // Elimina il template (colonne, task e to-do seguono per ON DELETE CASCADE)
      await tx.delete(progettoTemplate).where(eq(progettoTemplate.id, id));
      // Registra l'eliminazione
      await this.audit.registra(tx, contesto, { azione: 'eliminazione', entita: 'progetto_template', entitaId: id, descrizione: attuale.nome });
    });
  }
}
