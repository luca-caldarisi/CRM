// Modulo progetti: bacheca dei task, to-do, ore e template

// Importa il decoratore di NestJS
import { Module } from '@nestjs/common';
// Importa i controller
import { ProgettiController } from './progetti.controller';
import { TaskController } from './task.controller';
import { TemplateController } from './template.controller';
// Importa i service
import { ProgettiService } from './progetti.service';
import { TaskService } from './task.service';
import { TemplateService } from './template.service';

@Module({
  // Rotte esposte dal modulo
  controllers: [ProgettiController, TaskController, TemplateController],
  // Servizi del modulo
  providers: [ProgettiService, TaskService, TemplateService],
  // Il service dei progetti serve anche agli allegati (verifica dell'accesso al progetto)
  exports: [ProgettiService],
})
export class ProgettiModule {}
