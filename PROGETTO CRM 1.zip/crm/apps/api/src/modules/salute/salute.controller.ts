// =====================================================================================
// Health check: usato dallo script di aggiornamento, da Nginx e dai sistemi di monitoraggio per sapere se l'API funziona
// =====================================================================================

// Importa i decoratori di NestJS
import { Controller, Get, Inject, ServiceUnavailableException } from '@nestjs/common';
// Importa l'helper SQL
import { sql } from 'drizzle-orm';
// Importa il token del database
import { DB } from '../../database/database.module';
import type { Database } from '../../database/client';
// Importa il decoratore delle rotte pubbliche
import { Pubblico } from '../../common/auth/decoratori';

@Controller('salute')
export class SaluteController {
  // Riceve il database
  constructor(@Inject(DB) private readonly db: Database) {}

  // GET /api/v1/salute
  @Get()
  // Nessuna autenticazione: non restituisce dati sensibili
  @Pubblico()
  async verifica() {
    try {
      // Query minima per verificare che il database risponda
      await this.db.execute(sql`SELECT 1`);
    } catch {
      // Database non raggiungibile: 503 (il container verrà segnalato come non sano)
      throw new ServiceUnavailableException('Database non raggiungibile');
    }
    // Tutto funziona
    return { stato: 'ok', database: 'ok' };
  }
}
