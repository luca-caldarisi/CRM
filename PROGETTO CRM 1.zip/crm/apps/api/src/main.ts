// =====================================================================================
// Punto di avvio dell'API
// =====================================================================================

// Carica il file .env PRIMA di qualsiasi altro import, così i decoratori che leggono process.env trovano i valori
import './config/carica-env';
// Richiesto da NestJS per i metadati dei decoratori
import 'reflect-metadata';
// Importa la factory di NestJS
import { NestFactory } from '@nestjs/core';
// Importa il tipo dell'applicazione Express
import type { NestExpressApplication } from '@nestjs/platform-express';
// Importa il logger strutturato
import { Logger } from 'nestjs-pino';
// Importa modulo radice e configurazione
import { AppModule } from './app.module';
import { configuraApp } from './app.setup';
import { ENV, type Env } from './config/env';

// Funzione di avvio
async function avvia(): Promise<void> {
  // Crea l'applicazione; bufferLogs trattiene i log finché il logger pino non è pronto
  const app = await NestFactory.create<NestExpressApplication>(AppModule, { bufferLogs: true });
  // Usa pino come logger di NestJS
  app.useLogger(app.get(Logger));
  // Applica middleware e impostazioni
  configuraApp(app);
  // Legge indirizzo e porta dalla configurazione
  const { HOST, PORT } = app.get<Env>(ENV);
  // Avvia il server HTTP (in produzione solo su 127.0.0.1: il traffico esterno passa da Nginx)
  await app.listen(PORT, HOST);
  // Messaggio di avvio
  app.get(Logger).log(`API in ascolto su ${HOST}:${PORT}`);
}

// Esegue l'avvio; in caso di errore (es. configurazione non valida) termina con codice 1
avvia().catch((errore: unknown) => {
  // Stampa l'errore
  console.error(errore);
  // Uscita con errore
  process.exit(1);
});
