// =====================================================================================
// Configurazione dell'applicazione HTTP condivisa tra avvio reale (main.ts) e test
// =====================================================================================

// Importa il tipo dell'applicazione Express di NestJS
import type { NestExpressApplication } from '@nestjs/platform-express';
// Middleware per leggere i cookie
import cookieParser from 'cookie-parser';
// Middleware che imposta gli header HTTP di sicurezza
import helmet from 'helmet';
// Configurazione
import { ENV, type Env } from './config/env';

// Applica middleware e impostazioni globali
export function configuraApp(app: NestExpressApplication): void {
  // Recupera la configurazione validata
  const env = app.get<Env>(ENV);
  // Numero di proxy fidati: con Nginx davanti, req.ip conterrà il vero IP del client
  app.set('trust proxy', env.TRUST_PROXY);
  // Header di sicurezza (X-Content-Type-Options, HSTS, niente X-Powered-By, ...)
  app.use(helmet());
  // Lettura dei cookie (serve per il refresh token)
  app.use(cookieParser());
  // Tutte le rotte iniziano con /api/v1 (il versionamento permette future API v2 senza rompere i client)
  app.setGlobalPrefix('api/v1');
  // Chiusura ordinata su SIGTERM (Docker): termina le richieste in corso e chiude il database
  app.enableShutdownHooks();
}
