// =====================================================================================
// Modulo radice: collega configurazione, database, sicurezza e moduli funzionali
// =====================================================================================

// Importa il decoratore di NestJS
import { Module, RequestMethod } from '@nestjs/common';
// Token per registrare guard e pipe globali tramite dependency injection
import { APP_FILTER, APP_GUARD, APP_PIPE } from '@nestjs/core';
// Limitazione della frequenza delle richieste
import { ThrottlerGuard, ThrottlerModule } from '@nestjs/throttler';
// Logger strutturato
import { LoggerModule } from 'nestjs-pino';
// Pipe di validazione basata sugli schemi Zod
import { ZodValidationPipe } from 'nestjs-zod';
// Configurazione e database
import { ConfigModule } from './config/config.module';
import { ENV, type Env } from './config/env';
import { DatabaseModule } from './database/database.module';
// Sicurezza ed errori
import { AutenticazioneGuard } from './common/auth/autenticazione.guard';
import { PermessiGuard } from './common/auth/permessi.guard';
import { ProblemDetailsFilter } from './common/errori/problem-details.filter';
// Moduli funzionali
import { AllegatiModule } from './modules/allegati/allegati.module';
import { AuditModule } from './modules/audit/audit.module';
import { AuthModule } from './modules/auth/auth.module';
import { ClientiModule } from './modules/clienti/clienti.module';
import { CommesseModule } from './modules/commesse/commesse.module';
import { ProgettiModule } from './modules/progetti/progetti.module';
import { RuoliModule } from './modules/ruoli/ruoli.module';
import { SaluteController } from './modules/salute/salute.controller';
import { UtentiModule } from './modules/utenti/utenti.module';

@Module({
  imports: [
    // Configurazione validata (deve essere il primo)
    ConfigModule,
    // Logger JSON con dati sensibili oscurati
    LoggerModule.forRootAsync({
      inject: [ENV],
      useFactory: (env: Env) => ({
        // Applica il logger HTTP a tutte le rotte (sintassi dei percorsi di Express 5)
        forRoutes: [{ path: '{*percorso}', method: RequestMethod.ALL }],
        pinoHttp: {
          // Livello di log
          level: env.LOG_LEVEL,
          // In sviluppo output colorato leggibile, in produzione JSON (per strumenti di analisi log)
          transport: env.NODE_ENV === 'development' ? { target: 'pino-pretty', options: { singleLine: true } } : undefined,
          // Non registra mai token, cookie e password
          redact: ['req.headers.authorization', 'req.headers.cookie', 'res.headers["set-cookie"]', 'req.body.password'],
          // Non registra le chiamate al health check (sarebbero migliaia di righe inutili)
          autoLogging: { ignore: (req) => req.url?.endsWith('/salute') ?? false },
        },
      }),
    }),
    // Limite globale di sicurezza: 300 richieste al minuto per IP (le rotte sensibili hanno limiti più stretti)
    ThrottlerModule.forRoot([{ name: 'default', ttl: 60_000, limit: 300 }]),
    // Infrastruttura
    DatabaseModule,
    AuditModule,
    AuthModule,
    // Moduli funzionali
    UtentiModule,
    RuoliModule,
    ClientiModule,
    CommesseModule,
    ProgettiModule,
    AllegatiModule,
  ],
  // Controller senza modulo dedicato
  controllers: [SaluteController],
  providers: [
    // Validazione automatica di body, query e parametri con gli schemi Zod dei DTO
    { provide: APP_PIPE, useClass: ZodValidationPipe },
    // Conversione di tutti gli errori in Problem Details
    { provide: APP_FILTER, useClass: ProblemDetailsFilter },
    // Guard globali, eseguiti in quest'ordine su ogni richiesta:
    // 1. limitazione frequenza richieste
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    // 2. autenticazione (chi sei)
    { provide: APP_GUARD, useClass: AutenticazioneGuard },
    // 3. autorizzazione (cosa puoi fare)
    { provide: APP_GUARD, useClass: PermessiGuard },
  ],
})
export class AppModule {}
