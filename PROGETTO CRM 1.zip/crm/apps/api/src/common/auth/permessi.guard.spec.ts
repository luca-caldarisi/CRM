// Test unitari del guard dei permessi (principio "deny by default")

// Importa il lettore dei metadati di NestJS
import { Reflector } from '@nestjs/core';
// Importa il tipo del contesto di esecuzione
import { Logger, type ExecutionContext } from '@nestjs/common';
// Importa il guard da testare e le chiavi dei metadati
import { PermessiGuard } from './permessi.guard';
import { CHIAVE_PERMESSO, CHIAVE_SOLO_AUTENTICATO } from './decoratori';

// Crea un contesto finto con i metadati e l'utente indicati
function contesto(metadati: Record<string, unknown>, permessi: Record<string, string> = {}): ExecutionContext {
  // Handler fittizio a cui associare i metadati
  const handler = () => undefined;
  // Registra ogni metadato sull'handler
  for (const [chiave, valore] of Object.entries(metadati)) Reflect.defineMetadata(chiave, valore, handler);
  // Oggetto che imita l'interfaccia usata dal guard
  return {
    getHandler: () => handler,
    getClass: () => class {},
    switchToHttp: () => ({ getRequest: () => ({ method: 'GET', originalUrl: '/test', utente: { permessi } }) }),
  } as unknown as ExecutionContext;
}

describe('PermessiGuard', () => {
  // Istanza del guard con il vero Reflector
  const guard = new PermessiGuard(new Reflector());
  // Silenzia il log di errore previsto nel primo test
  beforeAll(() => jest.spyOn(Logger.prototype, 'error').mockImplementation(() => undefined));

  it('nega le rotte che non dichiarano nessuna regola di accesso', () => {
    // Nessun metadato: deve lanciare 403
    expect(() => guard.canActivate(contesto({}, { 'clienti.read': 'tutti' }))).toThrow(expect.objectContaining({ status: 403 }));
  });

  it('consente le rotte @SoloAutenticato', () => {
    expect(guard.canActivate(contesto({ [CHIAVE_SOLO_AUTENTICATO]: true }))).toBe(true);
  });

  it('verifica il permesso richiesto', () => {
    // Permesso presente
    expect(guard.canActivate(contesto({ [CHIAVE_PERMESSO]: 'clienti.read' }, { 'clienti.read': 'propri' }))).toBe(true);
    // Permesso assente
    expect(() => guard.canActivate(contesto({ [CHIAVE_PERMESSO]: 'clienti.write' }, { 'clienti.read': 'tutti' }))).toThrow();
  });
});
