// =====================================================================================
// Guard di autenticazione (eseguito su ogni richiesta)
// -------------------------------------------------------------------------------------
// 1. lascia passare le rotte @Pubblico
// 2. verifica firma e scadenza dell'access token JWT
// 3. ricarica l'utente dal database: se è disattivato o i suoi permessi sono cambiati
//    dopo l'emissione del token, la richiesta viene rifiutata immediatamente
// 4. blocca l'uso dell'applicazione finché l'utente non cambia la password obbligatoria
// =====================================================================================

// Importa i decoratori e i tipi di NestJS
import { type CanActivate, type ExecutionContext, HttpStatus, Inject, Injectable } from '@nestjs/common';
// Reflector legge i metadati impostati dai decoratori
import { Reflector } from '@nestjs/core';
// Servizio per verificare i JWT
import { JwtService } from '@nestjs/jwt';
// Operatore di uguaglianza per le query
import { eq } from 'drizzle-orm';
// Codici di errore condivisi con il frontend
import { CODICI_ERRORE_AUTH } from '@crm/shared';
// Token del database e tabella utenti
import { DB } from '../../database/database.module';
import type { Database } from '../../database/client';
import { utenti } from '../../database/schema';
// Eccezioni applicative
import { ErroreApi, nonAutenticato } from '../errori/errori';
// Chiavi dei metadati
import { CHIAVE_CONSENTITO_CAMBIO_PASSWORD, CHIAVE_PUBBLICO } from './decoratori';
// Tipi
import type { PayloadAccessToken, RichiestaAutenticata } from './tipi';

@Injectable()
export class AutenticazioneGuard implements CanActivate {
  constructor(
    // Lettore dei metadati
    private readonly reflector: Reflector,
    // Servizio JWT (configurato nel modulo auth con segreto, issuer e audience)
    private readonly jwt: JwtService,
    // Database
    @Inject(DB) private readonly db: Database,
  ) {}

  // Metodo chiamato da NestJS prima di ogni handler
  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    // Legge @Pubblico dal metodo o, in mancanza, dalla classe del controller
    const pubblico = this.reflector.getAllAndOverride<boolean>(CHIAVE_PUBBLICO, [ctx.getHandler(), ctx.getClass()]);
    // Le rotte pubbliche non richiedono token
    if (pubblico) return true;

    // Recupera la richiesta HTTP
    const richiesta = ctx.switchToHttp().getRequest<RichiestaAutenticata>();
    // Legge l'header Authorization
    const header = richiesta.headers.authorization;
    // Deve essere nel formato "Bearer <token>"
    if (!header?.startsWith('Bearer ')) {
      throw nonAutenticato(CODICI_ERRORE_AUTH.tokenNonValido, 'Accesso richiesto');
    }
    // Estrae il token togliendo il prefisso
    const token = header.slice(7);

    // Variabile che conterrà il payload verificato
    let payload: PayloadAccessToken;
    try {
      // Verifica firma, scadenza, issuer e audience (configurati nel JwtModule)
      payload = await this.jwt.verifyAsync<PayloadAccessToken>(token);
    } catch {
      // Token scaduto, manomesso o firmato con un altro segreto
      throw nonAutenticato(CODICI_ERRORE_AUTH.tokenNonValido, 'Sessione scaduta');
    }

    // Ricarica dal database solo i campi necessari (una query per chiave primaria: costo trascurabile)
    const [utente] = await this.db
      .select({
        id: utenti.id,
        email: utenti.email,
        nome: utenti.nome,
        cognome: utenti.cognome,
        attivo: utenti.attivo,
        permVersion: utenti.permVersion,
        ruoloId: utenti.ruoloId,
        deveCambiarePassword: utenti.deveCambiarePassword,
      })
      .from(utenti)
      .where(eq(utenti.id, payload.sub))
      .limit(1);

    // Utente eliminato o disattivato: accesso negato subito, anche con token ancora valido
    if (!utente || !utente.attivo) {
      throw nonAutenticato(CODICI_ERRORE_AUTH.tokenNonValido, 'Account non attivo');
    }
    // Permessi o ruolo modificati dopo l'emissione del token: il client deve rinnovarlo
    if (utente.permVersion !== payload.pv) {
      throw nonAutenticato(CODICI_ERRORE_AUTH.tokenObsoleto, 'Permessi aggiornati, sessione da rinnovare');
    }

    // Rende l'utente disponibile a guard successivi, controller e service
    richiesta.utente = {
      id: utente.id,
      email: utente.email,
      nome: utente.nome,
      cognome: utente.cognome,
      ruoloId: utente.ruoloId,
      // I permessi del token sono affidabili perché la versione coincide con quella nel database
      permessi: payload.prm,
      deveCambiarePassword: utente.deveCambiarePassword,
    };

    // Se il cambio password è obbligatorio, consente solo le rotte esplicitamente autorizzate
    if (utente.deveCambiarePassword) {
      // Legge @ConsentitoConCambioPassword
      const consentito = this.reflector.getAllAndOverride<boolean>(CHIAVE_CONSENTITO_CAMBIO_PASSWORD, [ctx.getHandler(), ctx.getClass()]);
      // Blocca tutte le altre
      if (!consentito) {
        throw new ErroreApi(HttpStatus.FORBIDDEN, CODICI_ERRORE_AUTH.cambioPasswordRichiesto, 'Cambio password richiesto', 'Devi cambiare la password prima di continuare');
      }
    }

    // Autenticazione riuscita
    return true;
  }
}
