// =====================================================================================
// Funzioni di supporto per applicare l'ambito dei permessi nei service
// =====================================================================================

// Importa tipi e funzioni del catalogo permessi
import { ambitoPermesso, type Ambito, type CodicePermesso } from '@crm/shared';
// Importa l'eccezione di permesso negato
import { permessoNegato } from '../errori/errori';
// Importa il tipo dell'utente
import type { UtenteAutenticato } from './tipi';

// Restituisce l'ambito concesso all'utente per un permesso, oppure lancia 403 se non lo possiede
// (difesa in profondità: il guard ha già controllato, ma i service non devono fidarsi ciecamente)
export function richiediAmbito(utente: UtenteAutenticato, codice: CodicePermesso): Ambito {
  // Legge l'ambito dalla mappa dei permessi
  const ambito = ambitoPermesso(utente.permessi, codice);
  // Nessun permesso: accesso negato
  if (!ambito) throw permessoNegato();
  // Restituisce "tutti" o "propri"
  return ambito;
}

// true se l'utente possiede il permesso (con qualsiasi ambito)
export function haPermesso(utente: UtenteAutenticato, codice: CodicePermesso): boolean {
  // Converte in booleano la presenza del permesso
  return ambitoPermesso(utente.permessi, codice) !== null;
}
