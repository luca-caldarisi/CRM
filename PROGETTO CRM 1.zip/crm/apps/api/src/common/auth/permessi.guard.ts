// =====================================================================================
// Guard di autorizzazione (eseguito dopo quello di autenticazione)
// -------------------------------------------------------------------------------------
// Principio "deny by default": ogni rotta non pubblica DEVE dichiarare @RichiedePermesso
// oppure @SoloAutenticato. Una rotta dimenticata senza decoratore viene bloccata,
// invece di diventare accessibile a chiunque sia loggato.
// =====================================================================================

// Importa i decoratori e i tipi di NestJS
import { type CanActivate, type ExecutionContext, Injectable, Logger } from '@nestjs/common';
// Lettore dei metadati
import { Reflector } from '@nestjs/core';
// Tipo dei codici permesso
import type { CodicePermesso } from '@crm/shared';
// Eccezione di permesso negato
import { permessoNegato } from '../errori/errori';
// Chiavi dei metadati
import { CHIAVE_PERMESSO, CHIAVE_PUBBLICO, CHIAVE_SOLO_AUTENTICATO } from './decoratori';
// Tipo della richiesta
import type { RichiestaAutenticata } from './tipi';

@Injectable()
export class PermessiGuard implements CanActivate {
  // Logger per segnalare rotte configurate male
  private readonly logger = new Logger(PermessiGuard.name);

  // Riceve il lettore dei metadati
  constructor(private readonly reflector: Reflector) {}

  // Metodo chiamato da NestJS prima di ogni handler
  canActivate(ctx: ExecutionContext): boolean {
    // Bersagli su cui cercare i metadati: prima il metodo, poi la classe
    const bersagli = [ctx.getHandler(), ctx.getClass()];
    // Le rotte pubbliche sono già state gestite
    if (this.reflector.getAllAndOverride<boolean>(CHIAVE_PUBBLICO, bersagli)) return true;
    // Permesso richiesto dalla rotta
    const permesso = this.reflector.getAllAndOverride<CodicePermesso | undefined>(CHIAVE_PERMESSO, bersagli);
    // Rotta aperta a tutti gli utenti autenticati
    const soloAutenticato = this.reflector.getAllAndOverride<boolean>(CHIAVE_SOLO_AUTENTICATO, bersagli);
    // Recupera la richiesta con l'utente
    const richiesta = ctx.switchToHttp().getRequest<RichiestaAutenticata>();

    // Nessuna regola dichiarata: errore di configurazione, si nega e si segnala nei log
    if (!permesso && !soloAutenticato) {
      this.logger.error(`Rotta senza regola di accesso: ${richiesta.method} ${richiesta.originalUrl}`);
      throw permessoNegato();
    }
    // Rotta per qualsiasi utente autenticato
    if (!permesso) return true;
    // Verifica che l'utente abbia il permesso (con qualsiasi ambito: il service applicherà l'ambito)
    if (!richiesta.utente?.permessi[permesso]) throw permessoNegato();
    // Permesso presente
    return true;
  }
}
