// =====================================================================================
// Tipi usati dal sistema di autenticazione e autorizzazione
// =====================================================================================

// Importa il tipo della mappa permessi
import type { MappaPermessi } from '@crm/shared';
// Importa il tipo della richiesta Express
import type { Request } from 'express';

// Contenuto (payload) dell'access token JWT
export interface PayloadAccessToken {
  // "subject": identificativo dell'utente
  sub: string;
  // Versione dei permessi al momento dell'emissione
  pv: number;
  // Identificativo del ruolo
  rid: string;
  // Permessi effettivi con ambito
  prm: MappaPermessi;
}

// Utente autenticato disponibile nei controller e nei service
export interface UtenteAutenticato {
  // Identificativo
  id: string;
  // Email
  email: string;
  // Nome
  nome: string;
  // Cognome
  cognome: string;
  // Ruolo
  ruoloId: string;
  // Permessi effettivi
  permessi: MappaPermessi;
  // Obbligo di cambio password
  deveCambiarePassword: boolean;
}

// Contesto della richiesta passato ai service (chi, da dove)
export interface ContestoRichiesta {
  // Utente che esegue l'operazione
  utente: UtenteAutenticato;
  // Indirizzo IP del client
  ip: string | null;
}

// Richiesta Express estesa con l'utente autenticato (impostato dal guard)
export interface RichiestaAutenticata extends Request {
  // Presente su tutte le rotte non pubbliche
  utente?: UtenteAutenticato;
}
