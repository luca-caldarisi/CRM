// =====================================================================================
// Decoratori per dichiarare le regole di accesso delle rotte e leggere l'utente corrente
// =====================================================================================

// Importa le funzioni di NestJS per creare decoratori
import { createParamDecorator, type ExecutionContext, SetMetadata } from '@nestjs/common';
// Importa il tipo dei codici permesso
import type { CodicePermesso } from '@crm/shared';
// Importa i tipi della richiesta
import type { ContestoRichiesta, RichiestaAutenticata, UtenteAutenticato } from './tipi';

// Chiavi dei metadati letti dai guard
export const CHIAVE_PUBBLICO = 'auth:pubblico';
export const CHIAVE_PERMESSO = 'auth:permesso';
export const CHIAVE_SOLO_AUTENTICATO = 'auth:solo-autenticato';
export const CHIAVE_CONSENTITO_CAMBIO_PASSWORD = 'auth:consentito-cambio-password';

// Rotta accessibile senza login (es. login, health check)
export const Pubblico = () => SetMetadata(CHIAVE_PUBBLICO, true);

// Rotta che richiede un permesso specifico (es. @RichiedePermesso('clienti.read'))
export const RichiedePermesso = (codice: CodicePermesso) => SetMetadata(CHIAVE_PERMESSO, codice);

// Rotta accessibile a qualsiasi utente autenticato, senza permessi particolari (es. /auth/me)
// Serve a dichiarare esplicitamente la scelta: le rotte senza nessun decoratore vengono bloccate
export const SoloAutenticato = () => SetMetadata(CHIAVE_SOLO_AUTENTICATO, true);

// Rotta utilizzabile anche quando l'utente deve ancora cambiare la password
export const ConsentitoConCambioPassword = () => SetMetadata(CHIAVE_CONSENTITO_CAMBIO_PASSWORD, true);

// Estrae l'utente autenticato nei parametri di un metodo del controller
export const UtenteCorrente = createParamDecorator((_dati: unknown, ctx: ExecutionContext): UtenteAutenticato => {
  // Recupera la richiesta HTTP
  const richiesta = ctx.switchToHttp().getRequest<RichiestaAutenticata>();
  // Il guard garantisce che sia presente; se manca è un errore di configurazione della rotta
  if (!richiesta.utente) throw new Error('UtenteCorrente usato su una rotta pubblica');
  // Restituisce l'utente
  return richiesta.utente;
});

// Estrae il contesto (utente + IP) da passare ai service per l'audit log
export const Contesto = createParamDecorator((_dati: unknown, ctx: ExecutionContext): ContestoRichiesta => {
  // Recupera la richiesta HTTP
  const richiesta = ctx.switchToHttp().getRequest<RichiestaAutenticata>();
  // Il guard garantisce che l'utente sia presente
  if (!richiesta.utente) throw new Error('Contesto usato su una rotta pubblica');
  // Compone il contesto: req.ip rispetta l'impostazione "trust proxy"
  return { utente: richiesta.utente, ip: richiesta.ip ?? null };
});
