// =====================================================================================
// Calcolo delle differenze tra due versioni di un record (per l'audit log)
// =====================================================================================

// Tipo del risultato: campo -> valore precedente e successivo
export type Modifiche = Record<string, { prima: unknown; dopo: unknown }>;

// Campi che non vengono mai scritti nell'audit log
const CAMPI_ESCLUSI = new Set(['passwordHash', 'updatedAt', 'createdAt', 'updatedById', 'createdById', 'permVersion']);

// Normalizza un valore per il confronto e la serializzazione JSON
function normalizza(valore: unknown): unknown {
  // Le date diventano stringhe ISO
  if (valore instanceof Date) return valore.toISOString();
  // undefined diventa null
  return valore ?? null;
}

// Confronta "prima" e "dopo" e restituisce solo i campi cambiati (null se nessuna differenza)
export function calcolaModifiche(prima: Record<string, unknown> | null, dopo: Record<string, unknown> | null): Modifiche | null {
  // Insieme di tutte le chiavi presenti in almeno uno dei due oggetti
  const chiavi = new Set([...Object.keys(prima ?? {}), ...Object.keys(dopo ?? {})]);
  // Oggetto risultato
  const modifiche: Modifiche = {};
  // Scorre ogni campo
  for (const chiave of chiavi) {
    // Salta i campi tecnici o sensibili
    if (CAMPI_ESCLUSI.has(chiave)) continue;
    // Valore precedente normalizzato
    const a = normalizza(prima?.[chiave]);
    // Valore successivo normalizzato
    const b = normalizza(dopo?.[chiave]);
    // Confronto tramite JSON (gestisce anche oggetti annidati)
    if (JSON.stringify(a) !== JSON.stringify(b)) modifiche[chiave] = { prima: a, dopo: b };
  }
  // Nessuna modifica: restituisce null per non salvare oggetti vuoti
  return Object.keys(modifiche).length > 0 ? modifiche : null;
}
