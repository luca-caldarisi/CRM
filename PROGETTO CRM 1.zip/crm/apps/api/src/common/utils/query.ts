// =====================================================================================
// Funzioni di supporto per paginazione, ordinamento e ricerca nelle query
// =====================================================================================

// Importa i costruttori di ordinamento e i tipi di Drizzle
import { asc, desc, type AnyColumn, type SQL } from 'drizzle-orm';
// Importa il tipo dei parametri di paginazione
import type { Paginazione } from '@crm/shared';
// Importa l'eccezione per richieste non valide
import { ErroreApi } from '../errori/errori';

// Converte la stringa "sort" (es. "-createdAt,ragioneSociale") in clausole ORDER BY sicure
// Solo i campi presenti nella whitelist sono ammessi: il client non può ordinare per colonne arbitrarie
export function ordinamento(sort: string | undefined, consentiti: Record<string, AnyColumn | SQL>, predefinito: SQL[]): SQL[] {
  // Nessun ordinamento richiesto: usa quello predefinito
  if (!sort) return predefinito;
  // Divide la stringa nei singoli campi
  return sort.split(',').map((voce) => {
    // Un "-" iniziale indica ordine decrescente
    const decrescente = voce.startsWith('-');
    // Nome del campo senza il segno
    const campo = decrescente ? voce.slice(1) : voce;
    // Colonna corrispondente nella whitelist
    const colonna = consentiti[campo];
    // Campo non ammesso: errore 400 esplicito
    if (!colonna) throw new ErroreApi(400, 'ordinamento_non_valido', 'Richiesta non valida', `Ordinamento per "${campo}" non consentito`);
    // Restituisce la clausola nella direzione richiesta
    return decrescente ? desc(colonna) : asc(colonna);
  });
}

// Calcola LIMIT e OFFSET dai parametri di paginazione
export function limitOffset(p: Pick<Paginazione, 'page' | 'pageSize'>): { limit: number; offset: number } {
  // Offset = elementi delle pagine precedenti
  return { limit: p.pageSize, offset: (p.page - 1) * p.pageSize };
}

// Prepara un testo di ricerca per l'operatore ILIKE ("contiene"), neutralizzando i caratteri jolly
// Senza escape, un utente che cerca "50%" otterrebbe risultati sbagliati
export function patternContiene(testo: string): string {
  // Antepone "\" a \, % e _ e racchiude il testo tra %
  return `%${testo.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
}
