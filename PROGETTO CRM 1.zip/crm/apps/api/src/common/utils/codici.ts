// =====================================================================================
// Generazione dei codici progressivi leggibili (CL-00001, CM-2026-0001, ...)
// =====================================================================================

// Importa l'helper per scrivere SQL parametrizzato
import { sql } from 'drizzle-orm';
// Importa il tipo del database/transazione
import type { DbOTransazione } from '../../database/client';

// Incrementa in modo atomico il contatore indicato e restituisce il nuovo valore
// Va chiamata DENTRO la stessa transazione dell'inserimento: se l'inserimento fallisce,
// anche l'incremento viene annullato e non restano "buchi" nella numerazione
export async function prossimoNumero(tx: DbOTransazione, chiave: string): Promise<number> {
  // INSERT ... ON CONFLICT: crea il contatore a 1 oppure lo incrementa, bloccando la riga fino a fine transazione
  const risultato = await tx.execute<{ valore: number }>(sql`
    INSERT INTO contatori (chiave, valore) VALUES (${chiave}, 1)
    ON CONFLICT (chiave) DO UPDATE SET valore = contatori.valore + 1
    RETURNING valore
  `);
  // Legge il valore restituito
  const valore = risultato.rows[0]?.valore;
  // Non dovrebbe mai accadere: segnala un problema grave
  if (valore === undefined) throw new Error(`Contatore ${chiave} non aggiornato`);
  // Restituisce il numero
  return valore;
}

// Codice cliente: CL-00001
export async function prossimoCodiceCliente(tx: DbOTransazione): Promise<string> {
  // Numero progressivo globale
  const n = await prossimoNumero(tx, 'CL');
  // Riempie con zeri fino a 5 cifre
  return `CL-${String(n).padStart(5, '0')}`;
}

// Codice commessa: CM-2026-0001 (numerazione che riparte ogni anno)
export async function prossimoCodiceCommessa(tx: DbOTransazione, anno: number): Promise<string> {
  // Numero progressivo dell'anno
  const n = await prossimoNumero(tx, `CM-${anno}`);
  // Riempie con zeri fino a 4 cifre
  return `CM-${anno}-${String(n).padStart(4, '0')}`;
}

// Codice progetto: PR-2026-0001 (numerazione che riparte ogni anno)
export async function prossimoCodiceProgetto(tx: DbOTransazione, anno: number): Promise<string> {
  // Numero progressivo dell'anno, indipendente da quello delle commesse
  const n = await prossimoNumero(tx, `PR-${anno}`);
  // Riempie con zeri fino a 4 cifre
  return `PR-${anno}-${String(n).padStart(4, '0')}`;
}
