// =====================================================================================
// Generatore di UUID versione 7 (RFC 9562)
// -------------------------------------------------------------------------------------
// Gli UUID v7 iniziano con il timestamp in millisecondi: sono ordinabili nel tempo,
// quindi gli indici del database restano compatti (a differenza degli UUID v4 casuali),
// e non sono indovinabili come gli ID numerici progressivi.
// =====================================================================================

// Importa la funzione che genera byte casuali crittograficamente sicuri
import { randomBytes } from 'node:crypto';

// Genera un nuovo UUID v7 in formato testuale (es. "0191f3a0-7c2e-7a41-9d3b-5e8f2c1a4b6d")
export function uuidv7(): string {
  // Crea 16 byte casuali
  const bytes = randomBytes(16);
  // Legge l'ora corrente in millisecondi
  const ms = BigInt(Date.now());
  // Scrive i 48 bit del timestamp nei primi 6 byte (big-endian)
  bytes.writeUIntBE(Number(ms & 0xffffffffffffn), 0, 6);
  // Imposta i 4 bit alti del settimo byte alla versione 7 (0111)
  bytes[6] = (bytes[6]! & 0x0f) | 0x70;
  // Imposta i 2 bit alti del nono byte alla variante RFC (10)
  bytes[8] = (bytes[8]! & 0x3f) | 0x80;
  // Converte in esadecimale
  const hex = bytes.toString('hex');
  // Inserisce i trattini nelle posizioni standard 8-4-4-4-12
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
