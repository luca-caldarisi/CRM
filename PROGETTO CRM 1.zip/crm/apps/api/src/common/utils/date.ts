// =====================================================================================
// Date "di calendario" (AAAA-MM-GG) calcolate nel fuso orario aziendale
// -------------------------------------------------------------------------------------
// Una sola implementazione per tutti i service: prima esistevano tre copie di oggi()
// basate sul fuso del server; qui il fuso è esplicito, quindi il risultato è corretto
// anche se il server (o il PC di sviluppo) è impostato su UTC.
// =====================================================================================

// Fuso orario in cui lavora l'azienda (determina quando "cambia giorno")
export const FUSO_ORARIO_AZIENDALE = 'Europe/Rome';

// Formattatore riutilizzato: la locale "sv-SE" produce già il formato AAAA-MM-GG
const formattatoreData = new Intl.DateTimeFormat('sv-SE', { timeZone: FUSO_ORARIO_AZIENDALE, year: 'numeric', month: '2-digit', day: '2-digit' });

// Restituisce la data indicata (predefinito: adesso) come stringa AAAA-MM-GG nel fuso aziendale
export function dataIso(istante: Date = new Date()): string {
  // Formatta l'istante nel fuso aziendale
  return formattatoreData.format(istante);
}

// Data odierna in formato AAAA-MM-GG (scorciatoia usata dai service)
export function oggi(): string {
  // Data corrente nel fuso aziendale
  return dataIso();
}
