// =====================================================================================
// Verifiche di integrità riutilizzate da più moduli
// -------------------------------------------------------------------------------------
// Prima la stessa query era copiata in clienti, commesse, progetti e task.
// =====================================================================================

// Importa gli operatori di query
import { and, eq } from 'drizzle-orm';
// Importa il tipo del database/transazione
import type { DbOTransazione } from '../../database/client';
// Importa la tabella utenti
import { utenti } from '../../database/schema';
// Importa l'eccezione per le regole di business violate
import { regolaViolata } from '../errori/errori';

// Verifica che un utente esista e sia attivo prima di assegnargli qualcosa (422 altrimenti)
export async function verificaUtenteAttivo(tx: DbOTransazione, utenteId: string, messaggio = "L'utente indicato non esiste o non è attivo"): Promise<void> {
  // Cerca l'utente attivo leggendo il solo identificativo
  const [u] = await tx.select({ id: utenti.id }).from(utenti).where(and(eq(utenti.id, utenteId), eq(utenti.attivo, true))).limit(1);
  // Non trovato o disattivato: errore con il messaggio specifico del chiamante
  if (!u) throw regolaViolata(messaggio);
}
