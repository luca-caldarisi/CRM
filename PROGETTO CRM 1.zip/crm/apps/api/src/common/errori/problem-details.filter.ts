// =====================================================================================
// Filtro globale delle eccezioni: ogni errore diventa una risposta Problem Details
// -------------------------------------------------------------------------------------
// Gli errori imprevisti vengono registrati nei log con lo stack, ma al client arriva solo
// un messaggio generico: mai dettagli interni (stack, query SQL, nomi di tabelle).
// =====================================================================================

// Importa i tipi e i decoratori di NestJS
import { type ArgumentsHost, Catch, type ExceptionFilter, HttpException, HttpStatus, Logger } from '@nestjs/common';
// Importa l'eccezione di validazione di nestjs-zod
import { ZodValidationException } from 'nestjs-zod';
// Importa il tipo dell'errore di Zod
import type { ZodError } from 'zod';
// Importa i tipi di Express
import type { Response } from 'express';
// Importa il tipo condiviso della risposta di errore
import type { ProblemDetails } from '@crm/shared';

// Messaggi leggibili per i vincoli univoci del database (nome vincolo -> messaggio)
const MESSAGGI_VINCOLI: Record<string, string> = {
  utenti_email_unique: 'Esiste già un utente con questa email',
  ruoli_nome_unique: 'Esiste già un ruolo con questo nome',
  clienti_piva_unique: 'Esiste già un cliente con questa Partita IVA',
  sedi_legale_unique: 'Il cliente ha già una sede legale',
  contatti_principale_unique: 'Il cliente ha già un contatto principale',
  commesse_date_check: 'La data di chiusura non può precedere la data di apertura',
  commesse_valore_check: 'Il valore non può essere negativo',
};

// Titoli predefiniti per codice di stato
const TITOLI: Record<number, [string, string]> = {
  400: ['richiesta_non_valida', 'Richiesta non valida'],
  401: ['non_autenticato', 'Non autenticato'],
  403: ['permesso_negato', 'Permesso negato'],
  404: ['non_trovato', 'Risorsa non trovata'],
  409: ['conflitto', 'Conflitto'],
  413: ['file_troppo_grande', 'File troppo grande'],
  422: ['regola_violata', 'Operazione non consentita'],
  429: ['troppe_richieste', 'Troppe richieste, riprova tra poco'],
};

// Forma minima di un errore PostgreSQL (driver pg)
interface ErrorePg {
  code: string;
  constraint?: string;
}

// Verifica se un valore è un errore PostgreSQL, anche se incapsulato da Drizzle nella proprietà "cause"
function estraiErrorePg(errore: unknown): ErrorePg | null {
  // Controlla il valore stesso e la sua causa
  for (const candidato of [errore, (errore as { cause?: unknown })?.cause]) {
    // Un errore pg ha un "code" di 5 caratteri (SQLSTATE)
    if (candidato && typeof candidato === 'object' && typeof (candidato as ErrorePg).code === 'string' && (candidato as ErrorePg).code.length === 5) {
      return candidato as ErrorePg;
    }
  }
  // Non è un errore del database
  return null;
}

// @Catch() senza argomenti intercetta qualsiasi eccezione
@Catch()
export class ProblemDetailsFilter implements ExceptionFilter {
  // Logger dedicato al filtro
  private readonly logger = new Logger('Errori');

  // Metodo chiamato da NestJS per ogni eccezione non gestita
  catch(errore: unknown, host: ArgumentsHost): void {
    // Recupera l'oggetto risposta di Express
    const risposta = host.switchToHttp().getResponse<Response>();
    // Costruisce il corpo della risposta
    const corpo = this.costruisci(errore);
    // Se gli header sono già stati inviati (es. errore durante lo stream di un file) non si può rispondere
    if (risposta.headersSent) return;
    // Invia la risposta con il content-type standard per Problem Details
    risposta.status(corpo.status).type('application/problem+json').json(corpo);
  }

  // Converte l'eccezione nel formato Problem Details
  private costruisci(errore: unknown): ProblemDetails {
    // --- Errori di validazione Zod: 400 con elenco dei campi ---
    if (errore instanceof ZodValidationException) {
      // Recupera l'errore Zod originale
      const zodError = errore.getZodError() as ZodError;
      // Restituisce ogni problema con percorso del campo e messaggio
      return {
        type: 'validazione',
        title: 'Dati non validi',
        status: HttpStatus.BAD_REQUEST,
        errors: zodError.issues.map((i) => ({ campo: i.path.join('.'), messaggio: i.message })),
      };
    }

    // --- Eccezioni HTTP (incluse quelle applicative ErroreApi) ---
    if (errore instanceof HttpException) {
      // Codice di stato
      const status = errore.getStatus();
      // Corpo originale dell'eccezione
      const originale = errore.getResponse();
      // Titolo e tipo predefiniti per lo stato
      const [tipo, titolo] = TITOLI[status] ?? ['errore', 'Errore'];
      // Se l'eccezione ha già un corpo Problem Details (ErroreApi) lo usa
      if (typeof originale === 'object' && originale !== null && 'type' in originale) {
        return originale as ProblemDetails;
      }
      // Altrimenti usa il messaggio dell'eccezione come dettaglio (es. eccezioni standard di NestJS)
      const messaggio = typeof originale === 'object' && originale !== null && 'message' in originale ? String((originale as { message: unknown }).message) : errore.message;
      // Risposta con tipo e titolo predefiniti
      return { type: tipo, title: titolo, status, detail: messaggio };
    }

    // --- Errori del database ---
    const errorePg = estraiErrorePg(errore);
    if (errorePg) {
      // Messaggio leggibile per il vincolo violato, se noto
      const messaggio = errorePg.constraint ? MESSAGGI_VINCOLI[errorePg.constraint] : undefined;
      // 23505 = violazione di vincolo univoco
      if (errorePg.code === '23505') {
        return { type: 'conflitto', title: 'Conflitto', status: 409, detail: messaggio ?? 'Valore già presente' };
      }
      // 23503 = violazione di chiave esterna (riferimento a un record inesistente o ancora collegato)
      if (errorePg.code === '23503') {
        return { type: 'riferimento_non_valido', title: 'Operazione non consentita', status: 422, detail: 'Il record è collegato ad altri dati oppure fa riferimento a dati inesistenti' };
      }
      // 23514 = violazione di vincolo CHECK
      if (errorePg.code === '23514') {
        return { type: 'regola_violata', title: 'Operazione non consentita', status: 422, detail: messaggio ?? 'Dati non coerenti' };
      }
    }

    // --- Qualsiasi altro errore: imprevisto ---
    // Registra lo stack completo nei log del server
    this.logger.error(errore instanceof Error ? errore.stack ?? errore.message : String(errore));
    // Al client solo un messaggio generico
    return { type: 'errore_interno', title: 'Errore interno', status: 500, detail: 'Si è verificato un errore imprevisto' };
  }
}
