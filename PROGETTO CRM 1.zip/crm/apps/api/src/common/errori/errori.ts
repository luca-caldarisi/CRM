// =====================================================================================
// Eccezioni applicative con formato RFC 9457 (Problem Details)
// -------------------------------------------------------------------------------------
// I service lanciano queste eccezioni; il filtro globale le converte nella risposta JSON.
// =====================================================================================

// Importa la classe base delle eccezioni HTTP di NestJS e i codici di stato
import { HttpException, HttpStatus } from '@nestjs/common';

// Eccezione con codice macchina ("type") e messaggio leggibile
export class ErroreApi extends HttpException {
  constructor(
    // Codice di stato HTTP
    status: number,
    // Codice macchina dell'errore (es. "non_trovato")
    readonly tipo: string,
    // Titolo breve
    readonly titolo: string,
    // Dettaglio facoltativo mostrato all'utente
    readonly dettaglio?: string,
  ) {
    // Passa alla classe base un corpo già nel formato Problem Details
    super({ type: tipo, title: titolo, status, detail: dettaglio }, status);
  }
}

// 404: risorsa inesistente o fuori dall'ambito dell'utente (non si distingue per non rivelare l'esistenza)
// Il messaggio è neutro rispetto al genere: vale per "Cliente" come per "Commessa" o "Sede"
export function nonTrovato(cosa: string): ErroreApi {
  return new ErroreApi(HttpStatus.NOT_FOUND, 'non_trovato', 'Risorsa non trovata', `${cosa} inesistente o non accessibile`);
}

// 403: permesso mancante
export function permessoNegato(dettaglio = 'Non hai i permessi per eseguire questa operazione'): ErroreApi {
  return new ErroreApi(HttpStatus.FORBIDDEN, 'permesso_negato', 'Permesso negato', dettaglio);
}

// 422: la richiesta è formalmente corretta ma viola una regola di business
export function regolaViolata(dettaglio: string): ErroreApi {
  return new ErroreApi(HttpStatus.UNPROCESSABLE_ENTITY, 'regola_violata', 'Operazione non consentita', dettaglio);
}

// 409: conflitto con lo stato attuale (es. valore univoco già presente)
export function conflitto(dettaglio: string): ErroreApi {
  return new ErroreApi(HttpStatus.CONFLICT, 'conflitto', 'Conflitto', dettaglio);
}

// 401: autenticazione mancante o non valida
export function nonAutenticato(tipo: string, dettaglio: string): ErroreApi {
  return new ErroreApi(HttpStatus.UNAUTHORIZED, tipo, 'Non autenticato', dettaglio);
}
