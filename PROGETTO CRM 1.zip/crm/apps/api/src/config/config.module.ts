// =====================================================================================
// Modulo globale che valida e fornisce la configurazione
// =====================================================================================

// Carica il file .env (se presente) prima di validare le variabili
import './carica-env';
// Importa i decoratori di NestJS
import { Global, Module } from '@nestjs/common';
// Importa la validazione e il token
import { ENV, validaEnv } from './env';

@Global()
@Module({
  // Fornisce la configurazione validata una sola volta all'avvio
  providers: [{ provide: ENV, useFactory: () => validaEnv(process.env) }],
  // La rende disponibile a tutti i moduli
  exports: [ENV],
})
export class ConfigModule {}
