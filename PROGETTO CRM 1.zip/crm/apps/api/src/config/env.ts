// =====================================================================================
// Lettura e validazione delle variabili d'ambiente
// -------------------------------------------------------------------------------------
// L'applicazione si rifiuta di partire se manca una variabile o ha un valore non valido:
// meglio un errore chiaro all'avvio che un comportamento imprevedibile in produzione.
// =====================================================================================

// Importa Zod
import { z } from 'zod';

// Schema delle variabili d'ambiente
const envSchema = z.object({
  // Ambiente di esecuzione
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  // Indirizzo di ascolto: 127.0.0.1 = raggiungibile solo dal server stesso (Nginx), mai direttamente dalla rete
  HOST: z.string().min(1).default('127.0.0.1'),
  // Porta HTTP dell'API
  PORT: z.coerce.number().int().min(1).max(65535).default(3000),
  // Stringa di connessione PostgreSQL
  DATABASE_URL: z.string().startsWith('postgres', 'DATABASE_URL deve iniziare con postgres://'),
  // Segreto per firmare i JWT: lungo almeno 32 caratteri e non lasciato al valore di esempio
  JWT_SECRET: z
    .string()
    .min(32, 'JWT_SECRET deve avere almeno 32 caratteri')
    .refine((v) => !v.startsWith('sostituire'), 'JWT_SECRET non è stato cambiato rispetto al file di esempio'),
  // Durata dell'access token in minuti
  JWT_ACCESS_TTL_MIN: z.coerce.number().int().min(1).max(60).default(15),
  // Durata del refresh token in giorni
  REFRESH_TTL_GIORNI: z.coerce.number().int().min(1).max(90).default(7),
  // Origine del frontend (es. https://crm.azienda.it)
  APP_ORIGIN: z.url('APP_ORIGIN deve essere un URL completo'),
  // Cookie solo su HTTPS
  COOKIE_SECURE: z.enum(['true', 'false']).default('false').transform((v) => v === 'true'),
  // Numero di proxy fidati (per leggere l'IP reale del client dietro Nginx)
  TRUST_PROXY: z.coerce.number().int().min(0).max(5).default(0),
  // Cartella degli allegati
  UPLOAD_DIR: z.string().min(1).default('./storage/allegati'),
  // Livello di dettaglio dei log
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),
  // Tentativi di login consentiti al minuto per indirizzo IP
  LOGIN_RATE_LIMIT: z.coerce.number().int().min(1).default(10),
});

// Tipo della configurazione validata
export type Env = z.output<typeof envSchema>;

// Valida un oggetto di variabili (di norma process.env) e restituisce la configurazione tipizzata
export function validaEnv(sorgente: Record<string, string | undefined>): Env {
  // Esegue la validazione senza lanciare eccezioni
  const risultato = envSchema.safeParse(sorgente);
  // Se ci sono errori li elenca tutti in un unico messaggio leggibile
  if (!risultato.success) {
    // Trasforma ogni errore in una riga "VARIABILE: messaggio"
    const dettagli = risultato.error.issues.map((i) => `  - ${i.path.join('.')}: ${i.message}`).join('\n');
    // Interrompe l'avvio
    throw new Error(`Configurazione non valida:\n${dettagli}`);
  }
  // In produzione il cookie non sicuro è un errore grave: lo si blocca esplicitamente
  if (risultato.data.NODE_ENV === 'production' && !risultato.data.COOKIE_SECURE) {
    throw new Error('Configurazione non valida: in produzione COOKIE_SECURE deve essere true');
  }
  // Restituisce la configurazione validata
  return risultato.data;
}

// Token di iniezione con cui i servizi ricevono la configurazione
export const ENV = Symbol('ENV');
