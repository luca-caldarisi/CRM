// Carica le variabili dal file .env della radice del monorepo (solo se il file esiste)
// In Docker le variabili arrivano dall'ambiente e il file non c'è: nessun effetto.
// Le variabili già definite nell'ambiente hanno sempre la precedenza.

// Importa la funzione per costruire percorsi
import { resolve } from 'node:path';
// Importa dotenv
import { config } from 'dotenv';

// Il processo viene avviato dalla cartella apps/api: il file .env è due livelli sopra
config({ path: resolve(process.cwd(), '../../.env'), quiet: true });
