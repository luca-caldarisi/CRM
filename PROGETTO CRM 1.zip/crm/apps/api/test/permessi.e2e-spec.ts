// =====================================================================================
// Test di integrazione: ruoli, permessi, ambito "propri" e dati economici
// =====================================================================================

// Importa supertest
import request from 'supertest';
// Importa gli helper
import { ADMIN, avviaApp, creaUtente, emailUnica, login, type ContestoTest } from './helpers';

describe('Permessi e ruoli', () => {
  // Contesto dei test
  let ctx: ContestoTest;
  // Server HTTP
  let server: Parameters<typeof request>[0];
  // Token dell'amministratore
  let admin: string;

  // Avvio applicazione e login admin
  beforeAll(async () => {
    ctx = await avviaApp();
    server = ctx.app.getHttpServer();
    admin = (await login(ctx, ADMIN.email, ADMIN.password)).token;
  });

  // Chiusura
  afterAll(async () => {
    await ctx.app.close();
  });

  // Crea un cliente come admin e restituisce l'id
  async function creaCliente(ragioneSociale: string, commercialeId?: string): Promise<string> {
    const res = await request(server).post('/api/v1/clienti').set('authorization', `Bearer ${admin}`).send({ ragioneSociale, commercialeId }).expect(201);
    return res.body.id as string;
  }

  it('il Tecnico legge i clienti ma non può crearli, né gestire utenti o audit', async () => {
    // Utente tecnico
    const u = await creaUtente(ctx, 'Tecnico', emailUnica('tecnico'));
    const { token } = await login(ctx, u.email, u.password);
    // Lettura consentita
    await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token}`).expect(200);
    // Scrittura negata
    const r = await request(server).post('/api/v1/clienti').set('authorization', `Bearer ${token}`).send({ ragioneSociale: 'Non consentito Srl' }).expect(403);
    expect(r.body.type).toBe('permesso_negato');
    // Amministrazione negata
    await request(server).get('/api/v1/utenti').set('authorization', `Bearer ${token}`).expect(403);
    await request(server).get('/api/v1/ruoli').set('authorization', `Bearer ${token}`).expect(403);
    await request(server).get('/api/v1/audit').set('authorization', `Bearer ${token}`).expect(403);
    // L'elenco utenti per le select è invece disponibile a tutti
    await request(server).get('/api/v1/utenti/opzioni').set('authorization', `Bearer ${token}`).expect(200);
  });

  it('il valore delle commesse non viene inviato a chi non ha il permesso economici.read', async () => {
    // Cliente e commessa con valore
    const clienteId = await creaCliente('Economici Spa');
    const c = await request(server).post('/api/v1/commesse').set('authorization', `Bearer ${admin}`).send({ clienteId, titolo: 'Server nuovo', tipo: 'progetto', dataApertura: '2026-09-01', valore: 12500.5 }).expect(201);
    // L'admin vede il valore
    expect(c.body.valore).toBe('12500.50');
    // Il tecnico non riceve proprio il campo
    const u = await creaUtente(ctx, 'Tecnico', emailUnica('tecnico-eco'));
    const { token } = await login(ctx, u.email, u.password);
    const vista = await request(server).get(`/api/v1/commesse/${c.body.id}`).set('authorization', `Bearer ${token}`).expect(200);
    expect(vista.body).not.toHaveProperty('valore');
    // Nemmeno nella lista
    const lista = await request(server).get('/api/v1/commesse').set('authorization', `Bearer ${token}`).expect(200);
    expect(lista.body.data.every((x: object) => !('valore' in x))).toBe(true);
    // E non può ordinare per valore (si potrebbe dedurre)
    await request(server).get('/api/v1/commesse?sort=-valore').set('authorization', `Bearer ${token}`).expect(400);
  });

  it('la modifica dei permessi di un ruolo ha effetto immediato sui token già emessi', async () => {
    // Ruolo personalizzato senza permessi
    const ruolo = await request(server).post('/api/v1/ruoli').set('authorization', `Bearer ${admin}`).send({ nome: `Prova ${Date.now()}` }).expect(201);
    const u = await creaUtente(ctx, ruolo.body.nome, emailUnica('ruolo'));
    const { token, cookie } = await login(ctx, u.email, u.password);
    // Senza permessi: 403
    await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token}`).expect(403);
    // L'admin concede la lettura clienti
    await request(server).put(`/api/v1/ruoli/${ruolo.body.id}/permessi`).set('authorization', `Bearer ${admin}`).send({ permessi: [{ codice: 'clienti.read', ambito: 'tutti' }] }).expect(200);
    // Il vecchio token è diventato obsoleto
    const obsoleto = await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token}`).expect(401);
    expect(obsoleto.body.type).toBe('token_obsoleto');
    // Dopo il refresh il nuovo token contiene il permesso
    const nuovo = await request(server).post('/api/v1/auth/refresh').set('cookie', cookie).expect(200);
    await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${nuovo.body.accessToken}`).expect(200);
  });

  it('con ambito "propri" l\'utente vede e modifica solo i propri clienti', async () => {
    // Ruolo commerciale junior con ambito limitato
    const ruolo = await request(server).post('/api/v1/ruoli').set('authorization', `Bearer ${admin}`).send({ nome: `Junior ${Date.now()}` }).expect(201);
    await request(server)
      .put(`/api/v1/ruoli/${ruolo.body.id}/permessi`)
      .set('authorization', `Bearer ${admin}`)
      .send({ permessi: [{ codice: 'clienti.read', ambito: 'propri' }, { codice: 'clienti.write', ambito: 'propri' }] })
      .expect(200);
    // Utente del ruolo
    const u = await creaUtente(ctx, ruolo.body.nome, emailUnica('junior'));
    const { token } = await login(ctx, u.email, u.password);
    // Un cliente suo e uno di nessuno
    const mio = await creaCliente('Cliente Mio Srl', u.id);
    const altrui = await creaCliente('Cliente Altrui Srl');
    // In lista vede solo il suo
    const lista = await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token}`).expect(200);
    expect(lista.body.data.map((c: { id: string }) => c.id)).toEqual([mio]);
    // Il cliente altrui risulta inesistente (404, non 403: non se ne rivela l'esistenza)
    await request(server).get(`/api/v1/clienti/${altrui}`).set('authorization', `Bearer ${token}`).expect(404);
    await request(server).patch(`/api/v1/clienti/${altrui}`).set('authorization', `Bearer ${token}`).send({ note: 'x' }).expect(404);
    // Un cliente creato da lui gli viene assegnato automaticamente, anche se indica un altro commerciale
    const nuovo = await request(server).post('/api/v1/clienti').set('authorization', `Bearer ${token}`).send({ ragioneSociale: 'Creato Da Junior', commercialeId: null }).expect(201);
    expect(nuovo.body.commerciale.id).toBe(u.id);
  });

  it('il ruolo Admin non è modificabile e deve restare almeno un amministratore attivo', async () => {
    // Elenco ruoli
    const ruoli = await request(server).get('/api/v1/ruoli').set('authorization', `Bearer ${admin}`).expect(200);
    const ruoloAdmin = ruoli.body.find((r: { diSistema: boolean }) => r.diSistema);
    const ruoloTecnico = ruoli.body.find((r: { nome: string }) => r.nome === 'Tecnico');
    // I contatori degli utenti per ruolo sono corretti (1 admin, diversi tecnici creati dai test)
    expect(ruoloAdmin.numeroUtenti).toBe(1);
    expect(ruoloTecnico.numeroUtenti).toBeGreaterThan(0);
    // Modifica della matrice dell'Admin: 422
    await request(server).put(`/api/v1/ruoli/${ruoloAdmin.id}/permessi`).set('authorization', `Bearer ${admin}`).send({ permessi: [] }).expect(422);
    // Eliminazione di un ruolo con utenti assegnati: 422
    await request(server).delete(`/api/v1/ruoli/${ruoloTecnico.id}`).set('authorization', `Bearer ${admin}`).expect(422);
    // L'unico admin non può declassarsi
    const me = await request(server).get('/api/v1/auth/me').set('authorization', `Bearer ${admin}`).expect(200);
    const r = await request(server).patch(`/api/v1/utenti/${me.body.id}`).set('authorization', `Bearer ${admin}`).send({ ruoloId: ruoloTecnico.id }).expect(422);
    expect(r.body.detail).toContain('almeno un amministratore');
    // Né disattivarsi
    await request(server).patch(`/api/v1/utenti/${me.body.id}`).set('authorization', `Bearer ${admin}`).send({ attivo: false }).expect(422);
  });

  it('la creazione utente restituisce una password temporanea valida una sola volta', async () => {
    // Ruoli disponibili
    const ruoli = await request(server).get('/api/v1/ruoli').set('authorization', `Bearer ${admin}`).expect(200);
    const tecnico = ruoli.body.find((r: { nome: string }) => r.nome === 'Tecnico');
    // Creazione senza password: il server ne genera una
    const email = emailUnica('nuovo');
    const res = await request(server).post('/api/v1/utenti').set('authorization', `Bearer ${admin}`).send({ email, nome: 'Mario', cognome: 'Rossi', ruoloId: tecnico.id }).expect(201);
    expect(res.body.passwordTemporanea).toMatch(/^[A-Za-z0-9]{4}(-[A-Za-z0-9]{4}){3}$/);
    expect(res.body.utente.deveCambiarePassword).toBe(true);
    // Email duplicata: 409
    await request(server).post('/api/v1/utenti').set('authorization', `Bearer ${admin}`).send({ email: email.toUpperCase(), nome: 'Mario', cognome: 'Rossi', ruoloId: tecnico.id }).expect(409);
    // Con la password temporanea si accede
    await login(ctx, email, res.body.passwordTemporanea);
  });
});
