// =====================================================================================
// Test di integrazione: autenticazione, sessioni e protezioni di sicurezza
// =====================================================================================

// Importa supertest
import request from 'supertest';
// Importa gli operatori di query
import { eq, isNotNull } from 'drizzle-orm';
// Importa le tabelle
import { sessioni, utenti } from '../src/database/schema';
// Importa gli helper
import { ADMIN, avviaApp, creaUtente, emailUnica, login, type ContestoTest } from './helpers';

describe('Autenticazione', () => {
  // Contesto condiviso dai test del file
  let ctx: ContestoTest;
  // Server HTTP
  let server: Parameters<typeof request>[0];

  // Avvia l'applicazione prima dei test
  beforeAll(async () => {
    ctx = await avviaApp();
    server = ctx.app.getHttpServer();
  });

  // Chiude l'applicazione (e le connessioni al database) alla fine
  afterAll(async () => {
    await ctx.app.close();
  });

  it('rifiuta credenziali errate con lo stesso messaggio per email inesistente e password sbagliata', async () => {
    // Email inesistente
    const a = await request(server).post('/api/v1/auth/login').send({ email: 'nessuno@test.local', password: 'qualsiasi-cosa' }).expect(401);
    // Password sbagliata
    const b = await request(server).post('/api/v1/auth/login').send({ email: ADMIN.email, password: 'password-sbagliata' }).expect(401);
    // Stesso codice e stesso messaggio: non si può capire quali email esistono
    expect(a.body.type).toBe('credenziali_non_valide');
    expect(b.body).toEqual(a.body);
    // Ripristina il contatore dei tentativi dell'admin
    await ctx.db.update(utenti).set({ tentativiFalliti: 0 }).where(eq(utenti.email, ADMIN.email));
  });

  it('valida il formato della richiesta di login (400 con dettaglio dei campi)', async () => {
    // Email non valida
    const res = await request(server).post('/api/v1/auth/login').send({ email: 'non-una-email', password: '' }).expect(400);
    // Formato Problem Details con elenco errori
    expect(res.body.type).toBe('validazione');
    expect(res.body.errors.map((e: { campo: string }) => e.campo)).toEqual(expect.arrayContaining(['email', 'password']));
  });

  it('al login imposta un cookie httpOnly, SameSite=Strict, limitato alle rotte di autenticazione', async () => {
    // Login riuscito
    const res = await request(server).post('/api/v1/auth/login').send(ADMIN).expect(200);
    // Header del cookie
    const cookie = (res.headers['set-cookie'] as unknown as string[])[0]!;
    // Verifica gli attributi di sicurezza
    expect(cookie).toMatch(/^crm_rt=/);
    expect(cookie).toContain('HttpOnly');
    expect(cookie).toContain('SameSite=Strict');
    expect(cookie).toContain('Path=/api/v1/auth');
    // L'access token è nel corpo e la risposta non va in cache
    expect(res.body.accessToken).toEqual(expect.any(String));
    expect(res.headers['cache-control']).toBe('no-store');
  });

  it('senza token o con token manomesso risponde 401', async () => {
    // Nessun token
    await request(server).get('/api/v1/clienti').expect(401);
    // Token con firma alterata
    const { token } = await login(ctx, ADMIN.email, ADMIN.password);
    await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token.slice(0, -2)}xx`).expect(401);
    // Token con algoritmo "none" (attacco classico ai JWT)
    const [, payload] = token.split('.');
    const tokenNone = `${Buffer.from('{"alg":"none","typ":"JWT"}').toString('base64url')}.${payload}.`;
    await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${tokenNone}`).expect(401);
  });

  it('obbliga il cambio password prima di usare il CRM', async () => {
    // Crea un utente e imposta l'obbligo di cambio
    const u = await creaUtente(ctx, 'Tecnico', emailUnica('cambio'));
    await ctx.db.update(utenti).set({ deveCambiarePassword: true }).where(eq(utenti.id, u.id));
    // Login
    const { token, cookie } = await login(ctx, u.email, u.password);
    // Le rotte normali sono bloccate
    const bloccata = await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token}`).expect(403);
    expect(bloccata.body.type).toBe('cambio_password_richiesto');
    // Il profilo è accessibile e segnala l'obbligo
    const me = await request(server).get('/api/v1/auth/me').set('authorization', `Bearer ${token}`).expect(200);
    expect(me.body.deveCambiarePassword).toBe(true);
    // Password attuale sbagliata: 422
    await request(server).post('/api/v1/auth/cambia-password').set('authorization', `Bearer ${token}`).send({ passwordAttuale: 'sbagliata', nuovaPassword: 'NuovaPassword-Sicura-99' }).expect(422);
    // Nuova password troppo corta: 400
    await request(server).post('/api/v1/auth/cambia-password').set('authorization', `Bearer ${token}`).send({ passwordAttuale: u.password, nuovaPassword: 'corta' }).expect(400);
    // Cambio corretto
    await request(server).post('/api/v1/auth/cambia-password').set('authorization', `Bearer ${token}`).set('cookie', cookie).send({ passwordAttuale: u.password, nuovaPassword: 'NuovaPassword-Sicura-99' }).expect(204);
    // Ora le rotte sono accessibili con lo stesso token
    await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token}`).expect(200);
    // La sessione corrente resta valida
    await request(server).post('/api/v1/auth/refresh').set('cookie', cookie).expect(200);
  });

  it('ruota il refresh token e revoca tutta la famiglia se un token vecchio viene riutilizzato', async () => {
    // Login
    const { cookie: primo } = await login(ctx, ADMIN.email, ADMIN.password);
    // Primo refresh: nuovo cookie
    const r1 = await request(server).post('/api/v1/auth/refresh').set('cookie', primo).expect(200);
    const secondo = (r1.headers['set-cookie'] as unknown as string[])[0]!.split(';')[0]!;
    expect(secondo).not.toBe(primo);
    // Riutilizzo immediato del primo token: considerato concorrenza (409, da riprovare)
    const concorrente = await request(server).post('/api/v1/auth/refresh').set('cookie', primo).expect(409);
    expect(concorrente.body.type).toBe('refresh_in_corso');
    // Simula che la sostituzione sia avvenuta molto tempo fa
    await ctx.db.update(sessioni).set({ sostituitaIl: new Date(Date.now() - 60 * 60 * 1000) }).where(isNotNull(sessioni.sostituitaIl));
    // Riutilizzo del vecchio token: furto sospetto -> 401
    await request(server).post('/api/v1/auth/refresh').set('cookie', primo).expect(401);
    // Anche il token più recente della stessa famiglia è stato revocato
    await request(server).post('/api/v1/auth/refresh').set('cookie', secondo).expect(401);
  });

  it('blocca il refresh proveniente da un\'origine diversa dal frontend', async () => {
    // Login
    const { cookie } = await login(ctx, ADMIN.email, ADMIN.password);
    // Origine estranea
    await request(server).post('/api/v1/auth/refresh').set('cookie', cookie).set('origin', 'https://sito-malevolo.example').expect(403);
    // Origine corretta
    await request(server).post('/api/v1/auth/refresh').set('cookie', cookie).set('origin', 'http://localhost:5173').expect(200);
  });

  it('dopo il logout la sessione non è più rinnovabile', async () => {
    // Login
    const { cookie } = await login(ctx, ADMIN.email, ADMIN.password);
    // Logout
    await request(server).post('/api/v1/auth/logout').set('cookie', cookie).expect(204);
    // Refresh rifiutato
    await request(server).post('/api/v1/auth/refresh').set('cookie', cookie).expect(401);
  });

  it('blocca temporaneamente l\'account dopo 5 password errate, anche se poi la password è giusta', async () => {
    // Utente dedicato
    const u = await creaUtente(ctx, 'Tecnico', emailUnica('blocco'));
    // 5 tentativi errati
    for (let i = 0; i < 5; i++) {
      await request(server).post('/api/v1/auth/login').send({ email: u.email, password: 'sbagliata-sbagliata' }).expect(401);
    }
    // Password corretta ma account bloccato
    const res = await request(server).post('/api/v1/auth/login').send({ email: u.email, password: u.password }).expect(401);
    expect(res.body.type).toBe('account_bloccato');
  });

  it('un utente disattivato perde subito l\'accesso anche con un token ancora valido', async () => {
    // Utente e login
    const u = await creaUtente(ctx, 'Tecnico', emailUnica('disattivo'));
    const { token } = await login(ctx, u.email, u.password);
    // Accesso consentito
    await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token}`).expect(200);
    // L'admin disattiva l'utente tramite API
    const admin = await login(ctx, ADMIN.email, ADMIN.password);
    await request(server).patch(`/api/v1/utenti/${u.id}`).set('authorization', `Bearer ${admin.token}`).send({ attivo: false }).expect(200);
    // Il token dell'utente non funziona più
    await request(server).get('/api/v1/clienti').set('authorization', `Bearer ${token}`).expect(401);
  });
});
