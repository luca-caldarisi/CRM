// Variabili d'ambiente usate durante i test (sovrascrivono quelle del file .env)

// Importa il modulo per la cartella temporanea di sistema
import { tmpdir } from 'node:os';
// Importa la funzione per costruire percorsi
import { join } from 'node:path';

// Ambiente di test
process.env.NODE_ENV = 'test';
// Database dedicato ai test (mai quello di sviluppo o produzione): sovrascrivibile da riga di comando
process.env.DATABASE_URL = process.env.TEST_DATABASE_URL ?? 'postgres://crm:crm_dev_password@localhost:5432/crm_test';
// Segreto JWT fittizio valido solo per i test
process.env.JWT_SECRET = 'segreto-dei-test-lungo-almeno-trentadue-caratteri';
// Origine del frontend simulata
process.env.APP_ORIGIN = 'http://localhost:5173';
// Cookie non sicuri (niente HTTPS nei test)
process.env.COOKIE_SECURE = 'false';
// Allegati in una cartella temporanea
process.env.UPLOAD_DIR = join(tmpdir(), 'crm-test-allegati');
// Log silenziati per non sporcare l'output dei test
process.env.LOG_LEVEL = 'silent';
// Limite di login alto: i test fanno molti accessi dallo stesso IP
process.env.LOGIN_RATE_LIMIT = '1000';
