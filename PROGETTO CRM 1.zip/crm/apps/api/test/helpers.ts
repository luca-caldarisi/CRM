// =====================================================================================
// Funzioni di supporto comuni ai test di integrazione
// =====================================================================================

// Importa il modulo di test di NestJS
import { Test } from '@nestjs/testing';
// Importa il tipo dell'applicazione Express
import type { NestExpressApplication } from '@nestjs/platform-express';
// Importa supertest per simulare richieste HTTP
import request from 'supertest';
// Importa gli operatori di query
import { eq } from 'drizzle-orm';
// Importa modulo radice e configurazione
import { AppModule } from '../src/app.module';
import { configuraApp } from '../src/app.setup';
// Importa database, schema e seed
import { DB } from '../src/database/database.module';
import type { Database } from '../src/database/client';
import { ruoli, utenti } from '../src/database/schema';
import { eseguiSeed } from '../src/database/seed';
// Importa l'hashing delle password
import { hashPassword } from '../src/modules/auth/password';

// Credenziali dell'amministratore creato dal seed nei test
export const ADMIN = { email: 'admin@test.local', password: 'PasswordAdmin-Test-1' };

// Contesto disponibile ai test
export interface ContestoTest {
  app: NestExpressApplication;
  db: Database;
  http: ReturnType<typeof request>;
}

// Avvia l'applicazione completa (stessi moduli, guard e filtri della produzione)
export async function avviaApp(): Promise<ContestoTest> {
  // Compila il modulo radice
  const modulo = await Test.createTestingModule({ imports: [AppModule] }).compile();
  // Crea l'applicazione Express
  const app = modulo.createNestApplication<NestExpressApplication>({ logger: false });
  // Applica le stesse impostazioni di main.ts
  configuraApp(app);
  // Inizializza senza aprire una porta (supertest usa il server interno)
  await app.init();
  // Recupera il database
  const db = app.get<Database>(DB);
  // Crea permessi, ruoli e amministratore (idempotente)
  await eseguiSeed(db, { adminEmail: ADMIN.email, adminPassword: ADMIN.password }, () => undefined);
  // Nei test l'admin non deve cambiare password (tranne nel test dedicato, che la reimposta)
  await db.update(utenti).set({ deveCambiarePassword: false }).where(eq(utenti.email, ADMIN.email));
  // Restituisce il contesto
  return { app, db, http: request(app.getHttpServer()) };
}

// Esegue il login e restituisce access token e cookie
export async function login(ctx: ContestoTest, email: string, password: string): Promise<{ token: string; cookie: string }> {
  // Chiamata di login
  const res = await request(ctx.app.getHttpServer()).post('/api/v1/auth/login').send({ email, password }).expect(200);
  // Estrae il cookie impostato dal server
  const cookie = (res.headers['set-cookie'] as unknown as string[])[0]!.split(';')[0]!;
  // Restituisce token e cookie
  return { token: res.body.accessToken as string, cookie };
}

// Crea direttamente nel database un utente con il ruolo indicato (password già cambiata)
export async function creaUtente(ctx: ContestoTest, nomeRuolo: string, email: string, password = 'PasswordUtente-Test-1'): Promise<{ id: string; email: string; password: string }> {
  // Cerca il ruolo per nome
  const [ruolo] = await ctx.db.select().from(ruoli).where(eq(ruoli.nome, nomeRuolo)).limit(1);
  // Il ruolo deve esistere
  if (!ruolo) throw new Error(`Ruolo ${nomeRuolo} non trovato`);
  // Inserisce l'utente (le email dei test sono sempre univoche)
  const [u] = await ctx.db
    .insert(utenti)
    .values({ email, nome: 'Test', cognome: nomeRuolo, passwordHash: await hashPassword(password), ruoloId: ruolo.id, deveCambiarePassword: false })
    .returning({ id: utenti.id });
  // Restituisce i dati per il login
  return { id: u!.id, email, password };
}

// Genera un'email univoca per evitare collisioni tra test
export function emailUnica(prefisso: string): string {
  return `${prefisso}.${Date.now()}.${Math.floor(Math.random() * 1e6)}@test.local`;
}
