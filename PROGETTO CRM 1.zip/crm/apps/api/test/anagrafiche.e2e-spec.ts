// =====================================================================================
// Test di integrazione: clienti, sedi, contatti, commesse, allegati e audit log
// =====================================================================================

// Importa supertest
import request from 'supertest';
// Importa l'helper SQL
import { sql } from 'drizzle-orm';
// Importa gli helper
import { ADMIN, avviaApp, creaUtente, emailUnica, login, type ContestoTest } from './helpers';

describe('Anagrafiche', () => {
  // Contesto dei test
  let ctx: ContestoTest;
  // Server HTTP
  let server: Parameters<typeof request>[0];
  // Header di autorizzazione dell'admin
  let auth: { authorization: string };

  // Avvio e login
  beforeAll(async () => {
    ctx = await avviaApp();
    server = ctx.app.getHttpServer();
    auth = { authorization: `Bearer ${(await login(ctx, ADMIN.email, ADMIN.password)).token}` };
  });

  // Chiusura
  afterAll(async () => {
    await ctx.app.close();
  });

  it('valida i dati fiscali e assegna un codice progressivo', async () => {
    // P.IVA con carattere di controllo errato
    const errato = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Errata Srl', partitaIva: '01234567890' }).expect(400);
    expect(errato.body.errors[0].campo).toBe('partitaIva');
    // Cliente valido
    const ok = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Rossi Informatica Srl', partitaIva: 'IT 01234567897', email: 'INFO@ROSSI.IT' }).expect(201);
    // Codice nel formato atteso e dati normalizzati
    expect(ok.body.codice).toMatch(/^CL-\d{5}$/);
    expect(ok.body.partitaIva).toBe('01234567897');
    expect(ok.body.email).toBe('info@rossi.it');
    // Stessa P.IVA: conflitto con messaggio chiaro
    const dup = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Duplicato Srl', partitaIva: '01234567897' }).expect(409);
    expect(dup.body.detail).toBe('Esiste già un cliente con questa Partita IVA');
  });

  it('la ricerca neutralizza i caratteri jolly di SQL', async () => {
    // Clienti con nomi simili
    await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Sconto 50% Srl' }).expect(201);
    await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Sconto 500 Srl' }).expect(201);
    // Cercando "50%" si trova solo il cliente con il simbolo percentuale
    const res = await request(server).get('/api/v1/clienti').query({ q: '50%' }).set(auth).expect(200);
    expect(res.body.data.map((c: { ragioneSociale: string }) => c.ragioneSociale)).toEqual(['Sconto 50% Srl']);
  });

  it('gestisce sedi (una sola legale) e contatti (un solo principale)', async () => {
    // Cliente
    const c = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Sedi e Contatti Spa' }).expect(201);
    // Sede legale
    const legale = await request(server).post(`/api/v1/clienti/${c.body.id}/sedi`).set(auth).send({ tipo: 'legale', indirizzo: 'Via Roma 1', citta: 'Bologna', provincia: 'bo', cap: '40100' }).expect(201);
    expect(legale.body.provincia).toBe('BO');
    // Seconda sede legale: conflitto
    await request(server).post(`/api/v1/clienti/${c.body.id}/sedi`).set(auth).send({ tipo: 'legale', indirizzo: 'Via Milano 2', citta: 'Modena' }).expect(409);
    // Sede operativa consentita
    await request(server).post(`/api/v1/clienti/${c.body.id}/sedi`).set(auth).send({ tipo: 'operativa', indirizzo: 'Via Milano 2', citta: 'Modena' }).expect(201);
    // Due contatti marcati come principali: resta principale solo l'ultimo
    const primo = await request(server).post(`/api/v1/clienti/${c.body.id}/contatti`).set(auth).send({ nome: 'Anna', cognome: 'Bianchi', principale: true, sedeId: legale.body.id }).expect(201);
    await request(server).post(`/api/v1/clienti/${c.body.id}/contatti`).set(auth).send({ nome: 'Luca', cognome: 'Verdi', principale: true }).expect(201);
    const contatti = await request(server).get(`/api/v1/clienti/${c.body.id}/contatti`).set(auth).expect(200);
    expect(contatti.body.filter((x: { principale: boolean }) => x.principale).map((x: { nome: string }) => x.nome)).toEqual(['Luca']);
    expect(contatti.body.find((x: { id: string }) => x.id === primo.body.id).principale).toBe(false);
    // La lista clienti mostra la città della sede legale
    const lista = await request(server).get('/api/v1/clienti').query({ q: 'Sedi e Contatti' }).set(auth).expect(200);
    expect(lista.body.data[0].citta).toBe('Bologna');
  });

  it('gestisce il ciclo di vita delle commesse e impedisce di eliminare clienti con commesse aperte', async () => {
    // Cliente
    const c = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Commesse Srl' }).expect(201);
    // Date incoerenti: 400
    await request(server).post('/api/v1/commesse').set(auth).send({ clienteId: c.body.id, titolo: 'Errata', tipo: 'assistenza', dataApertura: '2026-05-10', dataChiusura: '2026-05-01' }).expect(400);
    // Commessa valida con codice annuale
    const m = await request(server).post('/api/v1/commesse').set(auth).send({ clienteId: c.body.id, titolo: 'Assistenza 2026', tipo: 'assistenza', dataApertura: '2026-01-01' }).expect(201);
    expect(m.body.codice).toMatch(new RegExp(`^CM-${new Date().getFullYear()}-\\d{4}$`));
    expect(m.body.stato).toBe('aperta');
    // Il cliente con commessa aperta non si elimina
    const blocco = await request(server).delete(`/api/v1/clienti/${c.body.id}`).set(auth).expect(422);
    expect(blocco.body.detail).toContain('commesse aperte');
    // Chiusura: la data viene impostata automaticamente
    const chiusa = await request(server).patch(`/api/v1/commesse/${m.body.id}`).set(auth).send({ stato: 'chiusa' }).expect(200);
    expect(chiusa.body.dataChiusura).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    // Ora il cliente si può eliminare (logicamente) e non compare più
    await request(server).delete(`/api/v1/clienti/${c.body.id}`).set(auth).expect(204);
    await request(server).get(`/api/v1/clienti/${c.body.id}`).set(auth).expect(404);
  });

  it('accetta solo allegati il cui contenuto corrisponde all\'estensione e ne protegge il download', async () => {
    // Cliente
    const c = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Allegati Srl' }).expect(201);
    // Contenuto di un PDF minimale
    const pdf = Buffer.from('%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF');
    // Caricamento valido
    const up = await request(server).post('/api/v1/allegati').set(auth).field('entita', 'cliente').field('entitaId', c.body.id).attach('file', pdf, 'Contratto firmato.pdf').expect(201);
    expect(up.body.mimeType).toBe('application/pdf');
    // Eseguibile rinominato in .pdf: rifiutato
    const falso = await request(server).post('/api/v1/allegati').set(auth).field('entita', 'cliente').field('entitaId', c.body.id).attach('file', Buffer.from('MZ\x90\x00 programma'), 'fattura.pdf').expect(422);
    expect(falso.body.type).toBe('contenuto_non_valido');
    // Estensione non ammessa
    await request(server).post('/api/v1/allegati').set(auth).field('entita', 'cliente').field('entitaId', c.body.id).attach('file', Buffer.from('echo'), 'script.sh').expect(422);
    // Download con header di sicurezza e contenuto identico
    const dl = await request(server).get(`/api/v1/allegati/${up.body.id}/download`).set(auth).buffer(true).parse((res, cb) => {
      // Raccoglie i byte della risposta
      const parti: Buffer[] = [];
      res.on('data', (d: Buffer) => parti.push(d));
      res.on('end', () => cb(null, Buffer.concat(parti)));
    }).expect(200);
    expect(dl.headers['content-disposition']).toContain("attachment; filename*=UTF-8''Contratto%20firmato.pdf");
    expect(dl.headers['x-content-type-options']).toBe('nosniff');
    expect((dl.body as Buffer).equals(pdf)).toBe(true);
    // Un tecnico (sola lettura clienti) può scaricare ma non caricare né eliminare
    const u = await creaUtente(ctx, 'Tecnico', emailUnica('allegati'));
    const tecnico = { authorization: `Bearer ${(await login(ctx, u.email, u.password)).token}` };
    await request(server).get(`/api/v1/allegati/${up.body.id}/download`).set(tecnico).expect(200);
    await request(server).post('/api/v1/allegati').set(tecnico).field('entita', 'cliente').field('entitaId', c.body.id).attach('file', pdf, 'altro.pdf').expect(403);
    await request(server).delete(`/api/v1/allegati/${up.body.id}`).set(tecnico).expect(403);
    // L'admin elimina
    await request(server).delete(`/api/v1/allegati/${up.body.id}`).set(auth).expect(204);
    await request(server).get(`/api/v1/allegati/${up.body.id}/download`).set(auth).expect(404);
  });

  it('registra le modifiche nell\'audit log, che non può essere alterato', async () => {
    // Cliente creato e modificato
    const c = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Audit Srl', telefono: '051 123456' }).expect(201);
    await request(server).patch(`/api/v1/clienti/${c.body.id}`).set(auth).send({ telefono: '051 654321' }).expect(200);
    // Storico del cliente
    const storico = await request(server).get('/api/v1/audit').query({ entita: 'cliente', entitaId: c.body.id }).set(auth).expect(200);
    expect(storico.body.data.map((v: { azione: string }) => v.azione)).toEqual(['modifica', 'creazione']);
    // La modifica contiene solo il campo cambiato, con valore prima e dopo
    expect(storico.body.data[0].modifiche).toEqual({ telefono: { prima: '051 123456', dopo: '051 654321' } });
    // Un tentativo di alterare il registro direttamente nel database fallisce
    await expect(ctx.db.execute(sql`UPDATE audit_log SET descrizione = 'manomesso'`)).rejects.toThrow();
    await expect(ctx.db.execute(sql`DELETE FROM audit_log`)).rejects.toThrow();
  });
});
