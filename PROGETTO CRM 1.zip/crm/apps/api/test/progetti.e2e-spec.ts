// =====================================================================================
// Test di integrazione del modulo Progetti:
// template, creazione da template, bacheca, spostamento task, to-do, ore e riepilogo
// =====================================================================================

// Importa supertest
import request from 'supertest';
// Importa gli operatori di query
import { eq } from 'drizzle-orm';
// Importa gli helper dei test
import { ADMIN, avviaApp, creaUtente, emailUnica, login, type ContestoTest } from './helpers';
// Importa le tabelle usate per le verifiche dirette sul database
import { progetti, task } from '../src/database/schema';

describe('Progetti', () => {
  // Contesto dei test
  let ctx: ContestoTest;
  // Server HTTP
  let server: Parameters<typeof request>[0];
  // Header di autorizzazione dell'admin
  let auth: { authorization: string };
  // Cliente usato da tutti i test
  let clienteId: string;

  // Avvio, login e cliente di prova
  beforeAll(async () => {
    ctx = await avviaApp();
    server = ctx.app.getHttpServer();
    auth = { authorization: `Bearer ${(await login(ctx, ADMIN.email, ADMIN.password)).token}` };
    // Cliente a cui collegare i progetti
    const c = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Progetti Cliente Srl' }).expect(201);
    clienteId = c.body.id;
  });

  // Chiusura
  afterAll(async () => {
    await ctx.app.close();
  });

  // Crea un template completo e restituisce il suo id
  async function creaTemplate(nome: string): Promise<string> {
    // Dati generali
    const t = await request(server).post('/api/v1/progetto-template').set(auth).send({ nome, categoria: 'Sistemistica' }).expect(201);
    // Struttura: 3 colonne e 2 task con to-do
    await request(server)
      .put(`/api/v1/progetto-template/${t.body.id}/struttura`)
      .set(auth)
      .send({
        colonne: [
          { nome: 'Da fare', consideraCompletato: false },
          { nome: 'In corso', consideraCompletato: false },
          { nome: 'Fatto', consideraCompletato: true },
        ],
        task: [
          { titolo: 'Sopralluogo', colonnaIndice: 0, oreStimate: 2, todo: ['Verificare rack', 'Contare prese rete'] },
          { titolo: 'Installazione', colonnaIndice: 0, oreStimate: 8, todo: ['Montare server'] },
        ],
      })
      .expect(200);
    // Id del template
    return t.body.id;
  }

  it('crea un progetto da template copiando colonne, task e to-do', async () => {
    // Template di partenza
    const templateId = await creaTemplate('Nuovo server');
    // Progetto creato dal template
    const p = await request(server)
      .post('/api/v1/progetti')
      .set(auth)
      .send({ clienteId, templateId, nome: 'Server sala CED', stato: 'in_corso', dataInizio: '2026-01-07', dataFinePrevista: '2026-02-07' })
      .expect(201);
    // Codice progressivo nel formato atteso
    expect(p.body.codice).toMatch(/^PR-\d{4}-\d{4}$/);
    // Le colonne sono state copiate nell'ordine del template
    expect(p.body.colonne.map((c: { nome: string }) => c.nome)).toEqual(['Da fare', 'In corso', 'Fatto']);
    // Solo l'ultima colonna conta come completamento
    expect(p.body.colonne.map((c: { consideraCompletato: boolean }) => c.consideraCompletato)).toEqual([false, false, true]);
    // Bacheca: i due task del template sono nella prima colonna
    const b = await request(server).get(`/api/v1/progetti/${p.body.id}/bacheca`).set(auth).expect(200);
    expect(b.body.colonne[0].task.map((t: { titolo: string }) => t.titolo)).toEqual(['Sopralluogo', 'Installazione']);
    // Le voci di to-do sono state copiate sul task corrispondente
    expect(b.body.colonne[0].task[0].todoTotali).toBe(2);
    expect(b.body.colonne[0].task[1].todoTotali).toBe(1);
    // Le colonne successive sono vuote
    expect(b.body.colonne[1].task).toEqual([]);
    // Un template già usato non si può eliminare: si disattiva
    const err = await request(server).delete(`/api/v1/progetto-template/${templateId}`).set(auth).expect(422);
    expect(err.body.detail).toContain('disattivalo');
  });

  it("rifiuta un template disattivato e una data di fine prevista anteriore all'inizio", async () => {
    // Template disattivato
    const t = await request(server).post('/api/v1/progetto-template').set(auth).send({ nome: 'Dismesso', attivo: false }).expect(201);
    // Creazione rifiutata con messaggio chiaro
    const err = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId, templateId: t.body.id, nome: 'Non valido' }).expect(422);
    expect(err.body.detail).toContain('non è più attivo');
    // Date incoerenti: bloccate dallo schema condiviso prima di arrivare al database
    const date = await request(server)
      .post('/api/v1/progetti')
      .set(auth)
      .send({ clienteId, nome: 'Date incoerenti', dataInizio: '2026-03-01', dataFinePrevista: '2026-02-01' })
      .expect(400);
    expect(date.body.errors[0].campo).toBe('dataFinePrevista');
  });

  it('senza template crea la bacheca predefinita e calcola l\'avanzamento sui task completati', async () => {
    // Progetto senza template
    const p = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId, nome: 'Progetto libero', stato: 'in_corso' }).expect(201);
    // Colonne predefinite
    expect(p.body.colonne.map((c: { nome: string }) => c.nome)).toEqual(['Da fare', 'In corso', 'In verifica', 'Completato']);
    // Identificativi delle colonne utili al test
    const daFare = p.body.colonne[0].id;
    const completato = p.body.colonne[3].id;
    // Quattro task nella prima colonna
    const creati = [];
    for (const titolo of ['Analisi', 'Configurazione', 'Test', 'Consegna']) {
      const t = await request(server).post(`/api/v1/progetti/${p.body.id}/task`).set(auth).send({ colonnaId: daFare, titolo, oreStimate: 1 }).expect(201);
      creati.push(t.body.id);
    }
    // Le posizioni sono progressive
    expect(creati.length).toBe(4);
    // Avanzamento iniziale: nessun task completato
    const prima = await request(server).get(`/api/v1/progetti/${p.body.id}/riepilogo`).set(auth).expect(200);
    expect(prima.body).toMatchObject({ taskTotali: 4, taskCompletati: 0, avanzamento: 0 });
    // Ore stimate: 4 task da 1 ora = 240 minuti
    expect(prima.body.minutiStimati).toBe(240);
    // Sposta un task nella colonna di completamento
    await request(server).post(`/api/v1/task/${creati[0]}/sposta`).set(auth).send({ colonnaId: completato, posizione: 0 }).expect(201);
    // Avanzamento aggiornato: 1 su 4 = 25%
    const dopo = await request(server).get(`/api/v1/progetti/${p.body.id}/riepilogo`).set(auth).expect(200);
    expect(dopo.body).toMatchObject({ taskTotali: 4, taskCompletati: 1, avanzamento: 25 });
    // Il momento di completamento è stato registrato
    const [riga] = await ctx.db.select({ completatoIl: task.completatoIl }).from(task).where(eq(task.id, creati[0]!)).limit(1);
    expect(riga!.completatoIl).not.toBeNull();
    // Riportandolo indietro il completamento viene azzerato
    await request(server).post(`/api/v1/task/${creati[0]}/sposta`).set(auth).send({ colonnaId: daFare, posizione: 0 }).expect(201);
    const [tornato] = await ctx.db.select({ completatoIl: task.completatoIl }).from(task).where(eq(task.id, creati[0]!)).limit(1);
    expect(tornato!.completatoIl).toBeNull();
    // L'avanzamento torna a zero
    const finale = await request(server).get(`/api/v1/progetti/${p.body.id}/riepilogo`).set(auth).expect(200);
    expect(finale.body.avanzamento).toBe(0);
  });

  it('riordina le posizioni spostando i task nella stessa colonna e tra colonne', async () => {
    // Progetto con quattro task
    const p = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId, nome: 'Riordino', stato: 'in_corso' }).expect(201);
    const daFare = p.body.colonne[0].id;
    const inCorso = p.body.colonne[1].id;
    // Task A, B, C, D in ordine
    const ids: string[] = [];
    for (const titolo of ['Task A', 'Task B', 'Task C', 'Task D']) {
      const t = await request(server).post(`/api/v1/progetti/${p.body.id}/task`).set(auth).send({ colonnaId: daFare, titolo }).expect(201);
      ids.push(t.body.id);
    }
    // Sposta D in cima alla stessa colonna
    await request(server).post(`/api/v1/task/${ids[3]}/sposta`).set(auth).send({ colonnaId: daFare, posizione: 0 }).expect(201);
    // Nuovo ordine: D, A, B, C
    let b = await request(server).get(`/api/v1/progetti/${p.body.id}/bacheca`).set(auth).expect(200);
    expect(b.body.colonne[0].task.map((t: { titolo: string }) => t.titolo)).toEqual(['Task D', 'Task A', 'Task B', 'Task C']);
    // Le posizioni sono contigue e senza duplicati
    expect(b.body.colonne[0].task.map((t: { ordine: number }) => t.ordine)).toEqual([0, 1, 2, 3]);
    // Sposta A nella seconda colonna
    await request(server).post(`/api/v1/task/${ids[0]}/sposta`).set(auth).send({ colonnaId: inCorso, posizione: 0 }).expect(201);
    // La prima colonna si compatta, la seconda contiene A
    b = await request(server).get(`/api/v1/progetti/${p.body.id}/bacheca`).set(auth).expect(200);
    expect(b.body.colonne[0].task.map((t: { titolo: string }) => t.titolo)).toEqual(['Task D', 'Task B', 'Task C']);
    expect(b.body.colonne[0].task.map((t: { ordine: number }) => t.ordine)).toEqual([0, 1, 2]);
    expect(b.body.colonne[1].task.map((t: { titolo: string }) => t.titolo)).toEqual(['Task A']);
    // Una colonna di un altro progetto non è utilizzabile come destinazione
    const altro = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId, nome: 'Altra bacheca' }).expect(201);
    await request(server).post(`/api/v1/task/${ids[1]}/sposta`).set(auth).send({ colonnaId: altro.body.colonne[0].id, posizione: 0 }).expect(404);
  });

  it('gestisce le voci della to-do assegnandole a tecnici diversi', async () => {
    // Tecnico a cui assegnare una voce
    const tecnico = await creaUtente(ctx, 'Tecnico', emailUnica('todo.tecnico'));
    // Progetto e task
    const p = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId, nome: 'Con to-do', stato: 'in_corso' }).expect(201);
    const t = await request(server).post(`/api/v1/progetti/${p.body.id}/task`).set(auth).send({ colonnaId: p.body.colonne[0].id, titolo: 'Con elenco' }).expect(201);
    // Due voci, la seconda assegnata al tecnico
    await request(server).post(`/api/v1/task/${t.body.id}/todo`).set(auth).send({ titolo: 'Preparare cavi' }).expect(201);
    const voci = await request(server).post(`/api/v1/task/${t.body.id}/todo`).set(auth).send({ titolo: 'Configurare switch', assegnatarioId: tecnico.id }).expect(201);
    // L'elenco restituito è in ordine e contiene l'assegnatario
    expect(voci.body.map((v: { titolo: string }) => v.titolo)).toEqual(['Preparare cavi', 'Configurare switch']);
    expect(voci.body[1].assegnatario.id).toBe(tecnico.id);
    // Spunta la prima voce
    const spuntate = await request(server).patch(`/api/v1/todo/${voci.body[0].id}`).set(auth).send({ completata: true }).expect(200);
    // Il momento del completamento viene registrato
    expect(spuntate.body[0].completata).toBe(true);
    expect(spuntate.body[0].completataIl).not.toBeNull();
    // Il conteggio nel dettaglio del task è coerente
    const dettaglio = await request(server).get(`/api/v1/task/${t.body.id}`).set(auth).expect(200);
    expect(dettaglio.body).toMatchObject({ todoTotali: 2, todoCompletate: 1 });
    // Il riepilogo del progetto riporta le stesse quantità
    const riepilogo = await request(server).get(`/api/v1/progetti/${p.body.id}/riepilogo`).set(auth).expect(200);
    expect(riepilogo.body).toMatchObject({ todoTotali: 2, todoCompletate: 1 });
    // Eliminando una voce le posizioni si compattano
    const rimaste = await request(server).delete(`/api/v1/todo/${voci.body[0].id}`).set(auth).expect(200);
    expect(rimaste.body.map((v: { ordine: number }) => v.ordine)).toEqual([0]);
  });

  it('registra le ore, rifiuta le date future e le somma nel riepilogo', async () => {
    // Progetto e task
    const p = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId, nome: 'Con ore', stato: 'in_corso' }).expect(201);
    const t = await request(server).post(`/api/v1/progetti/${p.body.id}/task`).set(auth).send({ colonnaId: p.body.colonne[0].id, titolo: 'Lavorato' }).expect(201);
    // Durata in formato "ore:minuti"
    await request(server).post(`/api/v1/task/${t.body.id}/ore`).set(auth).send({ data: '2026-01-08', durata: '1:30', descrizione: 'Configurazione' }).expect(201);
    // Durata in ore decimali con la virgola
    const ore = await request(server).post(`/api/v1/task/${t.body.id}/ore`).set(auth).send({ data: '2026-01-09', durata: '2,25' }).expect(201);
    // Entrambe le registrazioni sono presenti, dalla più recente
    expect(ore.body.map((r: { minuti: number }) => r.minuti)).toEqual([135, 90]);
    // Durata non interpretabile: errore di validazione sul campo
    const errata = await request(server).post(`/api/v1/task/${t.body.id}/ore`).set(auth).send({ data: '2026-01-09', durata: 'tanto' }).expect(400);
    expect(errata.body.errors[0].campo).toBe('durata');
    // Oltre 24 ore in un giorno: rifiutato
    await request(server).post(`/api/v1/task/${t.body.id}/ore`).set(auth).send({ data: '2026-01-09', durata: '25:00' }).expect(400);
    // Data futura: rifiutata dalla regola di business
    const domani = new Date(Date.now() + 86_400_000).toISOString().slice(0, 10);
    const futura = await request(server).post(`/api/v1/task/${t.body.id}/ore`).set(auth).send({ data: domani, durata: '1:00' }).expect(422);
    expect(futura.body.detail).toContain('data futura');
    // Il riepilogo somma i minuti e li attribuisce al tecnico
    const riepilogo = await request(server).get(`/api/v1/progetti/${p.body.id}/riepilogo`).set(auth).expect(200);
    expect(riepilogo.body.minutiRegistrati).toBe(225);
    expect(riepilogo.body.perTecnico[0].minuti).toBe(225);
    // L'elenco ore del progetto si può filtrare per data
    const filtrate = await request(server).get(`/api/v1/progetti/${p.body.id}/ore`).query({ dal: '2026-01-09' }).set(auth).expect(200);
    expect(filtrate.body).toHaveLength(1);
    // Eliminando una registrazione il totale si aggiorna
    await request(server).delete(`/api/v1/ore/${ore.body[0].id}`).set(auth).expect(204);
    const dopo = await request(server).get(`/api/v1/progetti/${p.body.id}/riepilogo`).set(auth).expect(200);
    expect(dopo.body.minutiRegistrati).toBe(90);
  });

  it('conta i task in ritardo solo se non completati', async () => {
    // Progetto con un task scaduto
    const p = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId, nome: 'Con ritardi', stato: 'in_corso' }).expect(201);
    const scaduto = await request(server)
      .post(`/api/v1/progetti/${p.body.id}/task`)
      .set(auth)
      .send({ colonnaId: p.body.colonne[0].id, titolo: 'Scaduto', dataScadenza: '2020-01-01' })
      .expect(201);
    // Il riepilogo lo segnala in ritardo
    const prima = await request(server).get(`/api/v1/progetti/${p.body.id}/riepilogo`).set(auth).expect(200);
    expect(prima.body.taskInRitardo).toBe(1);
    // Completandolo non è più in ritardo
    await request(server).post(`/api/v1/task/${scaduto.body.id}/sposta`).set(auth).send({ colonnaId: p.body.colonne[3].id, posizione: 0 }).expect(201);
    const dopo = await request(server).get(`/api/v1/progetti/${p.body.id}/riepilogo`).set(auth).expect(200);
    expect(dopo.body.taskInRitardo).toBe(0);
  });

  describe('ambito "propri" del tecnico', () => {
    // Tecnico con ambito "propri" su progetti e task
    let tecnico: { id: string; email: string; password: string };
    // Header di autorizzazione del tecnico
    let authTecnico: { authorization: string };
    // Progetto non assegnato al tecnico
    let progettoAltrui: { id: string; colonne: Array<{ id: string }> };

    // Prepara tecnico e progetto
    beforeAll(async () => {
      tecnico = await creaUtente(ctx, 'Tecnico', emailUnica('ambito.tecnico'));
      authTecnico = { authorization: `Bearer ${(await login(ctx, tecnico.email, tecnico.password)).token}` };
      const p = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId, nome: 'Non mio', stato: 'in_corso' }).expect(201);
      progettoAltrui = p.body;
    });

    it('non vede i progetti in cui non è coinvolto', async () => {
      // L'elenco non contiene il progetto altrui
      const elenco = await request(server).get('/api/v1/progetti').set(authTecnico).expect(200);
      expect(elenco.body.data.map((p: { id: string }) => p.id)).not.toContain(progettoAltrui.id);
      // Il dettaglio risponde 404: non si rivela l'esistenza del progetto
      await request(server).get(`/api/v1/progetti/${progettoAltrui.id}`).set(authTecnico).expect(404);
      // Anche la bacheca è inaccessibile
      await request(server).get(`/api/v1/progetti/${progettoAltrui.id}/bacheca`).set(authTecnico).expect(404);
    });

    it('vede il progetto quando gli viene assegnato un task, ma non modifica quelli altrui', async () => {
      // Task assegnato al tecnico dall'admin
      const mio = await request(server)
        .post(`/api/v1/progetti/${progettoAltrui.id}/task`)
        .set(auth)
        .send({ colonnaId: progettoAltrui.colonne[0]!.id, titolo: 'Assegnato al tecnico', responsabileId: tecnico.id })
        .expect(201);
      // Task di un collega
      const altrui = await request(server)
        .post(`/api/v1/progetti/${progettoAltrui.id}/task`)
        .set(auth)
        .send({ colonnaId: progettoAltrui.colonne[0]!.id, titolo: 'Di un collega' })
        .expect(201);
      // Ora il progetto è visibile
      const elenco = await request(server).get('/api/v1/progetti').set(authTecnico).expect(200);
      expect(elenco.body.data.map((p: { id: string }) => p.id)).toContain(progettoAltrui.id);
      // Può spostare il proprio task
      await request(server).post(`/api/v1/task/${mio.body.id}/sposta`).set(authTecnico).send({ colonnaId: progettoAltrui.colonne[1]!.id, posizione: 0 }).expect(201);
      // Non può spostare quello del collega
      const negato = await request(server)
        .post(`/api/v1/task/${altrui.body.id}/sposta`)
        .set(authTecnico)
        .send({ colonnaId: progettoAltrui.colonne[1]!.id, posizione: 0 })
        .expect(403);
      expect(negato.body.detail).toContain('di cui sei responsabile');
      // Non può passare il proprio task a un altro tecnico
      await request(server).patch(`/api/v1/task/${mio.body.id}`).set(authTecnico).send({ responsabileId: null }).expect(403);
      // Non può modificare i dati del progetto: il ruolo Tecnico non ha affatto progetti.write,
      // quindi la richiesta viene fermata dal guard con 403 prima di arrivare al service
      await request(server).patch(`/api/v1/progetti/${progettoAltrui.id}`).set(authTecnico).send({ nome: 'Rinominato' }).expect(403);
      // Nemmeno eliminarlo: manca progetti.delete
      await request(server).delete(`/api/v1/progetti/${progettoAltrui.id}`).set(authTecnico).expect(403);
    });

    it('registra le ore solo a proprio nome', async () => {
      // Task del tecnico nel progetto visibile
      const b = await request(server).get(`/api/v1/progetti/${progettoAltrui.id}/bacheca`).set(authTecnico).expect(200);
      // Individua il task di cui è responsabile
      const suoi = b.body.colonne.flatMap((c: { task: Array<{ id: string; responsabile: { id: string } | null }> }) => c.task).filter((t: { responsabile: { id: string } | null }) => t.responsabile?.id === tecnico.id);
      // Deve esistere almeno un task suo
      expect(suoi.length).toBeGreaterThan(0);
      // Registra le ore indicando (invano) un altro utente: il server le attribuisce comunque a lui
      const ore = await request(server)
        .post(`/api/v1/task/${suoi[0].id}/ore`)
        .set(authTecnico)
        .send({ data: '2026-01-10', durata: '2:00', utenteId: (await ctx.db.select({ id: progetti.createdById }).from(progetti).where(eq(progetti.id, progettoAltrui.id)).limit(1))[0]!.id })
        .expect(201);
      // L'autore registrato è il tecnico, non l'utente indicato nella richiesta
      expect(ore.body[0].utente.id).toBe(tecnico.id);
      // Non può eliminare le ore registrate da altri: l'admin ne aggiunge una
      const altrui = await request(server).post(`/api/v1/task/${suoi[0].id}/ore`).set(auth).send({ data: '2026-01-10', durata: '1:00' }).expect(201);
      // Individua la registrazione dell'admin
      const dellAdmin = altrui.body.find((r: { utente: { id: string } }) => r.utente.id !== tecnico.id);
      // Eliminazione negata
      const negato = await request(server).delete(`/api/v1/ore/${dellAdmin.id}`).set(authTecnico).expect(403);
      expect(negato.body.detail).toContain('registrato tu');
    });

    it('non può gestire i template', async () => {
      // La lettura è consentita (serve per scegliere un template)
      await request(server).get('/api/v1/progetto-template').set(authTecnico).expect(200);
      // La creazione richiede template.manage
      await request(server).post('/api/v1/progetto-template').set(authTecnico).send({ nome: 'Tentativo' }).expect(403);
    });
  });
  it('non elimina un cliente con progetti in corso, lo elimina dopo la conclusione', async () => {
    // Cliente dedicato a questo test
    const c = await request(server).post('/api/v1/clienti').set(auth).send({ ragioneSociale: 'Cliente Con Progetto Srl' }).expect(201);
    // Progetto in corso collegato al cliente
    const p = await request(server).post('/api/v1/progetti').set(auth).send({ clienteId: c.body.id, nome: 'Progetto attivo', stato: 'in_corso' }).expect(201);
    // L'eliminazione del cliente viene rifiutata con una regola di business (422)
    const r = await request(server).delete(`/api/v1/clienti/${c.body.id}`).set(auth).expect(422);
    // Il messaggio spiega il motivo
    expect(r.body.detail).toContain('progetti in corso');
    // Il progetto viene concluso
    await request(server).patch(`/api/v1/progetti/${p.body.id}`).set(auth).send({ stato: 'concluso' }).expect(200);
    // Ora il cliente si può eliminare
    await request(server).delete(`/api/v1/clienti/${c.body.id}`).set(auth).expect(204);
  });
});
