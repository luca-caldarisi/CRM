// Configurazione di Jest per i test di integrazione dell'API (su un database PostgreSQL reale)

module.exports = {
  // Cartella radice dei test: apps/api
  rootDir: '..',
  // File di test: *.e2e-spec.ts (integrazione) e *.spec.ts (unitari)
  testRegex: '(test/.*\\.e2e-spec|src/.*\\.spec)\\.ts$',
  // Ambiente Node (niente browser simulato)
  testEnvironment: 'node',
  // Compila TypeScript al volo con ts-jest
  transform: { '^.+\\.ts$': ['ts-jest', { tsconfig: '<rootDir>/test/tsconfig.json' }] },
  // Estensioni dei moduli
  moduleFileExtensions: ['ts', 'js', 'json'],
  // Imposta le variabili d'ambiente prima di caricare qualsiasi modulo
  setupFiles: ['<rootDir>/test/env-test.ts'],
  // Ricrea lo schema del database di test una volta prima di tutti i test
  globalSetup: '<rootDir>/test/setup-globale.ts',
  // Tempo massimo per singolo test (argon2 è volutamente lento)
  testTimeout: 30000,
};
