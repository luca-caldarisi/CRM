// Eseguito una sola volta prima di tutti i test: riparte da un database di test vuoto

// Importa i percorsi
import { resolve } from 'node:path';
// Importa l'helper SQL e il migratore di Drizzle
import { sql } from 'drizzle-orm';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
// Importa le variabili dei test
import './env-test';
// Importa la connessione
import { creaDatabase } from '../src/database/client';

export default async function setupGlobale(): Promise<void> {
  // Apre la connessione al database di test
  const { db, pool } = creaDatabase(process.env.DATABASE_URL!);
  // Sicurezza: si rifiuta di cancellare un database il cui nome non contiene "test"
  if (!process.env.DATABASE_URL!.includes('test')) throw new Error('Il database dei test deve contenere "test" nel nome');
  // Cancella tutto lo schema applicativo e quello delle migrazioni
  await db.execute(sql`DROP SCHEMA IF EXISTS public CASCADE; DROP SCHEMA IF EXISTS drizzle CASCADE; CREATE SCHEMA public;`);
  // Riapplica tutte le migrazioni da zero (verifica anche che siano corrette)
  await migrate(db, { migrationsFolder: resolve(__dirname, '../drizzle') });
  // Chiude la connessione
  await pool.end();
}
