// Configurazione di drizzle-kit: lo strumento che genera le migrazioni SQL confrontando lo schema TypeScript
// Uso: "pnpm db:generate" dopo aver modificato un file in src/database/schema

// Carica le variabili dal file .env nella radice del monorepo
import { config } from 'dotenv';
// Funzione di supporto che fornisce il tipo corretto alla configurazione
import { defineConfig } from 'drizzle-kit';

// Legge il file .env due cartelle sopra (radice del progetto)
config({ path: '../../.env' });

// Esporta la configurazione
export default defineConfig({
  // Database di destinazione
  dialect: 'postgresql',
  // File che contiene la definizione di tutte le tabelle
  schema: './src/database/schema/index.ts',
  // Cartella in cui vengono scritte le migrazioni SQL (da versionare su git)
  out: './drizzle',
  // Stringa di connessione presa dalle variabili d'ambiente (mai scritta nel codice)
  dbCredentials: { url: process.env.DATABASE_URL ?? '' },
  // Chiede conferma prima di operazioni potenzialmente distruttive
  strict: true,
  // Mostra nel dettaglio le istruzioni SQL generate
  verbose: true,
});
