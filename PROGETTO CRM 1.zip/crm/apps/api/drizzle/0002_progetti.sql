CREATE TYPE "public"."priorita_task" AS ENUM('bassa', 'media', 'alta', 'urgente');--> statement-breakpoint
CREATE TYPE "public"."stato_progetto" AS ENUM('pianificato', 'in_corso', 'sospeso', 'concluso', 'annullato');--> statement-breakpoint
ALTER TYPE "public"."entita_allegato" ADD VALUE 'progetto';--> statement-breakpoint
CREATE TABLE "progetti" (
	"id" uuid PRIMARY KEY NOT NULL,
	"codice" varchar(20) NOT NULL,
	"cliente_id" uuid NOT NULL,
	"commessa_id" uuid,
	"template_id" uuid,
	"nome" varchar(200) NOT NULL,
	"descrizione" text,
	"stato" "stato_progetto" DEFAULT 'pianificato' NOT NULL,
	"responsabile_id" uuid,
	"data_inizio" date,
	"data_fine_prevista" date,
	"data_fine_effettiva" date,
	"note" text,
	"created_by_id" uuid,
	"updated_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "progetti_codice_unique" UNIQUE("codice"),
	CONSTRAINT "progetti_date_check" CHECK ("progetti"."data_fine_prevista" IS NULL OR "progetti"."data_inizio" IS NULL OR "progetti"."data_fine_prevista" >= "progetti"."data_inizio")
);
--> statement-breakpoint
CREATE TABLE "progetto_colonne" (
	"id" uuid PRIMARY KEY NOT NULL,
	"progetto_id" uuid NOT NULL,
	"nome" varchar(40) NOT NULL,
	"ordine" integer NOT NULL,
	"considera_completato" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE "progetto_template" (
	"id" uuid PRIMARY KEY NOT NULL,
	"nome" varchar(120) NOT NULL,
	"categoria" varchar(60),
	"descrizione" text,
	"durata_stimata_gg" integer,
	"attivo" boolean DEFAULT true NOT NULL,
	"created_by_id" uuid,
	"updated_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "progetto_template_nome_unique" UNIQUE("nome")
);
--> statement-breakpoint
CREATE TABLE "registrazioni_ore" (
	"id" uuid PRIMARY KEY NOT NULL,
	"task_id" uuid NOT NULL,
	"utente_id" uuid NOT NULL,
	"data" date NOT NULL,
	"minuti" integer NOT NULL,
	"descrizione" varchar(500),
	"created_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "registrazioni_ore_minuti_check" CHECK ("registrazioni_ore"."minuti" > 0 AND "registrazioni_ore"."minuti" <= 1440)
);
--> statement-breakpoint
CREATE TABLE "task" (
	"id" uuid PRIMARY KEY NOT NULL,
	"progetto_id" uuid NOT NULL,
	"colonna_id" uuid NOT NULL,
	"titolo" varchar(200) NOT NULL,
	"descrizione" text,
	"priorita" "priorita_task" DEFAULT 'media' NOT NULL,
	"responsabile_id" uuid,
	"data_scadenza" date,
	"ore_stimate" numeric(6, 2),
	"ordine" integer DEFAULT 0 NOT NULL,
	"completato_il" timestamp with time zone,
	"created_by_id" uuid,
	"updated_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "task_todo" (
	"id" uuid PRIMARY KEY NOT NULL,
	"task_id" uuid NOT NULL,
	"titolo" varchar(200) NOT NULL,
	"completata" boolean DEFAULT false NOT NULL,
	"completata_il" timestamp with time zone,
	"assegnatario_id" uuid,
	"ordine" integer DEFAULT 0 NOT NULL,
	"created_by_id" uuid,
	"updated_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "template_colonne" (
	"id" uuid PRIMARY KEY NOT NULL,
	"template_id" uuid NOT NULL,
	"nome" varchar(40) NOT NULL,
	"ordine" integer NOT NULL,
	"considera_completato" boolean DEFAULT false NOT NULL
);
--> statement-breakpoint
CREATE TABLE "template_task" (
	"id" uuid PRIMARY KEY NOT NULL,
	"template_id" uuid NOT NULL,
	"colonna_indice" integer DEFAULT 0 NOT NULL,
	"titolo" varchar(200) NOT NULL,
	"descrizione" text,
	"ore_stimate" numeric(6, 2),
	"ordine" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "template_todo" (
	"id" uuid PRIMARY KEY NOT NULL,
	"template_task_id" uuid NOT NULL,
	"titolo" varchar(200) NOT NULL,
	"ordine" integer NOT NULL
);
--> statement-breakpoint
ALTER TABLE "progetti" ADD CONSTRAINT "progetti_cliente_id_clienti_id_fk" FOREIGN KEY ("cliente_id") REFERENCES "public"."clienti"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "progetti" ADD CONSTRAINT "progetti_commessa_id_commesse_id_fk" FOREIGN KEY ("commessa_id") REFERENCES "public"."commesse"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "progetti" ADD CONSTRAINT "progetti_template_id_progetto_template_id_fk" FOREIGN KEY ("template_id") REFERENCES "public"."progetto_template"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "progetti" ADD CONSTRAINT "progetti_responsabile_id_utenti_id_fk" FOREIGN KEY ("responsabile_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "progetti" ADD CONSTRAINT "progetti_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "progetti" ADD CONSTRAINT "progetti_updated_by_id_utenti_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "progetto_colonne" ADD CONSTRAINT "progetto_colonne_progetto_id_progetti_id_fk" FOREIGN KEY ("progetto_id") REFERENCES "public"."progetti"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "progetto_template" ADD CONSTRAINT "progetto_template_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "progetto_template" ADD CONSTRAINT "progetto_template_updated_by_id_utenti_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "registrazioni_ore" ADD CONSTRAINT "registrazioni_ore_task_id_task_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."task"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "registrazioni_ore" ADD CONSTRAINT "registrazioni_ore_utente_id_utenti_id_fk" FOREIGN KEY ("utente_id") REFERENCES "public"."utenti"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "registrazioni_ore" ADD CONSTRAINT "registrazioni_ore_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task" ADD CONSTRAINT "task_progetto_id_progetti_id_fk" FOREIGN KEY ("progetto_id") REFERENCES "public"."progetti"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task" ADD CONSTRAINT "task_colonna_id_progetto_colonne_id_fk" FOREIGN KEY ("colonna_id") REFERENCES "public"."progetto_colonne"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task" ADD CONSTRAINT "task_responsabile_id_utenti_id_fk" FOREIGN KEY ("responsabile_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task" ADD CONSTRAINT "task_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task" ADD CONSTRAINT "task_updated_by_id_utenti_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_todo" ADD CONSTRAINT "task_todo_task_id_task_id_fk" FOREIGN KEY ("task_id") REFERENCES "public"."task"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_todo" ADD CONSTRAINT "task_todo_assegnatario_id_utenti_id_fk" FOREIGN KEY ("assegnatario_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_todo" ADD CONSTRAINT "task_todo_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "task_todo" ADD CONSTRAINT "task_todo_updated_by_id_utenti_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "template_colonne" ADD CONSTRAINT "template_colonne_template_id_progetto_template_id_fk" FOREIGN KEY ("template_id") REFERENCES "public"."progetto_template"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "template_task" ADD CONSTRAINT "template_task_template_id_progetto_template_id_fk" FOREIGN KEY ("template_id") REFERENCES "public"."progetto_template"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "template_todo" ADD CONSTRAINT "template_todo_template_task_id_template_task_id_fk" FOREIGN KEY ("template_task_id") REFERENCES "public"."template_task"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "progetti_cliente_idx" ON "progetti" USING btree ("cliente_id");--> statement-breakpoint
CREATE INDEX "progetti_stato_idx" ON "progetti" USING btree ("stato");--> statement-breakpoint
CREATE INDEX "progetti_responsabile_idx" ON "progetti" USING btree ("responsabile_id");--> statement-breakpoint
CREATE UNIQUE INDEX "progetto_colonne_ordine_unique" ON "progetto_colonne" USING btree ("progetto_id","ordine");--> statement-breakpoint
CREATE INDEX "registrazioni_ore_task_idx" ON "registrazioni_ore" USING btree ("task_id");--> statement-breakpoint
CREATE INDEX "registrazioni_ore_utente_idx" ON "registrazioni_ore" USING btree ("utente_id","data");--> statement-breakpoint
CREATE INDEX "task_progetto_idx" ON "task" USING btree ("progetto_id","colonna_id","ordine");--> statement-breakpoint
CREATE INDEX "task_responsabile_idx" ON "task" USING btree ("responsabile_id");--> statement-breakpoint
CREATE INDEX "task_todo_task_idx" ON "task_todo" USING btree ("task_id","ordine");--> statement-breakpoint
CREATE INDEX "task_todo_assegnatario_idx" ON "task_todo" USING btree ("assegnatario_id");--> statement-breakpoint
CREATE UNIQUE INDEX "template_colonne_ordine_unique" ON "template_colonne" USING btree ("template_id","ordine");--> statement-breakpoint
CREATE INDEX "template_task_template_idx" ON "template_task" USING btree ("template_id");--> statement-breakpoint
CREATE INDEX "template_todo_task_idx" ON "template_todo" USING btree ("template_task_id");