-- Estensione per la ricerca "contiene" veloce tramite trigrammi (trusted: non richiede superuser)
CREATE EXTENSION IF NOT EXISTS pg_trgm;--> statement-breakpoint
CREATE TYPE "public"."ambito" AS ENUM('tutti', 'propri');--> statement-breakpoint
CREATE TYPE "public"."azione_audit" AS ENUM('creazione', 'modifica', 'eliminazione', 'login', 'login_fallito', 'logout', 'cambio_password', 'reset_password', 'permessi');--> statement-breakpoint
CREATE TYPE "public"."entita_allegato" AS ENUM('cliente', 'commessa');--> statement-breakpoint
CREATE TYPE "public"."stato_commessa" AS ENUM('aperta', 'sospesa', 'chiusa', 'annullata');--> statement-breakpoint
CREATE TYPE "public"."tipo_commessa" AS ENUM('assistenza', 'progetto', 'fornitura', 'mista');--> statement-breakpoint
CREATE TYPE "public"."tipo_sede" AS ENUM('legale', 'operativa');--> statement-breakpoint
CREATE TABLE "audit_log" (
	"id" uuid PRIMARY KEY NOT NULL,
	"utente_id" uuid,
	"azione" "azione_audit" NOT NULL,
	"entita" varchar(50) NOT NULL,
	"entita_id" uuid,
	"descrizione" varchar(300),
	"modifiche" jsonb,
	"ip" varchar(45),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "contatori" (
	"chiave" varchar(40) PRIMARY KEY NOT NULL,
	"valore" integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE "permessi" (
	"codice" varchar(64) PRIMARY KEY NOT NULL,
	"modulo" varchar(50) NOT NULL,
	"descrizione" varchar(200) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "ruoli" (
	"id" uuid PRIMARY KEY NOT NULL,
	"nome" varchar(50) NOT NULL,
	"descrizione" varchar(200),
	"di_sistema" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "ruoli_nome_unique" UNIQUE("nome")
);
--> statement-breakpoint
CREATE TABLE "ruoli_permessi" (
	"ruolo_id" uuid NOT NULL,
	"permesso_codice" varchar(64) NOT NULL,
	"ambito" "ambito" NOT NULL,
	CONSTRAINT "ruoli_permessi_ruolo_id_permesso_codice_pk" PRIMARY KEY("ruolo_id","permesso_codice")
);
--> statement-breakpoint
CREATE TABLE "sessioni" (
	"id" uuid PRIMARY KEY NOT NULL,
	"utente_id" uuid NOT NULL,
	"famiglia_id" uuid NOT NULL,
	"token_hash" char(64) NOT NULL,
	"scade_il" timestamp with time zone NOT NULL,
	"revocata_il" timestamp with time zone,
	"sostituita_il" timestamp with time zone,
	"ip" varchar(45),
	"user_agent" varchar(300),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "sessioni_token_hash_unique" UNIQUE("token_hash")
);
--> statement-breakpoint
CREATE TABLE "utenti" (
	"id" uuid PRIMARY KEY NOT NULL,
	"email" varchar(254) NOT NULL,
	"nome" varchar(80) NOT NULL,
	"cognome" varchar(80) NOT NULL,
	"password_hash" varchar(255) NOT NULL,
	"ruolo_id" uuid NOT NULL,
	"attivo" boolean DEFAULT true NOT NULL,
	"deve_cambiare_password" boolean DEFAULT true NOT NULL,
	"perm_version" integer DEFAULT 1 NOT NULL,
	"tentativi_falliti" integer DEFAULT 0 NOT NULL,
	"bloccato_fino_a" timestamp with time zone,
	"ultimo_accesso" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "allegati" (
	"id" uuid PRIMARY KEY NOT NULL,
	"entita" "entita_allegato" NOT NULL,
	"entita_id" uuid NOT NULL,
	"nome_originale" varchar(255) NOT NULL,
	"percorso" varchar(200) NOT NULL,
	"mime_type" varchar(100) NOT NULL,
	"dimensione" integer NOT NULL,
	"sha256" char(64) NOT NULL,
	"caricato_da_id" uuid NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "allegati_percorso_unique" UNIQUE("percorso")
);
--> statement-breakpoint
CREATE TABLE "clienti" (
	"id" uuid PRIMARY KEY NOT NULL,
	"codice" varchar(20) NOT NULL,
	"ragione_sociale" varchar(200) NOT NULL,
	"partita_iva" varchar(20),
	"codice_fiscale" varchar(16),
	"codice_sdi" char(7),
	"pec" varchar(254),
	"email" varchar(254),
	"telefono" varchar(30),
	"sito_web" varchar(200),
	"note" text,
	"commerciale_id" uuid,
	"created_by_id" uuid,
	"updated_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "clienti_codice_unique" UNIQUE("codice")
);
--> statement-breakpoint
CREATE TABLE "commesse" (
	"id" uuid PRIMARY KEY NOT NULL,
	"codice" varchar(20) NOT NULL,
	"cliente_id" uuid NOT NULL,
	"titolo" varchar(200) NOT NULL,
	"descrizione" text,
	"tipo" "tipo_commessa" NOT NULL,
	"stato" "stato_commessa" DEFAULT 'aperta' NOT NULL,
	"valore" numeric(12, 2),
	"data_apertura" date NOT NULL,
	"data_chiusura" date,
	"responsabile_id" uuid,
	"created_by_id" uuid,
	"updated_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "commesse_codice_unique" UNIQUE("codice"),
	CONSTRAINT "commesse_date_check" CHECK ("commesse"."data_chiusura" IS NULL OR "commesse"."data_chiusura" >= "commesse"."data_apertura"),
	CONSTRAINT "commesse_valore_check" CHECK ("commesse"."valore" IS NULL OR "commesse"."valore" >= 0)
);
--> statement-breakpoint
CREATE TABLE "contatti" (
	"id" uuid PRIMARY KEY NOT NULL,
	"cliente_id" uuid NOT NULL,
	"sede_id" uuid,
	"nome" varchar(80) NOT NULL,
	"cognome" varchar(80),
	"ruolo_aziendale" varchar(100),
	"email" varchar(254),
	"telefono" varchar(30),
	"cellulare" varchar(30),
	"principale" boolean DEFAULT false NOT NULL,
	"note" text,
	"created_by_id" uuid,
	"updated_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sedi" (
	"id" uuid PRIMARY KEY NOT NULL,
	"cliente_id" uuid NOT NULL,
	"tipo" "tipo_sede" NOT NULL,
	"nome" varchar(100),
	"indirizzo" varchar(200) NOT NULL,
	"cap" varchar(10),
	"citta" varchar(100) NOT NULL,
	"provincia" char(2),
	"nazione" char(2) DEFAULT 'IT' NOT NULL,
	"created_by_id" uuid,
	"updated_by_id" uuid,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "audit_log" ADD CONSTRAINT "audit_log_utente_id_utenti_id_fk" FOREIGN KEY ("utente_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ruoli_permessi" ADD CONSTRAINT "ruoli_permessi_ruolo_id_ruoli_id_fk" FOREIGN KEY ("ruolo_id") REFERENCES "public"."ruoli"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "ruoli_permessi" ADD CONSTRAINT "ruoli_permessi_permesso_codice_permessi_codice_fk" FOREIGN KEY ("permesso_codice") REFERENCES "public"."permessi"("codice") ON DELETE cascade ON UPDATE cascade;--> statement-breakpoint
ALTER TABLE "sessioni" ADD CONSTRAINT "sessioni_utente_id_utenti_id_fk" FOREIGN KEY ("utente_id") REFERENCES "public"."utenti"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "utenti" ADD CONSTRAINT "utenti_ruolo_id_ruoli_id_fk" FOREIGN KEY ("ruolo_id") REFERENCES "public"."ruoli"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "allegati" ADD CONSTRAINT "allegati_caricato_da_id_utenti_id_fk" FOREIGN KEY ("caricato_da_id") REFERENCES "public"."utenti"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "clienti" ADD CONSTRAINT "clienti_commerciale_id_utenti_id_fk" FOREIGN KEY ("commerciale_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "clienti" ADD CONSTRAINT "clienti_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "clienti" ADD CONSTRAINT "clienti_updated_by_id_utenti_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "commesse" ADD CONSTRAINT "commesse_cliente_id_clienti_id_fk" FOREIGN KEY ("cliente_id") REFERENCES "public"."clienti"("id") ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "commesse" ADD CONSTRAINT "commesse_responsabile_id_utenti_id_fk" FOREIGN KEY ("responsabile_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "commesse" ADD CONSTRAINT "commesse_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "commesse" ADD CONSTRAINT "commesse_updated_by_id_utenti_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contatti" ADD CONSTRAINT "contatti_cliente_id_clienti_id_fk" FOREIGN KEY ("cliente_id") REFERENCES "public"."clienti"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contatti" ADD CONSTRAINT "contatti_sede_id_sedi_id_fk" FOREIGN KEY ("sede_id") REFERENCES "public"."sedi"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contatti" ADD CONSTRAINT "contatti_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "contatti" ADD CONSTRAINT "contatti_updated_by_id_utenti_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sedi" ADD CONSTRAINT "sedi_cliente_id_clienti_id_fk" FOREIGN KEY ("cliente_id") REFERENCES "public"."clienti"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sedi" ADD CONSTRAINT "sedi_created_by_id_utenti_id_fk" FOREIGN KEY ("created_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "sedi" ADD CONSTRAINT "sedi_updated_by_id_utenti_id_fk" FOREIGN KEY ("updated_by_id") REFERENCES "public"."utenti"("id") ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "audit_entita_idx" ON "audit_log" USING btree ("entita","entita_id");--> statement-breakpoint
CREATE INDEX "audit_utente_idx" ON "audit_log" USING btree ("utente_id");--> statement-breakpoint
CREATE INDEX "audit_data_idx" ON "audit_log" USING btree ("created_at");--> statement-breakpoint
CREATE INDEX "sessioni_utente_idx" ON "sessioni" USING btree ("utente_id");--> statement-breakpoint
CREATE INDEX "sessioni_famiglia_idx" ON "sessioni" USING btree ("famiglia_id");--> statement-breakpoint
CREATE UNIQUE INDEX "utenti_email_unique" ON "utenti" USING btree (lower("email"));--> statement-breakpoint
CREATE INDEX "utenti_ruolo_idx" ON "utenti" USING btree ("ruolo_id");--> statement-breakpoint
CREATE INDEX "allegati_entita_idx" ON "allegati" USING btree ("entita","entita_id");--> statement-breakpoint
CREATE UNIQUE INDEX "clienti_piva_unique" ON "clienti" USING btree ("partita_iva") WHERE "clienti"."deleted_at" IS NULL AND "clienti"."partita_iva" IS NOT NULL;--> statement-breakpoint
CREATE INDEX "clienti_ragione_sociale_trgm_idx" ON "clienti" USING gin ("ragione_sociale" gin_trgm_ops);--> statement-breakpoint
CREATE INDEX "clienti_commerciale_idx" ON "clienti" USING btree ("commerciale_id");--> statement-breakpoint
CREATE INDEX "commesse_cliente_idx" ON "commesse" USING btree ("cliente_id");--> statement-breakpoint
CREATE INDEX "commesse_stato_idx" ON "commesse" USING btree ("stato");--> statement-breakpoint
CREATE INDEX "commesse_responsabile_idx" ON "commesse" USING btree ("responsabile_id");--> statement-breakpoint
CREATE INDEX "contatti_cliente_idx" ON "contatti" USING btree ("cliente_id");--> statement-breakpoint
CREATE UNIQUE INDEX "contatti_principale_unique" ON "contatti" USING btree ("cliente_id") WHERE "contatti"."principale" = true;--> statement-breakpoint
CREATE INDEX "sedi_cliente_idx" ON "sedi" USING btree ("cliente_id");--> statement-breakpoint
CREATE UNIQUE INDEX "sedi_legale_unique" ON "sedi" USING btree ("cliente_id") WHERE "sedi"."tipo" = 'legale';