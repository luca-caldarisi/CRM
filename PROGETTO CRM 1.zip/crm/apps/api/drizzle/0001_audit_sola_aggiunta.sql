-- =====================================================================================
-- Rende l'audit log "in sola aggiunta": nessuno può modificare o cancellare le voci,
-- nemmeno l'applicazione in caso di bug o di credenziali del database compromesse
-- (per aggirare il blocco servirebbe un amministratore del DB che rimuove il trigger).
-- =====================================================================================

-- Funzione eseguita dal trigger: interrompe l'operazione con un errore
CREATE OR REPLACE FUNCTION audit_log_blocca_modifiche() RETURNS trigger AS $$
BEGIN
  -- Solleva un'eccezione che annulla l'intera transazione
  RAISE EXCEPTION 'audit_log è in sola aggiunta: % non consentito', TG_OP;
END;
$$ LANGUAGE plpgsql;
--> statement-breakpoint

-- Trigger che intercetta UPDATE e DELETE su ogni riga dell'audit log
CREATE TRIGGER audit_log_sola_aggiunta
  BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION audit_log_blocca_modifiche();
--> statement-breakpoint

-- Blocca anche TRUNCATE, che non passa dai trigger di riga
CREATE TRIGGER audit_log_no_truncate
  BEFORE TRUNCATE ON audit_log
  FOR EACH STATEMENT EXECUTE FUNCTION audit_log_blocca_modifiche();
