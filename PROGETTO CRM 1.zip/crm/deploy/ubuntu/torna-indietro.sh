#!/usr/bin/env bash
# =====================================================================================
# RITORNO A UNA VERSIONE PRECEDENTE (comando: sudo crm-torna-indietro [nome-versione])
# -------------------------------------------------------------------------------------
# Senza argomenti riattiva la versione installata subito prima di quella attuale.
# ATTENZIONE: non annulla le migrazioni del database. Se la nuova versione ha modificato
# le tabelle in modo incompatibile, ripristinare anche il backup "prima-di-<versione>".
# =====================================================================================

# Interrompe al primo errore
set -euo pipefail

# Cartella reale dello script
CARTELLA_SCRIPT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
# Carica percorsi e funzioni comuni
# shellcheck source=comune.sh
source "$CARTELLA_SCRIPT/comune.sh"

# Serve root
richiedi_root

# Versione attiva
ATTUALE="$(readlink -f "$DIR_CORRENTE" 2>/dev/null || true)"
# Versioni installate con un'API (esclude la pagina provvisoria), dalla più recente
# (esclude anche le versioni marcate come fallite da crm-aggiorna)
# shellcheck disable=SC2011
mapfile -t VERSIONI < <(ls -1dt "$DIR_RELEASE"/*/api 2>/dev/null | xargs -r -n1 dirname | grep -v -- '-fallita$')

# Mostra l'elenco
echo "Versioni installate (dalla più recente):"
for v in "${VERSIONI[@]}"; do
  # Segna quella attiva
  [[ "$v" == "$ATTUALE" ]] && echo "  * $(basename "$v")  (attiva)" || echo "    $(basename "$v")"
done

if [[ -n "${1:-}" ]]; then
  # Versione indicata esplicitamente
  DESTINAZIONE="$DIR_RELEASE/$1"
else
  # Cerca la versione successiva a quella attiva nell'elenco (cioè la precedente in ordine di tempo)
  DESTINAZIONE=""
  for ((i = 0; i < ${#VERSIONI[@]} - 1; i++)); do
    [[ "${VERSIONI[$i]}" == "$ATTUALE" ]] && DESTINAZIONE="${VERSIONI[$((i + 1))]}" && break
  done
fi

# Controlli
[[ -n "$DESTINAZIONE" && -d "$DESTINAZIONE/api" ]] || errore "nessuna versione precedente disponibile"
[[ "$DESTINAZIONE" != "$ATTUALE" ]] || errore "la versione indicata è già attiva"

# Conferma dell'operatore
read -rp "Riattivare $(basename "$DESTINAZIONE")? Scrivere SI per confermare: " RISPOSTA
[[ "$RISPOSTA" == "SI" ]] || errore "operazione annullata"

log "Attivazione di $(basename "$DESTINAZIONE")"
# Cambia la versione attiva
attiva_versione "$DESTINAZIONE"
# Riavvia l'API
systemctl restart crm-api
# Verifica
attendi_api 60 || errore "l'API non risponde: controllare con 'journalctl -u crm-api -n 100'"
log "Versione $(basename "$DESTINAZIONE") attiva"
