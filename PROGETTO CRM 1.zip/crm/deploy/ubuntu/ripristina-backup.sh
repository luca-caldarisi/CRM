#!/usr/bin/env bash
# =====================================================================================
# RIPRISTINO di un backup (comando: sudo crm-ripristina-backup <file.dump> [file-allegati.tar.gz])
# -------------------------------------------------------------------------------------
# Sostituisce il database (e facoltativamente gli allegati) con quelli del backup indicato.
# Prima di sovrascrivere esegue un backup di sicurezza dello stato attuale.
# Da provare una volta al mese (idealmente su una VM di prova) per essere certi che i backup funzionino.
# =====================================================================================

# Interrompe al primo errore
set -euo pipefail

# Cartella reale dello script
CARTELLA_SCRIPT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
# Carica percorsi e funzioni comuni
# shellcheck source=comune.sh
source "$CARTELLA_SCRIPT/comune.sh"

# Serve root
richiedi_root

# File del database (obbligatorio) e degli allegati (facoltativo)
FILE_DB="$(readlink -f "${1:-}")" || true
FILE_ALLEGATI="${2:-}"
# Controlli sui file
[[ -n "${1:-}" && -f "$FILE_DB" ]] || errore "uso: crm-ripristina-backup <file.dump> [file-allegati.tar.gz]"
[[ -z "$FILE_ALLEGATI" || -f "$FILE_ALLEGATI" ]] || errore "file degli allegati non trovato: $FILE_ALLEGATI"
# Verifica preliminare che il dump sia leggibile
runuser -u postgres -- pg_restore --list <"$FILE_DB" >/dev/null || errore "il file $FILE_DB non è un backup valido"

# Conferma esplicita: l'operazione sovrascrive i dati attuali
avviso "il database attuale verrà SOSTITUITO con il contenuto di $(basename "$FILE_DB")"
[[ -n "$FILE_ALLEGATI" ]] && avviso "anche gli allegati verranno sostituiti con $(basename "$FILE_ALLEGATI")"
read -rp "Scrivere RIPRISTINA per confermare: " RISPOSTA
[[ "$RISPOSTA" == "RIPRISTINA" ]] || errore "operazione annullata"

log "Backup di sicurezza dello stato attuale"
# Permette di annullare il ripristino se si è scelto il file sbagliato
"$CARTELLA_SCRIPT/backup.sh" "prima-del-ripristino"

log "Arresto dell'API"
# Nessuna scrittura durante il ripristino
systemctl stop crm-api
# Evita avvisi sulla cartella corrente
cd /

log "Ripristino database"
# Chiude eventuali connessioni rimaste e ricrea il database vuoto
runuser -u postgres -- dropdb --if-exists --force crm
runuser -u postgres -- createdb -O "$CRM_UTENTE" crm
# Ripristina: --role fa sì che tutti gli oggetti appartengano all'utente crm, come in origine
runuser -u postgres -- pg_restore --dbname=crm --no-owner --role="$CRM_UTENTE" --exit-on-error <"$FILE_DB"

if [[ -n "$FILE_ALLEGATI" ]]; then
  log "Ripristino allegati"
  # Mette da parte la cartella attuale invece di cancellarla
  mv "$DIR_DATI/allegati" "$DIR_DATI/allegati.prima-del-ripristino-$(date +%Y%m%d-%H%M%S)"
  # Estrae l'archivio (contiene la cartella "allegati")
  tar -xzf "$FILE_ALLEGATI" -C "$DIR_DATI"
  # Ripristina proprietario e permessi
  chown -R "$CRM_UTENTE:$CRM_UTENTE" "$DIR_DATI/allegati"
  chmod 0750 "$DIR_DATI/allegati"
fi

log "Riavvio dell'API"
# Riavvia il servizio
systemctl start crm-api
# Verifica
attendi_api 60 || errore "l'API non risponde dopo il ripristino: controllare con 'journalctl -u crm-api -n 100'"
log "Ripristino completato"
