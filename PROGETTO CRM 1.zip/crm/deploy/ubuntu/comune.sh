#!/usr/bin/env bash
# =====================================================================================
# Funzioni e percorsi comuni a tutti gli script di gestione del CRM su Ubuntu
# Non si esegue da solo: viene incluso dagli altri script con "source".
# =====================================================================================

# Le variabili sono usate dagli script che includono questo file
# shellcheck disable=SC2034

# Utente di sistema con cui gira l'API (senza shell e senza password)
CRM_UTENTE="crm"
# Cartella del programma: contiene le versioni installate e il collegamento a quella attiva
DIR_BASE="/opt/crm"
# Cartella delle versioni installate (una sottocartella per ogni aggiornamento)
DIR_RELEASE="$DIR_BASE/releases"
# Collegamento simbolico alla versione in uso
DIR_CORRENTE="$DIR_BASE/current"
# Cartella della configurazione riservata (segreti)
DIR_CONF="/etc/crm"
# File con le variabili d'ambiente dell'API
FILE_ENV="$DIR_CONF/crm.env"
# Cartella dei certificati HTTPS
DIR_CERT="$DIR_CONF/certs"
# Cartella dei dati (allegati)
DIR_DATI="/var/lib/crm"
# Cartella dei backup locali
DIR_BACKUP="/var/backups/crm"
# Indirizzo locale del controllo di salute dell'API
URL_SALUTE="http://127.0.0.1:3000/api/v1/salute"

# Stampa un titolo di fase in blu
log() {
  echo -e "\n\033[1;34m==> $*\033[0m"
}

# Stampa un avviso in giallo
avviso() {
  echo -e "\033[1;33mATTENZIONE: $*\033[0m"
}

# Stampa un errore in rosso e termina lo script
errore() {
  echo -e "\033[1;31mERRORE: $*\033[0m" >&2
  exit 1
}

# Verifica che lo script sia eseguito come root (con sudo)
richiedi_root() {
  [[ $EUID -eq 0 ]] || errore "eseguire lo script con sudo"
}

# Esegue un comando come utente "crm" con le variabili di /etc/crm/crm.env, dalla cartella indicata
# Uso: esegui_come_crm /cartella comando argomenti...
esegui_come_crm() {
  # Cartella di lavoro
  local cartella="$1"
  # Rimuove il primo argomento: restano comando e argomenti
  shift
  # Sottoshell: le variabili caricate non restano nello script chiamante
  (
    # "set -a" esporta automaticamente tutte le variabili lette dal file
    set -a
    # Carica le variabili d'ambiente di produzione
    # shellcheck disable=SC1090
    source "$FILE_ENV"
    # Disattiva l'esportazione automatica
    set +a
    # Entra nella cartella
    cd "$cartella" || exit 1
    # runuser -m mantiene le variabili d'ambiente cambiando utente
    runuser -u "$CRM_UTENTE" -m -- "$@"
  )
}

# Attende che l'API risponda al controllo di salute (massimo N secondi); restituisce 0 se ok
attendi_api() {
  # Secondi massimi di attesa (predefinito 30)
  local secondi="${1:-30}"
  # Un tentativo al secondo
  for ((i = 0; i < secondi; i++)); do
    # curl -f fallisce se la risposta non è 2xx
    if curl -fsS --max-time 2 "$URL_SALUTE" >/dev/null 2>&1; then
      return 0
    fi
    # Attende un secondo prima di riprovare
    sleep 1
  done
  # Tempo scaduto
  return 1
}

# Punta il collegamento "current" alla versione indicata in modo atomico
# (prima crea un collegamento temporaneo, poi lo rinomina: non esiste mai un istante senza versione attiva)
attiva_versione() {
  # Cartella della versione da attivare
  local versione="$1"
  # Collegamento temporaneo
  ln -sfn "$versione" "$DIR_BASE/current.nuovo"
  # Sostituzione atomica
  mv -Tf "$DIR_BASE/current.nuovo" "$DIR_CORRENTE"
}
