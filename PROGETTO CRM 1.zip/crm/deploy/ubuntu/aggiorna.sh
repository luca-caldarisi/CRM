#!/usr/bin/env bash
# =====================================================================================
# INSTALLAZIONE / AGGIORNAMENTO del codice del CRM (comando: sudo crm-aggiorna <cartella-sorgente>)
# -------------------------------------------------------------------------------------
# 1. compila il progetto in una cartella temporanea (il sorgente non viene toccato)
# 2. prepara una nuova versione in /opt/crm/releases/<data-commit>
# 3. esegue un backup del database
# 4. applica le migrazioni e il seed
# 5. attiva la nuova versione e riavvia l'API
# 6. se l'API non risponde entro 60 secondi, torna automaticamente alla versione precedente
# =====================================================================================

# Interrompe al primo errore
set -euo pipefail

# Cartella reale dello script (anche quando è richiamato tramite il collegamento /usr/local/sbin/crm-aggiorna)
CARTELLA_SCRIPT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
# Carica percorsi e funzioni comuni
# shellcheck source=comune.sh
source "$CARTELLA_SCRIPT/comune.sh"

# Serve root
richiedi_root
# Deve esistere la configurazione creata da installa.sh
[[ -f "$FILE_ENV" ]] || errore "$FILE_ENV non trovato: eseguire prima deploy/ubuntu/installa.sh"

# Cartella del codice sorgente (primo argomento, predefinita /opt/crm/sorgente)
SORGENTE="$(readlink -f "${1:-$DIR_BASE/sorgente}")"
# Deve essere la radice del progetto
[[ -f "$SORGENTE/pnpm-workspace.yaml" ]] || errore "$SORGENTE non contiene il progetto CRM"

# -------------------------------------------------------------------------------------
# Nome della versione: data e ora, più il commit git se disponibile
# -------------------------------------------------------------------------------------
VERSIONE="$(date +%Y%m%d-%H%M%S)"
# safe.directory=* evita l'errore di git quando la cartella appartiene a un altro utente
if COMMIT="$(git -c safe.directory='*' -C "$SORGENTE" rev-parse --short HEAD 2>/dev/null)"; then
  VERSIONE="$VERSIONE-$COMMIT"
fi
# Cartella della nuova versione
RELEASE="$DIR_RELEASE/$VERSIONE"
# Versione attualmente attiva (vuota al primo aggiornamento)
PRECEDENTE="$(readlink -f "$DIR_CORRENTE" 2>/dev/null || true)"

# -------------------------------------------------------------------------------------
# 1. Compilazione in una cartella temporanea
# -------------------------------------------------------------------------------------
log "Compilazione della versione $VERSIONE"
# Cartella temporanea di build
BUILD="$(mktemp -d /tmp/crm-build.XXXXXX)"
# Alla fine dello script (anche in caso di errore) la cartella temporanea viene eliminata
trap 'rm -rf "$BUILD"' EXIT
# Copia il sorgente escludendo dipendenze, compilati, git e file con segreti di sviluppo
rsync -a --exclude node_modules --exclude dist --exclude .git --exclude .env --exclude 'apps/api/storage' "$SORGENTE"/ "$BUILD"/
# Entra nella cartella di build
cd "$BUILD"
# Versione di pnpm richiesta dal progetto
VERSIONE_PNPM="$(node -p "require('./package.json').packageManager.split('@')[1]")"
# Installa la versione corretta di pnpm se necessario
[[ "$(pnpm --version 2>/dev/null || true)" == "$VERSIONE_PNPM" ]] || npm install -g "pnpm@$VERSIONE_PNPM"
# Installa le dipendenze esattamente come nel lockfile (fallisce se il lockfile non è aggiornato)
pnpm install --frozen-lockfile
# Compila libreria condivisa, API e frontend
pnpm --filter @crm/shared build
pnpm --filter @crm/api build
pnpm --filter @crm/web build

# -------------------------------------------------------------------------------------
# 2. Preparazione della nuova versione
# -------------------------------------------------------------------------------------
log "Preparazione di $RELEASE"
# Copia l'API con le sole dipendenze di produzione (senza strumenti di sviluppo)
pnpm --filter @crm/api deploy --prod --legacy "$RELEASE/api"
# Aggiunge codice compilato e migrazioni SQL
cp -r apps/api/dist apps/api/drizzle "$RELEASE/api/"
# Rimuove dalla versione i sorgenti TypeScript e i test (non servono in produzione)
rm -rf "$RELEASE/api/src" "$RELEASE/api/test"
# Copia i file statici del frontend
cp -r apps/web/dist "$RELEASE/web"
# Annota il nome della versione
echo "$VERSIONE" >"$RELEASE/VERSIONE"
# Permessi dell'API: root può modificare, il gruppo crm solo leggere (l'API non può alterare il proprio codice)
chown -R root:"$CRM_UTENTE" "$RELEASE/api"
chmod -R u=rwX,g=rX,o= "$RELEASE/api"
# Permessi del frontend: leggibile da Nginx
chown -R root:root "$RELEASE/web" "$RELEASE/VERSIONE"
chmod -R u=rwX,go=rX "$RELEASE/web"
chmod 0755 "$RELEASE"

# -------------------------------------------------------------------------------------
# 3. Backup prima di modificare il database
# -------------------------------------------------------------------------------------
log "Backup prima dell'aggiornamento"
# Usa lo stesso script del backup notturno con un'etichetta riconoscibile
"$CARTELLA_SCRIPT/backup.sh" "prima-di-$VERSIONE"

# -------------------------------------------------------------------------------------
# 4. Migrazioni e seed (eseguiti come utente crm con la configurazione di produzione)
# -------------------------------------------------------------------------------------
log "Migrazioni del database"
# Applica le migrazioni non ancora eseguite
esegui_come_crm "$RELEASE/api" node dist/src/database/migra.js
# Sincronizza permessi e ruoli, crea l'Admin se manca
esegui_come_crm "$RELEASE/api" node dist/src/database/seed.js

# -------------------------------------------------------------------------------------
# 5. Attivazione e riavvio
# -------------------------------------------------------------------------------------
log "Attivazione della nuova versione"
# Punta "current" alla nuova versione
attiva_versione "$RELEASE"
# Riavvia l'API (Nginx legge il frontend direttamente dalla nuova cartella)
systemctl restart crm-api

# -------------------------------------------------------------------------------------
# 6. Verifica e ritorno automatico alla versione precedente
# -------------------------------------------------------------------------------------
log "Verifica dell'API"
if attendi_api 60; then
  echo "API attiva: versione $VERSIONE"
else
  # L'API non risponde
  avviso "l'API non risponde dopo 60 secondi"
  # Ultime righe del log per capire il problema
  journalctl -u crm-api -n 30 --no-pager || true
  # Se esiste una versione precedente valida la riattiva
  if [[ -n "$PRECEDENTE" && -d "$PRECEDENTE/api" ]]; then
    attiva_versione "$PRECEDENTE"
    systemctl restart crm-api
    # Rinomina la versione difettosa: resta per l'analisi ma non verrà mai proposta da crm-torna-indietro
    mv "$RELEASE" "$RELEASE-fallita"
    errore "ripristinata la versione precedente ($(basename "$PRECEDENTE")). Le migrazioni già applicate NON sono state annullate: se necessario ripristinare il backup con crm-ripristina-backup."
  fi
  # Primo aggiornamento: nessuna versione a cui tornare
  errore "installazione non riuscita: controllare con 'journalctl -u crm-api -n 100'"
fi

# -------------------------------------------------------------------------------------
# 7. Pulizia delle versioni vecchie (ne restano 5, mai quella attiva)
# -------------------------------------------------------------------------------------
log "Pulizia versioni vecchie"
# Elenca le versioni dalla più recente, salta le prime 5 ed elimina le altre
ls -1dt "$DIR_RELEASE"/*/ | tail -n +6 | while read -r vecchia; do
  # Non elimina mai la versione attiva
  [[ "$(readlink -f "$vecchia")" == "$(readlink -f "$DIR_CORRENTE")" ]] && continue
  # Elimina la cartella
  rm -rf "$vecchia"
  echo "Rimossa $(basename "$vecchia")"
done

log "Aggiornamento completato"
