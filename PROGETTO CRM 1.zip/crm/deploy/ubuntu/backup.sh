#!/usr/bin/env bash
# =====================================================================================
# BACKUP del CRM: database + allegati (comando: sudo crm-backup [etichetta])
# -------------------------------------------------------------------------------------
# Eseguito ogni notte alle 02:00 dal timer systemd crm-backup.timer e prima di ogni aggiornamento.
# I file vanno in /var/backups/crm e restano 14 giorni.
# Copia fuori dal server: impostare BACKUP_REMOTO in /etc/crm/backup.env
#   (es. BACKUP_REMOTO=backup@nas.azienda.local:/volume1/backup/crm/ con chiave SSH)
# Regola 3-2-1: il backup che resta solo su questo server NON protegge da guasti del server.
# =====================================================================================

# Interrompe al primo errore
set -euo pipefail

# Cartella reale dello script
CARTELLA_SCRIPT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
# Carica percorsi e funzioni comuni
# shellcheck source=comune.sh
source "$CARTELLA_SCRIPT/comune.sh"

# Serve root
richiedi_root

# Impostazioni facoltative (BACKUP_REMOTO, RSYNC_RSH): caricate anche quando lo script è lanciato a mano
if [[ -f "$DIR_CONF/backup.env" ]]; then
  # Esporta le variabili lette dal file
  set -a
  # shellcheck disable=SC1091
  source "$DIR_CONF/backup.env"
  # Disattiva l'esportazione automatica
  set +a
fi

# Etichetta nel nome del file (predefinita "notturno")
ETICHETTA="${1:-notturno}"
# Giorni di conservazione (modificabile con la variabile GIORNI_CONSERVAZIONE)
GIORNI="${GIORNI_CONSERVAZIONE:-14}"
# Data e ora nel nome dei file
DATA="$(date +%Y%m%d-%H%M%S)"
# Nomi dei file
FILE_DB="$DIR_BACKUP/crm-db-$DATA-$ETICHETTA.dump"
FILE_ALLEGATI="$DIR_BACKUP/crm-allegati-$DATA-$ETICHETTA.tar.gz"

# I file creati sono leggibili solo da root
umask 077
# Crea la cartella se manca
install -d -m 0700 "$DIR_BACKUP"
# Evita avvisi di postgres sulla cartella corrente non accessibile
cd /

log "Backup database"
# Dump in formato compresso di PostgreSQL, eseguito dall'amministratore del database (nessuna password necessaria)
runuser -u postgres -- pg_dump --format=custom --dbname=crm >"$FILE_DB"
# Verifica che il file sia leggibile da pg_restore (un backup non verificato non è un backup)
runuser -u postgres -- pg_restore --list <"$FILE_DB" >/dev/null || errore "il file di backup del database è danneggiato"
echo "$FILE_DB ($(du -h "$FILE_DB" | cut -f1))"

log "Backup allegati"
# Archivio compresso della cartella degli allegati
tar -czf "$FILE_ALLEGATI" -C "$DIR_DATI" allegati
# Verifica che l'archivio sia integro
tar -tzf "$FILE_ALLEGATI" >/dev/null || errore "l'archivio degli allegati è danneggiato"
echo "$FILE_ALLEGATI ($(du -h "$FILE_ALLEGATI" | cut -f1))"

log "Pulizia backup più vecchi di $GIORNI giorni"
# Elimina i file scaduti e ne stampa il nome
find "$DIR_BACKUP" -maxdepth 1 -name 'crm-*' -type f -mtime +"$GIORNI" -print -delete

# Copia remota facoltativa
if [[ -n "${BACKUP_REMOTO:-}" ]]; then
  log "Copia su $BACKUP_REMOTO"
  # rsync copia solo i file nuovi; senza --delete i backup remoti non vengono mai cancellati da qui
  rsync -a "$DIR_BACKUP"/ "$BACKUP_REMOTO" || errore "copia remota non riuscita"
else
  avviso "BACKUP_REMOTO non impostato: i backup esistono solo su questo server"
fi

log "Backup completato"
