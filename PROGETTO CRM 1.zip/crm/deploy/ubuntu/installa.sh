#!/usr/bin/env bash
# =====================================================================================
# INSTALLAZIONE INIZIALE del CRM su Ubuntu Server 24.04 LTS
# -------------------------------------------------------------------------------------
# Prepara il server: pacchetti, Node.js, PostgreSQL, utente di sistema, segreti,
# certificato HTTPS, Nginx, servizi systemd, backup notturno, firewall.
# Si può rieseguire senza danni: salta i passaggi già fatti e non sovrascrive i segreti.
#
# Uso (dalla cartella del progetto copiata sul server):
#   sudo DOMINIO=crm.azienda.local ADMIN_EMAIL=admin@azienda.it RETE_LAN=192.168.1.0/24 ./deploy/ubuntu/installa.sh
# Poi installare il codice con:
#   sudo crm-aggiorna /opt/crm/sorgente
# =====================================================================================

# Interrompe lo script al primo errore, su variabili non definite e negli errori delle pipe
set -euo pipefail

# Cartella in cui si trova questo script (anche se richiamato da un'altra cartella)
CARTELLA_SCRIPT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
# Radice del progetto (due livelli sopra deploy/ubuntu)
RADICE_PROGETTO="$(cd "$CARTELLA_SCRIPT/../.." && pwd)"
# Carica percorsi e funzioni comuni
# shellcheck source=comune.sh
source "$CARTELLA_SCRIPT/comune.sh"

# -------------------------------------------------------------------------------------
# 0. Controlli preliminari e parametri
# -------------------------------------------------------------------------------------

# Serve root
richiedi_root
# Legge le informazioni sulla distribuzione
# shellcheck disable=SC1091
source /etc/os-release
# Lo script è scritto e verificato per Ubuntu 24.04
[[ "$ID" == "ubuntu" && "$VERSION_ID" == "24.04" ]] || errore "sistema non supportato ($PRETTY_NAME): serve Ubuntu Server 24.04 LTS"

# Nome con cui gli utenti apriranno il CRM (se non passato come variabile lo chiede)
DOMINIO="${DOMINIO:-}"
[[ -n "$DOMINIO" ]] || read -rp "Nome del server (es. crm.azienda.local): " DOMINIO
# Controllo del formato del nome (lettere, numeri, punti e trattini)
[[ "$DOMINIO" =~ ^[A-Za-z0-9.-]+$ ]] || errore "nome del server non valido: $DOMINIO"

# Email del primo amministratore (usata solo se il file di configurazione non esiste ancora)
ADMIN_EMAIL="${ADMIN_EMAIL:-}"
# Reti autorizzate ad aprire il CRM, separate da virgola (vuoto = qualsiasi rete)
RETE_LAN="${RETE_LAN:-}"

# -------------------------------------------------------------------------------------
# 1. Fuso orario e pacchetti di sistema
# -------------------------------------------------------------------------------------
log "Fuso orario Europe/Rome"
# Le date del registro attività e dei filtri usano l'ora italiana
timedatectl set-timezone Europe/Rome || avviso "impossibile impostare il fuso orario"

log "Installazione pacchetti di sistema"
# Nessuna domanda interattiva durante l'installazione
export DEBIAN_FRONTEND=noninteractive
# Aggiorna l'elenco dei pacchetti
apt-get update -q
# Installa: certificati, strumenti di rete, Nginx, PostgreSQL 16 (versione ufficiale di Ubuntu 24.04),
# firewall, aggiornamenti automatici di sicurezza, OpenSSL, rsync e git
apt-get install -y -q ca-certificates curl gnupg nginx postgresql postgresql-contrib ufw unattended-upgrades openssl rsync git

# -------------------------------------------------------------------------------------
# 2. Node.js 24 LTS (Ubuntu 24.04 include solo Node 18, troppo vecchio)
# -------------------------------------------------------------------------------------
log "Node.js"
# Versione principale installata (0 se Node non c'è)
VERSIONE_NODE="$(command -v node >/dev/null && node -p 'process.versions.node.split(".")[0]' || echo 0)"
# Installa dal repository ufficiale NodeSource solo se manca o è più vecchio della 22
if (( VERSIONE_NODE < 22 )); then
  # Cartella delle chiavi dei repository
  install -d -m 0755 /etc/apt/keyrings
  # Scarica la chiave di firma del repository NodeSource
  curl -fsSL https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key | gpg --dearmor --yes -o /etc/apt/keyrings/nodesource.gpg
  # Aggiunge il repository di Node.js 24, accettando solo pacchetti firmati con quella chiave
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_24.x nodistro main" >/etc/apt/sources.list.d/nodesource.list
  # Aggiorna e installa
  apt-get update -q
  apt-get install -y -q nodejs
fi
# Mostra la versione in uso
echo "Node.js $(node -v)"

# Versione di pnpm richiesta dal progetto (campo packageManager di package.json)
VERSIONE_PNPM="$(node -p "require('$RADICE_PROGETTO/package.json').packageManager.split('@')[1]")"
# Installa pnpm alla versione esatta se manca o è diversa
if [[ "$(pnpm --version 2>/dev/null || true)" != "$VERSIONE_PNPM" ]]; then
  npm install -g "pnpm@$VERSIONE_PNPM"
fi
# Mostra la versione in uso
echo "pnpm $(pnpm --version)"

# -------------------------------------------------------------------------------------
# 3. Utente di sistema e cartelle
# -------------------------------------------------------------------------------------
log "Utente di sistema e cartelle"
# Crea l'utente "crm" senza shell di login e senza password (serve solo a far girare l'API)
id -u "$CRM_UTENTE" >/dev/null 2>&1 || useradd --system --home-dir "$DIR_BASE" --no-create-home --shell /usr/sbin/nologin "$CRM_UTENTE"
# Programma: leggibile da tutti (Nginx deve leggere il frontend), modificabile solo da root
install -d -o root -g root -m 0755 "$DIR_BASE" "$DIR_RELEASE"
# Configurazione: leggibile solo da root e dal gruppo crm
install -d -o root -g "$CRM_UTENTE" -m 0750 "$DIR_CONF"
# Certificati: solo root (Nginx li legge all'avvio come root)
install -d -o root -g root -m 0700 "$DIR_CERT"
# Dati: l'unica cartella in cui l'API può scrivere
install -d -o "$CRM_UTENTE" -g "$CRM_UTENTE" -m 0750 "$DIR_DATI" "$DIR_DATI/allegati"
# Backup: solo root
install -d -o root -g root -m 0700 "$DIR_BACKUP"

# -------------------------------------------------------------------------------------
# 4. PostgreSQL e segreti
# -------------------------------------------------------------------------------------
log "PostgreSQL"
# Avvia PostgreSQL e lo abilita all'avvio del server
systemctl enable --now postgresql
# Per impostazione predefinita PostgreSQL ascolta solo su localhost: non è raggiungibile dalla rete

# Il file dei segreti viene creato una sola volta: rieseguendo lo script non cambia nulla
if [[ ! -f "$FILE_ENV" ]]; then
  # L'email dell'amministratore è necessaria per il primo avvio
  [[ -n "$ADMIN_EMAIL" ]] || read -rp "Email del primo amministratore: " ADMIN_EMAIL
  # Controllo minimo del formato
  [[ "$ADMIN_EMAIL" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]] || errore "email non valida: $ADMIN_EMAIL"
  # Password del database: 48 caratteri esadecimali casuali
  PASSWORD_DB="$(openssl rand -hex 24)"
  # Segreto per firmare i token: 64 caratteri esadecimali casuali
  SEGRETO_JWT="$(openssl rand -hex 32)"
  # Password iniziale dell'amministratore (da cambiare al primo accesso)
  PASSWORD_ADMIN="$(openssl rand -hex 4)-$(openssl rand -hex 4)-$(openssl rand -hex 4)"

  # Crea l'utente del database o, se esiste già, gli assegna la nuova password
  # (i comandi arrivano da stdin: la password non compare nell'elenco dei processi)
  runuser -u postgres -- psql -v ON_ERROR_STOP=1 -q <<SQL
DO \$\$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '$CRM_UTENTE') THEN
    ALTER ROLE $CRM_UTENTE WITH LOGIN PASSWORD '$PASSWORD_DB';
  ELSE
    CREATE ROLE $CRM_UTENTE WITH LOGIN PASSWORD '$PASSWORD_DB';
  END IF;
END
\$\$;
SQL
  # Crea il database se non esiste, di proprietà dell'utente crm
  if ! runuser -u postgres -- psql -tAc "SELECT 1 FROM pg_database WHERE datname = 'crm'" | grep -q 1; then
    runuser -u postgres -- createdb -O "$CRM_UTENTE" crm
  fi

  log "Creazione di $FILE_ENV"
  # I file creati da qui in poi non sono leggibili dagli altri utenti
  umask 027
  # Scrive la configurazione di produzione
  cat >"$FILE_ENV" <<EOF
# =====================================================================================
# Configurazione di produzione del CRM (generata da installa.sh il $(date '+%d/%m/%Y %H:%M'))
# Contiene SEGRETI: leggibile solo da root e dal gruppo crm. Non copiarlo via email o chat.
# Dopo una modifica: sudo systemctl restart crm-api
# =====================================================================================
NODE_ENV=production
HOST=127.0.0.1
PORT=3000
DATABASE_URL=postgres://$CRM_UTENTE:$PASSWORD_DB@127.0.0.1:5432/crm
JWT_SECRET=$SEGRETO_JWT
JWT_ACCESS_TTL_MIN=15
REFRESH_TTL_GIORNI=7
APP_ORIGIN=https://$DOMINIO
COOKIE_SECURE=true
TRUST_PROXY=1
UPLOAD_DIR=$DIR_DATI/allegati
LOG_LEVEL=info
LOGIN_RATE_LIMIT=10
# Primo amministratore: usato solo se nel database non esiste ancora un Admin.
# Dopo il primo accesso si possono cancellare queste due righe.
ADMIN_EMAIL=$ADMIN_EMAIL
ADMIN_PASSWORD_INIZIALE=$PASSWORD_ADMIN
EOF
  # Proprietario root, leggibile dal gruppo crm (l'API), nessun accesso per gli altri
  chown root:"$CRM_UTENTE" "$FILE_ENV"
  chmod 0640 "$FILE_ENV"
  # Ripristina la maschera predefinita
  umask 022
  # Ricorda di mostrare la password alla fine
  MOSTRA_PASSWORD_ADMIN="$PASSWORD_ADMIN"
else
  echo "$FILE_ENV esiste già: segreti invariati"
fi

# -------------------------------------------------------------------------------------
# 5. Certificato HTTPS
# -------------------------------------------------------------------------------------
log "Certificato HTTPS"
# Genera un certificato autofirmato solo se non ne è già presente uno
if [[ ! -f "$DIR_CERT/crm.crt" ]]; then
  # Chiave RSA 2048 bit e certificato valido 2 anni con il nome del server
  openssl req -x509 -nodes -newkey rsa:2048 -days 730 \
    -keyout "$DIR_CERT/crm.key" -out "$DIR_CERT/crm.crt" \
    -subj "/CN=$DOMINIO" -addext "subjectAltName=DNS:$DOMINIO" 2>/dev/null
  # La chiave privata è leggibile solo da root
  chmod 0600 "$DIR_CERT/crm.key"
  # Promemoria: i browser mostreranno un avviso finché non si usa un certificato attendibile
  avviso "creato un certificato AUTOFIRMATO. Sostituire $DIR_CERT/crm.crt e crm.key con un certificato della CA aziendale."
else
  echo "Certificato già presente"
fi

# -------------------------------------------------------------------------------------
# 6. Nginx
# -------------------------------------------------------------------------------------
log "Nginx"
# Header di sicurezza condivisi
install -m 0644 "$CARTELLA_SCRIPT/nginx-sicurezza.conf" /etc/nginx/snippets/crm-sicurezza.conf
# Sito del CRM con il nome del server al posto del segnaposto
sed "s/__DOMINIO__/$DOMINIO/g" "$CARTELLA_SCRIPT/nginx-crm.conf" >/etc/nginx/sites-available/crm
# Abilita il sito
ln -sfn /etc/nginx/sites-available/crm /etc/nginx/sites-enabled/crm
# Disattiva la pagina di benvenuto predefinita di Nginx
rm -f /etc/nginx/sites-enabled/default
# Pagina provvisoria finché non viene installata la prima versione del CRM
if [[ ! -e "$DIR_CORRENTE" ]]; then
  # Cartella provvisoria con un semplice messaggio
  install -d -m 0755 "$DIR_RELEASE/in-attesa/web"
  echo '<!doctype html><meta charset="utf-8"><title>CRM</title><p>CRM in installazione.</p>' >"$DIR_RELEASE/in-attesa/web/index.html"
  # La rende temporaneamente la versione attiva
  attiva_versione "$DIR_RELEASE/in-attesa"
fi
# Verifica la sintassi della configurazione prima di applicarla
nginx -t
# Abilita all'avvio e ricarica la configurazione
systemctl enable nginx
systemctl reload nginx || systemctl restart nginx

# -------------------------------------------------------------------------------------
# 7. Servizi systemd e comandi di gestione
# -------------------------------------------------------------------------------------
log "Servizi systemd"
# Servizio dell'API, backup notturno e relativo timer
install -m 0644 "$CARTELLA_SCRIPT/crm-api.service" "$CARTELLA_SCRIPT/crm-backup.service" "$CARTELLA_SCRIPT/crm-backup.timer" /etc/systemd/system/
# Ricarica le definizioni dei servizi
systemctl daemon-reload
# L'API partirà automaticamente all'avvio del server (verrà avviata dal primo aggiornamento)
systemctl enable crm-api
# Attiva il backup notturno
systemctl enable --now crm-backup.timer

# Copia gli script di gestione in una cartella di sistema
install -d -m 0755 /usr/local/lib/crm
install -m 0755 "$CARTELLA_SCRIPT"/{comune,aggiorna,torna-indietro,backup,ripristina-backup}.sh /usr/local/lib/crm/
# Comandi brevi utilizzabili da qualsiasi cartella
ln -sfn /usr/local/lib/crm/aggiorna.sh /usr/local/sbin/crm-aggiorna
ln -sfn /usr/local/lib/crm/torna-indietro.sh /usr/local/sbin/crm-torna-indietro
ln -sfn /usr/local/lib/crm/backup.sh /usr/local/sbin/crm-backup
ln -sfn /usr/local/lib/crm/ripristina-backup.sh /usr/local/sbin/crm-ripristina-backup

# -------------------------------------------------------------------------------------
# 8. Aggiornamenti automatici di sicurezza
# -------------------------------------------------------------------------------------
log "Aggiornamenti automatici di sicurezza"
# Abilita l'aggiornamento quotidiano dell'elenco pacchetti e l'installazione delle patch di sicurezza
cat >/etc/apt/apt.conf.d/20auto-upgrades <<EOF
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
EOF

# -------------------------------------------------------------------------------------
# 9. Firewall
# -------------------------------------------------------------------------------------
log "Firewall (ufw)"
# SSH sempre consentito, così non si perde l'accesso al server
ufw allow OpenSSH >/dev/null
if [[ -n "$RETE_LAN" ]]; then
  # HTTP/HTTPS consentiti solo dalle reti indicate (LAN e VPN)
  IFS=',' read -ra RETI <<<"$RETE_LAN"
  for rete in "${RETI[@]}"; do
    ufw allow from "$rete" to any port 80,443 proto tcp >/dev/null
  done
else
  # Nessuna rete indicata: HTTP/HTTPS aperti a tutte le reti che raggiungono il server
  avviso "RETE_LAN non impostata: il CRM è raggiungibile da qualsiasi rete arrivi al server"
  ufw allow 'Nginx Full' >/dev/null
fi
# Attiva il firewall (blocca tutto il resto in ingresso)
ufw --force enable >/dev/null
# Mostra le regole
ufw status

# -------------------------------------------------------------------------------------
# Riepilogo
# -------------------------------------------------------------------------------------
log "Installazione di base completata"
echo "Prossimo passo: installare il codice del CRM con"
echo "  sudo crm-aggiorna $RADICE_PROGETTO"
# La password iniziale viene mostrata una sola volta
if [[ -n "${MOSTRA_PASSWORD_ADMIN:-}" ]]; then
  echo
  echo "Primo accesso su https://$DOMINIO"
  echo "  Email:    $ADMIN_EMAIL"
  echo "  Password: $MOSTRA_PASSWORD_ADMIN   (verrà chiesto di cambiarla)"
  echo "La password è salvata anche in $FILE_ENV finché non viene rimossa."
fi
