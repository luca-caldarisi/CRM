# CRM Azienda IT — Architettura tecnica v1

Stato: approvata · Fasi 0, 1 e 5 sviluppate · Aggiornata: 18/09/2026 · Base: `crm-it-specifica-tecnica.pdf` + risposte di Luca

---

## 1. Requisiti confermati

| Tema | Decisione |
|---|---|
| Utenti | 5 all'avvio, 10 entro 2-3 anni. Solo personale interno |
| Installazione | Server aziendale on-premise (hardware già disponibile) |
| Portale clienti / ticket esterni | Fuori dall'MVP. Il modello dati lo prevede già (campo `origine` sugli interventi) |
| Office 365 | Integrazione opzionale in una fase successiva (SSO, invio email, calendario). Priorità alla parte locale |
| Assistenza | Separazione tra **Commesse** e **Interventi**. Le commesse contengono **contratti di assistenza** e **pacchetti ore** |
| Credenziali clienti | Non gestite nel CRM (per ora) |
| Sviluppo | Stack scelto da Claude: il più diffuso e manutenibile |
| Permessi | Utente Admin che configura ruoli e permessi da interfaccia |

---

## 2. Stack tecnologico

| Livello | Tecnologia | Motivo |
|---|---|---|
| Runtime | Node.js 24 LTS (repository NodeSource) | Supporto a lungo termine, un solo linguaggio (TypeScript) su frontend e backend |
| Backend | NestJS + TypeScript | Architettura a moduli adatta a un CRM con molti domini; dependency injection e test semplici; molto diffuso |
| ORM / migrazioni | Drizzle ORM + drizzle-kit | Schema in TypeScript, migrazioni SQL leggibili e versionate, query parametrizzate; supporta nativamente indici parziali e vincoli CHECK; nessun motore binario da scaricare (vedi §2.1) |
| Validazione | Zod (pacchetto condiviso) + nestjs-zod | Gli stessi schemi validano i form nel frontend e le richieste nel backend: nessuna duplicazione |
| Database | PostgreSQL 16 (pacchetto ufficiale Ubuntu 24.04) | Dati fortemente relazionali, transazioni, JSONB per i template, ricerca testuale; aggiornamenti di sicurezza automatici dal sistema, supportato fino al 2028 |
| Code / job | Redis + BullMQ (dalla Fase 3) | Promemoria scadenze, email, generazione PDF in background |
| PDF | Puppeteer (HTML → PDF) nel processo worker | Template HTML/CSS facili da modificare |
| Frontend | React 19 + TypeScript + Vite 7 | SPA interna: niente SEO, niente server rendering da gestire |
| Routing | React Router | Standard di fatto |
| Dati server | TanStack Query | Cache, invalidazioni e stati di caricamento senza codice manuale |
| Tabelle | Componente tabella interno | Ordinamento, filtri e paginazione sono lato server: una libreria dedicata non serve |
| Form | React Hook Form + Zod | Form complessi performanti con validazione condivisa |
| UI | Tailwind CSS + shadcn/ui | Componenti accessibili e aspetto da SaaS professionale |
| Calendario / Kanban | FullCalendar · dnd-kit | Soluzioni mature e diffuse |
| Stato client | Zustand (solo per stato UI globale) | Leggero; Redux non serve |
| Reverse proxy | Nginx | Serve la build del frontend e fa da proxy per `/api` sullo stesso dominio (niente CORS) |
| Installazione | Ubuntu Server 24.04 + systemd | Installazione nativa su VM dedicata, gestita con script (`deploy/ubuntu`): più familiare per la gestione sistemistica aziendale |
| Log | pino (JSON strutturato) | Log leggibili e filtrabili |
| Monorepo | pnpm workspaces | Frontend, backend e pacchetto condiviso in un unico repository |

**Scelte scartate e perché**

- **Next.js:** il CRM è interno e dietro VPN. Il server rendering aggiunge complessità senza benefici.
- **Microservizi:** con 10 utenti basta un monolite modulare, che resta separabile in futuro se servisse.
- **MinIO / S3:** su un solo server per 10 utenti basta una cartella locale (`/var/lib/crm/allegati`). Lo storage è dietro un'interfaccia `StorageService`, quindi passare a S3 in futuro non richiede di cambiare i moduli.
- **GraphQL e WebSocket:** non servono nell'MVP. REST + OpenAPI è sufficiente e le notifiche in-app si aggiornano con un polling leggero ogni 60 secondi.
- **pg_cron:** i job pianificati sono tutti in BullMQ, così c'è un solo punto da monitorare.
- **Docker:** valutato e scartato su scelta di Luca a favore dell'installazione nativa, più vicina agli strumenti già in uso in azienda. Gli svantaggi (aggiornamenti e ritorno alle versioni precedenti manuali) sono compensati dagli script `crm-aggiorna` e `crm-torna-indietro` e dagli snapshot della VM.

### 2.1 Decisioni prese durante lo sviluppo

- **Drizzle al posto di Prisma.** Prisma scarica un motore binario per le migrazioni da un server esterno: complica le installazioni on-premise con rete filtrata e non gestisce nello schema gli indici parziali che servono con il soft delete (es. P.IVA univoca solo tra i clienti non eliminati). Drizzle è TypeScript puro, genera SQL leggibile e supporta questi vincoli direttamente.
- **Major rilasciate da poche settimane escluse.** NestJS 12, TypeScript 7, React Router 8 e TanStack Table 9 sono uscite da poco: si usa l'ultima versione della major precedente, ancora supportata, e si aggiorna quando l'ecosistema è maturo.
- **Redis rimandato alla Fase 3.** Il controllo della versione dei permessi avviene con una lettura per chiave primaria sul database a ogni richiesta (costo trascurabile con 10 utenti); Redis arriverà con BullMQ.
- **Documenti su cartella locale** tramite `StorageService` (sostituibile con S3 senza toccare i moduli).

### 2.2 Revisione del codice (18/09/2026)

Verifica completa: typecheck, 52 test automatici (13 shared + 39 API), build, migrazioni senza differenze con lo schema, giro di tutte le pagine nel browser.

- **Helper comuni** in `common/utils`: `verificaUtenteAttivo` (prima copiata in 4 service) e `oggi()` nel fuso `Europe/Rome` (prima 3 copie basate sul fuso del server).
- **Query in transazione in sequenza** nel dettaglio task: le query parallele sulla stessa connessione sono deprecate da `pg` e verranno rimosse in `pg@9`.
- **Eliminazione cliente** bloccata anche con progetti non conclusi (prima solo con commesse aperte): i progetti sarebbero spariti dagli elenchi restando raggiungibili via URL.
- **Messaggi 404** neutri rispetto al genere ("Commessa inesistente o non accessibile").
- **Frontend:** pagine caricate a richiesta (`React.lazy`) e librerie in chunk separati: il codice applicativo iniziale passa da 835 kB a 117 kB e le librerie restano in cache tra un aggiornamento e l'altro.
- **Select con opzioni caricate dal server** (responsabile, commerciale, commessa, sede, ruolo): l'hook `useAllineaSelect` evita che il form di modifica mostri "— Nessuno —" quando le opzioni arrivano dopo l'apertura.
- **Nuova scheda "Progetti"** nel dettaglio cliente e commessa (componente unico `ElencoProgettiCollegati`), con creazione del progetto già collegata a cliente e commessa.
- **Build del pacchetto condiviso** compatibile con Windows (niente `rm -rf`).

---

## 3. Architettura

```text
             Rete aziendale / VPN
                     │  HTTPS
              ┌──────▼──────┐
              │    Nginx    │  file statici React + proxy /api
              └──────┬──────┘
                     │
        ┌────────────▼────────────┐        ┌──────────────┐
        │  API NestJS (monolite)  │───────▶│   Redis      │
        │  auth · RBAC · moduli   │  code  │  (BullMQ)    │
        └───────┬─────────┬───────┘        └──────┬───────┘
                │         │                       │
         ┌──────▼───┐  ┌──▼────────────┐   ┌──────▼─────────┐
         │PostgreSQL│  │ Volume file   │◀──│ Worker NestJS  │
         │          │◀─│ (allegati/PDF)│   │ promemoria·PDF │
         └──────────┘  └───────────────┘   │ email          │
                                           └────────────────┘
```

API e worker usano la **stessa codebase**, avviata come due servizi systemd distinti (`crm-api` e, dalla Fase 3, `crm-worker`). Così i job pesanti (PDF, email) non rallentano le richieste degli utenti.

---

## 4. Struttura del progetto

```text
crm/
├── apps/
│   ├── api/                          # Backend NestJS
│   │   ├── drizzle/                  # Migrazioni SQL versionate
│   │   ├── test/                     # Test di integrazione su PostgreSQL reale
│   │   └── src/
│   │       ├── main.ts               # Avvio API
│   │       ├── worker.ts             # Avvio worker (code BullMQ)
│   │       ├── app.module.ts
│   │       ├── config/               # Variabili d'ambiente validate con Zod
│   │       ├── common/               # Guard, decoratori, filtri errori, utilità
│   │       ├── database/             # Schema Drizzle, connessione, migrazioni, seed
│   │       └── modules/
│   │           ├── auth/
│   │           ├── utenti/
│   │           ├── ruoli/            # Ruoli e matrice permessi
│   │           ├── audit/
│   │           ├── clienti/          # Clienti, sedi, contatti
│   │           ├── commesse/
│   │           ├── contratti/        # Contratti di assistenza
│   │           ├── pacchetti-ore/
│   │           ├── interventi/       # Interventi, registrazioni ore, rapportini
│   │           ├── licenze/
│   │           ├── noleggi/          # Apparati e noleggi
│   │           ├── scadenziario/     # Vista unificata delle scadenze
│   │           ├── progetti/         # Progetti, bacheca, task, to-do, ore, template
│   │           ├── allegati/
│   │           ├── notifiche/
│   │           └── dashboard/
│   └── web/                          # Frontend React
│       └── src/
│           ├── app/                  # Router, provider, layout principale
│           ├── components/ui/        # Componenti shadcn/ui
│           ├── components/common/    # DataTable, PageHeader, ConfirmDialog, ...
│           ├── features/             # Una cartella per modulo
│           │   └── clienti/
│           │       ├── api.ts        # Hook TanStack Query
│           │       ├── components/
│           │       └── pages/
│           ├── lib/                  # Client HTTP, gestione auth, formattazioni
│           └── styles/
├── packages/
│   └── shared/                       # Schemi Zod, enum, catalogo permessi
├── deploy/ubuntu/                    # Script di installazione, systemd, Nginx
│   ├── nginx/
│   ├── compose.dev.yml
│   └── compose.prod.yml
├── scripts/                          # backup.sh, restore.sh
└── docs/
```

Il frontend è organizzato **per funzionalità** (`features/clienti`) e non per tipo di file: tutto il codice di un modulo sta in un'unica cartella, e questo con 15 moduli fa una grande differenza.

---

## 5. Modello dati

### 5.1 Convenzioni

- **Chiavi primarie:** UUID v7 (ordinabili nel tempo e non indovinabili negli URL).
- **Campi di tracciamento su ogni tabella di dominio:** `created_at`, `updated_at`, `created_by`, `updated_by`.
- **Soft delete** (`deleted_at`) su anagrafiche, commesse, interventi, progetti. Mai sull'audit log.
- **Importi:** `numeric(12,2)`. **Durate:** minuti interi (mai ore decimali, che creano errori di arrotondamento).
- **Codici leggibili** progressivi per anno: `CM-2026-0001` (commesse), `IN-2026-0001` (interventi), `PR-2026-0001` (progetti), generati in transazione.
- Gli **stati** sono enum PostgreSQL.

### 5.2 Entità e relazioni

**Sicurezza e utenti**

| Tabella | Campi principali | Note |
|---|---|---|
| `utente` | email (unique), nome, cognome, password_hash (argon2id), ruolo_id, attivo, deve_cambiare_password, ultimo_accesso, perm_version | Un ruolo per utente |
| `ruolo` | nome (unique), descrizione, di_sistema | Il ruolo Admin non è modificabile né eliminabile |
| `permesso` | codice (PK, es. `interventi.read`), modulo, descrizione | Catalogo definito nel codice, sincronizzato dal seed |
| `ruolo_permesso` | ruolo_id, permesso_codice, ambito [`tutti`, `propri`] | L'ambito limita i dati visibili (vedi §7) |
| `sessione` | utente_id, refresh_token_hash, scade_il, revocata_il, ip, user_agent | Rotazione del refresh token |
| `audit_log` | utente_id, azione, entita, entita_id, modifiche JSONB (prima/dopo), ip, creato_il | Solo inserimento: UPDATE e DELETE revocati a livello DB |

**Clienti e commesse**

| Tabella | Campi principali | Note |
|---|---|---|
| `cliente` | codice, ragione_sociale, piva, codice_fiscale, codice_sdi, pec, telefono, email, sito, note, commerciale_id | Indice full-text su ragione sociale e P.IVA |
| `sede` | cliente_id, tipo [legale, operativa], nome, indirizzo, cap, citta, provincia, nazione | Un cliente ha N sedi |
| `contatto` | cliente_id, sede_id?, nome, cognome, ruolo_aziendale, email, telefono, cellulare, principale, note | Tabella vera, non JSON: ricercabile ed esportabile per il GDPR |
| `commessa` | codice, cliente_id, titolo, descrizione, tipo [assistenza, progetto, fornitura, mista], stato [aperta, sospesa, chiusa, annullata], valore, data_apertura, data_chiusura, responsabile_id | Contenitore commerciale di contratti, pacchetti e progetti |
| `contratto_assistenza` | commessa_id, nome, tipo [canone, a_chiamata, ore_incluse], data_inizio, data_scadenza, canone, periodicita [mensile, trimestrale, annuale], ore_incluse_periodo_min?, rinnovo_automatico, preavviso_disdetta_gg, arrotondamento_min, minimo_addebito_min, sla_ore?, stato | Il campo arrotondamento vale per gli interventi coperti dal contratto |
| `pacchetto_ore` | commessa_id, contratto_id?, descrizione, minuti_acquistati, data_acquisto, data_scadenza?, prezzo, stato [attivo, esaurito, scaduto] | Il residuo si calcola dai consumi e non viene salvato come campo |

**Interventi e ore**

| Tabella | Campi principali | Note |
|---|---|---|
| `intervento` | codice, cliente_id, commessa_id?, contratto_id?, progetto_id?, sede_id?, contatto_id?, titolo, descrizione, tipo [remoto, on_site, laboratorio], priorita, stato [aperto, pianificato, in_corso, completato, validato, annullato], origine [interno, telefono, email, portale], data_richiesta, data_pianificata, fatturabile | `origine = portale` è già pronto per il futuro portale clienti |
| `intervento_tecnico` | intervento_id, utente_id | Più tecnici per intervento |
| `registrazione_ore` | intervento_id, utente_id, inizio, fine, minuti_lavorati, minuti_addebitati, descrizione_attivita | `minuti_addebitati` = lavorati dopo arrotondamento e minimo |
| `consumo_ore` | registrazione_id, pacchetto_id?, minuti, fuori_pacchetto | Permette di dividere una registrazione tra più pacchetti o su ore extra |

**Scadenziario e noleggi**

| Tabella | Campi principali | Note |
|---|---|---|
| `licenza` | cliente_id, commessa_id?, prodotto, fornitore, quantita, data_attivazione, data_scadenza, costo, prezzo_vendita, rinnovo_automatico, referente_interno_id, stato, note | |
| `apparato` | tipo, marca, modello, seriale (unique), stato [disponibile, noleggiato, in_riparazione, dismesso], note | Lo stesso apparato può essere noleggiato più volte nel tempo |
| `noleggio` | cliente_id, commessa_id?, apparato_id, sede_id?, data_inizio, data_scadenza, canone, periodicita, stato [attivo, scaduto, restituito], data_restituzione, note | Vincolo: un solo noleggio attivo per apparato |
| `v_scadenziario` | vista SQL (UNION) di licenze, contratti, noleggi e pacchetti con scadenza | Una sola query per dashboard e promemoria |
| `promemoria_inviato` | entita, entita_id, soglia_giorni, inviato_il | Vincolo unique: lo stesso promemoria non parte due volte |

**Progetti, task e ore (realizzato)**

| Tabella | Campi principali | Note |
|---|---|---|
| `progetto_template` | nome (unique), categoria, descrizione, durata_stimata_gg, attivo | Lo "stampo" dei progetti ricorrenti. Un template già usato non si elimina: si disattiva |
| `template_colonne` | template_id, nome, ordine, considera_completato | Fasi della bacheca previste dal template (2-8) |
| `template_task` | template_id, colonna_indice, titolo, descrizione, ore_stimate, ordine | La colonna è indicata per **posizione**, così resta valida anche rinominando le fasi |
| `template_todo` | template_task_id, titolo, ordine | Voci della to-do predefinite (nel template non esistono assegnazioni) |
| `progetti` | codice (`PR-2026-0001`), cliente_id, commessa_id?, template_id?, nome, descrizione, stato [pianificato, in_corso, sospeso, concluso, annullato], responsabile_id, data_inizio, data_fine_prevista, data_fine_effettiva, note | Soft delete. Vincolo CHECK sulla coerenza delle date |
| `progetto_colonne` | progetto_id, nome, ordine, considera_completato | **Copia (snapshot)** delle colonne del template: modificare il template non tocca i progetti in corso |
| `task` | progetto_id, colonna_id, titolo, descrizione, priorita [bassa, media, alta, urgente], responsabile_id, data_scadenza, ore_stimate, ordine, completato_il | Un **solo responsabile** per task. `ordine` è la posizione nella colonna |
| `task_todo` | task_id, titolo, completata, completata_il, assegnatario_id, ordine | Ogni voce può essere assegnata a un tecnico **diverso** dal responsabile del task |
| `registrazioni_ore` | task_id, utente_id, data, minuti, descrizione | Durate in minuti interi (CHECK: 1 minuto - 24 ore). Nella Fase 2 la stessa tabella accoglierà anche le ore degli interventi |

Le ore dei progetti **non** scalano dai pacchetti ore dei contratti di assistenza: i progetti sono lavori a corpo, il consumo pacchetti riguarda solo l'assistenza (scelta confermata in analisi).

**Calcolo dell'avanzamento.** La percentuale è il rapporto fra i task che si trovano in una colonna con `considera_completato = true` e il totale dei task del progetto. È un criterio semplice, prevedibile e che non richiede all'utente di aggiornare due cose (la colonna e una percentuale). Le ore restano un indicatore separato: preventivate contro registrate.

**Trasversali**

| Tabella | Campi principali | Note |
|---|---|---|
| `allegato` | entita, entita_id, nome_originale, percorso_storage, mime_type, dimensione, sha256, caricato_da | Collegamento generico: il permesso di scaricare viene verificato sull'entità padre |
| `notifica` | utente_id, tipo, titolo, messaggio, link, letta_il | |
| `impostazione` | chiave, valore JSONB | Soglie promemoria (default 90/60/30/7 giorni), logo e dati aziendali per i PDF |

### 5.3 Regole di business principali

1. **Registrazione ore.** Quando un tecnico salva le ore su un intervento:
   - si calcolano i `minuti_addebitati` con le regole del contratto collegato (arrotondamento e minimo di addebito);
   - in una transazione, bloccando le righe dei pacchetti (`SELECT … FOR UPDATE`), i minuti vengono scalati dal pacchetto attivo più vecchio con residuo disponibile;
   - se il residuo non basta, la parte restante va sul pacchetto successivo, oppure viene marcata `fuori_pacchetto` (ore extra da fatturare);
   - se un pacchetto arriva a zero diventa `esaurito`, e il commerciale e il responsabile di commessa ricevono una notifica.
2. **Contratti con ore incluse.** A ogni rinnovo del periodo il sistema genera automaticamente un nuovo `pacchetto_ore`. In questo modo il consumo usa sempre la stessa logica.
3. **Interventi validati.** Un intervento `validato` non si modifica più: le ore sono consolidate per la fatturazione e per annullarlo serve il permesso `interventi.riapri`.
4. **Promemoria.** Ogni giorno alle 07:00 un job legge `v_scadenziario` e, per ogni soglia raggiunta, crea una notifica in-app e un'email per il referente interno. `promemoria_inviato` evita gli invii doppi.
5. **Fatturazione.** Il CRM non emette fatture. Fornisce un export (CSV/Excel) delle ore fatturabili e dei canoni per periodo, da importare nel gestionale.

---

## 6. Autenticazione

- **Login** con email e password; password salvate con hash **argon2id**.
- **Access token JWT** valido 15 minuti, tenuto solo in memoria nel frontend (mai in localStorage).
- **Refresh token** opaco, ruotato a ogni utilizzo, salvato come hash in `sessioni` e inviato in un cookie `httpOnly`, `Secure`, `SameSite=Strict` con `Path=/api/v1/auth`.
- Se un refresh token già usato viene riutilizzato (segnale di furto), tutte le sessioni dell'utente vengono revocate.
- **Brute force:** rate limit sul login (5 tentativi al minuto per IP ed email) e blocco progressivo dell'account.
- **Password:** minimo 12 caratteri, controllo sulle password comuni e cambio obbligatorio al primo accesso.
- **Fasi successive:** MFA TOTP per gli admin, oppure accesso con Microsoft 365 (Entra ID), che dà anche MFA e disattivazione centralizzata degli account.

**Primo utente Admin.** Viene creato dal seed al primo avvio usando `ADMIN_EMAIL` e `ADMIN_PASSWORD_INIZIALE` presi dal file `.env` (mai nel codice), con cambio password obbligatorio al primo login. Il sistema impedisce di eliminare o declassare l'ultimo Admin rimasto.

---

## 7. Ruoli e permessi configurabili

### 7.1 Funzionamento

- I permessi sono un **catalogo fisso definito nel codice** (`packages/shared/permissions.ts`), nel formato `modulo.azione`.
- I **ruoli** si creano e si modificano dall'Admin tramite una **matrice** (righe = permessi, colonne = nessuno / propri / tutti).
- **Ambito `propri`:** l'utente vede solo i record di cui è assegnatario o responsabile (tecnico sull'intervento, responsabile del progetto, assegnatario del task).
- **Verifica lato backend in due punti:**
  1. un guard `@RichiedePermesso('interventi.read')` blocca la richiesta se il ruolo non ha il permesso (403);
  2. il service applica l'ambito direttamente nella query (`where tecnici some utente_id = me`). Un tecnico non vede i record altrui neanche indovinando l'ID: riceve 404.
- **Dati economici** (valori commesse, prezzi, canoni, costi) protetti da un permesso separato `economici.read`. Senza quel permesso i campi vengono rimossi dalla risposta API, non solo nascosti nell'interfaccia.
- **Cambio di ruolo o permessi:** si incrementa `perm_version` e il guard la confronta con il valore nel database a ogni richiesta: la modifica ha effetto subito, il client riceve 401 `token_obsoleto` e rinnova il token con i nuovi permessi.

### 7.2 Catalogo iniziale (estratto)

`clienti.read/write/delete` · `commesse.read/write/delete` · `contratti.read/write` · `pacchetti.read/write` · `interventi.read/write/delete/valida/riapri` · `ore.write/altri_utenti` · `licenze.read/write` · `noleggi.read/write` · `scadenziario.read` · `progetti.read/write/delete` · `task.write` · `template.manage` · `economici.read` · `export.read` · `utenti.manage` · `ruoli.manage` · `audit.read` · `impostazioni.manage` · `gdpr.manage`

### 7.3 Ruoli predefiniti (modificabili, tranne Admin)

| Area | Admin | Commerciale | Tecnico | Sola lettura |
|---|---|---|---|---|
| Clienti e contatti | tutti · scrittura | tutti · scrittura | tutti · lettura | tutti · lettura |
| Commesse, contratti, pacchetti | tutti · scrittura | tutti · scrittura | tutti · lettura | tutti · lettura |
| Dati economici | sì | sì | no | no |
| Interventi e ore | tutti | tutti · lettura | propri · scrittura | tutti · lettura |
| Validazione interventi | sì | sì | no | no |
| Progetti | tutti | tutti · lettura | propri (coinvolto) | tutti · lettura |
| Task e to-do | tutti | — | propri (solo i task di cui è responsabile) | — |
| Ore sui task | tutti (anche per altri) | — | propri (solo a proprio nome) | — |
| Template di progetto | sì | no | no | no |
| Scadenziario, licenze, noleggi | tutti · scrittura | tutti · scrittura | tutti · lettura | tutti · lettura |
| Utenti, ruoli, audit, impostazioni | sì | no | no | no |

### 7.4 Ambito "propri" nel modulo Progetti

Le regole sono scritte in un unico file (`modules/progetti/accesso-progetti.ts`) e applicate da tutti i service del modulo, così non possono divergere fra un endpoint e l'altro:

| Permesso | Ambito `propri` significa |
|---|---|
| `progetti.read` | progetti in cui l'utente è **coinvolto**: responsabile del progetto, responsabile di almeno un task, oppure assegnatario di almeno una voce di to-do |
| `progetti.write` / `progetti.delete` | solo i progetti di cui è **responsabile** |
| `task.write` | può operare nei progetti in cui è coinvolto, ma solo sui task di cui è responsabile; i task che crea vengono assegnati a lui stesso e non può passarli ad altri. Può spuntare le voci di to-do assegnate a sé anche su task altrui |
| `ore.write` | registra ore solo a proprio nome (il campo `utenteId` della richiesta viene ignorato) ed elimina solo le proprie registrazioni |

L'interfaccia rispecchia le stesse regole — per esempio la maniglia di trascinamento compare solo sui task che l'utente può davvero spostare — ma la verifica che conta resta quella del server: un progetto fuori ambito risponde 404 (non 403) per non rivelarne l'esistenza.

---

## 8. Convenzioni API

- **Prefisso:** `/api/v1`. Documentazione OpenAPI generata automaticamente e accessibile solo agli Admin autenticati.
- **Paginazione:** `?page=1&pageSize=25` (massimo 100). La risposta è `{ data: [...], meta: { page, pageSize, total } }`.
- **Ordinamento:** `?sort=-dataScadenza,ragioneSociale` (con una whitelist dei campi ammessi).
- **Filtri e ricerca:** `?stato=attivo&clienteId=…&q=testo`.
- **Errori:** formato RFC 9457 `{ type, title, status, detail, errors[] }`. 400 validazione · 401 non autenticato · 403 permesso mancante · 404 non trovato o fuori ambito · 409 conflitto · 422 regola di business · 429 rate limit.
- **Verbi:** `GET`, `POST`, `PATCH` (modifica parziale), `DELETE` (soft delete).

### 8.1 Endpoint Fase 1-2

```text
POST   /auth/login                        pubblico (rate limit)
POST   /auth/refresh                      cookie refresh
POST   /auth/logout
GET    /auth/me                           profilo + permessi effettivi
POST   /auth/cambia-password

GET    /utenti · POST /utenti · PATCH /utenti/:id           utenti.manage
GET    /permessi                                            ruoli.manage
GET    /ruoli · POST /ruoli · PATCH /ruoli/:id
PUT    /ruoli/:id/permessi                                  ruoli.manage

GET    /clienti · POST /clienti · GET|PATCH|DELETE /clienti/:id
GET    /clienti/:id/sedi · POST /clienti/:id/sedi · PATCH|DELETE /sedi/:id
GET    /clienti/:id/contatti · POST /clienti/:id/contatti · PATCH|DELETE /contatti/:id
GET    /clienti/:id/stampa.pdf

GET    /commesse · POST /commesse · GET|PATCH|DELETE /commesse/:id
GET    /commesse/:id/stampa.pdf
GET    /commesse/:id/contratti · POST /commesse/:id/contratti · PATCH /contratti/:id
GET    /commesse/:id/pacchetti · POST /commesse/:id/pacchetti · PATCH /pacchetti/:id
GET    /pacchetti/:id/movimenti

GET    /interventi · POST /interventi · GET|PATCH|DELETE /interventi/:id
POST   /interventi/:id/valida · POST /interventi/:id/riapri
GET    /interventi/:id/ore · POST /interventi/:id/ore · PATCH|DELETE /ore/:id
GET    /interventi/:id/rapportino.pdf

GET    /progetti · POST /progetti · GET|PATCH|DELETE /progetti/:id
GET    /progetti/:id/bacheca                                colonne con i task (Kanban)
GET    /progetti/:id/riepilogo                              avanzamento, ritardi, ore
GET    /progetti/:id/ore                                    ?utenteId=&dal=&al=
POST   /progetti/:id/task                                   task.write
GET|PATCH|DELETE /task/:id
POST   /task/:id/sposta                                     { colonnaId, posizione }
POST   /task/:id/todo · PATCH|DELETE /todo/:id
POST   /task/:id/ore · DELETE /ore/:id                      ore.write
GET    /progetto-template · POST /progetto-template         lettura: progetti.read
GET|PATCH|DELETE /progetto-template/:id                     scrittura: template.manage
PUT    /progetto-template/:id/struttura                     colonne + task + to-do (sostituzione completa)

POST   /allegati (multipart) · GET /allegati/:id/download · DELETE /allegati/:id
GET    /audit                                               audit.read
```

I task hanno rotte proprie (`/task/:id`) e non annidate sotto il progetto: si raggiungono sempre dal loro identificativo e il progetto viene ricavato lato server, dove viene applicato il controllo di accesso.

### 8.2 Esempio dettagliato — registrazione ore

`POST /api/v1/interventi/:id/ore` · permesso `ore.write` (ambito `propri`: solo sugli interventi assegnati; per registrare ore di altri serve `ore.altri_utenti`)

Richiesta:
```json
{
  "utenteId": "0191f…",
  "inizio": "2026-09-18T09:00:00+02:00",
  "fine": "2026-09-18T10:10:00+02:00",
  "descrizioneAttivita": "Aggiornamento firmware firewall e verifica regole NAT"
}
```

Risposta `201`:
```json
{
  "data": {
    "id": "0191f…",
    "minutiLavorati": 70,
    "minutiAddebitati": 75,
    "consumi": [
      { "pacchettoId": "0191e…", "minuti": 45, "fuoriPacchetto": false },
      { "pacchettoId": null, "minuti": 30, "fuoriPacchetto": true }
    ],
    "residuoPacchettoMinuti": 0
  }
}
```

Errori: `400` fine precedente all'inizio o durata oltre 24 ore · `403` permesso mancante · `404` intervento inesistente o fuori ambito · `422` intervento già validato o annullato · `409` registrazione sovrapposta per lo stesso tecnico.

### 8.3 Esempio dettagliato — matrice permessi

`PUT /api/v1/ruoli/:id/permessi` · permesso `ruoli.manage`

```json
{ "permessi": [ { "codice": "interventi.read", "ambito": "propri" }, { "codice": "clienti.read", "ambito": "tutti" } ] }
```

Errori: `400` codice permesso inesistente · `422` tentativo di modificare il ruolo Admin di sistema.

---

## 9. Sicurezza

| Rischio | Contromisura |
|---|---|
| SQL injection | Solo Drizzle con query parametrizzate; eventuale SQL raw solo con il template `sql` di Drizzle (mai concatenazione di stringhe) |
| XSS | React fa l'escaping di default; niente `dangerouslySetInnerHTML`; CSP restrittiva da Nginx; HTML dei PDF generato con escaping |
| CSRF | Cookie `SameSite=Strict` con path limitato; stesso dominio; access token nell'header `Authorization` |
| Accessi non autorizzati | Guard sui permessi su **ogni** endpoint (deny by default); ambito applicato nelle query; test automatici per ruolo |
| Upload | Massimo 25 MB; whitelist di estensioni; MIME verificato sul contenuto; file salvati con nome casuale fuori dalla webroot; download solo via API con `Content-Disposition: attachment` |
| Segreti | File `.env` con permessi 600, fuori da git; `.env.example` senza valori; secret JWT generati casualmente |
| Database | Utente applicativo senza privilegi di superuser; PostgreSQL in ascolto solo su localhost |
| Header HTTP | helmet + HSTS + `X-Content-Type-Options` + `Referrer-Policy` |
| Tracciabilità | Audit log scritto dai service nella stessa transazione della modifica (solo i campi cambiati), più login, logout e cambi di permessi; trigger PostgreSQL che impedisce UPDATE/DELETE/TRUNCATE |
| GDPR | Export dei dati di un contatto o cliente; anonimizzazione su richiesta; policy di retention configurabile; backup cifrati |
| Esposizione | **Il CRM non va esposto su Internet**: accesso dalla LAN o tramite la VPN aziendale |

---

## 10. Infrastruttura on-premise (installazione nativa)

Guida operativa completa: `docs/installazione-ubuntu.md`.

- **Server:** VM dedicata (Proxmox, VMware o Hyper-V) con Ubuntu Server 24.04 LTS. Da 2 a 4 vCPU, da 4 a 8 GB di RAM e 60 GB di disco.
- **Componenti:**
  - Nginx (porte 80 e 443, unico servizio esposto);
  - API come servizio systemd `crm-api`, con utente `crm` e in ascolto su `127.0.0.1:3000`;
  - PostgreSQL 16 in ascolto solo su localhost;
  - dalla Fase 3, Redis (`redis-server`) e il servizio `crm-worker`.
- **Isolamento del servizio:**
  - file system in sola lettura tranne `/var/lib/crm`;
  - `NoNewPrivileges`, nessuna capability, `/tmp` privata;
  - codice di proprietà di root: l'API non può modificare se stessa.
- **Percorsi:**

  | Percorso | Contenuto |
  |---|---|
  | `/opt/crm/releases/<versione>` | Una cartella per ogni versione installata, più il collegamento `current` alla versione attiva |
  | `/etc/crm/crm.env` | Segreti generati automaticamente |
  | `/etc/crm/certs` | Certificato HTTPS |
  | `/var/lib/crm/allegati` | Documenti caricati |
  | `/var/backups/crm` | Backup locali |

- **HTTPS:** certificato autofirmato all'installazione, poi sostituito con uno della CA interna o di Let's Encrypt tramite challenge DNS.
- **Firewall (ufw):** SSH sempre aperto, porte 80 e 443 solo dalle reti LAN e VPN indicate (`RETE_LAN`).
- **Aggiornamenti del sistema:** `unattended-upgrades` per le patch di sicurezza di Ubuntu, PostgreSQL e Nginx.
- **Rilascio di una nuova versione (`crm-aggiorna`):**
  1. build in una cartella temporanea;
  2. backup;
  3. migrazioni e seed;
  4. cambio atomico del collegamento `current` e riavvio;
  5. controllo di salute con ritorno automatico alla versione precedente se fallisce.

  Restano le ultime 5 versioni. Prima degli aggiornamenti importanti conviene anche uno snapshot della VM.
- **Backup (regola 3-2-1):**
  - timer systemd ogni notte alle 02:00: `pg_dump` in formato custom verificato con `pg_restore --list`, più l'archivio degli allegati;
  - conservazione locale di 14 giorni e copia `rsync` su NAS o fuori sede (`BACKUP_REMOTO`);
  - ripristino con `crm-ripristina-backup`, da provare ogni mese.
- **Monitoraggio:**
  - log in journald (`journalctl -u crm-api`), in formato JSON;
  - endpoint `/api/v1/salute` controllabile da Uptime Kuma o dall'RMM aziendale;
  - controllo dello spazio disco e della scadenza del certificato.

---

## 11. Office 365 (fase successiva)

| Integrazione | Valore | Note |
|---|---|---|
| Accesso con Microsoft (Entra ID, OIDC) | Alto | MFA e disattivazione degli account gestite centralmente. Il login locale resta disponibile come emergenza per l'Admin |
| Invio email tramite Microsoft Graph | Alto | Da preferire all'SMTP con autenticazione base, che Microsoft sta dismettendo |
| Sincronizzazione calendario (interventi pianificati → Outlook) | Medio | Solo in uscita, per semplicità |

---

## 12. Roadmap

| Fase | Contenuto | Risultato |
|---|---|---|
| 0 — Setup ✅ | Monorepo, formattazione, test di base, layout frontend, script di installazione su Ubuntu | Progetto avviabile e installabile |
| 1 — Fondamenta ✅ | Auth, utenti, ruoli e matrice permessi, audit log, clienti/sedi/contatti, commesse, allegati | Anagrafica completa e sicura · 40 test automatici |
| 2 — Assistenza | Contratti di assistenza, pacchetti ore, interventi, registrazione ore con consumo, rapportino PDF, stampa scheda cliente e commessa | Gestione operativa dell'assistenza |
| 3 — Scadenziario | Licenze, apparati e noleggi, vista unificata, job promemoria, notifiche in-app ed email, dashboard scadenze 30/60/90 | Nessun rinnovo dimenticato |
| 5 — Progetti ✅ | Template con editor, progetti da template (snapshot), bacheca Kanban con trascinamento, to-do per task assegnabili ai singoli tecnici, registrazione ore per task, riepilogo dell'avanzamento | Gestione completa dei progetti · 11 test dedicati |
| 4 — Operatività | Calendario aggregato (task e interventi pianificati), notifiche, ricerca globale | |
| 6 — Rifinitura | Dashboard KPI, report ed export, ricerca globale (Ctrl+K), Office 365, MFA, test E2E, deploy in produzione | CRM in produzione |
| Futuro | Portale clienti per i ticket (diventano interventi con `origine = portale`) | |

Rispetto al PDF originale, l'assistenza (interventi e ore) è anticipata alla Fase 2 perché è il cuore operativo quotidiano. Lo scadenziario viene subito dopo perché ha un impatto economico diretto.

La Fase 5 (Progetti) è stata anticipata su richiesta ed è già in funzione: si veda §5.2 per il modello dati e §8.1 per le API.

---

## 13. Domande aperte

1. **Ore:** qual è l'arrotondamento standard (blocchi da 15 o 30 minuti?) e c'è un minimo di addebito per intervento? Vale anche il tempo di viaggio per gli interventi on-site?
2. **Pacchetti:** i pacchetti ore scadono? Si può andare in negativo, con ore extra fatturate a parte?
3. **Rapportino:** il rapportino d'intervento deve essere firmato dal cliente (per esempio su tablet), o basta il PDF?
4. **Server:** che hypervisor usate? Esiste già un dominio aziendale e una VPN per l'accesso da remoto?
