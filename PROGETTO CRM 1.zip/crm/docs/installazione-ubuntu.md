# Installazione del CRM su Ubuntu Server 24.04

Guida passo passo per installare, aggiornare, fare il backup e ripristinare il CRM su una VM aziendale.
Tutti i comandi si eseguono sul server da un utente con `sudo`.

---

## Come è organizzata l'installazione

| Componente | Dove | Note |
|---|---|---|
| Nginx | pacchetto Ubuntu | Unico servizio raggiungibile dalla rete (porte 80 → 443) |
| API NestJS | servizio systemd `crm-api` | Gira come utente `crm` senza privilegi, ascolta solo su `127.0.0.1:3000` |
| PostgreSQL 16 | pacchetto Ubuntu | Ascolta solo su `localhost`, aggiornamenti di sicurezza automatici |
| Node.js 24 LTS | repository NodeSource | Ubuntu 24.04 include solo Node 18 |
| Configurazione e segreti | `/etc/crm/crm.env` | Generato automaticamente, leggibile solo da root e dall'utente `crm` |
| Certificato HTTPS | `/etc/crm/certs/` | Autofirmato alla prima installazione, da sostituire |
| Programma | `/opt/crm/releases/<versione>` | `/opt/crm/current` punta alla versione attiva; restano le ultime 5 |
| Allegati | `/var/lib/crm/allegati` | Unica cartella in cui l'API può scrivere |
| Backup | `/var/backups/crm` | Ogni notte alle 02:00 e prima di ogni aggiornamento, conservati 14 giorni |

Comandi di gestione installati sul server:

| Comando | Cosa fa |
|---|---|
| `sudo crm-aggiorna <cartella>` | Compila e installa una nuova versione; se l'API non parte torna da solo alla precedente |
| `sudo crm-torna-indietro` | Riattiva la versione installata prima di quella attuale |
| `sudo crm-backup` | Esegue subito un backup di database e allegati |
| `sudo crm-ripristina-backup <file.dump> [allegati.tar.gz]` | Ripristina un backup |

---

## 1. Preparare la VM

- **Sistema:** Ubuntu Server 24.04 LTS, installazione minima con OpenSSH.
- **Risorse consigliate:** 2-4 vCPU, 4-8 GB di RAM, 60 GB di disco (i backup locali occupano spazio).
- **Rete:** IP statico e un nome DNS interno (es. `crm.azienda.local`) che punta a quell'IP.
- **Hypervisor:** fare uno **snapshot della VM** subito dopo l'installazione del sistema operativo.

## 2. Copiare il progetto sul server

Scegliete uno dei due metodi.

**Con git (consigliato):**

```bash
sudo mkdir -p /opt/crm
sudo git clone <indirizzo-del-repository> /opt/crm/sorgente
```

**Con lo zip:** copiatelo sul server (es. con WinSCP) ed estraetelo:

```bash
sudo apt install -y unzip
sudo mkdir -p /opt/crm
sudo unzip crm-fase-1.zip -d /opt/crm
sudo mv /opt/crm/crm /opt/crm/sorgente
```

## 3. Installazione di base (una sola volta)

Sostituite i valori tra `<>`:

```bash
cd /opt/crm/sorgente
sudo DOMINIO=<crm.azienda.local> \
     ADMIN_EMAIL=<vostra.email@azienda.it> \
     RETE_LAN=<192.168.1.0/24>,<10.8.0.0/24> \
     ./deploy/ubuntu/installa.sh
```

- `DOMINIO`: il nome con cui gli utenti apriranno il CRM.
- `ADMIN_EMAIL`: l'email del primo amministratore.
- `RETE_LAN`: le reti autorizzate (LAN e VPN, separate da virgola). Se la omettete, il CRM è raggiungibile da qualsiasi rete arrivi al server.

Lo script, alla fine, **mostra la password iniziale dell'amministratore**: annotatela.
Si può rieseguire senza problemi, perché non sovrascrive segreti né certificati già presenti.

> Il firewall lascia sempre aperto SSH (porta 22). Se usate un'altra porta SSH, aggiungetela prima con `sudo ufw allow <porta>/tcp`.

## 4. Prima installazione del codice

```bash
sudo crm-aggiorna /opt/crm/sorgente
```

La prima esecuzione dura qualche minuto, perché scarica le dipendenze e compila. Al termine aprite `https://<DOMINIO>`
e accedete con l'email e la password mostrate al punto 3: il CRM chiederà subito di impostarne una nuova.

Dopo il primo accesso rimuovete la password iniziale dal file di configurazione:

```bash
sudo nano /etc/crm/crm.env        # cancellare la riga ADMIN_PASSWORD_INIZIALE
```

## 5. Certificato HTTPS definitivo

Il certificato creato dall'installazione è autofirmato, quindi i browser mostrano un avviso. Sostituitelo con uno
emesso dalla CA aziendale oppure con Let's Encrypt tramite challenge DNS:

```bash
sudo cp crm.crt /etc/crm/certs/crm.crt        # certificato (con eventuale catena intermedia)
sudo cp crm.key /etc/crm/certs/crm.key        # chiave privata
sudo chmod 600 /etc/crm/certs/crm.key
sudo nginx -t && sudo systemctl reload nginx
```

## 6. Backup fuori dal server (obbligatorio)

I backup in `/var/backups/crm` **non proteggono da un guasto del server**. Configurate la copia su NAS:

```bash
# 1. Chiave SSH dedicata per root, da autorizzare sul NAS
sudo ssh-keygen -t ed25519 -f /root/.ssh/crm-backup -N ""
sudo cat /root/.ssh/crm-backup.pub          # da aggiungere agli authorized_keys dell'utente di backup sul NAS

# 2. Destinazione della copia
echo 'BACKUP_REMOTO="backup@nas.azienda.local:/volume1/backup/crm/"' | sudo tee /etc/crm/backup.env
echo 'RSYNC_RSH="ssh -i /root/.ssh/crm-backup -o StrictHostKeyChecking=accept-new"' | sudo tee -a /etc/crm/backup.env
sudo chmod 600 /etc/crm/backup.env

# 3. Prova immediata
sudo systemctl start crm-backup && sudo journalctl -u crm-backup -n 30
```

Verificate anche lo stato del backup notturno:

```bash
systemctl list-timers crm-backup.timer      # prossima esecuzione
sudo journalctl -u crm-backup -n 50         # esito dell'ultima
```

**Una volta al mese provate un ripristino**, idealmente su una VM di prova clonata (vedi punto 9).

---

## 7. Aggiornare il CRM

```bash
# Prima dell'aggiornamento: snapshot della VM dall'hypervisor (consigliato)
cd /opt/crm/sorgente
sudo git pull                                # oppure estrarre il nuovo zip nella stessa cartella
sudo crm-aggiorna /opt/crm/sorgente
```

`crm-aggiorna` esegue un backup, applica le migrazioni, attiva la nuova versione e verifica che l'API risponda.
Se entro 60 secondi l'API non risponde, **torna automaticamente alla versione precedente**, e segna quella
difettosa come `-fallita`.

## 8. Tornare a una versione precedente

```bash
sudo crm-torna-indietro                      # la versione installata prima di quella attuale
sudo crm-torna-indietro 20260917-184736-a1b2c3d   # una versione specifica (nome in /opt/crm/releases)
```

> Tornare indietro cambia il programma ma **non annulla le modifiche al database**. Se la versione più recente
> ha modificato le tabelle, ripristinate anche il backup `crm-db-...-prima-di-<versione>.dump` (punto 9).

## 9. Ripristinare un backup

```bash
ls -lt /var/backups/crm | head               # elenco dei backup, dal più recente
sudo crm-ripristina-backup /var/backups/crm/crm-db-<data>-notturno.dump /var/backups/crm/crm-allegati-<data>-notturno.tar.gz
```

Lo script chiede di scrivere `RIPRISTINA`. Poi salva lo stato attuale in un backup `prima-del-ripristino`, ferma
l'API, sostituisce il database e gli allegati (la cartella precedente viene rinominata, non cancellata) e riavvia.

---

## Controlli e risoluzione problemi

| Cosa verificare | Comando |
|---|---|
| Stato dell'API | `sudo systemctl status crm-api` |
| Log dell'API in tempo reale | `sudo journalctl -u crm-api -f` |
| Errori dell'API nell'ultima ora (livello 50 = errore) | `sudo journalctl -u crm-api --since "1 hour ago" \| grep '"level":50'` |
| Salute di API e database | `curl http://127.0.0.1:3000/api/v1/salute` |
| Versione attiva | `cat /opt/crm/current/VERSIONE` |
| Log di Nginx | `sudo tail -f /var/log/nginx/crm.error.log` |
| Configurazione di Nginx | `sudo nginx -t` |
| Stato di PostgreSQL | `sudo systemctl status postgresql` |
| Regole del firewall | `sudo ufw status` |
| Spazio su disco | `df -h /var /opt` |

**Problemi frequenti**

- **Il browser mostra "502 Bad Gateway":** l'API è ferma. Guardate `journalctl -u crm-api -n 100`. Spesso si tratta di un valore sbagliato in `/etc/crm/crm.env` (l'API all'avvio elenca le variabili non valide).
- **Il login funziona ma dopo il ricaricamento della pagina chiede di nuovo l'accesso:** `APP_ORIGIN` in `/etc/crm/crm.env` deve corrispondere esattamente all'indirizzo aperto nel browser (es. `https://crm.azienda.local`). Dopo la modifica: `sudo systemctl restart crm-api`.
- **Upload rifiutato con "413":** il file supera i 25 MB.
- **Account bloccato:** un amministratore può sbloccarlo con "Reset password" nella pagina Utenti.
